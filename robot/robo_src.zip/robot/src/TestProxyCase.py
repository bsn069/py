# -*- coding:utf8 -*-
import gevent
from locust import Locust, TaskSet, task
# from locust.events import spawn
from locust.asyncevent import asyncresult_manager
from proxy.gameserver import GameServer
from proxy.xgserver import XGServer
from ks_passport.testcase import *
from ks_passport.http_request import *
from ks_passport.jinshan_channel import JinShanChannel
from ks_passport.common import sign

class ProxyTasks(TaskSet):
    TIMEOUT = 30
#     PROXY_SERVER = ("10.20.110.37", 20002)
    PROXY_SERVER = ("10.20.69.70", 20002)
#     PROXY_SERVER = ("120.92.92.193", 20002)
    PROXY_HTTP = "https://10.20.110.37:8089"

    def on_start(self):
        gevent.sleep(1)
        self.conn = None
        need_connected = False
        need_registered = False
        for task in self.parent.task_set.tasks:
            if not need_connected and task.func_name in ["rerify_session_mi", "rerify_session_xg", "rerify_session_jinshan"]:
                need_connected = True
            elif not need_registered and task.func_name in ["msg_push", "report_online_num", "report_login"]:
                need_connected = True
                need_registered = True
                
        if need_connected:
            self.gameserver = GameServer(self.PROXY_SERVER)
            self.gameserver.Connect()
            if not asyncresult_manager.wait(self.gameserver, 'connected', self.TIMEOUT):
                raise "connect error" 

            if need_registered:
                self.gameserver.RegisterReq()
                if not asyncresult_manager.wait(self.gameserver, 'RegisterReq', self.TIMEOUT):
                    raise "register error" 
    
    def on_end(self):
        if self.gameserver:
            self.gameserver.connecter.close()
            self.gameserver = None
            
    def get_jinshan_token(self):
        index = get_account(True)
        account = '%07d' % index
        param = {
                 'appId':"10074",
                 'deviceId':account,
                 'passportId':'%s@test.com' % account,
                 'password':base64.b64encode("king5688".encode("hex")),
                 'version':'4.0.4',
                 }
        param['sign'] = sign(param, action="login", appkey="3264718148282430")
        result, code, data = request("http://120.92.136.224:11000/v3/"+"login", "login", fields=param)
        if result and code == 1 and 'token' in data:
            token = data['token']
            uid = data['uid']
            name = data['passportId']
        else:
            return None, None, None, None
        return token, uid, name, account  
      
    @task(0)
    def paynotify(self):
        server = XGServer(self.PROXY_HTTP)
        g = gevent.spawn(asyncresult_manager.wait, server, "All", self.TIMEOUT)
        server.paynotify()
        g.join()
    
    @task(0) 
    def rerify_session_mi(self):
        self.gameserver.Send_RerifySession("mi")
        asyncresult_manager.wait(self.gameserver, "RerifySession", self.TIMEOUT)
#         d = gevent.spawn(asyncresult_manager.await, self.gameserver, 'RerifySession', self.TIMEOUT)
#         
#         d.join()
        
    @task(0)    
    def rerify_session_xg(self):
        self.gameserver.Send_RerifySession("xg")
        asyncresult_manager.wait(self.gameserver, 'RerifySession', self.TIMEOUT)
        
    @task(1)    
    def rerify_session_jinshan(self):
        token, uid, name, deviceId= self.get_jinshan_token()  
        if token == None or uid == None:
            return
        while True:     
            self.gameserver.Send_RerifySession("jinshan",str(token), str(uid), str(name),str(deviceId))
            asyncresult_manager.wait(self.gameserver, 'RerifySession', self.TIMEOUT)
        
    @task(0)
    def msg_push(self):
        d = gevent.spawn(asyncresult_manager.await, self.gameserver, 'MsgPushReq', self.TIMEOUT)
        self.gameserver.MsgPushReq()
        d.join()
        
    @task(0)
    def report_online_num(self):
        d = gevent.spawn(asyncresult_manager.await, self.gameserver, 'ReportOnlineNumReq', self.TIMEOUT)
        self.gameserver.ReportOnlineNumReq()
        d.join()
        
    @task(0)
    def report_login(self):
        d = gevent.spawn(asyncresult_manager.await, self.gameserver, 'ReportLoginReq', self.TIMEOUT)
        self.gameserver.ReportLoginReq()
        d.join()
        
class WebsiteUser(Locust):
    task_set = ProxyTasks
    stop_timeout = 60 * 10
    min_wait = 0
    max_wait = 0

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
 
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)
 
    sys.argv.extend(["-f", "TestProxyCase.py", "--no-web", "-H", "dddss", "-r", "1", "-c", "1"])
    locust.main.main()