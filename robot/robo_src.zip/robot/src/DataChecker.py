# coding:utf-8
import os
import re
import pprint
import logging
from copy import deepcopy

class DataChecker(object):
    def __init__(self, customLogPath, commonLogPath, outputLogPath, task):
        for path in [customLogPath, commonLogPath]:
            assert os.path.exists(path), "Path %s is  not exist" % path
        self.customLogPath = customLogPath
        self.commonLogPath = commonLogPath
        self.outputLogPath = outputLogPath
        self.task = task
        self.contrastDict = {
                                    "Bag" : self.bagDictContrast,
                                    "Coin" : self.coinDictContrast,
                                    "TradeItem" : self.tradeItemDictContrast,
                                    "TradeDetail" : self.tradeDetailDictContrast,
                                    "RoleDetail" : self.roleDetailDictContrast,
                              }
        self.haveCleanLog = False
        
    def getLogFileList(self, path):
        return [os.path.join(path, file) for file in os.listdir(path) if os.path.splitext(file)[1] == ".log"]
    
    def dictConverter(self, data, origDict):
        msgDict = {}
        familyId, username, dict = data.split("|")
        if self.task in ["Bag", "Coin", "RoleDetail"]:
            msgDict[familyId] = {
                                    "username" : username,
                                    "log" : eval(dict)
                                 }
        elif self.task == "TradeItem":
            evalDict = eval(dict)
            msgDict = origDict
            for key in evalDict:
                if key in msgDict.keys():
                    msgDict[key] += evalDict[key]
                else:
                    msgDict[key] = evalDict[key]
        elif self.task == "TradeDetail":
            evalDict = eval(dict)
            msgDict = origDict
            if familyId in msgDict:
                for itemType in evalDict:
                    if itemType in msgDict[familyId]["log"]:
                        for item in evalDict[itemType]:
                            if item in msgDict[familyId]["log"][itemType]:
                                msgDict[familyId]["log"][itemType][item] += evalDict[itemType][item]
                            else:
                                msgDict[familyId]["log"][itemType][item] = evalDict[itemType][item]
                    else:
                        msgDict[familyId]["log"][itemType] = evalDict[itemType]
            else:
                msgDict[familyId] = {
                                    "username" : username,
                                    "log" : evalDict
                                 }
        else:
            logging.debug("[ERROR]Task %s can not find!" % self.task)
        return msgDict
    
    def bagDictContrast(self, familyId, username, custBagDict, comBagDict):
        for gdpl in custBagDict:
            if gdpl in comBagDict:
                for bind in custBagDict[gdpl]:
                    if bind in comBagDict[gdpl]:
                        custBindDict = custBagDict[gdpl][bind] 
                        comBindDict = comBagDict[gdpl][bind]
                        if len(custBindDict) == len(comBindDict):
                            if len(custBindDict) == 1 and (custBindDict.values()[0]["count"] != comBindDict.values()[0]["count"]):
                                self.writeLog("[WARNNING][%s|%s]Item %s|Bind %s|count != the count in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, gdpl, bind, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                                return
                        else:
                            self.writeLog("[WARNNING][%s|%s]Item %s|Bind %s|length != the bind in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, gdpl, bind, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                            return
                    else:
                        self.writeLog("[WARNNING][%s|%s]Item %s|Bind %s can not find in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, gdpl, bind, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                        return
            else:
                self.writeLog("[WARNNING][%s|%s]Item %s can not find in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, gdpl, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                return
    
    def coinDictContrast(self, familyId, username, custBagDict, comBagDict):
        '''
        VALUE_COIN_NULL = 0
        VALUE_COIN_SILVER = 1
        VALUE_COIN_GOLD = 2
        VALUE_COIN_BIND_GOLD = 3
        VALUE_COIN_XIAYI = 4
        VALUE_COIN_REPUTATION = 5
        VALUE_COIN_BATTLE_HONOR = 6
        VALUE_COIN_LUN_JIAN_PRESTIGE = 7
        VALUE_COIN_MASTER_COIN = 8'
        '''
        for coin in custBagDict:
            if coin in comBagDict:
                if custBagDict[coin] != comBagDict[coin]:
                    self.writeLog("[WARNNING][%s|%s]Coin %s|count != the count in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, coin, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                    return
            else:
                self.writeLog("[WARNNING][%s|%s]Coin %s can not find in comBagDict\ncustBagDict =\n%s\ncomBagDict =\n%s" % (familyId, username, coin, pprint.pformat(custBagDict), pprint.pformat(comBagDict)))
                return
    
    def tradeItemDictContrast(self, custBagDict, comBagDict):
        for gdpl in custBagDict:
            if gdpl in comBagDict:
                if custBagDict[gdpl] != comBagDict[gdpl]:
                    self.writeLog("[WARNNING]Item %s|custBagDict item count %s != %s in comBagDict" % (gdpl, custBagDict[gdpl], comBagDict[gdpl]))
            else:
                self.writeLog("[WARNNING]Item %s can not find in comBagDict" % gdpl)
    
    def tradeDetailDictContrast(self, familyId, username, custBagDict, comBagDict, errorCountDict):
        differDict = {}
        for itemType in custBagDict:
            differDict[itemType] = {}
            unionKeyList = list(set(custBagDict[itemType].keys()).union(set(comBagDict[itemType].keys())))
            for unionKey in unionKeyList:
                if unionKey in custBagDict[itemType]:
                    if unionKey in comBagDict[itemType]:
                        if custBagDict[itemType][unionKey] != comBagDict[itemType][unionKey]:
                            differDict[itemType][unionKey] = comBagDict[itemType][unionKey] - custBagDict[itemType][unionKey]
                    else:
                        differDict[itemType][unionKey] = -custBagDict[itemType][unionKey]
                else:
                    differDict[itemType][unionKey] = comBagDict[itemType][unionKey]
            if not differDict[itemType]:
                del differDict[itemType]
                
        try:
            from ServerLog import ServerLogDict
            if familyId in ServerLogDict["last"] and familyId in ServerLogDict["origin"]:
                lastServerLogDict = ServerLogDict["last"][familyId]
                originServerLogDict = ServerLogDict["origin"][familyId]
                for logDict in [lastServerLogDict, originServerLogDict]:
                    for itemType in logDict.keys():
                        if not logDict[itemType]:
                            del logDict[itemType]
                if differDict == lastServerLogDict:
                    print "[%s|%s]differDict = \n%s\n== lastServerLogDict =\n%s" % (familyId, username, pprint.pformat(differDict), pprint.pformat(lastServerLogDict))
                elif differDict == originServerLogDict:
                    print "[%s|%s]differDict = \n%s\n== originServerLogDict =\n%s" % (familyId, username, pprint.pformat(differDict), pprint.pformat(originServerLogDict))
                else:
                    errorTypeList = []
                    for itemType in ["coin", "item"]:
                        if itemType in differDict and itemType in originServerLogDict:
                            if differDict[itemType] != originServerLogDict[itemType]:
                                errorTypeList.append(itemType)
                        else:
                            errorTypeList.append(itemType)
                    assert errorTypeList#进到else逻辑里一定有一种类型是对不上的，没有就是计算有问题
                    if "coin" in errorTypeList and "item" not in errorTypeList:#仅仅钱对不上
                        errorCountDict["coin"] += 1
                    elif "item" in errorTypeList and "coin" not in errorTypeList:#仅仅物品对不上
                        errorCountDict["item"] += 1
                    else:#钱和物品都对不上
                        errorCountDict["all"] += 1
                    self.writeLog("[WARNNING][%s|%s]differDict = \n%s\n!= lastServerLogDict =\n%s\nor originServerLogDict =\n%s" % (familyId, username, pprint.pformat(differDict), pprint.pformat(lastServerLogDict), pprint.pformat(originServerLogDict)))
        except Exception, e:
            self.writeLog("[ERROR] %s" % e)
    
    def roleDetailDictContrast(self, familyId, username, custBagDict, comBagDict):
        def BagContrast(custBag, comBag):
            result = True
            for gdpl in custBag:
                if gdpl in comBag:
                    for bind in custBag[gdpl]:
                        if bind in comBag[gdpl]:
                            custBagItemCount = 0
                            comBagItemCount = 0
                            for itemId in custBag[gdpl][bind]:
                                custBagItemCount += custBag[gdpl][bind][itemId]["count"]
                            for itemId in comBag[gdpl][bind]:
                                comBagItemCount += comBag[gdpl][bind][itemId]["count"]
                            if custBagItemCount != comBagItemCount:
                                self.writeLog("[WARNNING][%s|%s]DataType %s|BagType %s|gdpl %s|bind %s|custBagDict count %s != %s in comBagDict" % (familyId, username, dataType, bagType, gdpl, bind, custBagItemCount, comBagItemCount))
                                result = False
                                return result
                        else:
                            self.writeLog("[WARNNING][%s|%s]DataType %s|BagType %s|gdpl %s|custBagDict =\n%s\nbind %s not in comBagDict =\n%s" % (familyId, username, dataType, bagType, gdpl, pprint.pformat(custBag[gdpl]), bind, pprint.pformat(comBag[gdpl])))
                            result = False
                            return result
                else:
                    self.writeLog("[WARNNING][%s|%s]DataType %s|BagType %s|custBagDict =\n%s\ngdpl %s not in comBagDict =\n%s" % (familyId, username, dataType, bagType, pprint.pformat(custBag), gdpl, pprint.pformat(comBag)))
                    result = False
                    return result
            return result
        for dataType in custBagDict:
            if dataType in ["member1Bag", "member2Bag", "member3Bag"]:#背包因为重新登录itemId会变化的原因所以要单独处理
                for bagType in custBagDict[dataType]:
                    if not BagContrast(custBagDict[dataType][bagType], comBagDict[dataType][bagType]):
                        return
            elif dataType in ["consumeBag", "bookBag", "taskItemBag", "recycleBag"]:
                if not BagContrast(custBagDict[dataType], comBagDict[dataType]):
                    return
            else:
                if custBagDict[dataType] != comBagDict[dataType]:
                    self.writeLog("[WARNNING][%s|%s]DataType %s|custBagDict data %s != %s in comBagDict" % (familyId, username, dataType, pprint.pformat(custBagDict[dataType]), pprint.pformat(comBagDict[dataType])))
                    return
    
    def getLogMsg(self, path):
        fileList = self.getLogFileList(path)
        if fileList:
            try:
                msgDict = {}
                for file in fileList:
                    for line in open(file, "r"):
                        pos = line.find("[DataChecker]")
                        if pos != -1:
                            lineStr = line[pos+len("[DataChecker]"):]
                            match = re.match(r'\[(\w*)\](.*)', lineStr)
                            if match:
                                if match.group(1) == self.task:
                                    msgDict.update(self.dictConverter(match.group(2), msgDict))
                            else:
                                logging.debug("[ERROR]Log %s do not match!" % lineStr)
                return msgDict
            except Exception, e:
                logging.debug("[ERROR] %s" % e)
        else:
            logging.debug("[ERROR]Can not fing log file in path %s" % path)
    
    def writeLog(self, line):
        if not self.haveCleanLog:
            state = "w+"
            self.haveCleanLog = True
        else:
            state = "a+"
        f = open(self.outputLogPath, state)
        f.write(line+"\n")
        f.close()
        
    def main(self):
        customLogDict = self.getLogMsg(self.customLogPath)
        commonLogDict = self.getLogMsg(self.commonLogPath)
#         logging.debug("customLogDict =\n%s\ncommonLogDict =\n%s" % (pprint.pformat(customLogDict), pprint.pformat(commonLogDict)))
        if customLogDict and commonLogDict:
            if self.task in ["Bag", "Coin", "RoleDetail"]:
                for key in customLogDict:
                    username = customLogDict[key]["username"]
                    if key in commonLogDict.keys():
                        custBagDict = customLogDict[key]["log"]
                        comBagDict = commonLogDict[key]["log"]
                        self.contrastDict[self.task](key, username, custBagDict, comBagDict)
                    else:
                        self.writeLog("[WARNNING][%s|%s]FamilyId can not find in commonLogDict" % (key, username))
            elif self.task == "TradeItem":
                self.contrastDict[self.task](customLogDict, commonLogDict)
            elif self.task == "TradeDetail":
                errorCountDict = {
                                  "coin" : 0,
                                  "item" : 0,
                                  "all" : 0,
                                }
                for key in customLogDict:
                    username = customLogDict[key]["username"]
                    if key in commonLogDict.keys():
                        custBagDict = customLogDict[key]["log"]
                        comBagDict = commonLogDict[key]["log"]
                        self.contrastDict[self.task](key, username, custBagDict, comBagDict, errorCountDict)
                    else:
                        self.writeLog("[WARNNING][%s|%s]FamilyId can not find in commonLogDict" % (key, username))
                self.writeLog("[TOTAL]CoinErrorCount = %d, ItemErrorCount = %d, AllErrorCount = %d" % (errorCountDict["coin"], errorCountDict["item"], errorCountDict["all"]))
            else:
                logging.debug("[ERROR]Task %s can not find!" % self.task)
        else:
            if not customLogDict:
                line = '[ERROR]CustomLogDict is empty'
            else:
                line = '[ERROR]CommonLogDict is empty'
            self.writeLog(line)
        self.writeLog("[FINISH]")

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    
    projectPath = os.getcwd()
    customLogPath = os.path.join(projectPath, "logc")
    commonLogPath = os.path.join(projectPath, "log")
    outputLogPath = os.path.join(projectPath, "DataChecker.log")
    '''
    --- Task ---
    Bag 个人背包物品检查
    Coin 个人金币元宝检查
    TradeItem 全部拍卖行相关物品检查
    TradeDetail 个人拍卖行相关物品与金币检查
    RoleDetail 个人角色详细数据检查
    '''
    c = DataChecker(customLogPath, commonLogPath, outputLogPath, task="RoleDetail")
    c.main()