# coding:utf8
'''
Created on 2015-5-11

@author: Administrator
'''
import uuid
import gevent
import inspect
import datetime
from gevent import Greenlet
from ModuleState.StateDefine import *
from ModuleState.FamilyState import *
from ModuleState.NotifyState import NotifyState

from NetPackHandle.LoginServerNetPackHandle import *
from NetPackHandle.GameServerNetPackHandle import *
from NetPackHandle.MediaServerNetPackHandle import *
from NetPackHandle.PortalServerNetPackHandle import *
from OtherCharacter.OtherCharacterManager import *

from TestCase.Files import Character
from TestCase.Files import Maintask
from TestCase.Files import Kin
from TestCase.Files import Friend
from TestCase.Files import RandomBoss
from TestCase.Files import ServerTime
from TestCase.Files.FamilyBase import FamilyBase
from TestCase.Files import Team
from TestCase.Files import GraveDigger
from TestCase.Files import Killer
from TestCase.Files import HomeLand
from TestCase.Files import DoubleAction
from TestCase.Files import Guardian
from TestCase.Files import BigFight
from TestCase.Files import CrossBattle
from TestCase.Files import CrossFriend
from Config.GameConfig import GameConfig
from TestCase.Files import PlayerFight
from TestCase.Files import Master
from TestCase.Files import Escort
from TestCase.Files import Dungeon
from TestCase.Files import Bag
from TestCase.Files import NewYear
from TestCase.Files import DialogInfo
from TestCase.Files import OfflineChat
from TestCase.Files import ChatRoom
from TestCase.Files import Valentine
from TestCase.Files import Camp
from TestCase.Files import Skill
from TestCase.Files import XiaoMiJing
from TestCase.Files import DaMiJing
from TestCase.Files import LineInfo
from TestCase.Files import BossChallenge
from TestCase.Files import Battle
from TestCase.Files import Equip
from TestCase.Files import Appearance
from TestCase.Files import LimitedAcution
from TestCase.Files import RedPacket
from TestCase.Files import CrusadeAgainst
from TestCase.Files import Grave
from TestCase.Files import Instance
from TestCase.Files import EatChicken
from TestCase.Files import WuYi
class Family(FamilyBase):

    def __init__(self, ip, port, userName, account=None, serverGroupId=1, caseId=-1, authToken=None):
        FamilyBase.__init__(self)
        self.loginWaitTime = 0
        self.authAddress = (ip, port)
        self.gsAddress = None
        self.msAddress = None
        self.psAddress = None
        self.serverGroupId = serverGroupId
        self.gameConfig = GameConfig()
        self.caseId = caseId
        self.authToken = authToken
        self.KuaFuGroupId = serverGroupId
        #-----------login server Info---------------
        
        self.imei = str(random.randint(100000000000000, 999999999999999))
        self.uuid = str(uuid.uuid4())

        if account == None:
            self.userName = uuid.uuid4().hex[:15]
        else:
            self.userName = account
        logging.debug('Username_Id: %s' % self.userName)
        self.token = None
        self.userId = None

        # self.gsAddress = None
        self.channelId = None
        
        self.groupId = None
        self.centerID = None
        self.encryptKey = None
        
        #-----------gs server Info---------------

        self.mainName = u"男%s" % userName
        self.coupleName = u"女%s" % userName
        self.familyId = None
        self.isNewRole = False
        MAINSEX = {
                                MALE:   1,#男性
                                FEMALE: 1 #女性
                  }
        self.main_sex = Rand.weighted_choice(MAINSEX)
#         self.main_sex = MALE #MALE男 FEMALE女 
        #----------------------------------------
        self.state = STATE_INVALID
        self.lastState = STATE_INVALID
        self.setStateStartTime = 0
        
        # self.Register("SetState", self.SetState)
        # self.Register("SetInfo", self.SetInfo)
        # self.Register("GetInfo", self.GetInfo)
        
        self.loginServerNetPackHandle = None
        self.gameServerNetPackHandle = None
        self.mediaServerNetPackHandle = None
        self.portalServerNetPackHandle = None
        self.otherCharacterManager = OtherCharacterManager()
         
        self.characterMan = Character.Character()
        self.characterWoman = Character.Character()
        self.characterChild = Character.Character()
        self.characterCur = self.characterMan
        self.maintaskMan = Maintask.Maintask()
        self.kinMan = Kin.Kin()
        self.friendMan = Friend.Friend(self)
        self.randomBoss = RandomBoss.RandomBoss()
        self.serverTime = ServerTime.ServerTime()
        self.graveDigger = GraveDigger.GraveDigger()
        self.killer = Killer.Killer()
        self.homeland = HomeLand.HomeLand()
        self.doubleAction = DoubleAction.DoubleAction()
        self.playerFight = PlayerFight.PlayerFight()
        self.guardian = Guardian.Guardian()
        self.master = Master.Master()
        self.escort = Escort.Escort()
        self.dungeon = Dungeon.Dungeon()
        self.bigfight = BigFight.BigFight()
        self.bag = Bag.Bag(self)
        self.dialog = DialogInfo.DialogInfo()
        self.offlinechat = OfflineChat.OfflineChat()
        self.chatroom = ChatRoom.ChatRoom()
        self.newyear = NewYear.NewYear()
        self.valentine = Valentine.Valentine()
        self.camp = Camp.Camp()
        self.skill = Skill.Skill(self)
        self.xiaomijing = XiaoMiJing.XiaoMiJing()
        self.damijing = DaMiJing.DaMiJing()
        self.lineInfo = LineInfo.LineInfo()
        self.boss_challenge = BossChallenge.BossChallenge()
        self.battle = Battle.Battle()
        self.equip = Equip.Equip()
        self.crossbattle = CrossBattle.CrossBattle()
        self.crossfriend = CrossFriend.CrossFriend()
        self.limitedacution = LimitedAcution.LimitedAcution()
        self.appearance = Appearance.Appearance(self)
        self.redpacket = RedPacket.RedPacket()
        self.crusadeaginst = CrusadeAgainst.CrusadeAgainst()
        self.grave = Grave.Grave()
        self.instance = Instance.Instance()
        self.eatchicken = EatChicken.EatChicken()
        self.wuyi = WuYi.WuYi()
        self.isAddGold = True
        self.isAddSliver = True
        self.notifyState = NotifyState()
        self.behavior = Behavior.BEGIN
        self.valueCoin = {}
        self.energy = 0 #精力
        self.shops = {}
        self.items = {}
        self.team_manager = Team.TeamManager(self)
        self.roleLoop = False
        self.isLandingMember = False
        
        # 论剑相关
        self.lunjianList = []

        # 多角色
        self.familyListRetire = {}
        self.familyListUnretire = {}

        # 天香玉露
        self.flower = (0, 0)
        # 组队副本
        self.boss = (0, 0)
        self.isKillBossOver = None

        #LoctionServer运用
        self.Play ={}
        #是否跨服
        self.KUAFU = False
        # 开服日期
        self.openDay = None
    def Getsexmember(self):
        #成男，童男
        man_sexmember   = {1:1,4:1}
        #成女，童女
        woman_sexmember = {2:1,3:1}
        if self.main_sex == MALE: #MALE男 FEMALE女 
            return Rand.weighted_choice(man_sexmember)
        else:
            return Rand.weighted_choice(woman_sexmember)
    def GetCurCharacter(self):
        return self.characterCur

    def Init(self):
        self.SetState(STATE_LS_LOGINING)
    
    def ConnectLoginServer(self):
        self.loginServerNetPackHandle = LoginServerNetPackHandle(self.authAddress, self)
        self.loginServerNetPackHandle.ConnectLoginServer()
        
    def ConnectGameServer(self):
        self.gameServerNetPackHandle = GameServerNetPackHandle(self.gsAddress, self)
#         self.gameServerNetPackHandle = GameServerNetPackHandle(("10.20.110.39", 9261), self)
        self.gameServerNetPackHandle.ConnectGameServer()

    def ConnectMediaServer(self):
        self.mediaServerNetPackHandle = MediaServerNetPackHandle(self.msAddress, self)
        self.mediaServerNetPackHandle.ConnectMediaServer()

    def ConnectPortalServer(self, address):
        self.portalServerNetPackHandle = PortalServerNetPackHandle(self)
        self.portalServerNetPackHandle.ConnectPortalServer(address)
          
    def UnLogin(self):
        if self.loginServerNetPackHandle:
            self.loginServerNetPackHandle.LSUninit()
        if self.gameServerNetPackHandle:
            self.gameServerNetPackHandle.GSUninit()
        if self.mediaServerNetPackHandle:
            self.mediaServerNetPackHandle.MSUninit()
        if self.portalServerNetPackHandle:
            self.portalServerNetPackHandle.Uninit()

    def RandomMove(self):
        self.gameServerNetPackHandle.RandomMove()

    def EnterArena(self):
        self.gameServerNetPackHandle.EnterArena()

    def LevelUp(self):
        self.gameServerNetPackHandle.LevelUp_Character()

    def PlaySkill(self, skillId, target):
        target = self.otherCharacterManager.getSceneCharacter()
        skill.Skill_Start(skillId, self.gameServerNetPackHandle.GetConnect(), self.characterCur, target)

    #Base Correlation function
    def SetInfo(self, **kwds):
        for name, value in kwds.iteritems():
            setattr(self, name, value)

    def GetInfo(self, *args):
        result = []
        for name in args:
            result.append(getattr(self, name))
        return result

    def SetState(self, state):
        logging.debug("[FamilyId : %s]set state from = %d, to = %d" % (self.familyId, self.state, state))
#         #显示调用堆栈
#         stack = inspect.stack()
#         the_class = stack[1][0].f_locals["self"].__class__
#         the_method = stack[1][0].f_code.co_name
#         logging.debug("SetState was called by {}.{}()".format(str(the_class), the_method))
        if self.state == STATE_GS_END:#当状态被设置为STATE_GS_END后, 其他流程无法将其改变
            return
        self.lastState = self.state
        self.state = state
        self.setStateStartTime = time.time()
        
        if state == STATE_LS_LOGINING:
            self.ConnectLoginServer()
        elif state == STATE_GS_LOGINING:
            # self.ConnectGameServer() 废弃
            pass

    def GetState(self):
        return self.state
    
    def ResetState(self):
        while self.gameServerNetPackHandle.gsConnect and self.gameServerNetPackHandle.gsConnect.connected:
            gevent.sleep(2)
            if self.setStateStartTime and time.time() - self.setStateStartTime >= 60:
                logging.debug("---------------------------------【状态重置】---------------------------------")
                self.state = self.lastState
                self.setStateStartTime = 0
    
    def CheckState(self):
        while self.gameServerNetPackHandle.gsConnect and self.gameServerNetPackHandle.gsConnect.connected:
            gevent.sleep(2)
            if self.setStateStartTime and time.time() - self.setStateStartTime >= 160:
                logging.debug("---------------------------------【状态检查】---------------------------------")
                logMsg = "FamilyId:%s, Username:%s, state:%s, laststate:%s, lastSkillId:%s" % (self.familyId, self.userName, self.state, self.lastState, self.skill.lastSkillId)
                self.gameServerNetPackHandle.MarkTestCase("CheckState", isSuccess=False, exception=logMsg)
                self.gameServerNetPackHandle.ChatRequestByMsg(logMsg, emChatChannelWorld)
                if self.gameServerNetPackHandle.sceneTemplateId  in [2001]:
                    self.SetState(STATE_GS_SKILLTEST_TRANSFER_MAP)
                else:
                    self.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                break
    
    def GetPlayerId(self):
        return self.characterCur.playerId
    
    def GetAllCharacterPlayerId(self):
        playerIdList = []
        for character in [self.characterMan, self.characterWoman, self.characterChild]:
            if character.playerId:
                playerIdList.append(character.playerId)
        return playerIdList
    
    def GetCharacterByPlayerId(self, charId):
        character = None
        for char in [self.characterMan, self.characterWoman, self.characterChild]:
            if char.playerId == charId:
                character = char
                break
        return character
    
    def GetOpenDay(self):
        return (datetime.date.today() - self.openDay).days
        
        
if __name__ == '__main__':
    pass
