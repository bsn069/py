# coding=gb18030
'''
Created on 2015-5-11

@author: Administrator
'''

import ctypes
import DllLoader

_DLL = DllLoader.G_DLL_DETOUR_D

class Map(object):
    """ """
    def __init__(self, id, mapName):
        self.handle = 0
        self.id = id
        self.mapName = mapName
        self.CreateMapHandle()
        
    def __del__(self):
        if self.handle:
            _DLL.ReleaseMapHandle(self.handle)
            self.handle = 0

    def CreateMapHandle(self):
        ret_value = ctypes.c_uint32()
        if self.handle:
            _DLL.ReleaseMapHandle(self.handle)
            self.handle = 0

        self.handle = _DLL.CreateMapHandle(self.id, self.mapName)
        if 0 == self.handle:
            print(ret_value.value)
            raise ("����Mapʧ��")
    
    def SetMapSize(self, fWidth, fHight):
        _DLL.SetMapSize(self.handle, fWidth, fHight)
        
    def GetID(self):
        return self.m_id
    
    def GetWidth(self):
        ret_value = ctypes.c_float()
        ret_code = _DLL.GetWidth(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetWidth() Error"
        return ret_value.value
    
    def GetHight(self):
        ret_value = ctypes.c_float()
        ret_code = _DLL.GetHight(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetHight() Error"
        return ret_value.value
    
    def GetRegionWidth(self):
        ret_value = ctypes.c_float()
        ret_code = _DLL.GetRegionWidth(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetRegionWidth() Error"
        return ret_value.value
 
    def GetRegionHight(self):
        ret_value = ctypes.c_float()
        ret_code = _DLL.GetRegionWidth(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetRegionWidth() Error"
        return ret_value.value
    
    def GetRegionCross(self):
        ret_value = ctypes.c_uint()
        ret_code = _DLL.GetRegionCross(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetRegionCross() Error"
        return ret_value.value
    
    def GetRegionVertical(self):
        ret_value = ctypes.c_uint()
        ret_code = _DLL.GetRegionVertical(self.handle,
                                         ctypes.byref(ret_value))
        if not ret_code:
            raise "GetRegionVertical() Error"
        return ret_value.value
    
    def GetNavPathCount(self, srcX, srcY, srcZ, dstX, dstY, dstZ):
        srcTenPos = ctypes.c_float * 3
        dstTenPos = ctypes.c_float * 3

        srcPos = srcTenPos(srcX, srcY, srcZ)
        dstPos = dstTenPos(dstX, dstY, dstZ)
        
        ret_code = _DLL.GetRegionVertical(self.handle,
                                         ctypes.byref(srcPos),
                                         ctypes.byref(dstPos))
        return ret_code      
    
    def GetNavPathEx(self, NavPathCount):
        NavPath = ctypes.c_float(NavPathCount)

        ret_code = _DLL.GetRegionVertical(self.handle,
                                         ctypes.byref(NavPath),
                                         NavPathCount)
        if not ret_code:
            raise "GetNavPathEx() Error"
        return NavPath.value   
    
    def test(self):
        _DLL.test()
        
    