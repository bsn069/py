# coding=gb18030
'''
Created on 2015-5-11

@author: Administrator
'''
import platform
import ctypes
import os
G_BUILD_VERSION = "Debug"
G_LINUX_DLL_SUFFIX = r'.so'
G_WIN_DLL_SUFFIX = r'.dll'



G_DLL_DETOUR_NAME = r'PythonDetour'
#G_DLL_DETOUR_NAME = r'Detour'
G_DLL_DETOUR_D = None

def LoadDll():
    global G_DLL_DETOUR_D
    print os.getcwd()
    sysstr = platform.system()
    if(sysstr == "Windows"):
        if(G_BUILD_VERSION == "Debug"):
            G_DLL_DETOUR_D = ctypes.CDLL(G_DLL_DETOUR_NAME + r'd' + G_WIN_DLL_SUFFIX)
        else:
            G_DLL_DETOUR_D = ctypes.CDLL(G_DLL_DETOUR_NAME + G_WIN_DLL_SUFFIX)
    else:
        if(G_BUILD_VERSION == "Debug"):
            G_DLL_DETOUR_D = ctypes.CDLL(G_DLL_DETOUR_NAME + r'd' + G_LINUX_DLL_SUFFIX)
        else:
            G_DLL_DETOUR_D = ctypes.CDLL(G_DLL_DETOUR_NAME + G_LINUX_DLL_SUFFIX)
            
LoadDll()
