# coding=gb18030
__version__ = '1.0.0.0'
__author__ = 'yangmingbang'

import sys
import Map

sys.modules['Map'] = Map