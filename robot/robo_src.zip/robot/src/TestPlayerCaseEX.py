# -*- coding:utf8 -*-
import time
import traceback
from locust import Locust, TaskSet, task
from locust.events import *
from locust.core import remotecall
from locust.events import request_success, request_failure
from Config.CaseDefine import *
from Family import *
from Tools.GenerateChinese import generate_chinese
from TestCase.Files import IllegalCaseError
from TestCase.Files.Portal import Portal
from Config.RunConfig import *
from account.account_def import AccountDef
from Tools.Activator import Activator
from account.account_service import get_login_account, free_login_account
from ks_passport.jinshan_channel import JinShanChannel
from TestCase.Script.TestCase_LBS import TestCase as LBSTestCase, CaseType as LBSCaseType

STOP_TIME = 60 * 35
LOGIN_SERVER_WAIT_TIME = 60 * 5

index = 100000
max_count = 1000000
@remotecall
def get_familyid():
    global index
    if index < max_count:
        index += 1
        return index
    else:
        return -1

class AutoFreeAccount(object):
    def __init__(self, caseId=None):
        self.result = False
        self.account = None
        self.caseId = caseId
        
    def __enter__(self):
        (self.result, self.caseId, self.account) = get_login_account(self.caseId)
        return self
        
    def __exit__(self, type, value, trace):
        free_login_account(self.caseId, self.account)


# 开启案例记得  开启Chararcter_PlayerCase
class WebsiteTasks(TaskSet):
    LOCATION_SERVER = ('10.20.77.139', 9600)

    def on_start(self):
        gevent.sleep(1)
#        if random.randint(0, 1) == 1:
#            request_success.fire(request_type='get', name='5', response_time=0, response_length=0)
#            self.__server_cfg = ("10.20.107.114", 9252, 5)  # 5服-压测分支
#        else:
#            request_success.fire(request_type='get', name='7', response_time=0, response_length=0)
#            self.__server_cfg = ("10.20.69.70", 9252, 7)  # 7服-压测主干

        
        # portal server服务器
        self.__portal_server = None
        # self.__portal_server = ('10.20.69.70', 9262)

        # 游戏服务器
#         self.__server_cfg = ("120.131.8.252", 9252, 1)#BVT
#         self.__server_cfg = ("172.18.100.34", 9252, 27)  # 葡萄
#         self.__server_cfg = ("120.131.14.130", 9252, 27)  # UWA
#         self.__server_cfg = ("120.92.136.27", 9252, 1)  # MI
#        self.__server_cfg = ("10.20.77.52", 9252, 13)  # 13服-测试3服（可改1）
#         self.__server_cfg = ("10.20.77.53", 9252, 14)  # 14服-测试4服（可改2）
#         self.__server_cfg = ("10.20.77.54", 9252, 15)  # 15服-测试5服（可改3）
#         self.__server_cfg = ("10.20.77.56", 9252, 16)  # 16服-测试6服（不可改）
#        self.__server_cfg = ("10.20.77.218", 9252, 17)  # 17服-测试6服（可改4）
#        self.__server_cfg = ("10.20.77.61", 9252, 78)  # 78服-IOS测试2服
#         self.__server_cfg = ("10.20.69.152", 9252, 86)  # 86服-性能测试
#         self.__server_cfg = ("10.0.1.30", 9252, 1)  # 压测
#         self.__server_cfg = ("172.18.99.52", 9252, 42)  # 亚楠
#         self.__server_cfg = ("172.18.98.35", 9252, 44)  # 张强
#         self.__server_cfg = ("120.131.8.192", 9252, 11)  # 跨GC1
#        self.__server_cfg = ("192.168.32.2", 9252, 1)  # 金山云
#         self.__server_cfg = ("172.18.98.18", 9252, 33) # 宇刚
#         self.__server_cfg = ("172.18.98.47", 9252, 56) # 朱汉斌
#        self.__server_cfg = ("10.20.102.220", 9252, 50) # 50服-客户端优化
#        self.__server_cfg = ("10.20.97.121", 9252, 45) # 鹏飞
        self.__server_cfg = ("10.11.66.161", 9252, 79)  # 79服-远程WIN
#        self.__server_cfg = ("120.92.136.95", 9252, 99)
#        self.__server_cfg = ("10.20.69.153", 9252, 76)  # 76服-远程WIN
#        self.__server_cfg = ("10.20.107.114", 9252, 5)  # 5服-压测分支
#        self.__server_cfg = ("10.11.82.36", 9252, 7)  # 7服-压测主干
    
    def on_end(self):
        pass
        
    @task(1)
    def case_loop(self):
#         with  AutoFreeAccount(caseId=None) as auto_account:
        with  AutoFreeAccount(caseId=CaseManager.PVP) as auto_account:
            if auto_account.result == AccountDef.RESULT_OK:
                pass
            elif auto_account.result == AccountDef.RESULT_EMPTY:
                request_failure.fire(request_type='get', name="[AccountEmpty]", response_time=0, exception="Account Empty")
                asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
                return
            elif auto_account.result == AccountDef.RESULT_RAND:
                auto_account.account = None
            else:
                return
                
            family = Family(ip=self.__server_cfg[0],
                            port=self.__server_cfg[1],
                            userName=generate_chinese(5),
                            account=auto_account.account,
                            serverGroupId=self.__server_cfg[2],
                            caseId=auto_account.caseId)
            if auto_account.caseId == CaseManager.GODDESS:
                #主角色性别
                family.main_sex = random.randint(MALE, FEMALE)
            
            if self.__portal_server:
                portal = Portal(self.__portal_server, family)
                if not portal.Run():
                    return
            
            loopStartTime = time.time()
            while True:
                family.Init()
                if not asyncresult_manager.wait(family, "All_LoginServer", LOGIN_SERVER_WAIT_TIME):
                    family.UnLogin()
                    return
    
#                asyncresult_manager.events.get(self).has_key('Fun_Connect') 
                family.ConnectGameServer()
                if not asyncresult_manager.wait(family, "All_GameServer", 60):
                    family.UnLogin()
                    return
#                 family.gameServerNetPackHandle.SetFamilyLocationReq()
#                 asyncresult_manager.wait(family, "SvrSetFamilyLocationRsp", 60)
                
#                family.ConnectMediaServer()      
                if RUN_TYPE == CASE_TYPE.PREPARE_ROLE or RUN_TYPE == CASE_TYPE.LOGIN_ONLY:
                    family.gameServerNetPackHandle.LeaveGame()
                    asyncresult_manager.wait(family, "LeaveGame", 30)
                    family.UnLogin()
                    break
                else:
                    start_time = time.time()                    
                    try:
                        while time.time() - start_time <= STOP_TIME:
                            if family.behavior == Behavior.END:
                                break
                            elif family.behavior == Behavior.BEGIN:
                                family.behavior = Behavior.RUNNING
                                print CaseManager.GetCase(family.caseId)
                                test_case = Activator.create_instance(CaseManager.GetCase(family.caseId), family)
                            else:
                                test_case.Excute()
                                gevent.sleep(0.01)
                    except IllegalCaseError as e:
                        logging.error(e)
                    except Exception:
                        print traceback.format_exc()
                    finally:
                        if family.gameServerNetPackHandle.isReady:
                            family.gameServerNetPackHandle.LeaveGame()
                            asyncresult_manager.wait(family, "LeaveGame", 30)
                        family.UnLogin()
                
                # 离线消息案例
                if family.caseId in [CaseManager.OFFLINECHAT] and time.time() - loopStartTime < STOP_TIME and family.roleLoop:
                    family.isNewRole = False
                    family.behavior = Behavior.BEGIN
                    gevent.sleep(20) # 重登等待时间
                else:
                    break

    @task(0)
    def case_noloop(self):
        # TestCase
        test_cases = [
                CaseManager.EQUIP,  # 装备
#                CaseManager.MAINTASK,    # 主线任务
#                CaseManager.JIAZU, # 助战
                
                #以下案例为数据校验测试用，性能测试不用开
#                 CaseManager.TRADEHOUSE_DATA,  # 拍卖行数据校验
#                 CaseManager.DATACHECKER,  # 数据校验
#                 CaseManager.VALENTINE,  # 技能测试
        ]
        
        if RUN_TYPE in [CASE_TYPE.PREPARE_ROLE, CASE_TYPE.PLAY_WITH_CREATE_CUSTOM_ROLE, CASE_TYPE.PLAY_WITH_LOOP_ROLE]:
            result, caseId, account = get_login_account(CaseManager.EQUIP)
            if result == AccountDef.RESULT_EMPTY:
                request_failure.fire(request_type='get', name="[AccountEmpty]", response_time=0, exception="Account Empty")
                asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
        else:
            account = None
            
        family = Family(ip=self.__server_cfg[0],
                        port=self.__server_cfg[1],
                        userName=generate_chinese(5),
                        account=account,
                        serverGroupId=self.__server_cfg[2],
                        caseId=test_cases[0])
        del test_cases[0]
        
        
        if self.__portal_server:
            portal = Portal(self.__portal_server, family)
            if not portal.Run():
                return
        
        while True:
            family.Init()            
            if not asyncresult_manager.wait(family, "All_LoginServer", LOGIN_SERVER_WAIT_TIME):
                family.UnLogin()
                return
            
            family.ConnectGameServer()
            if not asyncresult_manager.wait(family, "All_GameServer", 600):
                family.UnLogin()
                return
#            family.ConnectMediaServer()
            if RUN_TYPE == CASE_TYPE.PREPARE_ROLE or RUN_TYPE == CASE_TYPE.LOGIN_ONLY:
                family.gameServerNetPackHandle.LeaveGame()
                asyncresult_manager.wait(family, "LeaveGame", 30)
                family.UnLogin()
                break
            else:
                start_time = time.time()
                    
                try:
                    while time.time() - start_time <= STOP_TIME:
                        if family.behavior == Behavior.END:
                            if test_cases:
                                family.caseId = test_cases[0]
                                test_cases.remove(family.caseId)
                                family.SetState(STATE_GS_PLAYING)
                                family.behavior = Behavior.BEGIN
                            else:
                                break
                        elif family.behavior == Behavior.BEGIN:
                            family.behavior = Behavior.RUNNING
                            test_case = Activator.create_instance(CaseManager.GetCase(family.caseId), family)
                        else:
                            test_case.Excute()
                            gevent.sleep(0.01)
                except IllegalCaseError as e:
                    logging.error(e)
                except Exception:
                    print traceback.format_exc()
                finally:
                    if family.gameServerNetPackHandle.isReady:
                        family.gameServerNetPackHandle.LeaveGame()
                        asyncresult_manager.wait(family, "LeaveGame", 30) 
                    family.UnLogin()
                break
            
    @task(0)
    def case_login_jinshan(self):
        from ks_passport.common import get_account
        channel = JinShanChannel()
        token = None
        
        account = '%07d' % get_account(True)
        while True:
            if token is None:
                result, code, token, uid, name, account = channel.login(account)
            else:
                result, code, token = channel.login_by_token(account, token)
            if not result or code != 1:
                return
            authToken  = channel.gen_token(uid, name, token, account)
            family = Family(ip=self.__server_cfg[0],
                            port=self.__server_cfg[1],
                            userName=generate_chinese(5),
                            account=account,
                            serverGroupId=self.__server_cfg[2],
                            caseId=None,
                            authToken=authToken)
            
            
            family.Init()            
            if not asyncresult_manager.wait(family, "All_LoginServer", LOGIN_SERVER_WAIT_TIME):
                family.UnLogin()
                return
            
    @task(0)
    def test_lbs_getfamily(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.FAMILY_GET)
    
    @task(0)
    def test_lbs_getfamily_ill(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.FAMILY_GET, illegal=True)
        
    @task(0)
    def test_lbs_setfamily(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.FAMILY_SET)
    
    @task(0)
    def test_lbs_setfamily_ill(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.FAMILY_SET, illegal=True)  
            
    @task(0)
    def test_lbs_getkin(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.KIN_GET)
    
    @task(0)
    def test_lbs_gettkin_ill(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.KIN_GET, illegal=True)
            
    @task(0)
    def test_lbs_settkin(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.KIN_SET)
    
    @task(0)
    def test_lbs_settkin_ill(self):
        case = LBSTestCase()
        case.Run(self.LOCATION_SERVER, LBSCaseType.KIN_SET, illegal=True)
                 
class WebsiteUser(Locust):
    task_set = WebsiteTasks
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0


if __name__ == "__main__":
    import locust.main
    import sys
    import logging

    logging.basicConfig(level=logging.DEBUG)
    # logging.basicConfig(level=logging.INFO) #用于显示数据校对的log
#     logging.basicConfig(level=logging.ERROR)

#     sys.argv.extend(["-f", "TestPlayerCaseEX.py", "--web-host=127.0.0.1", "-H", "dddss", "-r", "1", "-c", "1"])
    sys.argv.extend(["-f", __file__, "--no-web", "-H", "dddss", "-r", "1", "-c", "5"])
    locust.main.main()





