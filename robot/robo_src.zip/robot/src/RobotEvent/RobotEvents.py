""""
    hanlder all data to family 
    yujie   
"""

class RobotEvent(object):
    def __init__(self):
        self._handlers = {}

    def __iadd__(self, registerDict):
        for name, handler in registerDict.iteritems():
            self._handlers[name] = handler
        return self

    def __isub__(self, name):
        del self._handlers[name]
        return self

    def Set(self, name, **kwargs):
        if name in self._handlers:
            self._handlers[name](**kwargs)
            
    def Get(self, name, *args):
        if name in self._handlers:
            result = self._handlers[name](*args)
            return result
            
    def Destory(self):
        self._handlers = {}

