# coding=gb18030
'''
Created on 2015-6-1

@author: Administrator
'''
class CharacterSyncInfo(object):
    def __init__(self):
        self.id       = None 
        self.type     = None
        self.gender   = None
        self.faction  = None 
        self.edoing   = None
        self.dir      = None
        self.speed    = None
        self.posX     = None 
        self.posY     = None
        self.name     = None 
        self.hp_percent =  None
        self.level    = None 
        self.series   = None
        self.templateId = None
        self.familyId = None
        self.familyMemberType = None
        self.scene_template_id  = None
        self.scene_instalce_id  = None
        self.maxHp    = None
        self.curHp    = None