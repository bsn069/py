'''
Created on 2015-6-1

@author: Administrator
'''
import random
from locust.asyncevent import asyncresult_manager
from locust.events import *


class OtherCharacterManager(object):
    def __init__(self):
        self.characterList = {}
        self.id2familyid = {}
    
    # enter Scene
    def syncCharacterInfo(self, characterSyncInfo):
        if(characterSyncInfo.type == 2):
            self.characterList[characterSyncInfo.id] = characterSyncInfo
            infoDict = {}
            infoDict['familyid'] = characterSyncInfo.familyId
            infoDict['state'] = characterSyncInfo.state
            self.id2familyid[characterSyncInfo.id] = infoDict
            
    # leave Scene
    def playerLeaveScene(self, characterLeaveScene):
        
        for character_id in characterLeaveScene.id:
            if(self.characterList.has_key(character_id)):
                del self.characterList[character_id]
                
                del self.id2familyid[character_id]

            
    def syncCharacterState(self, characterSyncState):
        if(self.characterList.has_key(characterSyncState.id)):
            self.characterList[characterSyncState.id].speed = characterSyncState.CharacterStateInfo.speed
            self.characterList[characterSyncState.id].dir = characterSyncState.CharacterStateInfo.dir
            self.characterList[characterSyncState.id].posX = characterSyncState.CharacterStateInfo.posX
            self.characterList[characterSyncState.id].posY = characterSyncState.CharacterStateInfo.posY
            
    def getSceneCharacter(self):
        pos = 0
        count = random.randint(0, len(self.characterList))
        characterInfo = None
        for value in self.characterList.values():
            if(count == pos or pos == 0):
                characterInfo = value
                break
            pos += 1
        
        return characterInfo
    
    def setSceneId2FamilyidState(self, id, state):
        self.id2familyid[id]['state'] = state
        
    def getSceneId2FamilyidDict(self):
        return self.id2familyid
    