'''
Created on 2015-6-1

@author: Administrator
'''
class CharacterStateInfo(object):
    def __init__(self):
        self.time = None
        self.speed = None
        self.dir = None
        self.posX = None
        self.psxY = None
        self.dragTime = None
        self.skillId = None
        self.skillLevel = None
        
