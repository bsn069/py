'''
Created on 2015-6-1

@author: Administrator
'''
import CharacterStateInfo

class SyncCharacterState(object):
    def __init__(self):
        self.Id = None
        self.state = None
        self.characterStateInfo = CharacterStateInfo()
        