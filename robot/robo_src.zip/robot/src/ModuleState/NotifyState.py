__author__ = 'Administrator'

class NotifyState(object):
    STATE_GS_SYNC_MONEY = 0B1
    STATE_GS_SYNC_SHOP_GOODS_LIST = 0B10
    STATE_GS_SHOP_RESULT = 0B100

    def __init__(self):
        self.state = 0

    def check_state(self, state):
        return self.state & state

    def set_state(self, state):
        self.state |= state

    def unset_state(self, state):
        self.state = ~((~self.state) | state)
