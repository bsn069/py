'''
Created on 2015-5-26

@author: Administrator
'''
FAMILY_LOGINING_LS = 10000
FAMILY_LOGINED_LS = 10001