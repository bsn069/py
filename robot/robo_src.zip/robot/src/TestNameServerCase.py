# -*- coding:utf8 -*-
import gevent
import random
import time
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from TestCase.Files.NameServer import Server
from ModuleState.StateDefine import *


class NameTest(TaskSet):
    TIMEOUT = 60
    Name_SERVER = ('10.20.77.139', 9272)
    
    
    def on_start(self):
        gevent.sleep(1)

            
    @task(1)
    def test_portal(self): 
        nameserver = Server(self.Name_SERVER)
        nameserver.ConnectServer()
        if not asyncresult_manager.wait(nameserver.ServerNetPackHandle, "NameServerConnected", NameTest.TIMEOUT):
            nameserver.Uninit()
            return
        try:
            while nameserver.state == STATE_ZO_LOGINING: 
                start_time = time.time()
                for i in range(1):#模仿gs每秒发500个
                    nameserver.AskRoleNameRequest()
                end_time = time.time() - start_time
                if end_time<1:
                    gevent.sleep(1-end_time)
        except Exception:
                print traceback.format_exc()
        finally:
                nameserver.Uninit()
     

            
class WebsiteUser(Locust):
    task_set = NameTest
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0
    

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
  
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)

    sys.argv.extend(["-f", "TestNameServerCase.py", "--no-web",   "-H", "dddss", "-r", "2", "-c", "1"])
    locust.main.main()
