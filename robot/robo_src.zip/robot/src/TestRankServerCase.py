# -*- coding:utf8 -*-
import gevent
import random
import time
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from TestCase.Files.RankServer import Server
from ModuleState.StateDefine import *


class RankTest(TaskSet):
    TIMEOUT = 60
    RANK_SERVER = ('10.20.77.139', 9253)
    
    
    def on_start(self):
        gevent.sleep(1)

            
    @task(1)
    def test_portal(self): 
        rankserver = Server(self.RANK_SERVER)
        rankserver.ConnectServer()
        if not asyncresult_manager.wait(rankserver.ServerNetPackHandle, "RankServerConnected", RankTest.TIMEOUT):
            rankserver.Uninit()
            return
        try:
            while rankserver.state == STATE_ZO_LOGINING: 
                start_time = time.time()
                for i in range(1):
                    rankserver.GetRankingListRequest()
                end_time = time.time() - start_time
                if end_time<1:
                    gevent.sleep(1-end_time)
        except Exception:
                print traceback.format_exc()
        finally:
                rankserver.Uninit()
     

            
class WebsiteUser(Locust):
    task_set = RankTest
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0
    

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
  
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)

    sys.argv.extend(["-f", "TestRankServerCase.py", "--no-web",   "-H", "dddss", "-r", "2", "-c", "1"])
    locust.main.main()
