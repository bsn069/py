# encoding=utf-8

'''
Created on 2017年11月10日

@author: zhangpengfei
'''
from locust.core import remotecall
import hashlib
import random
import base64
import time
# import sys
# reload(sys)
# sys.setdefaultencoding('utf-8')
MAX_ACCOUNT = 500000
MAX_WAIT = 1000000


account_index = 1
@remotecall
def get_account(is_loop):
    global account_index
    if is_loop or account_index < MAX_ACCOUNT:
        account_index = account_index % MAX_ACCOUNT + 1
    else:
        account_index = MAX_ACCOUNT + 1
    if account_index % 1000 == 0:
        print account_index
    return account_index

login_index = 0
login_begin = None
@remotecall
def login_over(count=10):
    global login_begin, login_index
    login_index += 1
    if login_index == 1:
        login_begin = time.time()
    if login_index == count:
        print "login over, num=%d, sec=%f" % (count, time.time() -login_begin)
          
def Generate(Chinese_Len):
    username = ''
    while len(username) < Chinese_Len:
        head = random.randint(0xB0, 0xF7)
        tail = random.randint(0xA1, 0xFE)
        val = (head << 8) | tail
        word = "%x" % val
        SingleWord = word.decode('hex').decode('gbk', 'ignore')
        username += SingleWord
    return username.encode("gb2312")
                         
def md5sum(org_str):
    md5_test = hashlib.md5()
    md5_test.update(org_str)
    return md5_test.hexdigest()
    
def sign(d, action, appkey):
    sign_str = ''
    for k in sorted(d.keys()):
        sign_str += "%s=%s&" % (str(k), str(d[k]))
    sign_str = "%s:%s:%s" % (sign_str.rstrip('&'), action, appkey)
    return base64.b64encode(md5sum(sign_str))
        