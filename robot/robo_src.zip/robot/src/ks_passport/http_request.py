 # -*- coding:utf-8 -*-
import base64
import random
import xmlrpclib
import hashlib
import time
import json
import urllib3
from locust.events import request_success, request_failure

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

urllib3.disable_warnings()
http = urllib3.PoolManager(
                           num_pools=50,
                           maxsize=5000,
                           retries=False,)

def request(url, name, params_str="", fields={}, encode_body=False, timeout=120, check_code=True):
    result = False
    code = None
    data = None
    
    start_time = time.time()
    if encode_body:
        req = http.request_encode_body
    else:
        req = http.request
    try:
        if params_str:
                r= req('POST', url, body=params_str, timeout=timeout)
        elif fields:
                r= req('POST', url, fields=fields, timeout=timeout)
        else:
                r= req('GET', url, timeout=timeout)
    except Exception, ex:
        total_time = time.time() - start_time
        request_failure.fire(request_type="get", name=name, response_time=total_time, exception=str(type(ex)))
        return result, code, data
    
    total_time = time.time() - start_time
    code = r.status
    if r.status == 200:
        response = r.data
        if response:
            data = json.loads(response)
            if not check_code:
                request_success.fire(request_type="get", name=name, response_time=total_time, response_length=0)
                result = True
            else:
                if 'code' in data:
                    code = data['code']
                    if data['code'] == 1:
                        request_success.fire(request_type="get", name=name, response_time=total_time, response_length=0)
                        result = True
                    else:
                        request_failure.fire(request_type="get", name=name, response_time=total_time, exception="code=%d" % data['code'])
                else:        
                    request_failure.fire(request_type="get", name=name, response_time=total_time, exception="response=%s" % response)
        else:
            request_failure.fire(request_type="get", name=name, response_time=total_time, exception="response=none")
    else:
        request_failure.fire(request_type="get", name=name, response_time=total_time, exception="status=%s" % r.status)

    return result, code, data

def request_Passport(url, name, params_str="", fields={}, encode_body=False, timeout=120, check_code=True):
    result = False
    code = None
    data = None
    
    start_time = time.time()
    if encode_body:
        req = http.request_encode_body
    else:
        req = http.request
    try:
        if params_str:
                r= req('POST', url, body=params_str, timeout=timeout)
        elif fields:
                r= req('POST', url, fields=fields, timeout=timeout)
        else:
                r= req('GET', url, timeout=timeout)
    except Exception, ex:
        total_time = time.time() - start_time
        request_failure.fire(request_type="get", name=name, response_time=total_time, exception=str(type(ex)))
        return result, code, data
    
    total_time = time.time() - start_time
    code = r.status
    if r.status == 200:
        response = r.data
        if response:
            data = json.loads(response)
            if not check_code:
                request_success.fire(request_type="get", name=name, response_time=total_time, response_length=0)
                result = True
            else:
                if 'returnCode' in data:
                    code = data['returnCode']
                    if data['returnCode'] == 1 or data['returnCode'] == 5 or data['returnCode'] == 2:
                        request_success.fire(request_type="get", name=name, response_time=total_time, response_length=0)
                        result = True
                    else:
                        request_failure.fire(request_type="get", name=name, response_time=total_time, exception="returnCode=%d" % data['returnCode'])
                else:        
                    request_failure.fire(request_type="get", name=name, response_time=total_time, exception="response=%s" % response)
        else:
            request_failure.fire(request_type="get", name=name, response_time=total_time, exception="response=none")
    else:
        request_failure.fire(request_type="get", name=name, response_time=total_time, exception="status=%s" % r.status)

    return result, code, data

def middler_isExistedUserId(url, account):
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            code =  server.middler.isExistedUserId(account) 
            total_time = time.time()-start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.isExistedUserId", response_time=total_time, exception=str(type(ex))) 
            return
        if code == 1 or code == -1:
            request_success.fire(request_type="get", name="middler.isExistedUserId", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.isExistedUserId", response_time=total_time, exception="status=%s" % str(code))

def middler_getUserDetailInfo(url, account):  
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            code =  server.middler.getUserDetailInfo(account, '0') 
            total_time = time.time()-start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.getUserDetailInfo", response_time=total_time, exception=str(type(ex))) 
            return
        if len(code)>0:
            request_success.fire(request_type="get", name="middler.getUserDetailInfo", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.getUserDetailInfo", response_time=total_time, exception="status=%s" % str(code))         

def middler_login(url, account, password, ip):
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            code =  server.middler.login(account, password, ip)
            total_time = time.time() - start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.login", response_time=total_time, exception=str(type(ex))) 
            return
        if code == 1 or code == -1 or code == -2:
            request_success.fire(request_type="get", name="middler.login", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.login", response_time=total_time, exception="status=%s" % str(code))
           
def middler_modifyPassWord(url, account, password, ip):
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            code =  server.middler.modifyPassWord(account, password, ip) 
            total_time = time.time()-start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.modifyPassWord", response_time=total_time, exception=str(type(ex))) 
            return
        if code == 1:
            request_success.fire(request_type="get", name="middler.modifyPassWord", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.modifyPassWord", response_time=total_time, exception="status=%s" % str(code))
#随机产生手机号
def createPhone():
    prelist=["130","131","132","133","134","135","136","137","138","139","147","150","151","152","153","155","156","157","158","159","186","187","188"]
    return random.choice(prelist)+"".join(random.choice("0123456789") for i in range(8))

def middler_createNewUserForMobile(url, password):
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            code =  server.middler.createNewUserForMobile(createPhone(), password, password,'1325') 
            total_time = time.time()-start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.createNewUserForMobile", response_time=total_time, exception=str(type(ex))) 
            return
        if code == 1:
            request_success.fire(request_type="get", name="middler.createNewUserForMobile", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.createNewUserForMobile", response_time=total_time, exception="status=%s" % str(code))

def make_mail():  
    #产生随机数邮箱，  
    nummail=random.randint(100000000,3999999999)  
    nummail=str(nummail)  
    return nummail+"@qq.com" 

def middler_createNewUserForAll(url, account, password, ip, id_number):
        try:
            start_time = time.time()
            server = xmlrpclib.ServerProxy(url)
            local_time = time.strftime('%Y-%m-%d %X', time.localtime())
            code = server.middler.createNewUserForAll('8989989898', password, password, make_mail(), ip, local_time,Generate(2),'0',id_number,'1','','0')
            total_time = time.time()-start_time
        except Exception, ex:
            total_time = time.time() - start_time
            request_failure.fire(request_type="get", name="middler.createNewUserForAll", response_time=total_time, exception=str(type(ex))) 
            return
        if code == 1 or code == -1:
            request_success.fire(request_type="get", name="middler.createNewUserForAll", response_time=total_time, response_length=0)
        else:
            request_failure.fire(request_type="get", name="middler.createNewUserForAll", response_time=total_time, exception="status=%s" % str(code))          
          