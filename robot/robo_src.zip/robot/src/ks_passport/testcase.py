# coding:utf-8

import gevent
import IdCardNumber
from locust.core import HttpLocust, TaskSet, task
from http_request import *
from rendezvous import GetRendezvousPoint
from common import get_account, login_over, MAX_ACCOUNT, MAX_WAIT, Generate
from jinshan_channel import JinShanChannel

g_zevous  = None
def SetZevous(count=100000):
    global g_zevous
    g_zevous = GetRendezvousPoint('login', count)

class WebsiteTasks(TaskSet):
    def on_start(self):
        self.url_name = "http://180.235.73.251:8080/middlers"
        self.url_passport = "http://img.pp.pass.kingsoft.com:8080/middlers/middlerxmlrpcservlet"
        self.szpassword = '{MD5}' + base64.b64encode("king5688".encode("hex"))
        self.ip = '10.20.96.161'
        self.channel = JinShanChannel()
        SetZevous(1)
        
    @task(0)
    def register_jinshan_account(self):
        account = get_account(False)
        if account > MAX_ACCOUNT:
            request_success.fire(request_type="get", name="AccountEmpty", response_time=0, response_length=0)
            gevent.sleep(MAX_WAIT)
        self.channel.regesist('%07d' % account)
                
    @task(1)
    def login(self):
        account = '%07d' % get_account(True)
        result, code, token, uid, name, account = self.channel.login(account)
        if not result or code != 1:
            return
        self.channel.create_order(uid)
        
        # 等待人齐
        g_zevous.NotifyReady(1)
        g_zevous.AllReady()
        
        is_loop = True
        while True:            
#             print self.channel.verify_session(token)

            result, code, token = self.channel.login_by_token(account, token)
            if result:
                if not is_loop:
                    request_success.fire(request_type="get", name="loginMaxCount", response_time=0, response_length=0)
                    login_over()
                    gevent.sleep(MAX_WAIT)
            elif code ==502 or code == 504:
                continue
            else:
                break
    
    #实名验证 金山通行证
    @task(1)
    def verify_name(self):
        index = get_account(False)
        if index > MAX_ACCOUNT:
            request_success.fire(request_type="get", name="AccountEmpty", response_time=0, response_length=0)
            gevent.sleep(MAX_WAIT)
        account = '%07d' % index
        id_number,addrName,addrId,birthDays,sex,checkOut = IdCardNumber.getRandomIdNumber(0)
        sign_str = "/passport/idnum_verify/verify_account_idnum?account=%s&real_name=%s&id_number=%s" % (account+"@test.com", Generate(3), id_number)
        url = self.url_name+ sign_str
        result, code, data = request_Passport(url, "verify_name")
        
    def Generate1(self, Chinese_Len):
        username = ''
        while len(username) < Chinese_Len:
            head = random.randint(0xB0, 0xF7)
            tail = random.randint(0xA1, 0xFE)
            val = (head << 8) | tail
            word = "%x" % val
            SingleWord = word.decode('hex').decode('gbk', 'ignore')
            username += SingleWord
        return username
    #实名验证 西瓜
    @task(0)
    def verifyidard(self):
        index = get_account(False)
        if index > MAX_ACCOUNT:
            request_success.fire(request_type="get", name="AccountEmpty", response_time=0, response_length=0)
            gevent.sleep(MAX_WAIT)
        szpassportid = '%07d' % index + '@test.com'
        name = self.Generate1(3)
        id_number,addrName,addrId,birthDays,sex,checkOut = IdCardNumber.getRandomIdNumber(0)
        signstr = 'appId=%d&cardId=%s&name=%s&passportId=%s&version=4.0.4:verifyCardId:3264718148282430' % (10074, id_number, name, szpassportid)
        md5 = hashlib.md5()
        md5.update(signstr)
        sign = md5.hexdigest()
        b64sign = base64.b64encode(sign)
        reqstr = 'appId=%d&cardId=%s&name=%s&passportId=%s&version=4.0.4&sign=%s' % (10074, id_number, name, szpassportid, b64sign)
        requrl = 'https://js2sdk.xoyo.com:11443/v3/verifyCardId?%s' % reqstr
        result, code, data = request(requrl, "verifyidard_xigua") 
    
    @task(0)    
    def middler(self):
        index = get_account(False)
        if index > MAX_ACCOUNT:
            request_success.fire(request_type="get", name="AccountEmpty", response_time=0, response_length=0)
            gevent.sleep(MAX_WAIT)  
        szpassportid = '%07d' % index + '@test.com'
#        ip = socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff)))  
#        #登录密码认证
        middler_login(self.url_passport, szpassportid, self.szpassword, self.ip)
#        #修改登录密码
#        middler_modifyPassWord(self.url_passport, szpassportid, self.szpassword, self.ip)
#        #验证账号是否存在
#        middler_isExistedUserId(self.url_passport, szpassportid)
#        #拉取用户的详细信息
#        middler_getUserDetailInfo(self.url_passport, szpassportid)
#        #注册新用户（手机）
#        middler_createNewUserForMobile(self.url_passport, self.szpassword)
#        #注册新用户（邮箱）
#        id_number,addrName,addrId,birthDays,sex,checkOut = IdCardNumber.getRandomIdNumber(0)
#        middler_createNewUserForAll(self.url_passport, szpassportid, self.szpassword, self.ip, id_number)
    @task(0)
    def is_alive(self):
        # request("http://120.92.154.148:11000/isAlive", "isAlive", check_code=False)
        request("http://120.92.136.224:11000/isAlive", "isAlive", check_code=False)
                
class WebsiteUser(HttpLocust):
    host = ""
    task_set = WebsiteTasks
    stop_timeout = MAX_WAIT
    min_wait = 0
    max_wait = 0


if __name__ == "__main__":
    import locust.main
    import sys
    sys.argv.extend(["-f", "testcase.py", "--no-web", "-H", "dddss", "-r", "2", "-c", "1"])
    locust.main.main()
