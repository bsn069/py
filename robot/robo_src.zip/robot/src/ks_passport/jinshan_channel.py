# encoding=utf-8
'''
Created on 2017年11月10日

@author: zhangpengfei
'''
import base64
import gevent
import time
import hmac
import json
import hashlib
import random
from common import get_account, sign, md5sum
from http_request import request

class JinShanChannel(object):
    """
            登录：客户端登录 -> 金山通行证 -> token游戏服务端 -> token西瓜 -> 金山通行证服务端验证 -> 返回给西瓜 -> 游戏服务端 -> 游戏客户端
            实名：客户端 -> 金山通行证 -> passport -> 金山通行证 -> 客户端
            登录：客户端登录 -> 金山通行证 -> passport -> 金山通行证 -> token游戏服务端 -> token西瓜 -> 金山通行证服务端验证 -> 返回给西瓜 -> 游戏服务端 -> 游戏客户端
    """

    def __init__(self):
        self.url = "http://120.92.136.224:11000/v3/"
        self.password = base64.b64encode("king5688".encode("hex"))
        self.appid = '10074'
        self.captcha = '123456'
        self.version = '4.0.4'
        self.appkey = "3264718148282430"
        self.xg_appid = "111111534"
        self.planid = "7802"
        
    def gen_token(self, uid, name, token, deviceId):
        currTm = int(time.strftime('%Y%m%d%H%M%S',time.localtime(time.time())))
        xg_AppKey = 'f50936b32731485c922c5fba78122296'
        dataDict = {
                    "uid": uid,
                    "extData": "{\"version\":\"%s\"}" % self.version,
                    "ts": currTm,
                    "channelId": "jinshan",
                    "name": name,
                    "xgAppId": self.xg_appid,
#                         "xgAppId": "1024appid",
                    "authToken": token,
                    "planId": self.planid,
                    "deviceId": deviceId
                    }
        dataList = []
        for key in  sorted(dataDict.keys()):
            dataList.append("%s=%s" % (key, dataDict[key]))
        data = "&".join(dataList)
        sign = hmac.new(xg_AppKey, data, hashlib.sha1).digest().encode('hex')
        dataDict["sign"] = sign
        data_json = json.dumps(dataDict)
        authInfo_data = data_json.encode('base64').replace("\n", "")
        return authInfo_data
    
    def gen_token111(self, uid, name, token, deviceId):
        currTm = int(time.strftime('%Y%m%d%H%M%S',time.localtime(time.time())))
        xg_AppKey = 'f50936b32731485c922c5fba78122296'
        dataDict = {
                    "uid": uid,
                    "extData": "{\"version\":\"4.0.4\"}",
                    "ts": currTm,
                    "channelId": "jinshan",
                    "name": name,
                    "xgAppId": "111111534",
#                         "xgAppId": "1024appid",
                    "authToken": token,
                    "planId": "7802",
                    "deviceId": deviceId
                    }
        dataList = []
        for key in  sorted(dataDict.keys()):
            dataList.append("%s=%s" % (key, dataDict[key]))
        data = "&".join(dataList)
        sign = hmac.new(xg_AppKey, data, hashlib.sha1).digest().encode('hex')
        dataDict["sign"] = sign
        data_json = json.dumps(dataDict)
        authInfo_data = data_json.encode('base64').replace("\n", "")
        return authInfo_data
    
    def regesist(self, account):
        param = {
                 'appId':self.appid,
                 'captcha':self.captcha,
                 'deviceId':account,
                 'email':'%s@test.com' % (account),
                 'password':self.password,
                 'version':self.version,
                 }
        param['sign'] = sign(param, action="register", appkey=self.appkey)
        while True:
            result, code, data = request(self.url+"register", "register", fields=param)
            if result or code == 705:
                return code, account
            gevent.sleep(0)
        
    def login(self, account):
        param = {
                 'appId':self.appid,
                 'deviceId':account,
                 'passportId':'%s@test.com' % account,
                 'password':base64.b64encode("king5688".encode("hex")),
                 'version':self.version,
                 }
        param['sign'] = sign(param, action="login", appkey=self.appkey)
        result, code, data = request(self.url+"login", "login", fields=param)
        if result and code == 1 and 'token' in data:
            token = data['token']
            uid = data['uid']
            name = data['passportId']
        else:
            return result, code, None, None, None, None
        return result, code, token, uid, name, account
    
    def login_by_token(self, account, token):
        new_token = token
        param = {
                 'appId':self.appid,
                 'deviceId':account,
                 'token':token,
                 'version':self.version,
                 }
        param['sign'] = sign(param, action="loginByToken", appkey=self.appkey)
        result, code, data = request(self.url+"loginByToken", "loginByToken", fields=param)
        if result and code == 1 and 'token' in data:
            new_token = data['token']
        return result, code, new_token
    
    def verify_session(self, token):
        sign_str = "appId=%s&token=%s%s%s" % (self.appid, token, self.appid, "e45ophf_rm4m77nv2")
        sign = md5sum(sign_str)
        return request(self.url + "verifySession?appId=%s&token=%s&sign=%s" % (self.appid, token, sign), "verifySession")
    
    def create_order(self, passport_id):
#         充值渠道ID,不要压测JD和微信的，因为这个还要去JD和微信后台创建订单
#         376 - 支付宝极简支付
#         381 - 苹果手机支付
#         391 - 京东支付
#         401 - 微信支付
#         404 - google支付
#         405 - QQ钱包
#         406 - 汇付宝支付
        param = {
                 'appId':self.appid,
                 'channelId':random.choice([376, 405]),
                 'passportId':passport_id,
                 'productId':random.randint(1, 65535),
                 'productName':"测试道具",
                 'price':random.randint(1, 9999),
                 'amount':random.randint(1, 9999),
                 'version':self.version
                 }
        param['sign'] = sign(param, action="createOrder", appkey=self.appkey)
        result, code, data = request(self.url+"createOrder", "createOrder", fields=param)
        if result and code == 1:
            return True
        return False
        pass
