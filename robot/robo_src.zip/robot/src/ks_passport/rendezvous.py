from gevent import event, sleep, spawn
from locust.core import remotecall

points = {}
cpoints = {}


@remotecall
def InitRendezvouspoint(name, count):
    if name in points:
        print "aleady has rendezvous point %s" % name
        return

    points[name] = SPoint(name, count)


@remotecall
def NotifyReady(name, count):
    points[name].NotifyReady(count)


@remotecall
def IsAllReady(name):
    points[name].AllReady()


class SPoint():

    def __init__(self, name, count):
        self.name = name
        self.count = count
        self.aleady_count = 0
        self.event = event.Event()

    def NotifyReady(self, count):
        self.aleady_count = self.aleady_count + count
        if self.aleady_count >= self.count:
            self.event.set()

    def AllReady(self):
        if self.aleady_count >= self.count:
            return

        self.event.wait()


class RendezvousPoint():

    def __init__(self, name, count):
        self.name = name
        self.count = count
        self.aleady_count = 0
        self.event = None
        self.new = False
        self.report = None
        InitRendezvouspoint(self.name, count)

    def NotifyReady(self, count):
        self.aleady_count = self.aleady_count + count

    def AllReady(self, block=True, interval=1):
        if self.event and self.event.ready():
            return True

        def Report(point, interval):
            while True:
                if point.event and point.event.ready():
                    return True

                if point.aleady_count:
                    count = point.aleady_count
                    point.aleady_count = 0
                    NotifyReady(point.name, count)
                sleep(interval)

        if self.report is None:
            self.report = spawn(Report, self, interval)

        if block:
            if self.event is not None:
                self.event.wait()
            else:
                self.event = event.Event()
                IsAllReady(self.name)
                self.event.set()
            return True

        if not block:
            if self.event and self.event.ready():
                return True

            if self.event is None:
                self.event = event.Event()

                def RequestReady(name, revent):
                    IsAllReady(name)
                    revent.set()

                spawn(RequestReady, self.name, self.event)

            return False


def GetRendezvousPoint(name, count=None):
    if name in cpoints:
        return cpoints[name]

    cpoints[name] = RendezvousPoint(name, count)
    return cpoints[name]
