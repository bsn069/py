# coding:utf-8
import os
import sys
import random
import Queue
from account_def import AccountDef
from account_online import ACCOUNT as account_online_poor
sys.path.insert(0, os.path.abspath("../"))
sys.path.insert(0, os.path.abspath("../net"))
from Config.RoleFigures import FACTION_SKILL, SKILL_TALENT, TIANWANG, TANGMEN, EMEI, TIANREN, WUDANG
from Config.CaseDefine import CaseManager

def singleton(cls, *args, **kw):    
    instances = {}    
    def _singleton():    
        if cls not in instances:    
            instances[cls] = cls(*args, **kw)    
        return instances[cls]    
    return _singleton

@singleton
class AccountMgr(object):
    def __init__(self):
        self.account_release = AccountRelease()
        self.account_login = AccountLogin()
        self.account_battle = AccountBattle()
        self.account_yewai = AccountYeWai()
        self.account_skillid = AccountSkillID()
        self.account_leaguematch = AccountLeagueMatch()
        self.account_kin = AccountKin()
        self.account_action = AccountActionType()
        self.account_hengxujing = AccountHengXuJing()
        self.account_hengdaoshu = AccountHengDaoShu()
        self.account_xiaomijing = AccountXiaoMiJing()
        self.account_yewai_campTag = AccountYeWaiCampTag()
        self.account_cross_battle = AccountCrossBattle()
        self.account_cross_friend = AccountCrossFriend()
        self.account_realtime_voice = AccountRealTimeVioce()
        self.account_redpacket = AccountRedPacket()
        self.account_kinlist = AccountKinList()
        self.account_maiguzhiku = AccountMaiGuZhiKu()
        self.account_eatchicken = AccountEatChicken()
@singleton
class AccountGlobalAttr(object):       
    def __init__(self):
        self.kin_id = 0  
        self.team_id = 0
        
    def get_kin(self):
        self.kin_id += 1
        return self.kin_id
    
    def get_team(self):
        self.team_id += 1
        return self.team_id

class Account(object):
    def __init__(self):
        self.global_attr = AccountGlobalAttr()
        
    def get_account(self, context=None):
        return NotImplementedError
    
class AccountRelease(Account):
    def __init__(self):
        super(AccountRelease, self).__init__()
        self.index = 0
        self.useindex = account_online_poor
        self.cases = CaseManager.CASE_ACCOUNTNUM

    def get_release_account(self):
        if len(self.useindex) > 0:
            account = self.useindex[random.randint(0, len(self.useindex)-1)]
            self.useindex.remove(account)
            caseId = CaseManager.GetRandCaseId(self.cases)
            return True, caseId, account
        else:
            return None, None, None

    def free_release_account(self, account):
        self.useindex.append(account)
        
class AccountLogin(Account):
    def __init__(self):
        super(AccountLogin, self).__init__()
        self.num = 0
        self.accounts = {}
        self.cases = CaseManager.CASE_ACCOUNTNUM
        for key, value in CaseManager.CASE_ACCOUNTNUM.items():
            if value == 0:
                self.accounts[key] = None
            else:
                self.accounts[key] = Queue.Queue(value)
                for i in range(value):
                    self.accounts[key].put('%s_%d_%d' % (AccountDef.ACCOUNT_PRE, key, i))
    
    def get_account(self, caseId=None):
        if caseId is None:
            caseId = CaseManager.GetRandCaseId(self.cases)
            
        if caseId in self.cases and caseId in self.accounts:
            if self.accounts[caseId] == None:
                return (AccountDef.RESULT_RAND, caseId, None)
            elif self.cases[caseId] > 0:
                try:
                    account = self.accounts[caseId].get_nowait()
                    self.cases[caseId] -= 1
                    return AccountDef.RESULT_OK, caseId, account
                except Queue.Empty:
                    return AccountDef.RESULT_EMPTY, caseId, None
                    
            else:
                return AccountDef.RESULT_EMPTY, caseId, None
        return AccountDef.RESULT_EXCEPT, caseId, None
        
    
    def free_account(self, caseId, account):
        result = AccountDef.RESULT_EXCEPT
        if caseId in self.cases:
            self.accounts[caseId].put_nowait(account)
            self.cases[caseId] += 1
            result = AccountDef.RESULT_OK
        return result
            
class AccountActionType(Account):
    def __init__(self):
        super(AccountActionType, self).__init__()
        self.is_loop = True # 账号是否循环
        self.type_rule = [1, 1]
        self.type_rule_count = sum(self.type_rule)
        self.type_rule_queue = dict((sum(self.type_rule[0:i]), self.type_rule[i]) for i in range(len(self.type_rule)))
        self.account_num = 0
        self.type = -1
    
    def get_account(self):    
        if self.account_num in self.type_rule_queue:
            self.type = (self.type + 1) % len(self.type_rule )
        self.account_num = (self.account_num + 1) % self.type_rule_count
        result = str(self.type)
        return result

class AccountTeam(Account):
    def __init__(self):
        super(AccountTeam, self).__init__()
        self.team_id = 0
        self.is_loop = True # 账号是否循环
        self.team_num = (0, 5)
        self.team_rule = [] # # 分队信息,如不组队，1人队，2人对，3人队，4人队，5人队。这里为空的话，则每次生成队伍人数
        self.team_member_queue = []
        self.team_leader_id = 0
        self.team_leader_groupid = 0
        
    def get_account(self, team_leader_id=None, team_groupid=None):
        if not self.team_member_queue:
            if not self.is_loop:
                return  AccountDef.RESULT_EMPTY, 0, 0, 0, 0, 0
            
            if self.team_rule:
                team_rule = self.team_rule
            else:
                team_rule = [random.randint(self.team_num[0], self.team_num[1]) for i in xrange(10)]
                
            for team_num in team_rule:
                if team_num < 1:
                    self.team_member_queue.append((AccountDef.TEAM_SINGLE, 0))
                else:
                    self.team_member_queue.extend([(AccountDef.TEAM_LEADER, team_num) if i == 0 else (AccountDef.TEAM_MEMBER, team_num) for i in xrange(team_num)]) 
        
        member_type, count = self.team_member_queue.pop(0)
        if member_type == AccountDef.TEAM_LEADER:
            self.team_id = self.global_attr.get_team()
            self.team_leader_id = team_leader_id
            self.team_leader_groupid = team_groupid
        return AccountDef.RESULT_OK, self.team_id, self.team_leader_id, count, member_type, self.team_leader_groupid
        
class AccountBattle(AccountTeam):
    def __init__(self):
        super(AccountBattle, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (0, 15)
        self.team_rule = [] # 这里为空的话，则每次生成队伍人数

class AccountEatChicken(AccountTeam):
    def __init__(self):
        super(AccountEatChicken, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (0, 5)
        self.team_rule = [5] # 这里为空的话，则每次生成队伍人数
        
class AccountLeagueMatch(AccountTeam):
    def __init__(self):
        super(AccountLeagueMatch, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (0, 3)
        self.team_rule = [3] # 这里为空的话，则每次生成队伍人数
        
class AccountXiaoMiJing(AccountTeam):
    def __init__(self):
        super(AccountXiaoMiJing, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (3, 5)
        self.team_rule = [3] # 这里为空的话，则每次生成队伍人数        
        
class AccountHengXuJing(AccountTeam):
    def __init__(self):
        super(AccountHengXuJing, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (5, 5)
        self.team_rule = [5] # 这里为空的话，则每次生成队伍人数

class AccountHengDaoShu(AccountTeam):
    def __init__(self):
        super(AccountHengDaoShu, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (10, 15)
        self.team_rule = [10] # 这里为空的话，则每次生成队伍人数
        
class AccountCrossBattle(AccountTeam):
    def __init__(self):
        super(AccountCrossBattle, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (1, 15)
        self.team_rule = [3] # 这里为空的话，则每次生成队伍人数
class AccountMaiGuZhiKu(AccountTeam):
    def __init__(self):
        super(AccountMaiGuZhiKu, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (10, 15)
        self.team_rule = [15] # 这里为空的话，则每次生成队伍人数
        
class AccountCrossFriend(AccountTeam):
    def __init__(self):
        super(AccountCrossFriend, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (0, 2)
        self.team_rule = [2] # 这里为空的话，则每次生成队伍人数
    
class AccountYeWai(AccountTeam):
    def __init__(self):
        super(AccountYeWai, self).__init__()
        self.is_loop = True # 账号是否循环
        self.team_num = (1, 5)
        self.team_rule = [5] # 这里为空的话，则每次生成队伍人数

class AccountRealTimeVioce(AccountTeam):
    def __init__(self):
        super(AccountRealTimeVioce, self).__init__()
        self.is_loop = True
        self.team_num = (1, 5)
        self.team_rule = [5]

class AccountYeWaiCampTag():
    def __init__(self):
        self.camp_id = 0
        self.camp_count = 1
#        
    def get_account(self):
        if self.camp_count == 0:
            self.camp_id = (self.camp_id + 1) % 2
        self.camp_count = (self.camp_count + 1) % 15
        return self.camp_id
        
class AccountSkillID(Account):
    def __init__(self):
        super(AccountSkillID, self).__init__()
        self.skill_count_dict = {
                                TIANWANG: 0,
                                TANGMEN: 0,
                                EMEI: 0,
                                TIANREN: 0,
                                WUDANG: 0,
                              }
        self.skill_list_dict = {
                                TIANWANG: self._get_skill_list(TIANWANG),
                                TANGMEN: self._get_skill_list(TANGMEN),
                                EMEI: self._get_skill_list(EMEI),
                                TIANREN: self._get_skill_list(TIANREN),
                                WUDANG: self._get_skill_list(WUDANG),
                            }
        
    def _get_skill_list(self, faction):
        skillList = []
        for originSkill in FACTION_SKILL[faction][1]:
            skillList.append(originSkill)
            if originSkill in SKILL_TALENT:
                skillList += SKILL_TALENT[originSkill]
        return skillList
    
    def get_account(self, faction):
        skill_list = self.skill_list_dict[faction]
        count = self.skill_count_dict[faction] % len(skill_list)
        self.skill_count_dict[faction] += 1
        return skill_list[count]

class AccountKin(Account):
    def __init__(self):
        super(AccountKin, self).__init__()
        self.role_count = 0
        self.kin_role_count = 40#家族招募人数
        self.kin_id = 0
        self.member_count = 0
        self.kin_member_count = 15#家族招募人数
        self.team_id = 0
        self.team_count = 0
        self.team_leader_id = 0
        self.team_member_count = 5#队伍招募人数
    
    def get_account(self, familyId=None):
        if familyId:
            if self.member_count == 0:
                self.kin_id = self.global_attr.get_kin()
                kin_member = 0
            else:
                kin_member = 1
            self.member_count = (self.member_count + 1) % self.kin_member_count
            
            if self.team_count == 0:
                self.team_id = self.global_attr.get_team()
                self.team_leader_id = familyId
                team_member = 1
            else:
                team_member = 2
            self.team_count = (self.team_count + 1) % self.team_member_count
            return kin_member, self.kin_id, self.kin_member_count, team_member, self.team_id, self.team_leader_id, self.team_member_count
        else:
            if self.role_count == 0:
                kin_role = 0
            else:
                kin_role = 1
            self.role_count = (self.role_count + 1) % self.kin_role_count
            return kin_role, self.kin_role_count

class AccountRedPacket(AccountKin):
    def __init__(self):
        super(AccountRedPacket, self).__init__()
        self.kin_role_count = 5#家族招募人数

class AccountKinList(object):   
    def __init__(self):
        self.kin_count = 0#
        
    def get_account(self):
        self.kin_count += 1
        return self.kin_count