# coding:utf-8
__author__ = 'Administrator'


class AccountDef(object):
    ACCOUNT_PRE = 'js'

    # result
    RESULT_OK = 0
    RESULT_FAILED = 1
    RESULT_EXCEPT = 2
    RESULT_EMPTY = 3
    RESULT_FULL = 4
    RESULT_RAND = 5
    
    # team
    TEAM_SINGLE = 0
    TEAM_LEADER = 1
    TEAM_MEMBER = 2
