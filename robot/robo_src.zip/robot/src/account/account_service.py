# coding:utf-8

__author__ = 'Administrator'
from locust.core import remotecall
from account import AccountMgr
    
g_account_mgr = AccountMgr()

@remotecall
def get_account_release():
    return g_account_mgr.account_release.get_release_account()

@remotecall
def free_account_release(account):
    g_account_mgr.account_release.free_release_account(account)

@remotecall
def get_login_account(caseId=None):
    return g_account_mgr.account_login.get_account(caseId)

@remotecall
def free_login_account(caseId, account):
    return g_account_mgr.account_login.free_account(caseId, account)

@remotecall
def account_battle(team_leader_id, serverGroupId):
    return g_account_mgr.account_battle.get_account(team_leader_id, serverGroupId)

@remotecall
def account_yewai(team_leader_id, serverGroupId):
    return g_account_mgr.account_yewai.get_account(team_leader_id, serverGroupId)

@remotecall
def account_skillid(faction):
    return g_account_mgr.account_skillid.get_account(faction)

@remotecall
def account_leaguematch(leader_id, serverGroupId):
    return g_account_mgr.account_leaguematch.get_account(leader_id, serverGroupId)

@remotecall
def account_eatchicken(leader_id, serverGroupId):
    return g_account_mgr.account_eatchicken.get_account(leader_id, serverGroupId)

@remotecall
def account_xiaomijing(leader_id, serverGroupId):
    return g_account_mgr.account_xiaomijing.get_account(leader_id, serverGroupId)

@remotecall
def account_kin(familyId=None):
    return g_account_mgr.account_kin.get_account(familyId)

@remotecall
def account_action():
    return g_account_mgr.account_action.get_account()

@remotecall
def account_hengxujing(team_leader_id, serverGroupId):
    return g_account_mgr.account_hengxujing.get_account(team_leader_id, serverGroupId)

@remotecall
def account_hengdaoshu(team_leader_id, serverGroupId):
    return g_account_mgr.account_hengdaoshu.get_account(team_leader_id, serverGroupId)

@remotecall
def account_yewai_campTag():
    return g_account_mgr.account_yewai_campTag.get_account()

@remotecall
def account_cross_battle(leader_id, serverGroupId):
    return g_account_mgr.account_cross_battle.get_account(leader_id, serverGroupId)

@remotecall
def account_cross_friend(leader_id, serverGroupId):
    return g_account_mgr.account_cross_friend.get_account(leader_id, serverGroupId)

@remotecall
def account_realtime_voice(leader_id, serverGroupId):
    return g_account_mgr.account_realtime_voice.get_account(leader_id, serverGroupId)

@remotecall
def account_redpacket(familyId = None):
    return g_account_mgr.account_redpacket.get_account(familyId)

@remotecall
def account_kinlist():
    return g_account_mgr.account_kinlist.get_account()

@remotecall
def account_maiguzhiku(team_leader_id, serverGroupId):
    return g_account_mgr.account_maiguzhiku.get_account(team_leader_id, serverGroupId)
