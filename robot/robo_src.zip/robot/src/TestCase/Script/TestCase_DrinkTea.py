#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from TestCase.Files.IllegalCaseError import IllegalCaseError
from Tools.Rand import *
from Config.RunConfig import Config
import sys
import time
from TestCase_TeamBase import TeamBaseCase

'''
      喝茶TestCase
'''


class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    #参加类型
    SINGLE = 0
    TEAM = 1
    drink_time=random.randint(8, 12)
    DrinkTea_TIME = drink_time*60
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_TEA, TEAM_TYPE_TEA, u"品茶")
        self.family = family
        self.benterArena = True
        self.beginTime = time.time()
        self.gestureList = [[u'打坐', 2], [u'跳舞', 4], [u'演奏', 5], [u'舞剑', 6], [u'睡觉', 7],
                             [u'飞吻', 8], [u'送花', 9], [u'问好', 10], [u'再见', 11], [u'跪拜', 12]]
        if random.randint(0, 5) > 0:
            self.joinType = TestCase.TEAM
        else:
            self.joinType = TestCase.SINGLE
        self.joinType = TestCase.SINGLE #锁定类型，单人模式
        self.teaTimes=0#领取稀有茶次数

    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_WELFARE_WAIT)
                if self.benterArena:             
                    #茶馆-走到茶馆小二
#                    self.family.gameServerNetPackHandle.PlayerAutoPath()
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, 804, 611, 87)
                    self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            if case(STATE_GS_MOVE_ARRIVAL):
                if self.joinType == TestCase.TEAM:  # 组队
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                else:  # 单人
                    logging.debug("一个人的独饮")
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                break

            if case(STATE_GC_TEAM_RECRUIT_FINISHED):#茶馆小二
                self.family.SetState(STATE_GS_WELFARE_WAIT)
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.AskNpc("贺察")
                self.family.gameServerNetPackHandle.ApplyEnterTeaRoom()#进入茶馆
                self.benterArena = False
                logging.debug('茶室')
                break

            if case(STATE_GS_WELFARE_ENTER_TEAROOM):  #成功进入茶室
                self.family.SetState(STATE_GS_WELFARE_WAIT)
                logging.debug('成功进入茶室')
                #标记测试用例
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Welfare_EnterTeaRoom")
                logging.debug('表情')
                while self.gestureList:
                    gevent.sleep(10)
                    Gesture_num = random.randint(0, len(self.gestureList) - 1)
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(self.gestureList[Gesture_num][0], emChatChannelScene)#喊话
                    self.family.gameServerNetPackHandle.CharacterGesturePlay(self.gestureList[Gesture_num][1])
                    del self.gestureList[Gesture_num]
                break

            if case(STATE_GS_WELFARE_GOOD_TEA):#领取稀有茶品
                self.family.SetState(STATE_GS_WELFARE_WAIT)
                self.family.gameServerNetPackHandle.CharacterGestureStop()
                self.family.gameServerNetPackHandle.ApplyGrabTeaRoomAward()
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Welfare_ApplyTeaAward")
                self.teaTimes+=1
                logging.debug('领取稀有茶品')
                break

            if time.time() - self.beginTime >TestCase.DrinkTea_TIME:
                logging.debug("退出")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Tea_Finish")
                self.family.behavior = Behavior.END