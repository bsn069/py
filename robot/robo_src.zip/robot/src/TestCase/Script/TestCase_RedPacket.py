#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import asyncore
import logging
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Files.Shop import *
from Tools.Rand import *
from Config.RunConfig import Config
from TestCase_TeamBase import TeamBaseCase
from TestCase_KinBase import KinBaseCase
from account.account_service import account_redpacket
from account.account_def import AccountDef

"""
       红包的TestCase         
"""

class TestCase(TeamBaseCase, KinBaseCase):
    def __init__(self, family):
        self.family = family
        role, kin_role_count = account_redpacket()
        role = int(role)
        KinBaseCase.KIN_RECRUIT_NUM = int(kin_role_count)
        TeamBaseCase.__init__(self, family, TEAM_TYPE_FREE, TEAM_TYPE_FREE, u"红包")
        KinBaseCase.__init__(self, family, role)


    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        TeamBaseCase._Action(self)
        KinBaseCase._Action(self)
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_REDPACK_HISTORY_WAIT)
            self.family.gameServerNetPackHandle.Add_Sliver()#建立家族要钱
            self.family.gameServerNetPackHandle.QueryRedPacketHistoryReq()
            self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:GainTitle(78)")  # 添加称号
            return
    
        elif self.family.GetState() == STATE_GS_REDPACK_HISTORY_FINISHED:
            if  self.family.kinMan.id:
                self.family.SetState(STATE_GS_KIN_RECRUIT_FINISH)
            else:
                self.family.SetState(STATE_GS_KIN_BEGIN)
            return

        elif self.family.GetState() == STATE_GS_KIN_RECRUIT_FINISH:
            self.family.SetState(STATE_GC_TEAM_BEGIN)
            return

        elif self.family.GetState() == STATE_GC_TEAM_RECRUIT_FINISHED:
            if random.randint(0, 1000) < 10:
                self.family.SetState(STATE_GS_REDPACKET_SEED)
            else:
                gevent.sleep(1)
            return

        elif self.family.GetState() == STATE_GS_REDPACKET_SEED:
            worldNum = 30
            worldGold = random.randint(worldNum*2, worldNum*10)
            self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,%d,0)" % (worldGold+100))
            self.family.gameServerNetPackHandle.CallScript("PlayerCmd", "ChatBuyCountReq", 1, 2)#购买世界频道聊天次数
            self.family.redpacket.channel = random.choice([emChatChannelWorld, emChatChannelScene, emChatChannelFaction, emChatChannelTeam ])
            self.family.gameServerNetPackHandle.BriberyMoney(worldGold, worldNum, self.family.redpacket.channel, "RedPacket")
            gevent.sleep(30)
            self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
            return





