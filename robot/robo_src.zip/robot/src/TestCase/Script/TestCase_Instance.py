#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
import math
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *

"""
         逐鹿金滩的TestCase
"""

class TestCase(object):
    MINER = 0
    BUSINESSMAN = 1

    def __init__(self, family):
        self.family = family
        self.activityNps = (632, 955, 79)#报名NPC坐标
        self.goldPos = (259, 105, 69)
        self.businessman = {
                            0:(409, 63, 81), #魏员外
                            1:(114, 129,87),#钱七爷
                            2:(198, 55, 80),#何掌柜
                            3:(300, 110, 63),#胡大户
                            }
        self.businessmanId = None
        self.movePath = ()
        self.fightPos = (238, 124, 70)#乱斗地点
        membertypes = {
                     TestCase.MINER : 3,
                     TestCase.BUSINESSMAN : 1,
                     }
        self.memberType = Rand.weighted_choice(membertypes)#根据权重分配人物类型
        self.memberType = TestCase.MINER #锁定
        self.isexit = True
    def Excute(self):
        self._Action()
        
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_GOLD_DEER_START)
#                if self.family.isNewRole:
#                    self.family.gameServerNetPackHandle.BecomeStronger()#穿全部装备
                self.family.gameServerNetPackHandle.Add_Sliver()
                break
            
            elif case(STATE_GS_GOLD_DEER_START):
                self.family.SetState(STATE_GS_MOVE_GO)
                self.movePath = self.activityNps
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.movePath)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                sceneTemplateId = self.family.gameServerNetPackHandle.sceneTemplateId
                if sceneTemplateId == SceneLinan:
                    while self.family.instance.npcId is None:
                        gevent.sleep(1)
                    self.family.gameServerNetPackHandle.AskNpc_obj(self.family.instance.npcId)
                    break
                elif sceneTemplateId == SceneZhuluJinTan:
                    if self.memberType == TestCase.BUSINESSMAN:
                        self.family.SetState(STATE_GS_GOLD_DEER_BUSINESSMAN)
                        break
                    elif self.memberType == TestCase.MINER:
                        self.family.SetState(STATE_GS_GOLD_DEER_MINNER)
                        break
            
            #活动开始
            elif case(STATE_GS_GOLD_DEER_ACTIVITY):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                if random.randint(1, 100) < 5 and self.isexit:
                    self.family.SetState(STATE_GS_GOLD_DEER_END)
                    break
                self.isexit = False
                if self.memberType == TestCase.BUSINESSMAN:
                    self.businessmanId = random.randint(0,len(self.businessman.keys())-1)
                    self.movePath = self.businessman[self.businessmanId]
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                elif self.memberType == TestCase.MINER:
                    self.movePath = self.goldPos
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                
            elif case(STATE_GS_GOLD_DEER_BUSINESSMAN):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                npcId = self.family.instance.getbusinessman()
                if npcId == None:
                    self.movePath = self.businessman[self.businessmanId]
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.family.instance.businessmanDict[npcId]["pos"])
                gevent.sleep(1)
                self.family.gameServerNetPackHandle.Add_Sliver()
                self.family.gameServerNetPackHandle.AskNpc_obj(npcId)
                break
            
            elif case(STATE_GS_GOLD_DEER_SELL):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                list = []
                list = self.businessman.keys().pop(self.businessmanId)
                self.businessmanId = random.sample(list, 1)
                self.movePath = self.businessman[self.businessmanId]
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            #采取金矿
            elif case(STATE_GS_GOLD_DEER_MINNER):
                if self.family.instance.isfight:
                    self.family.SetState(STATE_GS_GOLD_DEER_FIGHT)
                    break
                elif self.family.instance.isend:
                    self.family.SetState(STATE_GS_GOLD_DEER_END)
                    break
                pos = self.family.instance.getgoldDict()
                if pos:
                    nowX = self.family.characterCur.posX
                    nowY = self.family.characterCur.posY
                    if (math.fabs(nowX - pos[0]) < 2 and math.fabs(nowY - pos[1]) < 2):
                        self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                        self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                        break
                    else:
                        self.movePath = pos
                        self.family.SetState(STATE_GS_MOVE_GO)
                        break

            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_GOLD_DEER_MINNER)
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                break 
            
            elif case(STATE_GS_GOLD_DEER_FIGHT):
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                if (math.fabs(nowX - self.fightPos[0]) < 2 and math.fabs(nowY - self.fightPos[1]) < 2):
                    self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                    self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                else:
                    self.movePath = self.fightPos
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                self.family.SetState(STATE_GS_GOLD_DEER_FIGHT)
                break
            
            elif case(STATE_GS_GOLD_DEER_END):
                self.family.SetState(STATE_GS_GOLD_DEER_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_CampWar_Finish")
                self.family.behavior = Behavior.END
                break