#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase


"""
         主线任务的TestCase
"""

MAIN_TASK_MOVE = 1
MAIN_TASK_TALK_TO_NPC = 2
ZHIXIAN_TASK_KUIQIBAOSHI = 30657


class TestCase(TeamBaseCase):
    # sleepTime is sleep second
    def __init__(self, family):
#        super(TestCase, self).__init__(
#            family, TEAM_TYPE_FREE, TEAM_TYPE_MAINTASK, u"主线任务")
        self.family = family  # 当前觉得信息
        self.benterArena = False

        self.moveTo = (0, 0)  # 目的地坐标
        self.taskStep = 0  # 任务步骤
        self.mainTaskIndex = 0  # 主线任务索引
        self.currentTaskId = 0  # 当前任务索引
        # 单人副本id
        self.missionId = 0  # 副本id
        self._InitMaintask()  # 初始化主线任务

    def _InitMaintask(self):
        for case in switch(self.family.GetCurCharacter().faction):
            # Task_YingSheXianSuo = 10150   #影社线索
            if case(TIANWANG):  # 天王
                Task_Tongmenqingshen1 = 10160
                Task_Yanzhixiang1 = 10038
                Task_Chunfenglou1 = 10121
                Task_LinAnFengMao1 = 10028
                Tesk_DaDiaoZhengShi1 = 10141
                break
            if case(TANGMEN):  # 唐门
                Task_Tongmenqingshen1 = 10161
                Task_Yanzhixiang1 = 10039
                Task_Chunfenglou1 = 10122
                Task_LinAnFengMao1 = 10029
                Tesk_DaDiaoZhengShi1 = 10142
                break
            if case(EMEI):  # 峨眉
                Task_Tongmenqingshen1 = 10162
                Task_Yanzhixiang1 = 10040
                Task_Chunfenglou1 = 10123
                Task_LinAnFengMao1 = 10030
                Tesk_DaDiaoZhengShi1 = 10143
                break
            if case(TIANREN):  # 天忍
                Task_Tongmenqingshen1 = 10163
                Task_Yanzhixiang1 = 10041
                Task_Chunfenglou1 = 10124
                Task_LinAnFengMao1 = 10031
                Tesk_DaDiaoZhengShi1 = 10144
                break
            if case(WUDANG):  # 武当
                Task_Tongmenqingshen1 = 10164
                Task_Yanzhixiang1 = 10042
                Task_Chunfenglou1 = 10125
                Task_LinAnFengMao1 = 10032
                Tesk_DaDiaoZhengShi1 = 10145
                break
            if case():
                raise "[Main task] faction error!"

        self.MainTaskDict = (
            # 需要重设RoleFigures中的任务值（已经重设）
            # 1初至临安
            (Task_ChuZhiLinAn, [
                [self.DoMoveTo, 750, 359],
                [self.AddTaskValue, Task_ChuZhiLinAn, Task_ChuZhiLinAn, 247, 1],
                [self.FinishTaskScript, Task_ChuZhiLinAn]
            ]
            ),
            # 2酒肆风波
            (Task_Jiusifengbo, [
                [self.DoAcceptTask, Task_Jiusifengbo],
                [self.DoMoveTo, 751, 441],
                [self.DoSingleMission, 1011],
                [self.DoMoveTo, 751, 441],
                [self.AddTaskValue, Task_Jiusifengbo, 10150, 161, 1],
                [self.FinishTaskScript, Task_Jiusifengbo],
            ]
            ),

            # 3探听风声
            (Task_Tantingfengsheng, [
                [self.DoAcceptTask, Task_Tantingfengsheng],
                [self.DoMoveTo, 745, 442],
                [self.AddTaskValue, Task_Tantingfengsheng, 10136, 162, 1],
                [self.DoMoveTo, 748, 444],
                [self.AddTaskValue, Task_Tantingfengsheng, 10181, 163, 1],
                [self.DoMoveTo, 745, 450],
                [self.AddTaskValue, Task_Tantingfengsheng, 10182, 164, 1],
                [self.FinishTaskScript, Task_Tantingfengsheng],
            ]
            ),

            # 4一醉方休
            (Task_Yizuifangxiu, [
                [self.DoAcceptTask, Task_Yizuifangxiu],
                [self.DoMoveTo, 746, 451],
                [self.meijiu],
                [self.FinishTaskScript, Task_Yizuifangxiu],
            ]
            ),

            # 5同门情深
            (Task_Tongmenqingshen, [
                [self.DoAcceptTask, Task_Tongmenqingshen],
                [self.DoMoveTo, 771, 452],
                [self.AddTaskValue, Task_Tongmenqingshen, Task_Tongmenqingshen, 239, 1],
                [self.DoMoveTo, 775, 455],
                [self.AddTaskValue, Task_Tongmenqingshen, Task_Tongmenqingshen1, 241, 1],
                [self.SetUpFiretrousers], #鉴定衣服
                [self.FinishTaskScript, Task_Tongmenqingshen],
            ]
            ),

            # 6胭脂巷
            (Task_Yanzhixiang, [
                [self.DoAcceptTask, Task_Yanzhixiang],
                [self.DoMoveTo, 768, 471],
                [self.AddTaskValue, Task_Yanzhixiang, 10001, 248, 1],
                [self.DoMoveTo, 804, 487],
                [self.AddTaskValue, Task_Yanzhixiang, 10002, 249, 1],
                [self.DoMoveTo, 817, 488],
                [self.AddTaskValue, Task_Yanzhixiang, Task_Yanzhixiang1, 250, 1],
                [self.FinishTaskScript, Task_Yanzhixiang],
            ]
            ),

            # 7游戏
            (Task_Youxi, [
                [self.DoAcceptTask, Task_Youxi],
                [self.DoMoveTo, 840, 475],
                [self.AddTaskValue, Task_Youxi, 10102, 160, 1],
                [self.DoMoveTo, 851, 457],
                [self.AddTaskValue, Task_Youxi, 10111, 11028, 1],  # 雷霆NPC
                [self.keepsleep, 60],
                [self.DoMoveTo, 842, 476],
                [self.FinishTaskScript, Task_Youxi],
            ]
            ),

            # 8春风楼
            (Task_Chunfenglou, [
                [self.DoAcceptTask, Task_Chunfenglou],
                [self.DoMoveTo, 841, 476],
                [self.DoSingleMission, 1013],
                [self.AddTaskValue, Task_Chunfenglou, 10044, 160, 1],
                [self.DoMoveTo, 749, 519],
                [self.AddTaskValue, Task_Chunfenglou, Task_Chunfenglou1, 198, 1],
                [self.FinishTaskScript, Task_Chunfenglou],
            ]
            ),

            # 9茶楼一聚
            (Task_Chalouyiju, [
                [self.DoAcceptTask, Task_Chalouyiju],
                [self.DoMoveTo, 748, 522],
                [self.AddTaskValue, Task_Chalouyiju, 10103, 60, 1],
                [self.DoMoveTo, 787, 599],
                [self.FinishTaskScript, Task_Chalouyiju],
            ]
            ),
            # 10燕子风波
            (Task_Yanzifengbo, [
                [self.DoAcceptTask, Task_Yanzifengbo],
                [self.DoMoveTo, 791, 609],
                [self.AddTaskValue, Task_Yanzifengbo, Task_Yanzifengbo, 246, 1],
                [self.DoMoveTo, 785, 630, 100],
                [self.fengzheng],
                [self.DoMoveTo, 790, 609],
                [self.AddTaskValue, Task_Yanzifengbo, 10114, 246, 1],
                [self.FinishTaskScript, Task_Yanzifengbo],
            ]
            ),   
            # 11好茶风波
            (Task_TianShengHaoCha, [
                [self.DoAcceptTask, Task_TianShengHaoCha],
                [self.DoMoveTo, 794, 595],
                [self.AddTaskValue, Task_TianShengHaoCha, Task_TianShengHaoCha, 251, 1],
                [self.DoMoveTo, 815, 595],
                [self.AddTaskValue, Task_TianShengHaoCha, 10007, 252, 1],
                [self.DoMoveTo, 813, 606],
                [self.AddTaskValue, Task_TianShengHaoCha, 10008, 253, 1],
                [self.DoMoveTo, 792, 610],
                [self.AddTaskValue, Task_TianShengHaoCha, 10009, 246, 1],
                [self.FinishTaskScript, Task_TianShengHaoCha],
            ]
            ),      
            # 11秘密据点
            (Task_MiMiJuDian, [
                [self.DoAcceptTask, Task_MiMiJuDian],
                [self.DoMoveTo, 786, 610],
                [self.AddTaskValue, Task_MiMiJuDian, Task_MiMiJuDian, 340, 1],
                [self.DoMoveTo, 679, 651, 91],
                [self.DoMoveTo, 683, 661],
                [self.AddTaskValue, Task_MiMiJuDian, 10110, 5, 1],
                [self.FinishTaskScript, Task_MiMiJuDian],
            ]
            ),
            # 12屡遭查禁
            (Task_LvZaoChaJin, [
                [self.DoAcceptTask, Task_LvZaoChaJin],
                [self.DoMoveTo, 708, 617, 117],
                [self.keepsleep, 10],
                [self.DoMoveTo, 725, 633, 125],
                [self.keepsleep, 10],
                [self.DoSingleMission, 1014],
                [self.FinishTaskScript, Task_LvZaoChaJin],
            ]
            ),    
            # 13临安风貌     
            (Task_LinAnFengMao, [
                [self.DoAcceptTask, Task_LinAnFengMao],
                [self.DoMoveTo, 712, 645, 125],
                [self.AddTaskValue, Task_LinAnFengMao, Task_LinAnFengMao, 255, 1],
                [self.keepsleep, 20],
                [self.DoMoveTo, 684, 662, 94],
                [self.AddTaskValue, Task_LinAnFengMao, Task_LinAnFengMao1, 5, 1],
                [self.FinishTaskScript, Task_LinAnFengMao],
            ]
            ),        
#            # 14故人相逢  
#            (Task_GuRenXiangFeng, [
#                [self.DoAcceptTask, Task_GuRenXiangFeng],
#                [self.DoMoveTo, 671, 657, 91],
#                [self.AddTaskValue, Task_GuRenXiangFeng, Task_GuRenXiangFeng, 165, 1],
#                [self.DoMoveTo, 693, 641, 91],
#                [self.liangcao],
#                [self.DoMoveTo, 640, 640, 91],
#                [self.putdown_liangcao],
#                [self.DoMoveTo, 636, 637, 91],
#                [self.AddTaskValue, Task_GuRenXiangFeng, 10105, 166, 1],
#                [self.DoMoveTo, 672, 658, 91],
#                [self.AddTaskValue, Task_GuRenXiangFeng, 10106, 165, 1],
#                [self.FinishTaskScript, Task_GuRenXiangFeng],
#            ]
#            ),  
#            # 15大雕争食
#            (Tesk_DaDiaoZhengShi, [
#                [self.DoAcceptTask, Tesk_DaDiaoZhengShi],
#                [self.DoMoveTo, 634, 660, 91],
#                [self.AddTaskValue, Tesk_DaDiaoZhengShi, Tesk_DaDiaoZhengShi, 264, 1],
#                [self.DoMoveTo, 648, 662, 91],
#                [self.dadiao],
#                [self.DoMoveTo, 655, 660, 91],
#                [self.dadiao],
#                [self.DoMoveTo, 662, 657, 91],
#                [self.dadiao],
#                [self.DoMoveTo, 662, 657, 91],
#                [self.AddTaskValue, Tesk_DaDiaoZhengShi, Tesk_DaDiaoZhengShi1, 165, 1],
#                [self.FinishTaskScript, Tesk_DaDiaoZhengShi],
#            ]
#            ),        
        )

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """

    def _Action(self):
#        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.gameServerNetPackHandle.ClearItemRoom()
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            if case(STATE_GS_MAIN_TASK_START):
                self.family.SetState(STATE_GS_MAIN_TASK_WAIT)
                if self.mainTaskIndex < len(self.MainTaskDict):
                    self.currentTaskId = self.MainTaskDict[self.mainTaskIndex][0]
                else:  # 完成已设置任务
                    self.family.behavior = Behavior.END
                    logging.debug("完成已设置任务")
                    self.family.gameServerNetPackHandle.MarkTestCase(
                        "TestCase_Maintask_Finish")
                    self.family.SetState(STATE_GS_PLAYING)
                    return

                if self.taskStep < len(self.MainTaskDict[self.mainTaskIndex][1]):
                    # 进行任务下一步操作
                    self.MainTaskDict[self.mainTaskIndex][1][self.taskStep][0](
                        *tuple(self.MainTaskDict[self.mainTaskIndex][1][self.taskStep][1:]))
                    self.taskStep += 1
                else:
                    self.taskStep = 0
                    self.mainTaskIndex += 1
                    self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            # 到达任务点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            if case(STATE_GS_MAIN_TASK_SYNC):
                if self.family.maintaskMan.GetMaintaskTaskID() == self.currentTaskId:
                    self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            if case(STATE_GS_MAIN_TASK_FINISHED):
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            # 结束单人副本战斗
            if case(STATE_GS_END_SINGLE_MISSION):
                self.family.SetState(STATE_GS_MAIN_TASK_WAIT)
                logging.debug("结束单人副本战斗")
                self.family.gameServerNetPackHandle.Do_EndSingleMission(self.missionId)
                self.family.gameServerNetPackHandle.LeaveSingleMission()
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            if case(STATE_GS_MAIN_TRANSFER_MAP):
                if self.family.gameServerNetPackHandle.sceneTemplateId == SceneYaoWangGu:
                    self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            # 组队完成
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            # 采集道具
            if case(STATE_GS_COLLECT_OBJECT):
                if self.family.graveDigger.tianxiangyuluId != None:
                    logging.debug("采集道具")
                    self.family.gameServerNetPackHandle.AskNpc_obj(
                        self.family.graveDigger.tianxiangyuluId)
                    self.family.graveDigger.tianxiangyuluId = None
                    gevent.sleep(8)
                break

            #　放技能
            if case(STATE_GS_LEAGUEMATCH_SKILL):
                logging.debug("放技能")
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.Do_CastSkill(
                    None, random.choice(self.family.gameServerNetPackHandle.attackList))
                break

            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                if self.family.isKillBossOver == True:
                    logging.debug("继续其他任务")
                    self.family.SetState(STATE_GS_MAIN_TASK_START)
                else:
                    self.family.gameServerNetPackHandle.SkillCanBeReleased(
                        self.family.skill.skillReleaseList)
                break
            
            if case(STATE_GS_NOVICE_MISSION_STARTING):
                self.family.SetState(STATE_GS_NOVICE_MISSION_WAIT)
                begin = time.time()
                noviceScene = 1000
                # 获得技能准备跳跃
                self.family.gameServerNetPackHandle.OpenModuleById(63)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 1)
                gevent.sleep(random.randint(1,3))
                # 跳跃1次落地
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 1.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 0)
                gevent.sleep(random.randint(1,3))
                # 飞两次
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 2)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 1.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 2.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 0)
                gevent.sleep(random.randint(1,3))
                # 获得技能打死野狼
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 3)
                self.family.gameServerNetPackHandle.OpenModuleById(61)
                gevent.sleep(random.randint(3,10))
                # 二段跳到悬崖底部
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 4)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 1.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 2.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 0)
                gevent.sleep(random.randint(1, 3))
                # 大雕带我上悬崖
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 5)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 6.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 0)
                gevent.sleep(random.randint(1, 3))
                # 做完大雕，到了打最后小怪和boss的地方
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 6)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 1.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 2.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 7.0)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogQinggongStage", 0)
                gevent.sleep(random.randint(3, 5))
                # 打Boss
                self.family.gameServerNetPackHandle.OpenModuleById(10)
                self.family.gameServerNetPackHandle.OpenModuleById(9)
                self.family.gameServerNetPackHandle.OpenModuleById(7)
                self.family.gameServerNetPackHandle.CallScript("LogCmd", "LogNoviceAction", noviceScene, 9)
                gevent.sleep(random.randint(5, 10))
                # 结束副本
                self.family.gameServerNetPackHandle.Do_EndSingleMission(1000, missionTime=int(time.time() - begin))
                self.family.gameServerNetPackHandle.LeaveSingleMission()
                break

    def meijiu(self):  # 采集香兰
        while self.family.maintaskMan.ismeijiu == False:
            while self.family.maintaskMan.meijiuId == None:
                gevent.sleep(2)
            logging.debug("再来一杯")
            self.moveTo = (self.family.maintaskMan.meijiuIdX,
                           self.family.maintaskMan.meijiuIdY)
            self.family.gameServerNetPackHandle.GM_MoveToPosition(
                False, *self.moveTo)
            self.family.gameServerNetPackHandle.AskNpc_obj(
                self.family.maintaskMan.meijiuId)
            gevent.sleep(8)
        self.family.SetState(STATE_GS_MAIN_TASK_START)
        
    def fengzheng(self):  # 风筝
        while self.family.maintaskMan.fengzhengId == None:
            gevent.sleep(2)
        logging.debug("风筝")
        self.moveTo = (self.family.maintaskMan.fengzhengX,
                       self.family.maintaskMan.fengzhengY)
        self.family.gameServerNetPackHandle.GM_MoveToPosition(
            False, *self.moveTo)
        self.family.gameServerNetPackHandle.AskNpc_obj(
            self.family.maintaskMan.fengzhengId)
        gevent.sleep(8)
        self.family.SetState(STATE_GS_MAIN_TASK_START)
        
    def liangcao(self):  # 搬运粮草
        while self.family.maintaskMan.liangcaoId == None:
            gevent.sleep(2)
        logging.debug("收集粮草")
        self.moveTo = (self.family.maintaskMan.liangcaoX,
                       self.family.maintaskMan.liangcaoY)
        self.family.gameServerNetPackHandle.GM_MoveToPosition(
            False, *self.moveTo)
        self.family.gameServerNetPackHandle.AskNpc_obj(
            self.family.maintaskMan.liangcaoId)
        gevent.sleep(10)
        self.family.SetState(STATE_GS_MAIN_TASK_START)

    def putdown_liangcao(self):
        gevent.sleep(5)
        self.family.gameServerNetPackHandle.CallScript("TaskCmd", "OnTransportArrive")
        self.family.SetState(STATE_GS_MAIN_TASK_START)


    def DoMoveTo(self, posX, posY, posZ = 0):  # 移动
        self.moveTo = (posX, posY, posZ)
        self.family.SetState(STATE_GS_MOVE_MOVING)
        if (posX == 785 and posY == 630) or (posX == 790 and posY == 609):#飞上屋顶
            self.family.gameServerNetPackHandle.GM_MoveToPosition(
                False, posX, posY, posZ)
            self.family.SetState(STATE_GS_MOVE_ARRIVAL)

        else:
            self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveTo)
#            self.family.gameServerNetPackHandle.GM_MoveToPosition(False, posX, posY, posZ)            
#            self.family.SetState(STATE_GS_MOVE_ARRIVAL)


    def DoAcceptTask(self, task_id):  # 接收任务
        self.family.gameServerNetPackHandle.Do_AcceptTask(task_id)
        gevent.sleep(3)
        self.family.SetState(STATE_GS_MAIN_TASK_START)

    def FinishTaskScript(self, taskid):
        self.family.gameServerNetPackHandle.CallScript("TaskCmd", "ApplyFinishTask", taskid)
        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_" + str(taskid))

    def AddTaskValue(self, taskId, stepId, extId, value):  # 设定步骤任务值，主线ID，任务步骤ID
        self.family.gameServerNetPackHandle.Do_ApplySetTaskStepValue(
            taskId, stepId, extId, value)  # 应用添加任务值
        self.family.SetState(STATE_GS_MAIN_TASK_START)

    def callscript(self, taskId):  # 设定任务步骤值
        self.family.gameServerNetPackHandle.CallScript(
            "LogCmd", "LogMainTaskLog", taskId)  # 应用添加任务值
        self.family.SetState(STATE_GS_MAIN_TASK_START)

    def DoSingleMission(self, missionId):  # 进入副本
        self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
        self.missionId = missionId
        self.family.gameServerNetPackHandle.Do_StartSingleMission(
            missionId)  # 进入精英副本

    def SetUpFiretrousers(self):  # 鉴定衣服
        while self.family.maintaskMan.isequip == False: 
            gevent.sleep(5)
        p = self.family.GetCurCharacter().faction
        q = 100 + p  # 从900开始是因为未鉴定裤子GDPL中的P值
        name = "5_22_FactionId_1" 
        str_num = str(q)
        gdpl = name.replace('FactionId', str_num)
        gevent.sleep(5)
        itemId = random.choice(self.family.bag.consumeBag[gdpl][True].keys())
        slotPosition = self.family.bag.consumeBag[gdpl][True][itemId]["slotPosition"]
        gevent.sleep(5)
        self.family.gameServerNetPackHandle.PutOn_BagEuqipment(
            slotPosition, itemId, memberType=1)
        self.family.SetState(STATE_GS_MAIN_TASK_START)
    
    def keepsleep(self, number):
        gevent.sleep(number)
        self.family.SetState(STATE_GS_MAIN_TASK_START)
        

    def dadiao(self):
        while len(self.family.maintaskMan.yingcaoId) != 3:
            self.family.gameServerNetPackHandle.force_sync_player()
            gevent.sleep(5)
        logging.debug("喂食大雕")
        for i in range(len(self.family.maintaskMan.yingcaoId)):
            self.family.gameServerNetPackHandle.AskNpc_obj(
                self.family.maintaskMan.yingcaoId[i])
            gevent.sleep(15)
        self.family.SetState(STATE_GS_MAIN_TASK_START)