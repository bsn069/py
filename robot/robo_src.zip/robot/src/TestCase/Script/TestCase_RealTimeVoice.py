#!/usr/bin/env python2.7
# coding:utf-8
import gevent
import random
from locust.asyncevent import asyncresult_manager
from locust.events import request_failure
from net.Common.ComDefine_pb2 import ChatRoom_Kin, ChatRoom_Team
from net.ProtoBuffer.ComProtocol_pb2 import TEAM_TYPE_FREE
from ModuleState.StateDefine import *
from Tools.GenerateChinese import generate_chinese
from Tools.Rand import Rand
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from TestCase_KinBase import  KinMemberType
from account.account_service import account_realtime_voice
from account.account_def import AccountDef


"""
        实时语音的TestCase
         
"""

class TestCase(TeamBaseCase):
    CHAT_ROOM = {
            ChatRoom_Kin:25,
            ChatRoom_Team : 1,
        }
    KIN_MEMBER_TYPE = {
            KinMemberType.LEADER  : 1,
            KinMemberType.MEMBER : 5,
        }
    LONG_TIME = 9999
    def __init__(self, family):
        self.family = family
        self.isfirst = True
        self.canEnter = False
        self.chat_room = Rand.weighted_choice(TestCase.CHAT_ROOM)
#        self.chat_room = ChatRoom_Kin
            
        if self.chat_room == ChatRoom_Team:
            super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_FREE, u"实时语音", teamCreateType=TeamCreateType.FIXED)
            (result,
             self.family.team_manager.myteam.accountId,
             self.family.team_manager.myteam.leaderFamilyId,
             self.family.team_manager.myteam.memberLimit,
             self.member_type,
             self.family.team_manager.myteam.leadergroupid) = account_realtime_voice(self.family.familyId, self.family.serverGroupId)
            if result == AccountDef.RESULT_EMPTY:
                request_failure.fire(request_type='get', name="[RealTimeVoice Account Empty]", response_time=0, exception="Account Empty")
                asyncresult_manager.wait(self, "AccountEmpty", 99999999999)

        

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):   
        if self.chat_room == ChatRoom_Team:
            super(TestCase, self)._Action()        
        if self.family.GetState() == STATE_GS_PLAYING:
            if self.isfirst:    
                self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "me:AddSilver(50000000, 1);")
            if self.family.kinMan.id:#如果在家族中需要先离开家族
                self.family.kinMan.needLeaveKin = True
                if self.family.kinMan.isLeader:
                    self.family.SetState(STATE_GS_KIN_DISMISS)
                return
            if self.chat_room == ChatRoom_Kin:
                self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_WAIT)
            elif self.chat_room == ChatRoom_Team:
                self.family.SetState(STATE_GS_REALTEAMVOICE_TEAM_WAIT)
            return
             
        #家族聊天室处理
        elif self.family.GetState() == STATE_GS_REALTEAMVOICE_KIN_WAIT:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            name = generate_chinese(5)
            self.family.gameServerNetPackHandle.Do_CreateKin(name)
            return
        
        elif self.family.GetState() == STATE_GS_KIN_UPGRADE:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            self.family.gameServerNetPackHandle.ChatRoomEnterRoom(self.family.kinMan.id, 1)
            return 
                                
        elif self.family.GetState() == STATE_GS_REALTEAMVOICE_KIN_OPEN_ENTER:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            self.family.gameServerNetPackHandle.ChatRoomChangeEnterOpen(self.family.kinMan.id, True)
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_RealTimeVoice_KinRoom_Created")
            self.role = Rand.weighted_choice(TestCase.KIN_MEMBER_TYPE)
#             self.role = KinMemberType.LEADER#固定为队员
            return                   
        
        elif self.family.GetState() == STATE_GS_REALTEAMVOICE_KIN_LEADER:
            if self.role == KinMemberType.LEADER:        
                self.MemberClean()
                self.ChatRoomOpenSpeak()
                self.RecruitChatRoomMember()
                gevent.sleep(10)
            else:
                self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_MEMBER)            
            return
        
        elif self.family.GetState() == STATE_GS_REALTEAMVOICE_KIN_MEMBER:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            if self.family.chatroom.roomId:
                self.family.gameServerNetPackHandle.ChatRoomLeaveRoom(self.family.chatroom.roomId)
            if self.family.chatroom.newRoomId:
                self.family.gameServerNetPackHandle.ChatRoomEnterRoom(self.family.chatroom.newRoomId, 1)
            else:
                self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_MEMBER)
                gevent.sleep(1)
            return
        
        elif self.family.GetState() ==  STATE_GS_KIN_DISMISS:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            self.family.gameServerNetPackHandle.Do_ApplyDismissKin()
            return 
        
        elif self.family.GetState() == STATE_GS_KIN_LEAVE_FINISH:
            self.family.SetState(STATE_GS_PLAYING)
            self.family.gameServerNetPackHandle.CallScriptGmDoCommand("KGameSwitch.SetDebug(2,False);")#清除家族退出CD
            return
            
        #队伍处理
        elif self.family.GetState() == STATE_GS_REALTEAMVOICE_TEAM_WAIT:
            self.family.SetState(STATE_GC_TEAM_BEGIN)
            return

        elif self.family.GetState() == STATE_GC_TEAM_RECRUIT_FINISHED:
            self.family.SetState(STATE_GS_REALTEAMVOICE_WAIT)
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_RealTimeVoice_Team_Finish")
            gevent.sleep(TestCase.LONG_TIME)
            return
        
    def ChatRoomOpenSpeak(self):
        if self.family.chatroom.memberDict:
            memberlist = random.sample(self.family.chatroom.memberDict.keys(), random.randint(1, len(self.family.chatroom.memberDict.keys())))
            if self.family.familyId in memberlist:
                memberlist.remove(self.family.familyId)
            if len(memberlist)>0:
                self.family.gameServerNetPackHandle.ChatRoomChangeSpeakOpen(self.family.kinMan.id, random.choice(memberlist), True) #上麦
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.ChatRoomChangeSpeakOpen(self.family.kinMan.id, random.choice(memberlist), False) #下麦
            
    def MemberClean(self):
        self.family.gameServerNetPackHandle.ChatRoomKickMember(self.family.kinMan.id)             #移除所有访客
            
    def RecruitChatRoomMember(self):
        msg = "RealTimeVoice:%d" % self.family.kinMan.id
        self.family.gameServerNetPackHandle.ChatRequestByMsg(msg)
