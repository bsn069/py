#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
import math
from ModuleState.StateDefine import *
# from Tools.JxLog import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Config.CaseDefine import *
from account.account_def import AccountDef
from account.account_service import account_action
from net.Common.ComDefine_pb2 import *

class Action:
    LONGWU = 1
    DUGUJIAN = 2
    BAIQIULIN = 3
    JIAGAOMING = 4
    CHUSHENGDIAN = 5

class TestCase:    
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.taskIndex = 0
        self.isLoop = 1
        self.isFirst = True
        self.task = None
        self.tasks = []
        self.actions = {
            Action.CHUSHENGDIAN :
            [
             (self.Move, (232.83, 313.22)),
             (self.Move, (238.76, 331.74)),
             (self.Reset,()),
            ],
            Action.LONGWU : 
            [
             (self.Move, (257.57, 209.68)),
             (self.Move, (273.46, 203.10)),
             (self.Reset,()),
            ],
            Action.DUGUJIAN : 
            [
             (self.Move, (307.19, 197.67)),
             (self.Move, (306.83, 186.38)),
             (self.Reset,()),
            ],
            Action.BAIQIULIN : 
            [
             (self.Move, (264.22, 168.00)),
             (self.Move, (271.79, 174.01)),
             (self.Move, (268.37, 179.38)),
             (self.Reset,()),
            ],
            Action.JIAGAOMING:
            [
             (self.Move, (166.10, 419.88)),
             (self.Skill,(166.10, 419.88)),
            ]
        }
        if False:
            account = account_action()
            logging.debug("RandomMove account = %s" % account)
            self.tasks = self.actions[int(account)]
        else:
#            self.task = random.Choice(self.ACTIONS.values())
            self.tasks = self.actions[Action.JIAGAOMING]
            
    def Move(self, x, y):
        self.family.SetState(STATE_GS_MOVE_MOVING)
        self.family.gameServerNetPackHandle.PlayerAutoPath(x, y)
#         self.family.gameServerNetPackHandle.GM_MoveToPosition(False, x, y)
#         gevent.sleep(2)
#         self.family.SetState(STATE_GS_MOVE_ARRIVAL)
        
    def Skill(self, x, y):
        self.family.SetState(STATE_GS_SKILLTEST_WAIT)
        self.skil_pos = (x, y)
        self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))

    def Reset(self):
        self.taskIndex = 0
        
    def GetNewSkillPos(self):
        alpha = 2 * math.pi * random.random()
        # random radius
        r = 6 * random.random()
        # calculating coordinates
        x = r * math.cos(alpha) + self.skil_pos[0]
        y = r * math.sin(alpha) + self.skil_pos[1]
        return (x, y)

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                if self.isFirst:#特殊需求（仅执行一次）
                    self.isFirst = False
                    gevent.spawn(self.family.gameServerNetPackHandle.LoopChat)#持续喊话
                    memberType = 1
                    self.family.gameServerNetPackHandle.RandomAvatar(memberType)#穿时装
#                     gevent.spawn(self.family.gameServerNetPackHandle.LoopWearMiJi)#穿秘籍
                    self.family.gameServerNetPackHandle.BecomeStronger(memberType)#穿全部装备
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(1, 70), memberType)#随机等级、装备和升星
                    gevent.sleep(5)
                    self.family.SetState(STATE_GS_RANDOMMOVE_LINEINFO)
                break
            
            if self.family.GetState() == STATE_GS_RANDOMMOVE_LINEINFO:
                self.family.SetState(STATE_GS_RANDOMMOVE_WAIT)
                gevent.sleep(1)
                self.family.gameServerNetPackHandle.Get_LineInfo()#获取分线信息309
                break
                
                
            if self.family.GetState() == STATE_GS_LINE_LIST:
                self.family.SetState(STATE_GS_LINE_LIST_WAIT)
                self.family.gameServerNetPackHandle.Get_LineList()#请求线路列表310
                break
            
            if self.family.GetState() == STATE_GS_LINE_SWITCH:#换线
                self.family.SetState(STATE_GS_LINE_SWITCH_WAIT)
                hotLineId = self.family.lineInfo.GetHotlineId(maxPlayerCount=150)
                curLineId = self.family.lineInfo.GetCurLineId()
                if hotLineId is None or curLineId is None:
                    self.family.SetState(STATE_GS_RANDOMMOVE_LINEINFO)
                else:
                    if hotLineId == curLineId:
                        self.family.SetState(STATE_GS_MAIN_TASK_START)
                    else:
                        self.family.gameServerNetPackHandle.Switch_SceneLine(hotLineId)
                break
            
            if case(STATE_GS_LINE_SWITCH_SUCCESS): #换线成功
                self.family.SetState(STATE_GS_LINE_SWITCH_SUCCESS)
                break
            
            if case(STATE_GS_MAIN_TASK_START):
                self.task, args = self.tasks[self.taskIndex]
                self.task(*args)
                break
            
            if case(STATE_GS_MOVE_ARRIVAL):

                self.taskIndex += 1
                self.family.SetState(STATE_GS_MAIN_TASK_START)
                break

            #技能后的移动
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                logging.debug("技能后的移动")
                gevent.sleep(1.5)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *(self.GetNewSkillPos()))
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                break
                