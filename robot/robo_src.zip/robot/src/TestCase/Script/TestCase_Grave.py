# coding:utf-8
#!/usr/bin/env python2.7

import random
import gevent
import asyncore
import logging
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Files.Shop import *
from Tools.Rand import *
from Config.RunConfig import Config
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from TestCase_LimitedAuction import LimitedAuction
from account.account_service import account_maiguzhiku
from account.account_def import AccountDef

"""
            埋骨之窟
"""

class TestCase(TeamBaseCase, LimitedAuction):
    def __init__(self, family):
        self.family = family
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE_BIG, TEAM_TYPE_FREE_BIG, u"埋骨", teamCreateType=TeamCreateType.FIXED)
        LimitedAuction.__init__(self,family)
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_maiguzhiku(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[Leaguage Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
            
        self.firstJoin = True
        self.pickGrass = False
        self.gmMove = True
        self.hasSetPostRoomPos = False
        self.moveTarget = {
                           'id' : 0,
                           'pos' : (0, 0),
                           }
        self.posDict = {#为得到夜光草位置推送的循环移动坐标
                        1 : [(147, 48), (161, 20), (133, 57)],
                        2 : [(51, 182), (11, 179), (20.9, 183.6)],
                        3 : [(200, 135), (244, 126), (214, 125)]
                        }
        self.postPosDict = {#移动至机关柱子房间的坐标
                            1 : (126.9, 117.0),
                            2 : (108.6, 157.6),
                            3 : (155.4, 170.8)
                            }
        self.postNameList = ["机关【壹】", "机关【贰】", "机关【叁】", "机关【肆】", "机关【伍】", "机关【陆】", "机关【柒】", "机关【捌】", "机关【玖】"]
        self.roomId = 0#所进入的家族周末关卡的房间 
        

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        super(TestCase, self)._Action()
        LimitedAuction._Action(self)
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            if self.firstJoin:
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("Grave:SetLeftCount(me, 2)")#设置埋骨活动次数
                self.family.grave.memberIdList.append(self.family.familyId)
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_TEAM)

        elif self.family.GetState() == STATE_GS_SINGLE_MISSION_RELEASE_SKILLS:  #放技能
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            self.family.gameServerNetPackHandle.SkillCanBeReleased()
            
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_TEAM:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            self.family.gameServerNetPackHandle.Transfer2Map(SenceMoXiangJu)#调转到准备场
            return
        
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_MOXIANGJU:
            self.family.SetState(STATE_GC_TEAM_BEGIN)
            self.family.gameServerNetPackHandle.GM_MoveToPosition(False, 36, 52, 93) #移动到NPC地点
            return
        
        elif self.family.GetState() == STATE_GC_TEAM_RECRUIT_FINISHED:
            self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
            if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
            return
            
        elif self.family.GetState() == STATE_GC_TEAM_MEMBER_CALL_FINISHED:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME)
            return
        
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            self.family.gameServerNetPackHandle.EnterKinWeekGame()
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Grave_Enter_MaiGuZhiKu")
            return
        
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_FLOWER:
            self.roomId = self.family.grave.GetWeekRoomId()
            self.moveTarget['pos'] = self.posDict[self.roomId][0]  
            self.family.gameServerNetPackHandle.ChatRequestByMsg(msg="GroveRoomId:%s" % self.roomId, channel=3)
            self.family.SetState(STATE_GS_MOVE_GO)
            
        
        #移动
        elif self.family.GetState() == STATE_GS_MOVE_GO:
            if self.gmMove:#解开柱子的触发需要普通移动
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveTarget['pos'])
            else:
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveTarget['pos'])

        
        elif self.family.GetState() == STATE_GS_MOVE_ARRIVAL:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            gevent.sleep(2)
            if self.family.grave.target == KinTargetTwo:
                logging.debug("移动到敌人位置了，搞个GM指令冷静一下！！！！！")
                self.gmMove = False
                self.family.gameServerNetPackHandle.GM_GetNpcKill(self.moveTarget['id'])
                gevent.sleep(1)
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_KILL)
                return
            elif self.family.grave.target == KinTargetThree:
                if not self.hasSetPostRoomPos:
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ENTER)
                    return
                if self.moveTarget['id']:
                    logging.debug("已移动到机关柱子旁~")
                    return
                else:
                    logging.debug("已移动到机关柱子房间~")
                    self.moveTarget = {'id' : 0, 'pos' : (0, 0)}
                    gevent.sleep(5)
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST)
                    return
            elif self.family.grave.target == KinTargetEnd:
                logging.debug("移动到Boss制尸者位置了，搞个GM冷静一下！！！！！")
                self.family.gameServerNetPackHandle.GM_GetNpcKill(self.moveTarget['id'])
                gevent.sleep(2)
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_BOSS)
                return
            logging.debug('埋骨之窟移动停止')
            if not self.pickGrass:
                gevent.sleep(5)#等待切换至"采摘解毒之草"的target
                self.pickGrass = True
            if self.moveTarget['id']:
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_PICK)
            else:
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_GETGRASS)
            
        #获取夜光草信息
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_GETGRASS:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            logging.debug('获取夜光草信息')
            while self.family.grave.grassIdDict:
                self.moveTarget = self.family.grave.GetGrassInfo()
                logging.debug("获取夜光草信息 = %s" % self.moveTarget)
                self.family.SetState(STATE_GS_MOVE_GO)
                return
            logging.debug('摘完了!!!!!!!!!!!!')
            if self.family.grave.target == KinTargetOne:#草没摘完，但草位置没有全部同步到
                if int(self.family.grave.countList[(self.roomId-1)]) < 30:
                    self.moveTarget['id'] = 0
                    randomPos = random.randint(0, len(self.posDict[self.roomId])-1)
                    self.moveTarget['pos'] = self.posDict[self.roomId][randomPos]
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    logging.debug('30朵摘完了，等待其他房间；NUM=%s' % self.family.grave.countList[(self.roomId-1)])
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_PICK_OVER_WAIT)
            else:
                logging.debug('全部房间都摘完了!!!!!!!!!!!!')
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_PICK_OVER_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Grave_Collect_Grass_Finish")
        
        #采摘夜光草
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_PICK:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_PICK_WAIT)
            logging.debug('采摘中...')
#             self.family.gameServerNetPackHandle.AskNpc(self.moveTarget['id'])
            self.family.gameServerNetPackHandle.AskNpc_obj(self.moveTarget['id'])
            self.moveTarget['id'] = 0
            gevent.sleep(3)
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_GETGRASS)
        
        #击败所有敌人
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_KILL:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            logging.debug("从字典中获取敌人信息")
            while self.family.grave.monsterDict:
                self.moveTarget = self.family.grave.GetMonsterInfo()
                logging.debug("敌人信息 = %s" % self.moveTarget)
                self.family.SetState(STATE_GS_MOVE_GO)
                return
            logging.debug("敌人信息列表为空了！！！！！！！！！！！！")
            self.gmMove = False
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_WAIT)
        
        #移动至机关柱子的房间
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ENTER:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            self.hasSetPostRoomPos = True
            self.moveTarget['id'] = 0
            self.moveTarget['pos'] = self.postPosDict[self.roomId]
            self.family.SetState(STATE_GS_MOVE_GO)
        
        #获取机关柱子信息
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            logging.debug("房间%s内familyId信息比较：familyId=%s; memberIdList=%s" % (self.roomId, self.family.familyId, self.family.grave.memberIdList))
            if self.family.grave.memberIdList and (self.family.familyId != self.family.grave.memberIdList[0]):#���Ƿ�����familyId�����ˣ���ȥ������
                logging.debug("不是房间%s内familyId最大的人，不去开机关" % self.roomId)
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)
                return
            postDict = self.family.grave.postDict
            logging.debug("获取机关柱子信息%s" % postDict)
            while postDict:
                postName = self.postNameList[0]
                if not self.family.grave.postTarget and postName in postDict.keys():#目标机关【壹】在房间内
                    self.family.grave.postTarget = postName
                    self.moveTarget = postDict[postName]
                    logging.debug("机关柱子%s在我房间%s里，准备移动过去，moveTarget=%s" % (postName, self.roomId, self.moveTarget))
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.moveTarget['pos'])
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ASK)
                    return
                elif self.family.grave.postTarget in postDict.keys():#当前需开启的机关目标在房间内
                    postName = self.family.grave.postTarget
                    self.moveTarget = postDict[postName]
                    logging.debug("机关柱子%s在我房间%s里，准备移动过去，moveTarget=%s" % (postName, self.roomId, self.moveTarget))
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.moveTarget['pos'])
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ASK)
                    return
                else:
                    logging.debug("机关1或者当前目标%s都不在房间%s内, postDict.keys()=%s" % (self.family.grave.postTarget, self.roomId, postDict.keys()))
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)
                return
            logging.debug("familyId : %s, 机关柱子字典为空了！！！！！！" % self.family.familyId)
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)#等待打boss
        
                #解开柱子
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ASK:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            gevent.sleep(2)
            logging.debug("准备解开柱子...")
#            postDict = dict((self.family.kinMan.postDict[name]["id"], name) for name in self.family.kinMan.postDict.keys())
#            if self.moveTarget['id'] not in postDict.keys() or self.family.kinMan.postTarget != postDict[self.moveTarget['id']]:#确保机关柱子是否被房间内其他人开启了
            if self.family.grave.memberIdList and (self.family.familyId != self.family.grave.memberIdList[0]):
                logging.debug("机关柱子被房间内其他人开启了")
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)
                return
            self.family.gameServerNetPackHandle.AskNpc_obj(self.moveTarget['id'])
            gevent.sleep(5)
            if self.family.grave.postTarget != self.postNameList[-1]:#是否为最后一个机关柱子
                if self.family.grave.postTarget:
                    postTarget = self.family.grave.postTarget
                else:
                    postTarget = self.postNameList[0]
                logging.debug("解开的柱子名称为：%s" % postTarget)
                NextPostName = self.postNameList[self.postNameList.index(postTarget)+1]
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg=u"下一个机关柱子为%s" % NextPostName.decode("utf-8"), channel=3)
                if NextPostName in self.family.grave.postDict.keys():#下一个机关柱子也在此房间内
                    self.family.grave.postTarget = NextPostName
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST)
                    return
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)
            else:
                logging.debug("机关柱子解完了，准备打boss")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Grave_Unlock_Organ_Finish")
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT)#等待打boss
        
        #获取制尸者Boss信息
        elif self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST_BOSS:
            self.family.SetState(STATE_GS_ENTER_WEEK_GAME_WAIT)
            logging.debug("获取制尸者Boss信息%s" % self.family.grave.bossDict)
            while self.family.grave.bossDict:
                self.moveTarget = self.family.grave.GetBossInfo()
                self.family.SetState(STATE_GS_MOVE_GO)
                return
            logging.debug("Boss字典为空了！！！")
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Grave_Beat_Boss_Finish")
            self.family.behavior = Behavior.END
            
#        #退出周末关卡
#        elif self.family.GetState() == STATE_GS_KIN_ENTER_WEEK_GAME_SUCCEED:
#            self.family.SetState(STATE_GS_KIN_WAIT)
#            self.isFinishedKinweek = True
#            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_Quit_Finish")