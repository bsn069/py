#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
import math
from locust.events import *
from locust.asyncevent import asyncresult_manager
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from Tools.Enum import enum
from account.account_def import AccountDef
from account.account_service import account_cross_friend
from _ast import Pass


'''
      跨服加好友TestCase
'''


class TestCase(object):
    def __init__(self, family):
        self.family = family
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_cross_friend(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[CrossBattle Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_CROSSFRIENG_WAIT)
                if self.family.team_manager.myteam.IsLeader():
                    pass
                else:
                    self.family.gameServerNetPackHandle.ChatRequestByMsg("CrossReadyOK",self.family.team_manager.myteam.leaderFamilyId)
                break
            
            elif case(STATE_GS_CROSSFRIENG_FIND):
                self.family.SetState(STATE_GS_CROSSFRIENG_WAIT)
                self.family.gameServerNetPackHandle.Do_SearchFamilyGlobalReq(self.family.crossfriend.familyid)
                break
            
            elif case(STATE_GS_CROSSFRIENG_JOIN):
                self.family.SetState(STATE_GS_CROSSFRIENG_WAIT)
                self.family.gameServerNetPackHandle.Do_ApplyAddFriend(self.family.crossfriend.familyid,self.family.crossfriend.askfriendgroupid)
                break
            
            elif case(STATE_GS_CROSSFRIENG_REPLY):
                self.family.SetState(STATE_GS_CROSSFRIENG_WAIT)
                if self.family.team_manager.myteam.IsLeader():
                    break
                elif random.randint(0, 100) < 50:#取消匹配
                    logging.debug("取消加好友")
                    self.family.SetState(STATE_GS_CROSSFRIENG_END)
                    break
                self.family.gameServerNetPackHandle.Do_AgreeAddFriend(self.family.crossfriend.familyid,self.family.team_manager.myteam.leadergroupid)
                break


            elif case(STATE_GS_CROSSFRIENG_END):
                self.family.SetState(STATE_GS_CROSSFRIENG_WAIT)
                self.family.gameServerNetPackHandle.ChatRequestByMsg("CrossAddOK",self.family.team_manager.myteam.leaderFamilyId)
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_CrossFriend_Finish")
                self.family.behavior = Behavior.END
                break













