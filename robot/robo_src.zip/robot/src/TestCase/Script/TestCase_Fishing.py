#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.Rand import Rand
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase_TeamBase import TeamBaseCase

class TestCase(TeamBaseCase):
    
    FISHING_NPC_POS = (852, 656)        #npc位置
    FISHING_POS = {1:(864, 640),  #钓鱼点一能自动寻路进来，不能自动寻路出去
                   2:(617, 808),  #钓鱼点三
                   3:(554.74, 761.06, 78.92),
                   4:(841, 683),
                   }


    FISHING_MAX_COUNT = 2
    FISHING_TIME = 60  * 2
    FISHING_TYPE_OTHER = (20,)
    #参加类型
    SINGLE = 0
    TEAM = 1

    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FISH, TEAM_TYPE_FISH, u"钓鱼")
        self.family = family
        self.family.fish_list = []
        self.step = 0
        self.count = 0
        self.beginTime = time.time()
        self.poolTypes = TestCase.FISHING_POS.keys()
        self.poolIndex = 0
        team_cases = {
                     TestCase.SINGLE : 1,       #单人
                     TestCase.TEAM : 5,         #组队
                     }
        self.jointeam = True
        self.isNPC = True
        self.joinType = Rand.weighted_choice(team_cases)#根据权重分配单人or组队
#         self.joinType = TestCase.TEAM #锁定类型，组队模式
#        self.joinType = TestCase.SINGLE #锁定类型，单人模式

    def _reset(self):
        del self.family.fish_list[:]
        self.step = 0                    #步骤
        self.beginTime = time.time()
        self.poolIndex = 0
        self.isNPC = True
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        state = self.family.GetState()
        for case in switch(state):
            if case(STATE_GS_PLAYING) and self.family.isNewRole:
                self.family.SetState(STATE_GS_FISHING_WAIT)
                self.family.gameServerNetPackHandle.Can_TeamJoinCheck = False
                self.family.gameServerNetPackHandle.TeamNotJoin = True
                self.family.SetState(STATE_GS_FINISHING_BEGIN)   
                break               #开始钓鱼
            elif  case(STATE_GS_PLAYING) and self.family.isNewRole==False:
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(500,3,2);")
                self.family.SetState(STATE_GS_FINISHING_BEGIN)  
                break

            elif case(STATE_GS_FINISHING_BEGIN):
                if self.joinType == TestCase.TEAM and self.jointeam == True:  # 组队
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                    self.jointeam = False
                    
                elif self.joinType == TestCase.TEAM and self.family.team_manager.myteam.IsInTeam():  # 组队完毕（第二轮）
                    self.family.SetState(STATE_GS_FISHING_BEGIN)
                else:
                    logging.debug("单人去钓")
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                break

            elif case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                if self.isNPC:
                    self.isNPC = False
                    coordinate = TestCase.FISHING_NPC_POS      
                else:
                    coordinate = TestCase.FISHING_POS[self.poolTypes[self.poolIndex]]
#                self.family.gameServerNetPackHandle.PlayerAutoPath(*TestCase.FISHING_NPC_POS)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *coordinate)  
                gevent.sleep(3)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            # 到达任务点
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_FISHING_WAIT)
                if self.step == 0: # 到达钓鱼NPC，对话买鱼饵
                    logging.debug("到达钓鱼NPC，对话买鱼饵")
                    gevent.sleep(3)
                    self.family.gameServerNetPackHandle.AskNpc("钓叟")
                    self.family.gameServerNetPackHandle.BuyFishBait(99)
                    self.step += 1
                elif self.step == 1: # 到达钓鱼地点，开始钓鱼
                    logging.debug("到达钓鱼地点，开始钓鱼")
                    self.family.SetState(STATE_GS_FISHING_BEGIN)
                    self.beginTime = time.time()
                elif self.step == 2: # 交任务
                    logging.debug("交任务")
                    self.family.SetState(STATE_GS_FISHING_CAL_FISH)
                    self.step += 1
                break

            elif case(STATE_GS_FISHING_BAIT):
                self.family.SetState(STATE_GS_FISHING_WAIT)
                self.family.gameServerNetPackHandle.ApplyAcceptFishingTask()
                break

            elif case(STATE_GS_FISHING_ACCEPT_TASK):              #钓鱼接收任务
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            elif case(STATE_GS_FISHING_BEGIN):                        #钓鱼开始
                self.family.SetState(STATE_GS_FISHING_WAIT)
                if time.time() - self.beginTime >TestCase.FISHING_TIME:
                    self.poolIndex += 1
                    if self.poolIndex >= len(self.poolTypes): #所有钓鱼点都调过了，暂停钓鱼任务，去交任务
                        self.step += 1
                        self.family.gameServerNetPackHandle.PauseFishingTask()     
                        self.isNPC = True            
                        self.family.SetState(STATE_GS_MOVE_GO)
                    else: # 移动到下个钓鱼点
                        self.beginTime = time.time()
                        self.family.gameServerNetPackHandle.PauseFishingTask() 
                        self.family.SetState(STATE_GS_MOVE_GO)
                else:  # 继续钓鱼
                    self.family.gameServerNetPackHandle.StartFishing(self.poolTypes[self.poolIndex])
                break

            elif case(STAGE_GS_FISHING_IN_HOOKING):                               #HOOKING挂钩
                self.family.SetState(STATE_GS_FISHING_WAIT)
                if Rand.rand_percent(20):                                       # 20%不去收杆
                    gevent.sleep(8)
                    self.family.SetState(STATE_GS_FISHING_BEGIN)
                else:
                    self.fish_type = random.choice(self.family.fish_list)            #随机一条鱼
                    self.family.gameServerNetPackHandle.ApplyGetOneFish(self.fish_type)
                    if self.fish_type in TestCase.FISHING_TYPE_OTHER:
                        self.family.SetState(STATE_GS_FISHING_BEGIN)
                break

            elif case(STATE_GS_FISHING_SHARE):                                    #钓鱼分享
                self.family.SetState(STATE_GS_FISHING_WAIT)
                self.family.gameServerNetPackHandle.ApplySendFishToOthers(self.fish_type)     #给其他人鱼
                self.family.SetState(STATE_GS_FISHING_BEGIN)
                break

            elif case(STATE_GS_FISHING_CAL_FISH):
                self.family.SetState(STATE_GS_FISHING_AWARD_WAIT)
                self.family.gameServerNetPackHandle.CalAllFish()   #CLI_TO_GS_CALC_ALL_FISH_VAL
                self.count += 1
                break

            elif case(STATE_GS_FISHING_AWARD):                        #钓鱼奖励
                self.family.SetState(STATE_GS_FISHING_WAIT)
                if self.count >= TestCase.FISHING_MAX_COUNT:        #钓到了超过最大计数的鱼
                    self._reset()
                    logging.debug("退出")
                    self.family.behavior = Behavior.END
                elif self.count == 1 and TestCase.FISHING_MAX_COUNT==2:
                    self._reset()
                    self.family.SetState(STATE_GS_FINISHING_BEGIN)
                else:
                    self.family.SetState(STATE_GS_FINISHING_BEGIN)
                break

            #奇遇操作后，恢复上一个操作的状态
            elif case(STATE_GS_FORTUITOUS_MEETING):
                self.family.gameServerNetPackHandle.FortuitousMeeting(random.randint(1, 2))    # 奇遇 1=收藏 2=赠送
                self.family.SetState(self.family.gameServerNetPackHandle.nowState)
                break