#coding=utf-8
__author__ = 'Administrator'

import random
import gevent
import asyncore
import logging
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
fromTools.GenerateChinesee import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import *


"""
         家族系统的TestCase
"""

class TestCase():

    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        # role 0=>成员 1=>族长
        self.role = None
        #
        self.firstJoin = True

        self.family.kinMan.GetKinList()

        self.kinDaily = False  # 判断是否家族副本返回到主场景

        self.kinDailyTime = 0  #进入家族副本的次数


    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        logging.debug(self.family.GetState())
        if self.family.GetState() == STATE_GS_KIN_LIST: # 获取家族列表
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.Do_GetKinList()
            if not is_normalcase():
                self.family.SetState(STATE_GS_KIN_LOOKUP)
            logging.debug("STATE_GS_KIN_LIST")

        elif self.family.GetState() == STATE_GS_KIN_LOOKUP: # 查找家族
            self.family.SetState(STATE_GS_KIN_WAIT)
            if (is_normalcase()):
                kin_list = self.family.kinMan.GetKinList()
                if len(kin_list):
                    name = kin_list[random.randint(0, len(kin_list) - 1)].name
                else:
                    name = u"中文"
            else: # 非法协议
                name = generate_chinese(random.randint(0, 10))
                self.family.SetState(STATE_GS_KIN_APPLY_JOIN)
            self.family.gameServerNetPackHandle.Do_ApplyLookUpKin(name)
            logging.debug("STATE_GS_KIN_LOOKUP")

        elif self.family.GetState() == STATE_GS_KIN_APPLY_JOIN: # 加入家族
            self.family.SetState(STATE_GS_KIN_WAIT)
            if (is_normalcase()):
                if self.role == 0: # 随机加入一个家族
                    kin_list = self.family.kinMan.GetKinList()
                    if len(kin_list):
                        self.family.SetState(STATE_GS_KIN_WAIT_APPROVE)
                        kin_id = kin_list[random.randint(0, len(kin_list) - 1)].id
                        #kin_id = 1015#################加入固定家族###########################
                        self.family.gameServerNetPackHandle.Do_ApplyJoinKin(kin_id)
                        logging.debug('加入家族')
                    else:
                        self.family.SetState(STATE_GS_KIN_LIST)

                elif self.role == 1: #创建一个家族
                    name = generate_chinese(5)
                    self.family.gameServerNetPackHandle.Do_CreateKin(name)
            else: # 非法协议
                if self.role == 0: # 随机加入一个家族
                    self.family.gameServerNetPackHandle.Do_ApplyJoinKin(randuint32())
                    self.family.SetState(STATE_GS_KIN_SIGN)
                elif self.role == 1: #创建一个家族
                    name = generate_chinese(random.randint(0, 10))
                    self.family.gameServerNetPackHandle.Do_CreateKin(name)
            logging.debug("STATE_GS_KIN_APPLY_JOIN")

        elif self.family.GetState() == STATE_GS_KIN_SIGN: # 家族签到/许愿
            self.family.SetState(STATE_GS_KIN_WAIT)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinSign()
            else: # 非法协议
                self.family.gameServerNetPackHandle.Do_KinSign(typeid = randuint32(),
                                                               msg = generate_chinese(randsint()))
                self.family.SetState(STATE_GS_KIN_SHOP)
            logging.debug("STATE_GS_KIN_SIGN")

        elif self.family.GetState() == STATE_GS_KIN_SKILL_USE: # 家族技能使用
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.GM_AddKinBuildPoint()#增加资产
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinSkillUse()
            else: # 非法协议
                self.family.gameServerNetPackHandle.Do_KinSkillUse(randsint())
                self.family.SetState(random.choice([STATE_GS_KIN_ADD_FIREND ,STATE_GS_KIN_SKILL_UPGRADE]))
            logging.debug("STATE_GS_KIN_SKILL_USE")

        elif self.family.GetState() == STATE_GS_KIN_APPLY_SETTING: # 招募设定
            self.family.SetState(STATE_GS_KIN_WAIT)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinApplySetting()
            else:
                self.family.gameServerNetPackHandle.Do_KinApplySetting(openApply=True,
                                                                       needApprove=False,
                                                                       joinNeedLevel=randsint(),
                                                                       applyNotice=randstring(randsint()))
                self.family.SetState(STATE_GS_KIN_SET_NOTICE)
            logging.debug("STATE_GS_KIN_APPLY_SETTING")

        elif self.family.GetState() == STATE_GS_KIN_SET_NOTICE: # 设置公告
            self.family.SetState(STATE_GS_KIN_WAIT)
#                 gevent.sleep(1)#
            notice = generate_chinese(randstring(randsint()))
            self.family.gameServerNetPackHandle.Do_KinSetNotice(notice)

        elif self.family.GetState() == STATE_GS_KIN_POST_VICE_LEADER: # 升副族长
            self.family.SetState(STATE_GS_KIN_POST_RESULT)
            gevent.sleep(10)#等待其他人加入
            kin_member = self.family.kinMan.GetKinMember()
#                 logging.debug('升副组长%s,人数%s' % (kin_member, len(kin_member)))#
            if is_normalcase():
                if len(kin_member) == 1:#没有人加入
                    self.family.SetState(STATE_GS_KIN_DISMISS)
                else:
                    for member in kin_member:
                        if kin_member[member].post == KinCommon:
                            self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(kin_member[member].familyId, KinDeputyLeader)
                            return
                        self.family.SetState(STATE_GS_KIN_POST_COMMON)
            else:
                self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(randuint32(), KinDeputyLeader)
                self.family.SetState(STATE_GS_KIN_POST_COMMON)


        elif self.family.GetState() == STATE_GS_KIN_POST_COMMON: # 撤除副族长
            self.family.SetState(STATE_GS_KIN_WAIT)
            gevent.sleep(5)
            if is_normalcase():
                kin_member = self.family.kinMan.GetKinMember()
                print kin_member
                for member in kin_member:
                    if kin_member[member].post == KinDeputyLeader:
                        self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(kin_member[member].familyId, KinCommon)
                        return
#                 self.family.SetState(STATE_GS_KIN_SKILL_UPGRADE)
            else:
                 self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(randuint32(), KinCommon)
                 self.family.SetState(STATE_GS_KIN_DISMISS)

        elif self.family.GetState() == STATE_GS_KIN_SKILL_UPGRADE: # 家族技能升级
            logging.debug('家族技能升级')
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.GM_AddKinBuildPoint()#增加资产
            gevent.sleep(5)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinSkillUpgrade()
            else: # 非法协议
                self.family.gameServerNetPackHandle.Do_KinSkillUpgrade(skill_id = randuint32(),
                                                                       attr = randuint32())
                self.family.SetState(STATE_GS_KIN_ADD_FIREND)


        elif self.family.GetState() == STATE_GS_KIN_SHOP:#刷新商店
            self.family.SetState(STATE_GS_KIN_WAIT)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinShopApply()
            else:
                self.family.SetState(STATE_GS_KIN_SHOP_BUY)


        elif self.family.GetState() == STATE_GS_KIN_SHOP_BUY:#商店购买
            self.family.SetState(STATE_GS_KIN_WAIT)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_KinShopBuy()
            else:
                for case in switch(random.randint(0, 3)):
                    if case(0):
                        self.family.gameServerNetPackHandle.Do_KinShopBuy(shop_id = randuint32())
                        break
                    if case(1):
                        self.family.gameServerNetPackHandle.Do_KinShopBuy(good_index = randuint32())
                        break
                    if case(0):
                        self.family.gameServerNetPackHandle.Do_KinShopBuy(buy_count = randuint32())
                        break
                    if case(0):
                        self.family.gameServerNetPackHandle.Do_KinShopBuy(goods_sequence = randsint())
                        break
                self.family.SetState(STATE_GS_SHOP_RESULT)

        elif self.family.GetState() == STATE_GS_SHOP_RESULT:#购买成功
            self.family.SetState(STATE_GS_KIN_SKILL_USE)#家族使用技能

        elif self.family.GetState() == STATE_GS_KIN_DISMISS: # 解散家族
            logging.debug('解散家族')
            self.family.SetState(STATE_GS_KIN_WAIT)
            # gevent.sleep(20)#做完其他项后，在家族中停留时间
            if randsint():
                kin_member = self.family.kinMan.GetKinMember()
                if len(kin_member) > 1:
                    for member in kin_member:
                        if kin_member[member].post != 1:
                            self.family.gameServerNetPackHandle.Do_ApplyKinKick(kin_member[member].familyId)#踢全部人
                            return
                self.family.gameServerNetPackHandle.Do_ApplyDismissKin()
            else:
                self.family.gameServerNetPackHandle.Do_ApplyKinKick(randuint32())
                self.family.gameServerNetPackHandle.Do_ApplyDismissKin()
                self.family.SetState(STATE_GS_KIN_LIST)


        elif self.family.GetState() == STATE_GS_KIN_QUIT: # 退出家族
            self.family.gameServerNetPackHandle.ApplyRankingRank(RANK_LIST_TYPE_KIN_FIGHTING) #查看家族排行
            self.family.gameServerNetPackHandle.ApplyRankingList(RANK_LIST_TYPE_KIN_FIGHTING)
            self.family.SetState(STATE_GS_KIN_WAIT)
            gevent.sleep(10)#做完其他项后，在家族中的停留时间
            logging.debug('退出家族')
            self.family.kinMan.kinKick = False
            self.family.gameServerNetPackHandle.Do_ApplyQuitKin()
            if randsint():
                self.family.SetState(STATE_GS_KIN_LIST)

        elif self.family.GetState() == STATE_GS_KIN_DAILY:  # 家族关卡
            logging.debug('****家族关卡')
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.TeamCreateReq(TEAM_TYPE_KINDAILY)  # 创建队伍
            gevent.sleep(1)
            self.family.gameServerNetPackHandle.EnterKinDailyGame()  # 进入副本


        elif self.family.GetState() == STATE_GS_ENTER_KIN_DAILY:  # 进入家族关卡 目前不需要加移动，怪会自己走过来打玩家
            self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
            self.kinDaily = True

        elif self.family.GetState() == STATE_GS_SINGLE_MISSION_RELEASE_SKILLS: #释放技能
            gevent.sleep(3)
            if is_normalcase():
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
            else:
                self.family.gameServerNetPackHandle.Do_CastSkill(None, randuint32())
                self.family.SetState(STATE_GS_FAMILY_ADD_AWARD_INFO)

        elif self.family.GetState() == STATE_GS_FAMILY_ADD_AWARD_INFO:
            if self.kinDaily:
                self.family.gameServerNetPackHandle.canSkill = False
                self.family.behavior = Behavior.END#退出

        elif self.family.GetState() == STATE_GS_KIN_ADD_FIREND:
            logging.debug('家族加好友')
            self.family.SetState(STATE_GS_KIN_WAIT_ADD_FIREND)
            kin_member_familyid = self.family.kinMan.GetKinMember().keys()
            if len(kin_member_familyid) == 1:
                self.family.SetState(STATE_GS_KIN_DAILY)
            else:
                kin_member_familyid.remove(self.family.familyId)
                logging.debug(kin_member_familyid)
                add_familyid = kin_member_familyid[len(kin_member_familyid)-1]
                #add_familyid = 508502 #--加固定的好友--#
                self.family.gameServerNetPackHandle.Do_ApplyAddFriend(add_familyid)
                self.family.SetState(STATE_GS_KIN_DAILY)


        elif self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.kinDaily:
                if self.role == 0:
                    self.family.SetState(STATE_GS_KIN_QUIT)
                elif self.role == 1:
                    self.family.SetState(STATE_GS_KIN_POST_VICE_LEADER)
                return


            if self.firstJoin:
                self.role = random.randint(0, 1)
                self.role = 0#锁定选择
                self.family.SetState(STATE_GS_KIN_LIST)
                self.firstJoin = False




def is_patriarch(familyId, kinMember):
    if kinMember[familyId].post == 1:
        return True
    else:
        return False
