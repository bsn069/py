# -*- coding:utf8 -*-
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *

'''
    家园的TestCase
    流程：  1：设置自己的家园心情，留言，说明
                 2：找其他机器人，去它的空间留言，心情评价，点赞，送礼物
                 3：回复自己家园的心情和留言,并删除,最后在自己空间再发一条留言和心情
'''


class TestCase():
    SET_ONESELF = 1
    EVALUATION_OTHER = 2
    EVALUATION_ONESELF = 3
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.otherFamily = None
        self.isOneself = TestCase.SET_ONESELF
        self.isEnd = 0

    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                if VALUE_COIN_GOLD not in self.family.valueCoin or self.family.valueCoin[VALUE_COIN_GOLD] < 6000:
                    self.family.gameServerNetPackHandle.SetGoldNumber()#GM充值
                self.family.gameServerNetPackHandle.GM_AddGift()#空间送礼
                self.family.mediaServerNetPackHandle.GetOwnerInfoReq()#获取个人信息
                break

            if case(STATE_MS_HOMELAND_ADD_BOARD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                for case in switch(self.isOneself):
                    if case(TestCase.SET_ONESELF):
                        self.family.SetState(STATE_MS_HOMELAND_SET_MOOD)
                        break
                    if case(TestCase.EVALUATION_OTHER):
                        self.family.SetState(STATE_MS_HOMELAND_GET_OTHER_MOOD)
                        break
                    if case(TestCase.EVALUATION_ONESELF):
                        self.family.SetState(STATE_MS_HOMELAND_GET_MY_MOOD)
                        break
                break

            if case(STATE_MS_HOMELAND_ADD_MOOD_COMMENT_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                for case in switch(self.isOneself):
                    if case(TestCase.EVALUATION_OTHER):
                        self.family.SetState(STATE_MS_HOMELAND_SEND_GIFT)
                        break
                    if case(TestCase.EVALUATION_ONESELF):
                        self.family.SetState(STATE_MS_HOMELAND_DEL_BOARD)
                        break
                break

            if case(STATE_MS_HOMELAND_ADD_MOOD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                self.family.SetState(STATE_MS_HOMELAND_SET_BLOG)
                break

            #设置自己留言
            if case(STATE_MS_HOMELAND_SET_BOARD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("设置自己留言")
                msg = u'自己发留言'
                self.family.mediaServerNetPackHandle.AddBoardMsgReq(ownerId=self.family.familyId,
                                                                    receiverId=self.family.familyId, content=msg)
                break

            #设置自己心情
            if case(STATE_MS_HOMELAND_SET_MOOD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("设置自己心情")
                msg = u'自己发心情'
                self.family.mediaServerNetPackHandle.AddMoodMsgReq(msg)
                break

            #设置自己说明
            if case(STATE_MS_HOMELAND_SET_BLOG):
                if self.isEnd:
                    logging.debug('结束')
                    self.family.behavior = Behavior.END
                    break
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                msg = u'设置个人说明'
                self.family.mediaServerNetPackHandle.SetBlogDeclareReq(msg)
                self.isOneself = TestCase.EVALUATION_OTHER
                break

            #找其他机器人
            if case(STATE_MS_HOMELAND_GET_OTHER_FAMILY):
                logging.debug("找其他机器人")
                msg = u'家园互动啦'
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg=msg, channel=emChatChannelWorld)
                self.otherFamily = self.family.homeland.GetOtherFamily()
                if not self.otherFamily:
                    gevent.sleep(3)
                    self.family.SetState(STATE_MS_HOMELAND_GET_OTHER_FAMILY)
                else:
                    logging.debug("空间点赞")
                    self.family.mediaServerNetPackHandle.AddBlogLikeReq(self.otherFamily)  # 空间点赞
                    self.family.SetState(STATE_MS_HOMELAND_GET_OTHER_BOARD)
                break

            if case(STATE_MS_HOMELAND_GET_OTHER_BOARD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("获取留言信息")
                self.family.mediaServerNetPackHandle.GetBoardMsgReq(self.otherFamily)
                break

            #给其他机器人留言
            if case(STATE_MS_HOMELAND_UPDATE_OTHER_BOARD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("给其他机器人留言")
                msg = u'我是%s，给你留言么么哒' % self.family.userName
                self.family.mediaServerNetPackHandle.AddBoardMsgReq(receiverId=self.otherFamily,
                                                                    ownerId=self.otherFamily, content=msg)
                break

            if case(STATE_MS_HOMELAND_GET_OTHER_MOOD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                self.family.mediaServerNetPackHandle.GetMoodMsgReq(familyId=self.otherFamily)
                break

            #评价其他机器人心情和点赞
            if case(STATE_MS_HOMELAND_UPDATE_OTHER_MOOD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("评价其他机器人心情和点赞")
                other_mood_msg = self.family.homeland.GetOtherMood()
                if other_mood_msg:
                    self.family.mediaServerNetPackHandle.AddMoodLikeReq(self.otherFamily, other_mood_msg.msgId)
                    msg = u'我是%s，评价你的心情么么哒' % self.family.userName
                    self.family.mediaServerNetPackHandle.AddMoodCommentReq(receiverId=self.otherFamily,
                                                                           msgId=other_mood_msg.msgId, msg=msg)
                else:
                    logging.debug('别人没心情')
                    self.family.SetState(STATE_MS_HOMELAND_SEND_GIFT)
                break

            #送礼物
            if case(STATE_MS_HOMELAND_SEND_GIFT):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("送礼物")
                self.family.gameServerNetPackHandle.SendOneGift(self.otherFamily)
                self.isOneself = TestCase.EVALUATION_ONESELF
                # self.family.SetState(STATE_MS_HOMELAND_GET_MY_BOARD)
                break

            #看自己家园的留言
            if case(STATE_MS_HOMELAND_GET_MY_BOARD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug("看自己家园的留言")
                self.family.mediaServerNetPackHandle.GetBoardMsgReq(self.family.familyId)
                break

            if case(STATE_MS_HOMELAND_UPDATE_MY_BOARD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                receiver_id, msg_id = self.family.homeland.IfHaveOtherBoard(self.family.familyId)
                if receiver_id and msg_id:
                    logging.debug("回复留言")
                    msg = u'回复留言么么哒'
                    self.family.mediaServerNetPackHandle.AddBoardMsgReq(receiverId=receiver_id,
                                                                        ownerId=self.family.familyId, content=msg)
                else:
                    logging.debug('没其他人的留言')
                    self.family.SetState(STATE_MS_HOMELAND_GET_MY_MOOD)
                break

            #看自己家园的心情
            if case(STATE_MS_HOMELAND_GET_MY_MOOD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                logging.debug('看自己家园的心情')
                self.family.mediaServerNetPackHandle.GetMoodMsgReq(self.family.familyId)
                break

            if case(STATE_MS_HOMELAND_UPDATE_MY_MOOD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                sender_id, msg_id, comment_id = self.family.homeland.IfMoodHaveOtherReply(self.family.familyId)
                if sender_id and msg_id and comment_id:
                    logging.debug('回复心情')
                    msg = u'回复心情么么哒'
                    self.family.mediaServerNetPackHandle.AddMoodCommentReq(receiverId=sender_id, msgId=msg_id, msg=msg)
                    self.family.SetState(STATE_MS_HOMELAND_DEL_BOARD)
                else:
                    logging.debug('心情没有别人评价')
                    self.family.SetState(STATE_MS_HOMELAND_DEL_BOARD)
                break

            #删除自己家园一条留言
            if case(STATE_MS_HOMELAND_DEL_BOARD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                my_one_board = self.family.homeland.GetMyOneBoard()
                if my_one_board:
                    logging.debug('删除自己家园一条留言')
                    self.family.mediaServerNetPackHandle.DelBoardMsgReq(my_one_board.senderId, my_one_board.msgId)
                else:
                    self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD_COMMENT)
                break

            if case(STATE_MS_HOMELAND_DEL_BOARD_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD_COMMENT)
                break

            #删除心情中的一条评论
            if case(STATE_MS_HOMELAND_DEL_MOOD_COMMENT):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                sender_id, msg_id, comment_id = self.family.homeland.IfMoodHaveOtherReply(self.family.familyId)
                if sender_id and msg_id and comment_id:
                    logging.debug('删除心情中的一条评论')
                    self.family.mediaServerNetPackHandle.DelMoodCommentReq(ownerId=self.family.familyId, msgId=msg_id,
                                                                           commentId=comment_id, senderId=sender_id)
                else:
                    self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD)
                break

            if case(STATE_MS_HOMELAND_DEL_MOOD_COMMENT_SUCCEED):
                self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD)
                break

            #删除一条心情
            if case(STATE_MS_HOMELAND_DEL_MOOD):
                self.family.SetState(STATE_MS_HOMELAND_WAIT)
                my_one_mood = self.family.homeland.GetMyOneMood()
                if my_one_mood:
                    logging.debug('删除一条心情')
                    self.family.mediaServerNetPackHandle.DelMoodMsgReq(my_one_mood.msgId)
                else:
                    logging.debug('没心情可以删除')
                    self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD_SUCCEED)
                break

            if case(STATE_MS_HOMELAND_DEL_MOOD_SUCCEED):
                self.isEnd = 1
                self.isOneself = TestCase.SET_ONESELF
                self.family.SetState(STATE_MS_HOMELAND_SET_BOARD)
                break







