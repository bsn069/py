# coding=utf-8
#!/usr/bin/env python2.7

import random
import gevent
import asyncore
import math
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *

"""
       流寇TestCase
"""

class TestCase(object):
    def __init__(self, family):
        self.family = family
        self.maple = self.family.crusadeaginst.get_maple()
        self.index = 0
        self.moveto = []
        self.bosspos = {}
       
    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.BecomeStronger()#穿全部装备
                self.family.SetState(STATE_GS_CRUSADEAHAINST_MAPLE_WAIT)
                self.family.gameServerNetPackHandle.Transfer2Map(self.maple)#进入野外地图
                break
            elif case(STATE_GS_CRUSADEAHAINST_MAPLE):
                self.family.SetState(STATE_GS_CRUSADEAHAINST_WAIT)
                self.family.gameServerNetPackHandle.AddBuffInvincible()#无敌Buff
                self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害999倍
                self.bosspos = self.family.crusadeaginst.bosspos[self.maple]
                self.family.SetState(STATE_GS_CRUSADEAHAINST_BOSS_POS)
                break
            
            elif case(STATE_GS_CRUSADEAHAINST_BOSS_POS):
                self.index += 1
                if self.index == 20:
                    self.index = 0
                self.moveto = self.bosspos[self.index]
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.PlayerAutoPath(self.moveto[0], self.moveto[2], self.moveto[1])       
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_CRUSADEAHAINST_WAIT)
                boss_list = self.family.crusadeaginst.bossDict.keys()
                if boss_list:
                    now_posx = self.family.characterCur.posX
                    now_posy = self.family.characterCur.posY
                    boss_posx = self.family.crusadeaginst.bossDict[boss_list[0]]["pos"][0]
                    boss_posy = self.family.crusadeaginst.bossDict[boss_list[0]]["pos"][1]
                    self.family.gameServerNetPackHandle.fightBossPosX = boss_posx
                    self.family.gameServerNetPackHandle.fightBossPosY = boss_posy
                    self.family.gameServerNetPackHandle.fightBossId = boss_list[0]
                    if math.fabs(boss_posx - now_posx) < 3 and math.fabs(boss_posy - now_posy) < 3:
                        logging.debug("在Boss旁，准备放技能")
                        self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                        break
                    else:
                        logging.debug("移动到boss位置")
                        self.family.gameServerNetPackHandle.PlayerAutoPath(boss_posx, boss_posy)
                        break
                else:
                    self.family.SetState(STATE_GS_CRUSADEAHAINST_BOSS_POS)
                    break
                    
            # 随机技能
            elif self.family.GetState() == STATE_GS_SINGLE_MISSION_RELEASE_SKILLS:
                self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Crusagains_Skill")
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)#技能
                gevent.sleep(5)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                     