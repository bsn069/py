#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *

'''
      排行榜的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.rankType = 0
        self.wait_time = 60 # 登陆60s后,3人排行榜才有响应

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        state = self.family.GetState()
        for case in switch(state):
            if case(STATE_GS_PLAYING):
                gevent.sleep(self.wait_time)
                self.rankType = random.choice(RANK_LIST_TYPE.values()) # 随机要查看的排行榜类型
                self.family.SetState(STATE_GS_RANK_WAIT)
                break

            if case(STATE_GS_RANK_WAIT):
                self.wait_time = 5  # 每次查询间隔
                logging.debug(self.rankType)#
                self.family.gameServerNetPackHandle.ApplyRankingRank(self.rankType) # 查看排行榜（3人）
                self.family.gameServerNetPackHandle.ApplyRankingList(self.rankType) # 查看前100名
                self.family.SetState(STATE_GS_PLAYING)
                break