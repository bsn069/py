# coding:utf-8
import random
import gevent
import asyncore
import math
import time
import logging
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase
from TestCase_WorldLimited import WorldLimitedCase

"""
         广场舞的TestCase
"""

class TestCase(WorldLimitedCase):
    def __init__(self, family):
        self.family = family
        self.isFirst = True
        self.gestureDict = {
                                "舞欢快" : 4,
                                "舞剑" : 6,
                                "舞酷炫" : 25,
                                "舞灵动" : 26,
                                "舞极乐" : 32,
                            }
        
        WorldLimitedCase.__init__(self,family)
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        WorldLimitedCase._Action(self)
        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_SQUAREDANCE_WAIT)
                gevent.sleep(3)
                if self.isFirst and self.family.isNewRole:#特殊需求（仅执行一次）
                    self.isFirst = False
                    memberType = 1
                    self.family.gameServerNetPackHandle.RandomAvatar(memberType)#穿时装
    #                 gevent.spawn(self.family.gameServerNetPackHandle.LoopWearMiJi)#穿秘籍
    #                 self.family.gameServerNetPackHandle.BecomeStronger(memberType)#穿全部装备
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(1, 60), memberType)#随机等级、装备和升星
#                 gevent.spawn(self.family.gameServerNetPackHandle.LoopChat)#持续喊话
                self.family.SetState(STATE_GS_WORLD_LIMITED_PLAYING)
                break
            elif case(STATE_GS_WORLD_LIMITED_END):
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                centerPos = (724.38, 723.36)
                self.family.gameServerNetPackHandle.PlayerAutoPath(*centerPos)
                break
 
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_SQUAREDANCE_WAIT)
                while self.family.GetState() == STATE_GS_SQUAREDANCE_WAIT:
                    GestureId = random.choice(self.gestureDict.values())
                    self.family.gameServerNetPackHandle.CharacterGesturePlay(GestureId)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_SquareDance_Gesture")
                    gevent.sleep(5)
                break
            
            elif case(STATE_GS_SQUAREDANCE_END):
                self.family.behavior = Behavior.END
                break
            