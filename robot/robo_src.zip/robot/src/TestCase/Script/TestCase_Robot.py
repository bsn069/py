# coding:utf-8
import random
import gevent
import asyncore
import time
import datetime
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Config.RoleFigures import *
from Tools.Rand import Rand
from TestCase_TeamBase import TeamBaseCase
from net.Common.ComDefine_pb2 import *

'''
    用于处理开活动等功能的机器人的TestCase
'''

class TestCase():
    
    KINWAR_START = 60 * 2
    KINWAR_SIGNUP_CLOSE = 60 * 5
    KINWAR_PVP_END = 60 * 28
    KINWAR_CLOSE = 60 * 30
    
    def __init__(self, family):
        self.family = family
        self.startTime = time.time()
        self.hasCleanKinWar = False
        self.task = KinWarStartWait

    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                logging.critical("LoginSuccess...%s" % time.time())
                #设置开服时间
                self.family.gameServerNetPackHandle.CallScript('GMCmd', 'DoCommand',
                         "GCExcute(me:GetGroupID(), {\"TimeFrame:Reset\"}); GCExcute(me:GetGroupID(), {\"KTimeFrame.SetServerOpenTime\", %d});" \
                         % int(time.mktime((datetime.datetime.now() - datetime.timedelta(days=30)).timetuple())))
                self.family.SetState(STATE_GS_ROBOT_RUN)
                break
            
            if case(STATE_GS_ROBOT_RUN):
                if not self.hasCleanKinWar:
                    self.hasCleanKinWar = True
                    self.CleanKinWar()
                    self.startTime = time.time()
                time_diff = time.time() - self.startTime
                if self.task == KinWarStartWait and time_diff >= TestCase.KINWAR_START:#开启家族战
                    logging.critical("StartKinWar...%s" % time.time())
                    self.family.gameServerNetPackHandle.StartKinWar()
                    self.task = KinWarSignUpCloseWait
                elif self.task == KinWarSignUpCloseWait and time_diff >= TestCase.KINWAR_SIGNUP_CLOSE:#结束家族战报名
                    logging.critical("CloseKinWarSignUp...%s" % time.time())
                    self.family.gameServerNetPackHandle.CloseKinWarSignUp()
                    self.task = KinWarPVPEndWait
                elif self.task == KinWarPVPEndWait and time_diff >= TestCase.KINWAR_PVP_END:#家族PVP时间截止
                    logging.critical("KinWarPVPEnd...%s" % time.time())
                    self.family.gameServerNetPackHandle.KinWarPVPEnd()
                    self.task = KinWarCloseWait
                elif self.task == KinWarCloseWait and time_diff >= TestCase.KINWAR_CLOSE:#关闭家族战
                    logging.critical("CloseKinWar...%s" % time.time())
                    self.family.gameServerNetPackHandle.CloseKinWar()
                    self.startTime = time.time()
                    self.task = KinWarStartWait
                break
            
    def CleanKinWar(self):
        logging.critical("CleanKinWar...%s" % time.time())
        self.family.gameServerNetPackHandle.KinWarPVPEnd()
        gevent.sleep(TestCase.KINWAR_CLOSE - TestCase.KINWAR_PVP_END)
        self.family.gameServerNetPackHandle.CloseKinWar()
    
