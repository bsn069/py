#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import asyncore
import logging
import math
import time
from cgi import log
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Files.Shop import *
from Tools.Rand import *
from Config.RunConfig import Config
from TestCase_TeamBase import TeamBaseCase
from TestCase_KinBase import KinBaseCase, KinMemberType
from TestCase_WorldLimited import WorldLimitedCase
from account.account_service import account_limited
from account.account_def import AccountDef
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
"""

         
"""

class TestCase(TeamBaseCase, KinBaseCase,WorldLimitedCase):

    VALUE_COIN_SILVER       = 1 #银量
    KIN_ROLE_DISTRIBUTE = 0#使用分发的角色类型
    KIN_ROLE_RANDOM = 1#使用随机的角色类型
    
    ROLE_MODE =  KIN_ROLE_RANDOM

    def __init__(self, family):
        self.family = family
        if TestCase.ROLE_MODE == TestCase.KIN_ROLE_DISTRIBUTE:
            role, kin_role_count = account_limited()
            role = int(role)
            KinBaseCase.KIN_RECRUIT_NUM = int(kin_role_count)
        else:
            memberDict = {
                                KinMemberType.LEADER  : 1,
                                KinMemberType.MEMBER : KinBaseCase.KIN_RECRUIT_NUM - 1
                          }
            role = Rand.weighted_choice(memberDict)
            role = KinMemberType.LEADER#锁定为族长
#            role = KinMemberType.MEMBER#锁定为族员

        TeamBaseCase.__init__(self, family, TEAM_TYPE_KINDAILY, TEAM_TYPE_KINDAILY, u"家族", emChatChannelInvite)
        KinBaseCase.__init__(self, family, role) 
        WorldLimitedCase.__init__(self,family)
        self.is_true = False
        self.is_firstJoin = True
        self.kin_list=[]
        self.membernumlist = []
        self.is_index = True
        self.total = 0
    def _reset(self):
        self.family.limitedacution.auctioninformationlist = []
        self.family.limitedacution.auctionshopdatalist=[]
        self.family.limitedacution.one_auctiondatainfolist=[]
    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        TeamBaseCase._Action(self)
        KinBaseCase._Action(self)
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_KIN_WAIT)
            
            if self.is_firstJoin:
                self.family.SetState(STATE_GS_KIN_BEGIN)
#                self.family.SetState(STATE_GS_KIN_BEGIN)
                self.is_firstJoin = False
                self.family.limitedacution.isFirstCalculation = False
#                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("KGameSwitch.SetDebug(2,False);")
#                self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "me:AddSilver(9999999999, 1);")
#                self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[KAuction.SetFamilyErrorCount(%d, 0)]], \"familyid:%d\"})" % (self.family.familyId,self.family.familyId))
                gevent.sleep(5)            
            return
        

        elif self.family.GetState() == STATE_GS_KIN_RECRUIT_FINISH :
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.family.kinMan.isLeader == True:
                self.kin_list = self.family.kinMan.GetKinMember()
                self.kinmemberlist = self.kin_list.keys()
                for i in range(len(self.kinmemberlist)):
                    str_value = str(self.family.kinMan.GetKinMember()[self.kinmemberlist[i]].familyId)
                    self.membernumlist.append(str_value)
                self.membernumlist=",".join(self.membernumlist)    
                #开启拍卖房间
#                self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[Auction:TestAddShop({%s},  %d)]], \"familyid:%d\"})" % (self.membernumlist,self.family.kinMan.id,self.family.familyId))
                self.is_true = True
                self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
            else:
                self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
            return
        
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_BEGIN and self.is_true == True and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self.family.gameServerNetPackHandle.AuctionConcernReq()
            return
        
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_CHANGE:
            if self.family.limitedacution.isFirstCalculation == False and self.family.kinMan.isLeader == True:            
                for i in range(len(self.family.limitedacution.totalshopinf)):
                        self.family.limitedacution.auctionshopdatalist= []
                        self.family.gameServerNetPackHandle.AuctionShopDataReq(self.family.limitedacution.totalshopinf[i][0],#shopid.hiId
                                                                               self.family.limitedacution.totalshopinf[i][1],#shopid.lowId
                                                                               self.family.limitedacution.totalshopinf[i][2])#版本号
                        while self.family.limitedacution.totalGoodsCount == 0:
                            gevent.sleep(5)
                        for i in range(self.family.limitedacution.totalGoodsCount):
                            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Limited_Goodsid")
                self._reset()
                self.family.limitedacution.isFirstCalculation = True
                self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
                return
            elif self.family.limitedacution.isFirstCalculation == True:
                self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
                self.family.gameServerNetPackHandle.AuctionShopDataReq(self.family.limitedacution.auctioninformationlist[0],#shopid.hiId
                                                                   self.family.limitedacution.auctioninformationlist[1],#shopid.lowId
                                                                   self.family.limitedacution.auctioninformationlist[2])#版本号
                gevent.sleep(5)
                while self.family.limitedacution.auctionshopdatalist[0] is None: 
                    gevent.sleep(5)
                if self.is_index ==False:
                    self.family.SetState(STATE_GS_LIMITED_AUCTION_INFOREP)
                    return 
                if self.is_true == True and self.family.kinMan.isLeader == True :
                    self.total = len(self.family.limitedacution.auctionshopdatalist)
                    self.is_true = False
                    self.family.limitedacution.sellneed =random.randint(0, self.total)
                    msg = u'LimitedAcution_buy:%d' % self.family.limitedacution.sellneed
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, channel=2)
                    for i in range(0, self.family.limitedacution.sellneed):
                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_Volume")            
                    self.family.SetState(STATE_GS_LIMITED_AUCTION_INFOREP)
                    return 
                
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_INFOREP :
            self.is_index =False
            if self.family.limitedacution.sellneed == 0:
                self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
                return
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self.family.gameServerNetPackHandle.AuctionGoodsDataReq(self.family.limitedacution.auctioninformationlist[0],
                                                                    self.family.limitedacution.auctioninformationlist[1],
                                                                    self.family.limitedacution.auctioninformationlist[2],
                                                                    self.family.limitedacution.auctionshopdatalist[0])#物品ID
            return                           
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_AUCTION and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            if len(self.family.limitedacution.one_auctiondatainfolist)>0 :            
                if self.family.valueCoin[1]<self.family.limitedacution.one_auctiondatainfolist[0] :
                    self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "me:AddSilver(100000000, 1);")#���ӽ�Ǯ

            acution_Treatment = {
                                        1 : 1,         #一口价
                                        0 : 29,        #竞拍价
                                    }
#            acution_changtype = Rand.weighted_choice(acution_Treatment)
            acution_changtype = 0
            if acution_changtype == 1:          
                self.family.gameServerNetPackHandle.AuctionBidGoodsReq(self.family.limitedacution.auctioninformationlist[0],
                                                                       self.family.limitedacution.auctioninformationlist[1],
                                                                       self.family.limitedacution.auctionshopdatalist[0],
                                                                       True,
                                                                       self.family.limitedacution.one_auctiondatainfolist[0])#��Ʒ�۸�ID                
            elif acution_changtype == 0:      
                self.family.gameServerNetPackHandle.AuctionBidGoodsReq(self.family.limitedacution.auctioninformationlist[0],
                                                                       self.family.limitedacution.auctioninformationlist[1],
                                                                       self.family.limitedacution.auctionshopdatalist[0],
                                                                       False,
                                                                       self.family.limitedacution.one_auctiondatainfolist[2])
           
        
            return
                              
        elif self.family.GetState() ==  STATE_GS_LIMITED_AUCTION_FINISH and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self._reset()
            gevent.sleep(2)
            self.family.gameServerNetPackHandle.AuctionConcernReq()   
        
        elif (self.family.GetState() == STATE_GS_LIMITED_AUCTION_END or self.total == (len(self.family.limitedacution.auctionshopdatalist)+self.family.limitedacution.sellneed)) and self.family.limitedacution.distinguish == 0 :
            if self.family.limitedacution.sellneed == 0:
                logging.debug("全部商品都流拍")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_FlowShot")
            else:
                logging.debug("完成限时拍卖")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_Finish")            
            self.family.limitedacution.distinguish +=1
            self._reset()
            self.family.SetState(STATE_GS_WORLD_LIMITED_PLAYING)
            return  
        
        elif self.family.GetState() == STATE_GS_WORLD_LIMITED_END:
            logging.debug("完成案例，退出")
#            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_Case_Finish")            
            self.family.behavior = Behavior.END
            return
        
        if self.family.limitedacution.distinguish >0:
            logging.debug("进入世界竞拍")
            WorldLimitedCase._Action(self)
            return
            
   