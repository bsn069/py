# coding:utf8
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from account.account_def import AccountDef
from account.account_service import account_xiaomijing

'''
    小秘境（九州行）的TestCase
    
    npc出生点 /data/script/mission/secretrealm/secretrealm_npcposition.lua
'''
        
class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_XIAOMIJING, u"小秘境组队", teamCreateType=TeamCreateType.FIXED)
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_xiaomijing(self.family.familyId, self.family.serverGroupId)
        self.family = family
        self.enterShuiyunjingNpcPos = (864, 873, 92)
        self.enterShuiyunjingNpcName = "太史丹"
        self.enterXiaomijingNpcPos = (152, 167)
        self.bossPosDict = {
                                SceneXiaoMiJing6 : [(161.47, 36.19), (123.64, 68), (73, 46), (79, 99), (156, 118), (187.27, 126.35), (132, 188)],
                                SceneXiaoMiJing7 : [(31, 96), (72.39, 60.56), (117.21, 56.91), (116.30, 95.78),(65, 159),(112.14, 157.27)],
                            }
        self.targetPos = {62.73, 125.66, 22}
        self.switchPos = ()
        self.moveIndex = 0
        self.isfirstenter = True
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            # 匹配
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                gevent.sleep(2)
                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.BecomeStronger()#穿装备
                elif self.family.isNewRole == False:    
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(503, 1, 10)")
                self.family.SetState(STATE_GS_MOVE_GO)
                break
                     
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                logging.debug('完成组队')
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_XiaoMiJing_TeamComplete")
                gevent.sleep(1)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):#为队长时
                    pos = self.enterXiaomijingNpcPos
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                    self.family.gameServerNetPackHandle.CallTeamMember()#通知队友传送
                    gevent.sleep(20)
                break
              
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):#为队长时
                    self.family.gameServerNetPackHandle.ApplySecretRealmGame()
            
            if case(STATE_GS_XIAOMIJING_JIGUAN):
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.targetPos)
                while self.family.xiaomijing.hasSwitch:
                    switchId = self.family.xiaomijing.GetSwitchId()
                    if switchId:
                        self.family.gameServerNetPackHandle.AddFullHP()
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(self.family.xiaomijing.switchDict[switchId]["pos"])
                        self.family.gameServerNetPackHandle.AskNpc_obj(switchId)
                        gevent.sleep(5)
                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_XiaoMiJing_JiGuan")
                        
            # 开始移动
            if case(STATE_GS_MOVE_GO):
                scene_template_id = self.family.gameServerNetPackHandle.sceneTemplateId
                if scene_template_id == SceneLinan:
                    pos = self.enterShuiyunjingNpcPos
                    self.family.gameServerNetPackHandle.PlayerAutoPath(*pos)
                elif scene_template_id == SceneShuiYunJing and self.isfirstenter:
                    self.isfirstenter = False
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                elif scene_template_id == SceneShuiYunJing and self.isfirstenter == False:
                    self.family.SetState(STATE_GS_LINE_SWITCH_SUCCESS)
                elif scene_template_id in self.bossPosDict:
                    lenBossPosList = len(self.bossPosDict[scene_template_id])
                    if self.family.xiaomijing.hasSwitch:
                        self.family.SetState(STATE_GS_XIAOMIJING_JIGUAN)
                        break
                    if self.moveIndex < lenBossPosList:
                        if self.moveIndex == 2:#打完n个boss后开启一击必杀，加快通关速度
                            self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害x999
                        if self.moveIndex == (lenBossPosList-1):#Boss点
                            logging.debug("打boss的过场剧情")
                            gevent.sleep(15)#打boss的过场剧情
                        pos = self.bossPosDict[scene_template_id][self.moveIndex]
                        logging.debug("pos = %s, moveIndex = %s" % (pos, self.moveIndex))
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *pos)
                        gevent.sleep(5)
                    else:
                        logging.debug("已走完全部地点 moveIndex = %s" % self.moveIndex)
                        if self.family.xiaomijing.boxMsg:
                            self.family.SetState(STATE_GS_XIAOMIJING_OPEN_BOX)
                        else:
                            self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                else:
                    logging.debug("找不到该地图 scene_template_id = %s" % scene_template_id)
                    self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                break

            # 到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                logging.debug("到达地点")
                scene_template_id = self.family.gameServerNetPackHandle.sceneTemplateId
                if scene_template_id == SceneLinan:
                    self.family.SetState(STATE_GS_XIAOMIJING_ASK_NPC)
                elif scene_template_id in self.bossPosDict:
                    self.moveIndex += 1
                    self.family.SetState(STATE_GS_XIAOMIJING_JUDGE)
                else:
                    logging.debug("Arrival找不到该地图 sceneTemplateId = %s" % scene_template_id)
                    self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                break
            
            #对话NPC进入水云境
            if case(STATE_GS_XIAOMIJING_ASK_NPC):
                npcId = self.family.gameServerNetPackHandle.GetNpcID(self.enterShuiyunjingNpcName)
                if npcId:
                    self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                    self.family.gameServerNetPackHandle.AskNpc_obj(npcId)
                    gevent.sleep(2)
                self.family.gameServerNetPackHandle.CallScriptTransfer(SceneShuiYunJing, -1.0, 3.0)#进入水云境
                break
            
            if case(STATE_GS_XIAOMIJING_JUDGE):
                self.family.xiaomijing.hasEnterShuiYunJing = True
                gevent.sleep(5)
                if self.family.xiaomijing.GetBossPos():
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                else:
                    self.family.SetState(STATE_GS_MOVE_GO)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_XiaoMiJing_Next")
                break
            
            if case(STATE_GS_LEAGUEMATCH_SKILL):#准备开始放技能
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                logging.debug('技能')
                self.family.gameServerNetPackHandle.canSkill = True
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))

            # 继续使用技能
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                bossPos = self.family.xiaomijing.GetBossPos()
                if bossPos:#有敌人就放技能
                    logging.debug("继续使用技能")
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *bossPos)
                    gevent.sleep(2)
                    self.family.gameServerNetPackHandle.SkillCanBeReleased()
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                else:#没有敌人进入下个区域
                    self.family.gameServerNetPackHandle.canSkill = False
                    gevent.sleep(3)
                    self.family.SetState(STATE_GS_XIAOMIJING_JUDGE)
                break
            

                        
            #开宝箱
            if case(STATE_GS_XIAOMIJING_OPEN_BOX):
                self.family.SetState(STATE_GS_XIAOMIJING_WAIT)
                logging.debug("开宝箱")
                pos = self.family.xiaomijing.boxMsg["pos"]
                boxId = self.family.xiaomijing.boxMsg["id"]
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.AskNpc_obj(boxId)
                break
            
            # 结束
            if case(STATE_GS_END):
                logging.debug("小秘境案例结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_XiaoMiJing_Finish")
                self.family.behavior = Behavior.END
                break









