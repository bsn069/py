#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import math
from locust.events import *
from locust.asyncevent import *
from Config.RoleFigures import Behavior
from net.Common.ComDefine_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import * 
from TestCase_TeamBase import TeamBaseCase, TeamCreateType, TeamMemberType, MatchType
from account.account_def import AccountDef
from account.account_service import account_hengxujing
from TestCase.Files.DaMiJing import JoinType
'''
      衡虚镜的TestCase
'''

class MoveState:
    NONE = 0
    APPLY_FIGHT = 1
    APPLY_ROB = 2
    BAOXIANG = 3
    FINDING_NPC = 4

class TestCase(TeamBaseCase):
    NAME = "DAMIJING"
    KEY_ITEM = (5, 1, 47, 1)
    REWARD_ID = 12042
    GUIDER_ID = 12043
    READY_SCENE_ID = 2032
    
    SCENE_INFO = {
                  # 场景模板ID:((指引者POS), (宝箱POS), (找不到怪物的时候，自动寻路的坐标)),
                  1861:((75.17, 56.25), (63.1, 62.8), ((75.17, 56.25), (72.29, 46.83), (98.11, 71.01), (53.76, 88.56), (34.59, 59.08))), # 水
                  1862:((75.22, 58.93), (63.1, 56.53), ((75.22, 58.93), (76.91, 47.42), (47.76, 43.41), (46.50, 79.27), (82.98, 77.16))),   # 火
                  1863:((88.72, 84.23), (98.3, 93.2), ((88.72, 84.23), (80.83, 65.53), (69.83, 74.82), (93.99, 104.15), (112.73, 91.12))), # 金
                  1864:((62.35, 65.99), (55.5, 71.28), ((62.35, 65.99), (70.33, 79.21), (61.70, 65.01), (48.73, 49.44))), # 木
                  1865:((60.9, 56.65), (60.68, 65.37), ((60.9, 56.65), (62.33, 44.59), (80.93, 64.31), (60.35, 84.68), (44.24, 64.16))),   # 土
                  }
    
    #sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_HENG_XU_JING, TEAM_TYPE_HENG_XU_JING, u"衡虚境", teamCreateType=TeamCreateType.FIXED)
        self.family = family
        self.sceneId = 0
        self.sceneTemplateId = 0
        self.moveState = MoveState.NONE
        self.time = None
        self.family.gameServerNetPackHandle.canSkill = False
        
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_hengxujing(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[HengXuJing Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)

            
        if self.family.team_manager.myteam.accountId % 5 != 0:
            self.family.damijing.joinType = JoinType.NORMAL
        else:
            self.family.damijing.joinType = JoinType.ROB
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_DAMIJING_WAIT_ENTRY_READY_SCENE)
                if self.family.isNewRole == False:
                    self.family.gameServerNetPackHandle.ClearItemRoom()
                if self.family.bag.GetItemCount(*self.KEY_ITEM) < 1:
                    self.family.gameServerNetPackHandle.CallScriptAddStackItem(*(self.KEY_ITEM + (20, 0, False, 0,)))
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.Transfer(self.READY_SCENE_ID, 0, 3.0)
                break
            
            if case(STATE_GS_DAMIJING_ENTRY_READY_SCENE):
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                break
            
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                if self.family.team_manager.myteam.IsLeader():
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                break
            
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                if self.family.damijing.joinType == JoinType.NORMAL:
                    self.family.gameServerNetPackHandle.DaMiJingEnterMission()
                elif self.family.damijing.joinType == JoinType.ROB:
                    self.family.damijing.level = 20
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(1010, 4, %d)" % self.family.damijing.level)
                    self.family.gameServerNetPackHandle.DaMiJingApplyMissionList()
                break

            if case(STATE_GS_DAMIJING_ENTER_SCENE):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                self.sceneTemplateId = self.family.gameServerNetPackHandle.sceneTemplateId
#                 self.family.gameServerNetPackHandle.AddBuffBlock()
                if not self.family.damijing.hasBeRob:
                    self.family.gameServerNetPackHandle.AddBuffHeavyDamage()
                break
            
            if case(STATE_GS_DAMIJING_MOVETO_GUARD):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                gevent.sleep(2)
                self.moveState = MoveState.APPLY_FIGHT
                self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.SCENE_INFO[self.family.gameServerNetPackHandle.sceneTemplateId][0]))
                self.sceneTemplateId = self.family.gameServerNetPackHandle.sceneTemplateId
                break
                
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                if self.moveState == MoveState.APPLY_FIGHT:
                    if self.family.team_manager.myteam.IsLeader():
                        if self.family.damijing.taishidanId:
                            self.family.gameServerNetPackHandle.AskNpc_obj(self.family.damijing.taishidanId)
                            self.family.damijing.taishidanId = None
                        else:
                            self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.SCENE_INFO[self.sceneTemplateId][0]))
                elif self.moveState == MoveState.BAOXIANG:
                    if self.family.damijing.baoXiang:
                        self.family.gameServerNetPackHandle.AskNpc_obj(self.family.damijing.baoXiang.keys()[0])
                        gevent.sleep(15)
#                     self.family.gameServerNetPackHandle.DaMiJingExitMission()
                elif self.moveState == MoveState.APPLY_ROB:
                    # 等待开始战斗的消息
                    pass
                elif self.moveState == MoveState.FINDING_NPC:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                else:
                    logging.error("[%s] STATE_GS_MOVE_ARRIVAL move State=%d" % (TestCase.NAME, self.moveState))
            
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                if self.family.damijing.joinType == JoinType.NORMAL and not self.family.damijing.hasBeRob:
                    if self.family.damijing.npcDict:
                        pos = random.choice(self.family.damijing.npcDict.values())
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
#                         gevent.sleep(1)
                        self.family.gameServerNetPackHandle.SkillCanBeReleased()
                    else:
#                        self.moveState = MoveState.FINDING_NPC
#                        self.family.gameServerNetPackHandle.PlayerAutoPath(*(random.choice(self.SCENE_INFO[self.sceneTemplateId][2])))
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *(random.choice(self.SCENE_INFO[self.sceneTemplateId][2])))
                        self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                        gevent.sleep(3)
                else:
                    if self.family.characterCur.state != CHAR_STATE_DEATH:
                        nowX = self.family.characterCur.posX
                        nowY = self.family.characterCur.posY
                        skillPos = self.SCENE_INFO[self.sceneTemplateId][0]
                        if math.fabs(nowX - skillPos[0]) > 3 or math.fabs(nowY - skillPos[1]) > 3:
                            self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *skillPos)
                        self.family.gameServerNetPackHandle.SkillCanBeReleased()
                break
                    
            if case(STATE_GS_DAMIJING_MOVETO_BAOXIANG):
                self.family.gameServerNetPackHandle.canSkill = False
                self.moveState = MoveState.BAOXIANG
                self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.SCENE_INFO[self.sceneTemplateId][1]))
                break
            
            if case(STATE_GS_DAMIJING_ROB_LIST_RSP):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                result = self.family.gameServerNetPackHandle.ClientApplyRobMission()
                if not result:
                    self.family.gameServerNetPackHandle.DaMiJingApplyMissionList()
                    gevent.sleep(5)
                break
            
            if case(STATE_GS_DAMIJING_MOVETO_ROB_SKILLPOINT):
                self.family.SetState(STATE_GS_DAMIJING_WAIT)
                self.moveState = MoveState.APPLY_ROB
                self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.SCENE_INFO[self.sceneTemplateId][0]))
                break
            
            if case(STATE_GS_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_DaMiJing_Finish")
                self.family.behavior = Behavior.END
                break
                
