#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
import math
from locust.events import *
from locust.asyncevent import asyncresult_manager
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from Tools.Enum import enum
from TestCase_TeamBase import TeamBaseCase, TeamCreateType, TeamMemberType
from account.account_def import AccountDef
from account.account_service import account_cross_battle
from _ast import Pass
from TestCase.Files.Team import TeamBaseInfo


'''
      跨服约战TestCase
'''


class TestCase(TeamBaseCase):
    MIN_LEVEL = 46
    NPC = {
           '跨服约战报名官':(64.92, 55.84, 43.75),
           }
    



    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE_BIG, TEAM_TYPE_FREE_BIG, u"跨服约战", teamCreateType=TeamCreateType.FIXED)
        self.family = family
        if random.randint(0, 1) == 1:
            self.family.crossbattle.type = True #大师赛开启
        self.moveTarget = {
                   'pos' : (0, 0),
                   }
        self.count = 0
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_cross_battle(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[CrossBattle Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                if self.family.isNewRole:
                    #第一次新建角色
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                self.family.SetState(STATE_GS_CROSSBATTLE_ENTER_WAIT)
                self.family.gameServerNetPackHandle.Transfer(SenceKuaFuBattle)
                break


            elif case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                if self.family.team_manager.myteam.IsLeader():
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                break
                
            elif case(STATE_GS_CROSSBATTLE_CREATROOM):
                self.family.gameServerNetPackHandle.Do_NVNCreateRoomReq()
                break
            
            elif case(STATE_GS_CROSSBATTLE_FINDROOM):
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                self.family.gameServerNetPackHandle.Do_RoomListReq()
                gevent.sleep(5)
                break
            
            elif case(STATE_GS_CROSSBATTLE_JOIN):
                self.family.gameServerNetPackHandle.Do_NVNJoinRoomReq()
                break
            
            elif case(STATE_GS_CROSSBATTLE_ENTER):
                self.family.SetState(STATE_GS_MOVE_GO)
                self.moveTarget["pos"] = TestCase.NPC['跨服约战报名官']
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveTarget["pos"])
                gevent.sleep(2)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                if self.count == 0:
                    self.count +=1
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
#                    self.family.SetState(STATE_GC_TEAM_MEMBER_CALL_FINISHED)
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)

            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):#释放下次技能
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                if math.fabs(nowX - self.moveTarget["pos"][0])> 3 or math.fabs(nowY - self.moveTarget["pos"][1]) > 3:
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.moveTarget["pos"])
                    gevent.sleep(1)
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            
            elif case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_CROSSBATTLE_FINDROOM)
                break

            elif case(STATE_GS_CROSSBATTLE_FIGHT):
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                self.moveTarget["pos"] = self.family.crossbattle.SencePos[self.family.gameServerNetPackHandle.sceneTemplateId]
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            elif case(STATE_GS_CROSSBATTLE_END):
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                logging.debug("跨服约战结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_CrossBattle_End")
                self.family.behavior = Behavior.END #结束案例
                break
