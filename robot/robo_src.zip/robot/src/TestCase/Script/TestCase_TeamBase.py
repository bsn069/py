# coding= utf-8
__author__ = 'Administrator'
import random
import gevent
import asyncore
import logging
import time
from Config.CaseDefine import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from TestCase.Files.Team import Team

class TeamMemberType(object):
    FREE = 0
    LEADER = 1
    MEMBER = 2
    
class TeamCreateType(object):
    FIXED = 0
    RANDOM = 1
    
class MatchType:
    SINGLE = 0
    TEAM = 1
    
class TeamBaseCase(object):
    MAX_WAIT_TEAM_TIME = random.randint(45, 75)

    def __init__(self, family, teamType, teamTypeEx, msg, channel=emChatChannelInvite, teamCreateType=TeamCreateType.RANDOM):
        self.family = family
        self.family.team_manager.myteam.type = teamType  # 服务端已经有定义的组队类型
        self.family.team_manager.myteam.typeEx = teamTypeEx # 服务端未定义的组队类型，比如主线任务，枫华谷
        self.family.team_manager.myteam.SetTeamLimit(random.randint(*Team.TEAM_MEMBER_LIMIT[teamTypeEx]))
        self.family.team_manager.myteam.teamCreateType = teamCreateType
        self.team_msg = msg
        self.is_skip_invite_check = False
        self.channel = channel
        self.beginTime = 0
        self.member_type = TeamMemberType.FREE
        

    def _Action(self):
        if self.family.state == STATE_GC_TEAM_BEGIN:
            self.family.SetState(STATE_GC_TEAM_WAIT)
            if self.family.team_manager.myteam.IsInTeam():
                self.family.SetState(STATE_GC_TEAM_QUIT_FOR_CREATE)
                logging.debug("退出队伍")
                self.family.gameServerNetPackHandle.TeamLeaveReq()
            else:
                self.family.team_manager.myteam.isBegin = True
                logging.debug("STATE_GC_TEAM_START")
                self.family.gameServerNetPackHandle.TeamListQuery()

        elif self.family.state == STATE_GC_TEAM_START:
            self.beginTime = time.time()
            if self.member_type == TeamMemberType.FREE:
                if self.family.team_manager.recruitList.has_key(self.family.team_manager.myteam.typeEx) and random.randint(0, 1) == 0:
                    self.family.SetState(STATE_GC_TEAM_APPLY)  # 加入队伍
                else:
                    if random.randint(0, Team.TEAM_MEMBER_LIMIT[self.family.team_manager.myteam.typeEx][1]) < 1:
                        self.family.SetState(STATE_GC_TEAM_CREATE)  # 创建队伍
                    else:
                        self.family.SetState(STATE_GC_TEAM_APPLY)  # 加入队伍
            elif self.member_type == TeamMemberType.LEADER:
                self.family.SetState(STATE_GC_TEAM_CREATE)  # 创建队伍
            elif self.member_type == TeamMemberType.MEMBER:
                self.family.SetState(STATE_GC_TEAM_APPLY)  # 加入队伍
        #创建队伍
        elif self.family.state == STATE_GC_TEAM_CREATE:
            logging.debug("创建队伍")
            self.family.SetState(STATE_GC_TEAM_CREATE_WAIT)
            self.family.gameServerNetPackHandle.TeamCreateReq(self.family.team_manager.myteam.type)

        # 发送队伍招募消息
        elif self.family.state == STATE_GC_TEAM_CREATE_FINISHED:
            self.family.SetState(STATE_GC_TEAM_RECRUIT)
            #队长加入队伍频道
            logging.debug("队长加入队伍频道")
            self.family.gameServerNetPackHandle.ChatRoomEnterRoom(self.family.team_manager.myteam.id, ChatRoom_Team)
            memberLimit = self.family.team_manager.myteam.GetTeamLimit()
            if memberLimit == 1:
                self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
            elif self.family.team_manager.myteam.teamCreateType == TeamCreateType.FIXED:
                # do nothing
                pass
            else:
                #招募信息
                msg = u"[26B2F3,<%s:%s(%d/%d)><%d>,team,%d,%d]" % (
                    self.family.mainName,
                    self.team_msg,
                    self.family.team_manager.myteam.MemberCount(),
                    self.family.team_manager.myteam.GetTeamLimit(),
                    self.family.team_manager.myteam.typeEx,
                    self.family.team_manager.myteam.id,
                    self.family.team_manager.myteam.type)
                StartTime = time.time()
                logging.debug("[ Team -> memberLimit = %d ]" % memberLimit)
                while self.family.GetState() == STATE_GC_TEAM_RECRUIT:
                    if (time.time() - StartTime) > TeamBaseCase.MAX_WAIT_TEAM_TIME * 2 and self.family.team_manager.myteam.MemberCount() == 1:
                        self.family.SetState(STATE_GC_TEAM_BEGIN)
                        break
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(msg=msg, channel=self.channel)
                    gevent.sleep(25)

        #申请加入队伍
        elif self.family.state == STATE_GC_TEAM_APPLY:
            if self.family.team_manager.myteam.teamCreateType == TeamCreateType.FIXED:
                # 给队长发送入队消息，请求队长拉入队伍
#                 self.family.SetState(STATE_GC_TEAM_APPLY_WAIT)
                self.family.gameServerNetPackHandle.TeamApplyMsg(self.family.team_manager.myteam.accountId,
                                                                 self.family.team_manager.myteam.leaderFamilyId,
                                                                 self.family.familyId,
                                                                 self.family.groupId)
                                                                
                gevent.sleep(5)
            else:
                # 超过MAX_WAIT_TEAM_TIME时间，还没有加入队伍，则选择创建队伍
                if (time.time() - self.beginTime) > TeamBaseCase.MAX_WAIT_TEAM_TIME * 2:
                    if self.member_type is TeamMemberType.MEMBER:
                        self.family.SetState(STATE_GC_TEAM_TIMEOUT)
                    else:
                        self.family.SetState(STATE_GC_TEAM_CREATE)
                else:
                    logging.debug("申请加入队伍")
                    self.family.gameServerNetPackHandle.TeamApplyReq(self.family.team_manager.myteam.typeEx)  # 申请入队
                    gevent.sleep(3)

        elif self.family.state ==  STATE_GC_TEAM_MEMBERCALL_BEGIN:
            if self.family.gameServerNetPackHandle.sceneTemplateId == self.family.team_manager.myteam.SceneTemplateId() \
            and self.family.gameServerNetPackHandle.sceneInstanceId == self.family.team_manager.myteam.SceneInstanceId():
                self.family.SetState(STATE_GC_TEAM_MEMBERCALL)
                self.family.gameServerNetPackHandle.MarkTestCase("STATE_GC_TEAM_MEMBERCALL")
            else:
                gevent.sleep(1)
                
        elif self.family.state == STATE_GC_TEAM_MEMBERCALL:
            if self.family.team_manager.myteam.IsAllNearby():
                self.family.SetState(STATE_GC_TEAM_MEMBER_CALL_FINISHED)
            else:
                self.family.gameServerNetPackHandle.TeamMemberCallCheck()
                gevent.sleep(15)
            
        elif self.family.state == STATE_GC_TEAM_RECRUIT_CHECKIN:
            self.family.gameServerNetPackHandle.ChatRequestByMsg(msg="TeamBeginCheckIn", channel=emChatChannelTeam)
            gevent.sleep(15) # 队伍频道CD
            
        elif self.family.state == STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN:
            self.family.gameServerNetPackHandle.ChatRequestByMsg(msg="TeamCheckIn|%d" % self.family.familyId,
                              channel=self.family.team_manager.myteam.leaderFamilyId)
            gevent.sleep(3)
            
        elif self.family.state == STATE_GC_TEAM_RECRUIT_CHECKIN_DONE:
            self.family.gameServerNetPackHandle.ChatRequestByMsg(msg="TeamReadyReq", channel=emChatChannelTeam)
            gevent.sleep(15) # 队伍频道CD
            

        elif self.family.state == STATE_GC_TEAM_QUIT_FINISHED:
            pass
            
