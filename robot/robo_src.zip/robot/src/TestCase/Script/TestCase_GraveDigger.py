#!/usr/bin/env python2.7
# coding:utf8
import math
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Config.RoleFigures import * 
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase

'''
    探宝的TestCase
'''


class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_TAN_BAO, TEAM_TYPE_TAN_BAO, u"探宝")
        self.family = family
        self.site = []
        self.npcSite = (77, 226)
        self.step = 0

        self.moveTarget = WaBaoMove_Common
        self.npcTarget = {}
        self.hasEnterSecondFloor = False
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                if self.family.graveDigger.isEnterDiGongFirstFloor:
                    gevent.sleep(5)
                    logging.debug("打完地宫了！结束案例")
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_GraveDigger_UndergroundPalaceFinish")
                    self.family.behavior = Behavior.END
                    break
                self.family.SetState(STATE_GS_MOVE_GO)
                self.family.gameServerNetPackHandle.Add_DiggerItem()
                if self.family.isNewRole==False:
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(118,5,5)")
                gevent.sleep(1)
                break

            if case(STATE_GS_START_GRAVEDIGGER_TEAM):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                self.family.gameServerNetPackHandle.Can_TeamJoinCheck = False
                self.family.gameServerNetPackHandle.TeamNotJoin = True
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                break

            #开启探宝
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):  #队长接任务，等待队员接受
                    logging.debug("等待队友传送过来")
                    gevent.sleep(10)
                    self.family.gameServerNetPackHandle.AskNpc("卫长风")
                    self.family.gameServerNetPackHandle.StartSeekTreasure()
                    gevent.sleep(3)
                else:
                    logging.debug("队友传送至队长位置")
                    self.family.gameServerNetPackHandle.TransferToTeammate(self.family.team_manager.myteam.leaderFamilyId)
                break

            #放入材料
            if case(STATE_GS_GRAVEDIGGER_PUTINCLUEITEM):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                self.family.gameServerNetPackHandle.PutInTreasureClueItem()
                break

            #传送到指定地图
            if case(STATE_GS_GRAVEDIGGER_TRANSFER2MAP):
                self.family.gameServerNetPackHandle.Transfer2Map(self.family.graveDigger.mapid)
                gevent.sleep(10)
                self.family.gameServerNetPackHandle.AddBuffInvincible()#增加无敌
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            #移动到探宝地点/探宝npc
            if case(STATE_GS_MOVE_GO):
                self.family.SetState(STATE_GS_MOVE_MOVING)
                if self.moveTarget == WaBaoMove_Common:
                    if self.step == 0:  # 到领取任务NPC
                        logging.debug("移动到领取任务NPC")
                        self.family.gameServerNetPackHandle.PlayerAutoPath(*self.npcSite)
#                         self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.npcSite)
                    elif self.step == 1:  # 到探宝地点
                        logging.debug("移动到探宝地点")
                        self.site = self.family.graveDigger.GetSite()
                        if self.site:
                            self.family.gameServerNetPackHandle.PlayerAutoPath(*self.site)
#                             self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.site)
                        else:
                            logging.debug("没有获取到探宝地点")
                elif self.moveTarget == WaBaoMove_ToNpc:#移动至地宫敌人位置
                    logging.debug("移动至地宫敌人位置")
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.npcTarget["pos"])
                elif self.moveTarget == WaBaoMove_ToSecondFloor:#移动至地宫二层
                    logging.debug("10s后移动至地宫二层")
                    self.family.gameServerNetPackHandle.canSkill = False
                    gevent.sleep(10)#等待打开地宫二层
                    self.family.gameServerNetPackHandle.PlayerAutoPath(PosDiGongSecondFloorCenter[0], PosDiGongSecondFloorCenter[1])
                elif self.moveTarget == WaBaoMove_ToBonfire:#移动至地宫篝火
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.family.graveDigger.bonfirePox)
                break

            #开始探宝
            if case(STATE_GS_MOVE_ARRIVAL):
                gevent.sleep(3)
                if self.moveTarget == WaBaoMove_Common:
                    if self.step == 0:
                        self.family.SetState(STATE_GS_START_GRAVEDIGGER_TEAM)
                        self.step += 1
                    elif self.step == 1:
                        logging.debug('到达地点 %d,%d 开始探宝' % (self.site[0], self.site[1]))
                        self.family.gameServerNetPackHandle.CollectAction()
                        gevent.sleep(10)
                        logging.debug("\nself.family.graveDigger.GetDigger() = {0}\n".format(self.family.graveDigger.GetDigger()))
                        if self.family.graveDigger.GetDigger() == WaDaoDiGong:
                            self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG)
                        elif self.family.graveDigger.SiteLen():
                            self.family.SetState(STATE_GS_MOVE_GO)
                        else:
                            self.family.behavior = Behavior.END
                elif self.moveTarget == WaBaoMove_ToNpc:#到达地宫敌人位置
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                elif self.moveTarget == WaBaoMove_ToSecondFloor:#到达地宫二层
                    self.moveTarget = WaBaoMove_ToNpc
                    self.family.gameServerNetPackHandle.canSkill = True
                    self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG_JUDGE)
                elif self.moveTarget == WaBaoMove_ToBonfire:#到达地宫篝火
                    logging.debug("到达地宫篝火")
                    self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                break

            #挖到地宫wwd
            if case(STATE_GS_GRAVEDIGGER_DIGONG):
                logging.debug('挖到地宫')
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                if self.family.graveDigger.digongId:
                    logging.debug("准备Ask地宫NPC的id = {0}".format(self.family.graveDigger.digongId))
#                     self.family.gameServerNetPackHandle.AskNpc(self.family.graveDigger.digongId)
                    self.family.gameServerNetPackHandle.AskNpc_obj(self.family.graveDigger.digongId)
                    gevent.sleep(1)
                else:
                    raise "地宫入口id为None"
                break
            
            #进入地宫
            if case(STATE_GS_GRAVEDIGGER_ENTER_DIGONG):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
#                 logging.debug("释放技能")
#                 self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                self.family.gameServerNetPackHandle.AddBuffBlock()#强力格挡
                gevent.sleep(20)#等待关卡开始
                self.moveTarget = WaBaoMove_ToNpc
                self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG_JUDGE)
                break
            
            #发现地宫二层
            if case(STATE_GS_GRAVEDIGGER_DIGONG_SECONDFLOOR):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                self.moveTarget = WaBaoMove_ToSecondFloor
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            #判断地宫敌人是否杀完了
            if case(STATE_GS_GRAVEDIGGER_DIGONG_JUDGE):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                npc = self.family.graveDigger.GetDiGongNpcInfo()
                if npc:
                    logging.debug("去杀敌人")
                    self.npcTarget = npc
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    if self.family.graveDigger.isEnterDiGongSecondFloor and not self.hasEnterSecondFloor:
                        logging.debug("去杀敌人")
                        self.hasEnterSecondFloor = True
                        self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG_SECONDFLOOR)
                    elif self.family.graveDigger.hasFindBonfire:
                        logging.debug("地宫敌人都杀掉了, 移动至篝火~")
                        self.moveTarget = WaBaoMove_ToBonfire
                        self.family.SetState(STATE_GS_MOVE_GO)
                    else:
                        logging.debug("案例异常")
                break
            
            #释放下次技能
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_GRAVEDIGGER_WAIT)
                if self.npcTarget["id"] in self.family.graveDigger.diGongNpcInfo.keys():
                    if math.fabs(self.family.characterCur.posX - self.npcTarget["pos"][0]) >= 3 or math.fabs(self.family.characterCur.posY - self.npcTarget["pos"][1]) >= 3:
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.npcTarget["pos"])
                    logging.debug("释放下次技能")
                    gevent.sleep(1.5)
                    self.family.gameServerNetPackHandle.SkillCanBeReleased()
                else:
                    logging.debug("目标npc已死亡，转向判断")
                    self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG_JUDGE)
                break

            #奇遇操作后，恢复上一个操作的状态
            if case(STATE_GS_FORTUITOUS_MEETING):
                self.family.gameServerNetPackHandle.FortuitousMeeting(random.randint(1, 2))
                self.family.SetState(self.family.gameServerNetPackHandle.nowState)
                logging.debug(self.family.GetState())
                break








