# coding:utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config

'''
      外观的TestCase
'''
class ColorPlan(object):
    MAX_COLOR_COUNT = 3

    def __init__(self, place):
        self.place = 0
        self.curPlanIdx = 0
        self.planCount = -1
        self._choiceIdx = -1
        self.isReplaced = False

    def Choice(self):
        choice = [x for x in range(0, self.planCount) if x != self.curPlanIdx]
        if choice:
            self.choice_idx = random.choice(choice)
            return self.choice_idx
        return -1

    def Add(self):
        if self.planCount < ColorPlan.MAX_COLOR_COUNT:
            self.planCount +=1
            self.curPlanIdx += 1
        else:
            self.planCount = ColorPlan.MAX_COLOR_COUNT
            self.curPlanIdx = ColorPlan.MAX_COLOR_COUNT - 1
            self.isReplaced = True

    def Remove(self):
        if self.planCount <= 1 or self.curPlanIdx == self._choiceIdx:
            return False
        else:
            if self._choiceIdx < self.curPlanIdx:
                self.curPlanIdx -= 1
            self.planCount -= 1
            self.isReplaced = False

    def Set(self):
        self.curPlanIdx = self._choiceIdx

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.color_plan = [ColorPlan(place=0), ColorPlan(place=1)] # 头发和衣服
        self.color_avatar_key = -1
        self.CustomFace_HairId = 0

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.gameServerNetPackHandle.GetEnoughMoney(VALUE_COIN_BIND_GOLD, 10000)
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,10000,0)")
                if self.family.isNewRole:
                    self.family.SetState(STATE_GS_APPEARANCE_WEAR_FASHION)
                else:
                    self.family.SetState(STATE_GS_APPEARANCE_COLORING_HEAD)
                break
            
            if case(STATE_GS_APPEARANCE_WEAR_FASHION):
                self.family.gameServerNetPackHandle.RandomAvatar()#穿随机时装
                gevent.sleep(5)
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            #走到染色店老板
            if case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.PlayerAutoPath(672, 551)
#                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, 235.17, 99)
                break
            
            #到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.gameServerNetPackHandle.AskNpc("沈荷叶")#对话
                self.family.SetState(STATE_GS_APPEARANCE_COLORING_HEAD)
                break
            
            #头发染色
            if case(STATE_GS_APPEARANCE_COLORING_HEAD):
                self.family.SetState(STATE_GS_APPEARANCE_COLORING_HEAD_WAIT)
                logging.debug("头发染色")
                key = self.GetAvatarKey(Appearance_Hair)
                if key != -1:
                    self.color_avatar_key = key
                    self.family.gameServerNetPackHandle.ApplyColoringItem(ELEMENT_HAIR, self.color_avatar_key)
                    self.color_plan[0].Add()
                else:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Appearance_ColoringHair", isSuccess=False, exception="key = -1")
                    self.family.SetState(STATE_GS_END)
                break
            
            #衣服染色
            if case(STATE_GS_APPEARANCE_COLORING_BODY):
                self.family.SetState(STATE_GS_APPEARANCE_COLORING_BODY_WAIT)
                logging.debug("衣服染色")
                key = self.GetAvatarKey(Appearance_Fashion)
                if key != -1:
                    self.color_avatar_key = key
                    self.family.gameServerNetPackHandle.ApplyColoringItem(ELEMENT_BODY, self.color_avatar_key)
                    self.color_plan[1].Add()
                else:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Appearance_ColoringFashion", isSuccess=False, exception="key = -1")
                    self.family.SetState(STATE_GS_END)
                break
            
            # 染色次数检查，一共染色4次，第4次会覆盖第3次的方案
            if case(STATE_GS_APPEARANCE_COLORING_COUNT_CHECK):
                logging.debug("染色次数检查")
                if self.color_plan[1].isReplaced:
                    self.family.SetState(STATE_GS_APPEARANCE_COLORING_APPLY_USE_PLAN)
                else:
                    self.family.SetState(STATE_GS_APPEARANCE_COLORING_BODY)
                break

            if case(STATE_GS_APPEARANCE_COLORING_APPLY_USE_PLAN):
                self.family.SetState(STATE_GS_APPEARANCE_WAIT)
                logging.debug("使用方案")
                plan = self.color_plan[1]
                self.family.gameServerNetPackHandle.ApplyUseColoringPlan(key=self.color_avatar_key,
                                                                         plan_idx=plan.Choice())
                plan.Set()
                break

            if case(STATE_GS_APPEARANCE_COLORING_APPLY_DEL_PLAN):
                self.family.SetState(STATE_GS_APPEARANCE_WAIT)
                logging.debug("删除方案")
                plan = self.color_plan[1]
                self.family.gameServerNetPackHandle.ApplyDelColoringPlan(key=self.color_avatar_key,
                                                                         plan_idx=plan.Choice())
                plan.Remove()
                break
            
            #捏脸
            if case(STATE_GS_APPEARANCE_FACE_BONE):
                self.family.SetState(STATE_GS_APPEARANCE_FACE_BONE_WAIT)
                face_bone = self.family.appearance.GetRandomFaceBoneData()
                logging.debug("face_bone=%s" % face_bone)
                self.CustomFace_HairId = self.family.appearance.AppearanceDict[Appearance_Hair]["avatarId"]
                if self.family.isNewRole:
                    bindFaceId = 1
                else:
                    bindFaceId = 2
                self.family.gameServerNetPackHandle.ApplySetMemberFace(face_bone, self.CustomFace_HairId, bindFaceId, hair_buy_index=2)
                break
            
            #妆容
            if case(STATE_GS_APPEARANCE_FACE_LOOK):
                self.family.SetState(STATE_GS_APPEARANCE_FACE_LOOK_WAIT)
                face_look = self.family.appearance.GetRandomFaceLookData()
                logging.debug("face_look=%s" % face_look)
                self.family.gameServerNetPackHandle.ApplySetMemberFace(face_look, self.CustomFace_HairId, 2, isBone=False, hair_buy_index=2)
                break
            
            #保存捏脸与妆容方案
            if case(STATE_GS_APPEARANCE_FACE_SAVE):
                faceData = self.family.characterCur.faceData
                if faceData:
                    self.family.gameServerNetPackHandle.ApplySaveFacePlan(faceData, hairId=self.CustomFace_HairId)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Appearance_FaceSave")
                    gevent.sleep(2)
                else:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Appearance_FaceSave", isSuccess=False, exception="faceData not found")
                self.family.SetState(STATE_GS_END)
                break
            
            if case(STATE_GS_END):
                logging.debug("外观案例结束")
                self.family.behavior = Behavior.END
                break
            
    def GetAvatarKey(self, avatarType):
        key = -1
        AppearanceDict = self.family.appearance.AppearanceDict
        if AppearanceDict[avatarType].has_key("key"):
            key = AppearanceDict[avatarType]["key"]
        return key
    