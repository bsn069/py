#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
import math
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from account.account_def import AccountDef
from locust.events import request_failure
from locust.asyncevent import asyncresult_manager
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from account.account_service import account_eatchicken

"""
        吃鸡TestCase
"""

class TestCase(TeamBaseCase):

    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_BATTLE_MATCH, TEAM_TYPE_BATTLE_MATCH, u"吃鸡活动", teamCreateType=TeamCreateType.FIXED)
        self.family = family
        self.npcPos = (27.72, 72.17, 38)
        self.target = ""
        self.moveTarget = {
                           'pos' : (0, 0, 0),
                           }
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_eatchicken(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[Eatchicken Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
            
    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_EAT_CHICKEN_START)
                if self.family.isNewRole:
                    #装备技能
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                break
            
            elif case(STATE_GS_EAT_CHICKEN_START):
                self.family.SetState(STATE_GS_EAT_CHICKEN_WAIT)
                self.family.gameServerNetPackHandle.Transfer(SceneMoBeiCaoYuan)
                break
            
            elif case(STATE_GS_EAT_CHICKEN_MOBEI):
                self.family.SetState(STATE_GS_MOVE_GO)
                self.target = "移动至NPC位置"
                self.moveTarget['pos'] = self.npcPos
                break
            
            elif case(STATE_GS_MOVE_GO):
                if self.family.eatchicken.ismove:
                    self.family.eatchicken.ismove = False
                sceneId = self.family.gameServerNetPackHandle.sceneTemplateId
                pos = self.moveTarget['pos']
                if sceneId == SenceXueYuSha:
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("pl:MoveToPosition({X}, {Y},{Z})".format(X=pos[0], Y=pos[1], Z=pos[2]))
                else:
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                gevent.sleep(1)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_EAT_CHICKEN_WAIT)
                if self.target == "移动至NPC位置":
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                    break
                elif self.target == "移动至毒圈中间":
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                    break
                elif self.target == "准备捡装备":
                    self.family.SetState(STATE_GS_EAT_CHICKEN_EQUIP)
                    break
                elif self.target == "开始捡装备":
                    self.family.SetState(STATE_GS_EAT_CHICKEN_SKILL)
                    self.family.gameServerNetPackHandle.PickUpDropInfo(self.family.eatchicken.equip['id'])
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCast_EatChicken_Equip")
                    break
                
            elif case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                break
            
            elif case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_EAT_CHICKEN_ASK)
                break        
                    
            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                if self.family.eatchicken.isdeath:
                    self.family.SetState(STATE_GS_EAT_CHICKEN_END)
                    break
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                if self.family.eatchicken.ismove:
                    self.family.SetState(STATE_GS_EAT_CHICKEN_SKILL)
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                gevent.sleep(1.5)
                if random.randint(0, 5) < 1:
                    self.family.SetState(STATE_GS_EAT_CHICKEN_EQUIP_WAIT)
                break
            
            elif case(STATE_GS_EAT_CHICKEN_EQUIP_WAIT):
                self.family.SetState(STATE_GS_EAT_CHICKEN_WAIT)
                self.target = "准备捡装备"
                self.moveTarget['pos'] = self.family.eatchicken.place_txt[random.randint(0, len(self.family.eatchicken.place_txt)-1)]
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_EAT_CHICKEN_EQUIP):
                self.family.SetState(STATE_GS_MOVE_GO)
                if self.family.eatchicken.equip['take']:
                    self.target = "开始捡装备"
                    self.moveTarget['pos'] = self.family.eatchicken.equip['pos']
                    self.family.eatchicken.equip['take'] = False
                else:
                    self.family.SetState(STATE_GS_EAT_CHICKEN_SKILL)
                break
            
            elif case(STATE_GS_EAT_CHICKEN_ASK):
                self.family.SetState(STATE_GS_EAT_CHICKEN_WAIT)
                self.family.gameServerNetPackHandle.CallScript("PlayerCmd", "LiveGameMatchReq")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCast_EatChicken_SignUp")
                break
            
            elif case(STATE_GS_EAT_CHICKEN_SKILL):
                self.family.SetState(STATE_GS_MOVE_GO)
                self.target = "移动至毒圈中间"
                self.moveTarget['pos'] = self.family.eatchicken.movepos['pos']
                break
            
            elif case(STATE_GS_EAT_CHICKEN_END):
                self.family.SetState(STATE_GS_EAT_CHICKEN_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_EatChicken_Finish")
                self.family.behavior = Behavior.END
                break


