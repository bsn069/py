# coding:utf-8
import random
import gevent
import asyncore
import math
import time
import logging
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from TestCase_KinBase import KinBaseCase, KinCreateType
from account.account_service import account_yewai, account_kin, account_yewai_campTag
from account.account import AccountDef

"""
         技能测试的TestCase
"""

class TestCase(TeamBaseCase, KinBaseCase):
    
    #队伍类型
    LEADER = 1
    MEMBER = 2
    
    def __init__(self, family):
        self.family = family        
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_SKILLTEST, u"技能测试", teamCreateType=TeamCreateType.FIXED)
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_yewai(self.family.familyId, self.family.serverGroupId)
        self.family.camp.campTag = account_yewai_campTag()

        self.fightMove = False
        self.fightMoveRadius = {#移动范围半径
                                SceneLongmen : 1,
                                SceneLiShanYiJi : 5,
                                }
        self.needRandomMove = False#是否需要攻击后随机移动
        self.needRandomPos = False#是否需要不聚集在一个点放技能
        self.family.skill.needCommonAttack = False#是否需要技能cd时放普攻
        self.randomPos = ()
        self.fightPos = {
                         SceneLongmen : (154.39, 81.28),#首领出没点四
                         SceneLiShanYiJi : (124.9, 56.14),#首领出没点六
                         }
        
        #进图的等级限制
        self.levelLimit = {
                           SceneLongmen : 23,
                           SceneLiShanYiJi : 23,#地图标的35但实际是23级
                           }
        self.map = random.choice([SceneLongmen, SceneLiShanYiJi])
        self.map =  SceneLiShanYiJi #锁定进入的地图
        
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):      
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_SKILLTEST_START)
                designatedSkillList = self.family.skill.GetDesignatedSkill(self.family.GetCurCharacter().faction)
                logging.debug("装备技能 designatedSkillList=%s" % designatedSkillList)
                if self.family.isNewRole:
                    memberType = 1
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,10000,0)")
    #                 gevent.spawn(self.family.gameServerNetPackHandle.LoopChat)#持续喊话
                    self.family.gameServerNetPackHandle.RandomAvatar(memberType)#穿时装
    #                 self.family.gameServerNetPackHandle.BecomeStronger(memberType)#穿全部装备
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(self.levelLimit[self.map], MaxLevel), memberType)#随机等级、装备和升星
                    #装备技能
                    self.family.gameServerNetPackHandle.EquipCharacterSkill(designatedSkillList, isReleaseByList=True)
                break
            
            elif case(STATE_GS_SKILLTEST_START):
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                break
            
            #组队招募完成
            elif case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_SKILLTEST_TRANSFER_MAP)
                break
            
            #组队（阵营流程）
            elif case(STATE_GC_TEAM_BEGIN):
                if self.member_type == TestCase.LEADER:
                    if self.family.team_manager.myteam.IsInTeam():
                        self.family.SetState(STATE_GC_TEAM_QUIT_FOR_CREATE)
                        logging.debug("退出队伍")
                        self.family.gameServerNetPackHandle.TeamLeaveReq()
                    else:
                        self.family.SetState(STATE_GC_TEAM_CREATE)
                else:
                    self.family.SetState(STATE_GS_SKILLTEST_TEAM_APPLY_WAIT)
                    msg = u'TeamApplyWait:%s' % self.family.team_manager.myteam.accountId
                    while self.family.GetState() == STATE_GS_SKILLTEST_TEAM_APPLY_WAIT:
                        self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, emChatChannelWorld)
                        gevent.sleep(10)
                break
            
            if case(STATE_GC_TEAM_CREATE):
                self.family.SetState(STATE_GC_TEAM_CREATE_WAIT)
                self.family.team_manager.myteam.isBegin = True
                self.family.gameServerNetPackHandle.TeamCreateReq()
                break
            
            if case(STATE_GC_TEAM_CREATE_FINISHED):
                self.family.SetState(STATE_GS_SKILLTEST_TEAM_INVITE_WAIT)
                break
                        
            #场景传送
            elif case(STATE_GS_SKILLTEST_TRANSFER_MAP):
                self.family.SetState(STATE_GS_RANDOMMOVE_GATHER_MAPLE_ENTER_WAIT)
                self.family.gameServerNetPackHandle.Transfer2Map(self.map)#进入野外地图
                break
            
            #设置阵营
            elif case(STATE_GS_SKILLTEST_SET_CAMP):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                if self.distributeType == TestCase.CAMP_DISTRIBUTE:#阵营模式才需要设置阵营
                    self.family.gameServerNetPackHandle.SetCamp(self.family.camp.campTag)
                    gevent.sleep(2)
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_RANDOMMOVE_LINEINFO):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                self.family.gameServerNetPackHandle.Get_LineInfo()
                break
            
            elif case(STATE_GS_LINE_LIST):
                self.family.SetState(STATE_GS_LINE_LIST_WAIT)
                self.family.gameServerNetPackHandle.Get_LineList()
                break
            
            elif case(STATE_GS_LINE_SWITCH):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                hotLineId = self.family.lineInfo.GetHotlineId(maxPlayerCount=150)
                curLineId = self.family.lineInfo.GetCurLineId()
                if hotLineId is None or curLineId is None:
                    self.family.SetState(STATE_GS_RANDOMMOVE_LINEINFO)
                else:
                    if hotLineId == curLineId:
                        self.family.SetState(STATE_GS_SKILLTEST_SET_CAMP)
                    else:
                        self.family.SetState(STATE_GS_SKILLTEST_ENTER_WAIT)
                        self.family.gameServerNetPackHandle.Switch_SceneLine(hotLineId)
                break
            
            elif case(STATE_GS_MOVE_GO):
                if self.fightMove or self.needRandomPos:
                    pos = self.randomPos = self.GetNewFightPos()
                else:
                    #self.family.gameServerNetPackHandle.AddBuffBlock()#强力格挡
                    pos = self.fightPos[self.map]
                self.family.gameServerNetPackHandle.PlayerAutoPath(*pos)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                logging.debug("到达目标点")
                if self.fightMove:
                    logging.debug("释放下次技能")
                    self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                    self.releaseSkill()
                else:
                    self.fightMove = True
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                break
            
            #进入战斗
            elif case(STATE_GS_LEAGUEMATCH_SKILL):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                logging.debug("进入战斗")
#                 self.family.gameServerNetPackHandle.ChangePKMode(PKMode_Kill)#切换为屠杀模式
#                 self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#一击必杀
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                if not (math.fabs(nowX - self.fightPos[self.map][0]) < 2 and math.fabs(nowY - self.fightPos[self.map][1]) < 2):
                    if self.needRandomPos:
                        pos = self.randomPos
                    else:
                        pos = self.fightPos[self.map]
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                if self.family.skill.needCommonAttack:
                    if self.family.GetCurCharacter().faction == TIANREN:
                        for i in range(4): 
                            self.family.gameServerNetPackHandle.Do_CastSkill(None, SKILL_TIANREN+i)
                            gevent.sleep(0.5)
                    else:
                        self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break

            #技能后的移动
            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_SKILLTEST_WAIT)
                logging.debug("技能后的移动")
                gevent.sleep(1.5)
                if self.needRandomMove:
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    nowX = self.family.characterCur.posX
                    nowY = self.family.characterCur.posY
                    if not (math.fabs(nowX - self.fightPos[self.map][0]) < 2 and math.fabs(nowY - self.fightPos[self.map][1]) < 2):
                        if self.needRandomPos:
                            pos = self.randomPos
                        else:
                            pos = self.fightPos[self.map]
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                    self.releaseSkill()
                break
    
    def GetNewFightPos(self):
        alpha = 2 * math.pi * random.random()
        # random radius
        r = self.fightMoveRadius[self.map] * random.random()
        # calculating coordinates
        x = r * math.cos(alpha) + self.fightPos[self.map][0]
        y = r * math.sin(alpha) + self.fightPos[self.map][1]
        return (x, y)
    
    def releaseSkill(self):
        self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
        self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
