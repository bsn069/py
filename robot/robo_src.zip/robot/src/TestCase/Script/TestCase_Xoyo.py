#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from Tools.Rand import Rand
from TestCase_TeamBase import TeamBaseCase

'''
    逍遥谷的TestCase
'''

class TestCase(TeamBaseCase):
    
    SINGLE = 0
    TEAM = 1
    
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_XOYO_LOW, TEAM_TYPE_XOYO_LOW, u"逍遥谷组队")
        self.family = family
        self.hasCancle = False
        self.hasEnterXoyo = False
        self.moveListIndex = 0
        self.moveDict = {
                         SceneXoyo2:[(96, 21)],
                         SceneXoyo3:[(22, 52)],
                         SceneXoyo4:[(100, 40)],
                         SceneXoyo5:[(31, 93)]
                         }
        
        self.enterMapNumb = 0
        
        TeamType = {
                                TestCase.SINGLE  : 1,
                                TestCase.TEAM : 3
                          }
#        self.TeamType = Rand.weighted_choice(TeamType)
        self.TeamType = TestCase.TEAM #锁定
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            # 匹配
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_XOYO_WAIT)
                if not self.hasEnterXoyo:
                    self.family.gameServerNetPackHandle.XOYO = True
                    self.family.gameServerNetPackHandle.Can_TeamJoinCheck = False
                    if self.family.isNewRole:
                        self.family.gameServerNetPackHandle.BecomeStronger()
                    self.family.SetState(STATE_GS_XOYO_ENTER_WAIT)
                    self.family.gameServerNetPackHandle.Transfer2Map(SceneXoyo)#进入水运境
                else:
                    self.family.gameServerNetPackHandle.canSkill = False#禁止技能
                    self.family.SetState(STATE_GS_FAMILY_ADD_AWARD_INFO)
                break
            
            if case(STATE_GS_XOYO_ENTER):
                self.family.SetState(STATE_GS_XOYO_WAIT)
                if self.TeamType == TestCase.SINGLE: # 单人
                    self.family.SetState(STATE_GC_TEAM_MEMBER_CALL_FINISHED)
                else:  # 组队
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                break    
            
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_XOYO_WAIT)
                logging.debug("完成组队")
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False,101,207)
                    gevent.sleep(2)
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)     
                          
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):#开始匹配
                self.family.SetState(STATE_GS_XOYO_WAIT)
                if not self.family.team_manager.myteam.IsInTeam():#单人匹配
                    logging.debug('单人开启匹配')
                    self.family.gameServerNetPackHandle.Do_AttandXoyoGame()
                elif self.family.team_manager.myteam.IsLeader(self.family.familyId):#组队并且为队长时
                    logging.debug('队长开启匹配')
                    self.family.gameServerNetPackHandle.Do_AttandXoyoGame()
                self.family.SetState(STATE_GS_WAIT_MATCHING_XOYOGAME)
                break
            
            if case(STATE_GS_XOYO_MATCHING):#逍遥谷匹配中
                self.family.SetState(STATE_GS_XOYO_CANCLE)
                if not self.hasCancle and random.randint(1, 6) <= 2:#取消匹配
                    self.hasCancle = True
                    logging.debug("取消匹配")
                    self.family.gameServerNetPackHandle.CancelXoyoGame()
                    if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                        self.family.gameServerNetPackHandle.TeamMatchingStateChange(False)
                break
            
            # 开始移动
            if case(STATE_GS_MOVE_GO):
                if self.moveListIndex >= len(self.moveList):
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)#释放技能
                    return
                gevent.sleep(1)
#                 self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveList[self.moveListIndex])
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveList[self.moveListIndex])
                break

            # 到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.moveListIndex += 1
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            if case(STATE_GS_START_FIGHT_BEGIN):
                logging.debug("enter xoyo map. map id = %d" % self.family.gameServerNetPackHandle.sceneTemplateId)
                gevent.sleep(10)
                self.hasEnterXoyo = True
                self.enterMapNumb += 1
                if self.moveDict.has_key(self.family.gameServerNetPackHandle.sceneTemplateId):
                    self.SetMoveList(self.family.gameServerNetPackHandle.sceneTemplateId)
                    self.moveListIndex = 0  # 计步清零
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                break

            if case(STATE_GS_LEAGUEMATCH_SKILL):#准备开始放技能
                logging.debug('技能')
                self.family.SetState(STATE_GS_XOYO_WAIT)
                self.family.gameServerNetPackHandle.canSkill = True
                self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害x999
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))

            # 继续使用技能
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_XOYO_WAIT)
                logging.debug("继续使用技能")
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.SkillCanBeReleased()
                break

            # 关卡结算
            if case(STATE_GS_FAMILY_ADD_AWARD_INFO):
                self.family.SetState(STATE_GS_XOYO_WAIT)
                if self.enterMapNumb >= 3:
                    logging.debug('逍遥谷案例结束')
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Xoyo_Finish")
                    self.family.SetState(STATE_GS_END)# 不循环匹配
                else:
                    logging.debug("逍遥谷进图数量不足")
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Xoyo_Finish", isSuccess=False, exception="EnterMapCount<3")
                    self.family.SetState(STATE_GS_END)
                break
            
            #退出
            if case(STATE_GS_END):
                self.family.behavior = Behavior.END
                break

    def SetMoveList(self, mapid):
        self.moveList = []
        self.moveList = self.moveDict[mapid]









