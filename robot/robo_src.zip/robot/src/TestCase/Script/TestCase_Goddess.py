# coding:utf-8
import random
import gevent
import asyncore
import math
import time
import logging
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase
from TestCase.Files.Valentine import Valentine

"""
         女神节的TestCase
"""

class TestCase(object):
    def __init__(self, family):
        self.family = family
        self.box = "5_4_301_1"
        self.npcName = "希子"
        self.npcPos = (202, 253)
        self.giftDict = {
                             u"女神节送礼-桃花宝匣" : Friend_TaoHuaBaoXia,
                            }
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_GODDESS_WAIT)
                self.family.gameServerNetPackHandle.SetGoldNumber()#获取足够元宝
                logging.debug("女神节活动！！！！！！！！！！！！！！！！！！！！！！")
                if self.family.main_sex == MALE:
                    self.family.SetState(STATE_GS_GODDESS_TEAM_INVITE_WAIT)
                    msg = u'送你桃花宝匣好吗'
                    while self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_WAIT:
                        self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, emChatChannelScene)
                        gevent.sleep(10)
                else:
                    self.family.SetState(STATE_GS_GODDESS_ACCEPT_WAIT)
                break
            
            elif case(STATE_GS_GODDESS_MOVE):
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.npcPos)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                if self.family.main_sex == MALE:
                    gevent.sleep(5)#等待对方走到目标点后再送礼
                    self.family.SetState(STATE_GS_GODDESS_SEND_GIFT)
                else:
                    self.family.SetState(STATE_GS_GODDESS_ACCEPT_GIFT_WAIT)
                break
            
            #送礼物
            elif case(STATE_GS_GODDESS_SEND_GIFT):
                self.family.SetState(STATE_GS_GODDESS_WAIT)
                member_list = self.family.team_manager.myteam.memberList
                for family_id in member_list:
                    if family_id == self.family.familyId:
                        continue
                    giftDesc = random.choice(self.giftDict.keys())
                    self.family.gameServerNetPackHandle.SetGoldNumber()#获取足够元宝
                    gevent.sleep(5)
                    self.family.gameServerNetPackHandle.SendGiftReq(receiverId=family_id, desc=giftDesc, shopId=FriendShop, goodId=self.giftDict[giftDesc], buyCount=1, priceIndex=0)
                self.family.SetState(STATE_GS_GODDESS_BUY_BOX)
                break
            
            #购买宝匣
            elif case(STATE_GS_GODDESS_BUY_BOX):
                self.family.SetState(STATE_GS_GODDESS_WAIT)
                self.family.gameServerNetPackHandle.SetGoldNumber()#获取足够元宝
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.ApplyBuyOnlineShopItem(shopId=TreasureShop, goodIndex=16, buyCount=5)
                gevent.sleep(5)
                itemId = random.choice(self.family.bag.consumeBag[self.box][True].keys())
                count = self.family.bag.consumeBag[self.box][True][itemId]["count"]
                slotPosition = self.family.bag.consumeBag[self.box][True][itemId]["slotPosition"]
                logging.debug("count = %s" % count)
                self.family.gameServerNetPackHandle.Do_UseItemBySlot(itemId, member=self.family.gameServerNetPackHandle.memberType, useCount=count, slotPosition=slotPosition)
                self.family.gameServerNetPackHandle.GetGoddessYingHuaYu(2000)#获取女神节莺华玉
                gevent.sleep(3)
                npc_id = self.family.gameServerNetPackHandle.GetNpcID(self.npcName)
                if npc_id:
                    self.family.gameServerNetPackHandle.AskNpc_obj(npc_id)
                else:
                    logging.debug("没有找到npc")
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Goddess_NpcError")
                    self.family.SetState(STATE_GS_GODDESS_BUY_FASHION)
                break
            
            #兑换时装
            elif case(STATE_GS_GODDESS_BUY_FASHION):
                self.family.SetState(STATE_GS_GODDESS_WAIT)
                logging.debug("兑换时装")
                memberType = self.family.gameServerNetPackHandle.memberType
                if self.family.main_sex == FEMALE:
                    self.family.gameServerNetPackHandle.AvatarChangeUseBindGoldFirst(0)
                    gevent.sleep(3)
                    #购买时装
                    self.family.gameServerNetPackHandle.Buy_AvaterGuise(random.choice(FashionList), memberType=memberType, buyIndex=2, colorPlanIndex=random.randint(0, 2))
                #购买奇兵
                self.family.gameServerNetPackHandle.Buy_AvaterGuise(random.choice([QiBing_WuMuLiuJin, QiBing_YiHeTingXiang, QiBing_NuanYuDuanChou]), memberType=memberType, buyIndex=2)
                # 购买脸饰
                self.family.gameServerNetPackHandle.Buy_AvaterGuise(Headdress_ZhuYinMianJu, memberType=memberType, buyIndex=2)
                # 购买背饰
                self.family.gameServerNetPackHandle.Buy_AvaterGuise(random.choice([Pendant_ShuiChenYan_Si, Pendant_ShuiChenYan_Mu]), memberType=memberType, buyIndex=2)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Goddess_Fashion")
                gevent.sleep(3)
                self.family.SetState(STATE_GS_END)
                break
            
            #退出
            elif case(STATE_GS_END):
                self.family.behavior = Behavior.END
                break
    
    