# coding:utf-8
import random
import gevent
import asyncore
import math
import time
import logging
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase
from TestCase.Files.Valentine import Valentine

"""
         情人节的TestCase
"""


class TestCase(object):
    POS = [     
                        [759, 375, 78],     
                        [490, 737, 78],     
                        [489, 811, 78],     
                        [596, 940, 78],     
                        [632, 835, 72],  
                        [694, 949, 76],   
                        [760, 937, 75],     
                        [768, 842, 75],
                        [604, 740, 78],
                        [816, 614, 87],
                        [524, 631, 88],
                        [757, 712, 86],
                        (692, 738, 81),
                   ]

    def __init__(self, family):
        self.family = family
        self.npcpos = (735.43, 739.92, 86.59)
        self.pos = random.choice(TestCase.POS)
        self.isfirst = True
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                if self.family.team_manager.myteam.IsInTeam():
                    logging.debug("退出队伍")
                    self.family.gameServerNetPackHandle.TeamLeaveReq()
                    gevent.sleep(5)
                self.family.gameServerNetPackHandle.ClearItemRoom()
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,10000,0)")
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.npcpos)
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                break
            
            #到达地点
            elif case(STATE_GS_MOVE_ARRIVAL):
                if self.family.main_sex == MALE: #为男性
                    self.family.SetState(STATE_GC_TEAM_CREATE)
                else:
                    self.family.SetState(STATE_GS_VALENTINE_WAIT_MSG)
                break  

            elif case(STATE_GC_TEAM_CREATE):
                self.family.SetState(STATE_GC_TEAM_CREATE_WAIT)
                self.family.team_manager.myteam.isBegin = True
                self.family.gameServerNetPackHandle.TeamCreateReq()
                break
            
            elif case(STATE_GC_TEAM_CREATE_FINISHED):
                msg = 'ValentinesDay:%d'% self.family.main_sex
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, emChatChannelScene)
                gevent.sleep(30)
                break
            
            elif case(STATE_GS_VALENTINE_MSG):
                self.family.SetState(STATE_GS_VALENTINE_WAIT_MSG)
                msg = 'ValentinesDay|Ready'
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, self.family.valentine.familyid)
                break
        
            elif case(STATE_GS_VALENTINE_START):
                if self.isfirst:
                    self.isfirst = False
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.npcpos)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Valentine_Team_Finish")
                while self.family.valentine.yuexialaoer == None:
                    self.family.gameServerNetPackHandle.MarkTestCase("NO_NAME")
                    self.family.gameServerNetPackHandle.ForceSyncPlayer()
                    gevent.sleep(2)
                self.family.gameServerNetPackHandle.AskNpc_obj(self.family.valentine.yuexialaoer)
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.CliGetFamilyLocationReq()
                break
            
            elif case(STATE_GS_VALENTINE_FIREWORKS): #男摆放烟花
                self.family.SetState(STATE_GS_VALENTINE_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Valentine_FIREWORKS")
                while self.family.valentine.yanhua == None:
                    gevent.sleep(2)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.pos)
                self.family.gameServerNetPackHandle.SetUpFire(self.family.valentine.yanhua)
                gevent.sleep(5)
                break
            
            elif case(STATE_GS_VALENTINE_FIRE):
                if self.family.main_sex == MALE: #为男性
                    msg = 'ValentinesDayFire:%d:%d:%d' % (self.pos[0], self.pos[1], self.pos[2])
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, self.family.valentine.familyid)
                else:
                    self.family.SetState(STATE_GS_VALENTINE_FIRE_WAIT)
                return
            
            elif case(STATE_GS_VALENTINE_FIRE_BEGIN):#女性点燃
                self.family.SetState(STATE_GS_VALENTINE_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Valentine_FIRE")
                while self.family.valentine.fire == None:
                    self.family.gameServerNetPackHandle.ForceSyncPlayer()
                    gevent.sleep(2)
                pos = (self.family.fireX, self.family.fireY, self.family.fireZ)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *pos)
                self.family.gameServerNetPackHandle.AskNpc_obj(self.family.valentine.fire)
                return
            
            #退出
            elif case(STATE_GS_VALENTINE_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Valentine_Finish")
                self.family.behavior = Behavior.END
                break
    
    