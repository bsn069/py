#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import logging
import asyncore
from ModuleState.StateDefine import *
# from Tools.JxLog import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Config.CaseDefine import *

"""
         玩家装备TestCase
"""

#character_sytem
BAOSHI = 101
JINGMAI = 102
MIJI = 103
ALEMCHY = 104
RECYCLE = 105
FUMO = 106

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.tasklist = [BAOSHI, JINGMAI, MIJI, ALEMCHY, RECYCLE, FUMO]
        self.shopIndex = 0
        self.isFirst = True
        '''
        8,1,1,1,,钧天玉        8,2,1,1,,苍天玉
        8,3,1,1,,变天玉        8,4,1,1,,玄天玉
        8,5,1,1,,幽天玉        8,6,1,1,,颢天玉
        8,7,1,1,,朱天玉        8,8,1,1,,炎天玉
        8,9,1,1,,阳天玉
        '''
        self.xuan_jade = ["8_1_1_1","8_2_1_1","8_3_1_1","8_4_1_1","8_5_1_1","8_6_1_1","8_7_1_1","8_8_1_1","8_9_1_1"]
    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    
    def _Action(self):
        if self.family.GetState() is not STATE_GS_PLAYING:
            return

        if not self.tasklist:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Equip_Finish") 
            gevent.sleep(10)#等待回购协议同步完毕
            logging.info("[DataChecker][RoleDetail]%s|%s|{'member1Bag':%s, 'member2Bag':%s, 'member3Bag':%s, 'equipGridEnhance':%s, 'stoneEnchase':%s, 'skillList':%s, 'meridianSync':%s, 'bookExp':%s, 'coin':%s, 'consumeBag':%s, 'bookBag':%s, 'taskItemBag':%s, 'recycleBag':%s}" % (self.family.familyId, self.family.userName, self.family.bag.member1Bag, self.family.bag.member2Bag, self.family.bag.member3Bag, self.family.bag.equipGridEnhance, self.family.bag.stoneEnchase, self.family.GetCurCharacter().skillList, self.family.bag.meridianSync, self.family.bag.bookExp, self.family.valueCoin, self.family.bag.consumeBag, self.family.bag.bookBag, self.family.bag.taskItemBag, self.family.bag.recycleBag))
            self.family.behavior = Behavior.END
            return
        
        if self.isFirst and self.family.isNewRole:
            self.isFirst = False
            self.family.gameServerNetPackHandle.GM_AddRepute(180000)#增加江湖阅历
            self.family.gameServerNetPackHandle.BecomeStronger()#穿全部装备
            self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,10000,0)")
            gevent.sleep(5)
            #装备技能
            self.family.gameServerNetPackHandle.CallScript("ItemCmd", "ApplyPurchaseBagSize") #增大背包
            self.family.gameServerNetPackHandle.EquipCharacterSkill()
            return
   
        task = self.tasklist[0]
        # 目前设置一直在购买
        if task == BAOSHI:
            bagDict = self.family.bag.member1Bag["Equip"]
            if bagDict:
                while True:
                    gdpl = random.choice(bagDict.keys())
                    g, d, p, l = map(int, gdpl.split("_"))
                    if d != SIGNET:#TODO:当前印鉴还不能镶嵌宝石
                        break
                itemId = bagDict[gdpl][True].keys()[0]
                slotPosition = bagDict[gdpl][True][itemId]["slotPosition"]
                logging.debug("equip gdpl=%s" % gdpl)
                holeIndex = random.randint(0, 2)#五阶五级套装默认是开3个孔位
                s_d, s_p = random.choice(self.family.equip.stoneEnchaseRule[d][holeIndex+1])
                s_l = random.randint(2, 6)#随机选择2~6级宝石
                self.family.gameServerNetPackHandle.CallScriptAddStackItem(2, s_d, s_p, s_l, 1, False, 0)
                gevent.sleep(1)
                stone_gdpl = "_".join((str(x) for x in [2, s_d, s_p, s_l]))
                logging.debug("stone gdpl=%s" % stone_gdpl)
                if stone_gdpl in self.family.bag.consumeBag:
                    logging.debug("self.family.bag.consumeBag=%s" % self.family.bag.consumeBag)
                    stone_itemId = self.family.bag.consumeBag[stone_gdpl][False].keys()[0]
                    stone_slotPosition = self.family.bag.consumeBag[stone_gdpl][False][stone_itemId]["slotPosition"]
                    self.family.gameServerNetPackHandle.ApplyEnchaseStone(itemId, slotPosition, stone_slotPosition, holeIndex)#宝石镶嵌
                    gevent.sleep(3)
#                    self.family.gameServerNetPackHandle.ApplyPeelStone(itemId, slotPosition, holeIndex)#宝石剥离
                else:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Equip_StoneError")
                #装备强化
                self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 1, 101, 1, 10, False, 0)
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.ApplyEnhanceEquipGrid(d)
            else:
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Equip_BagEmptyError")
            self.tasklist.remove(task)
        elif task == JINGMAI:
            self.family.gameServerNetPackHandle.ZazenReq()  # 获取真气
            gevent.sleep(2)
            for type in [0, 1]: # 左脉，右脉
                for acupoint in range(1, 21): # 打通第3，4节点，5个小节点打通一个大节点
                    self.family.gameServerNetPackHandle.OpenAcuPoint(type=type, acupoint=acupoint)  # 开穴
                    gevent.sleep(1)
            self.tasklist.remove(task)
        elif task == MIJI:
            self.family.gameServerNetPackHandle.Add_MiJi()#添加秘籍
            gevent.sleep(3)
            self.family.gameServerNetPackHandle.PutOn_MiJi(index=1, count=2)#系统会自动装备一个添加的秘籍
            gevent.sleep(3)
            #秘籍强化
            self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 3, 2, 1, 2, False, 0)
            gevent.sleep(2)
            bagDict = eval(self.family.gameServerNetPackHandle.memberType2Bag[self.family.gameServerNetPackHandle.memberType])["Book"]
            if bagDict:
                gdpl = random.choice(bagDict.keys())
                itemId = random.choice(bagDict[gdpl][True].keys())
                self.family.gameServerNetPackHandle.ApplyAddBookExp(itemId, 1, 0)
            gevent.sleep(2)
#             self.family.gameServerNetPackHandle.TakeOff_MiJi()
            self.tasklist.remove(task)
        elif task == ALEMCHY:#宝石合成
            alemchyType = random.choice(ALCHEM_CFG.keys())
            stoneDict = ALCHEM_CFG[alemchyType]
            stoneKey = random.choice(stoneDict.keys())
            g, d, p, l, count, = stoneDict[stoneKey]
            self.family.gameServerNetPackHandle.CallScriptAddStackItem(g, d, p, l, count, False, 0)
            gevent.sleep(2)
            self.family.gameServerNetPackHandle.Do_ApplyAlchemy(stoneKey, alemchyType)
            self.tasklist.remove(task)
        elif task == RECYCLE:#物品回购
            materialList = ["5_1_%d_1" % p for p in range(1, 9)]
            sellItemDict = {}
            for gdpl in  self.family.bag.consumeBag:
                if gdpl in materialList:
                    itemId = random.choice(self.family.bag.consumeBag[gdpl][True].keys())
                    count = random.randint(1, self.family.bag.consumeBag[gdpl][True][itemId]["count"])
                    slotPosition = self.family.bag.consumeBag[gdpl][True][itemId]["slotPosition"]
                    sellItemDict["gdpl"] = gdpl
                    sellItemDict["itemId"] = itemId
                    sellItemDict["count"] = count
                    sellItemDict["slotPosition"] = slotPosition
                    break
            if sellItemDict:
                self.family.gameServerNetPackHandle.Add_Sliver()
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.ApplySellItem(sellItemDict["itemId"], sellItemDict["count"], sellItemDict["slotPosition"])
                gevent.sleep(3) 
                if sellItemDict["gdpl"] in self.family.bag.recycleBag:
                    itemId = random.choice(self.family.bag.recycleBag[sellItemDict["gdpl"]][True].keys())
                    count = self.family.bag.recycleBag[sellItemDict["gdpl"]][True][itemId]["count"]
                    self.family.gameServerNetPackHandle.ApplyBuyRecycleItem(itemId, count)
                    gevent.sleep(2)
            self.tasklist.remove(task)
        elif task == FUMO:
            signetlist = ["1_10_201_1","1_10_301_1"]
            for gdpl in  self.family.bag.consumeBag:
                if  gdpl in signetlist:
                    itemId = random.choice(self.family.bag.consumeBag[gdpl][False].keys())
                    slotPosition = self.family.bag.consumeBag[gdpl][False][itemId]["slotPosition"]
                    self.family.gameServerNetPackHandle.PutOn_BagEuqipment(slotPosition, itemId)
            self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 14, 1, 2, 9, False, 0)
            self.family.gameServerNetPackHandle.ApplyOpenSignetHole()
            gevent.sleep(5)
            for i in range(9):
                self.family.gameServerNetPackHandle.CallScriptAddStackItem(8, i+1, 1, 1, 1, False, 0)
                gevent.sleep(0)
            for gdpl in self.family.bag.consumeBag:
                if  gdpl in self.xuan_jade:
                    itemId = random.choice(self.family.bag.consumeBag[gdpl][True].keys())
                    slotPosition = self.family.bag.consumeBag[gdpl][True][itemId]["slotPosition"]
                    self.family.gameServerNetPackHandle.PutOn_BagEuqipment(slotPosition, itemId)
            self.family.gameServerNetPackHandle.CallScriptAddStackItem(8, 10, 1, 1201, 1, False, 0)
            gevent.sleep(1)
            for gdpl in self.family.bag.consumeBag:
                if  gdpl in ["8_10_1_1201"]:
                    itemId = random.choice(self.family.bag.consumeBag[gdpl][False].keys())
                    slotPosition = self.family.bag.consumeBag[gdpl][False][itemId]["slotPosition"]
                    self.family.gameServerNetPackHandle.ApplyEnchantSignet(slotPosition, itemId)
            self.tasklist.remove(task)
            return