# coding:utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from gevent.hub import sleep
from quopri import ishex

'''
      双人付费休闲动作的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            #走到城中心
            if case(STATE_GS_MOVE_GO):
                # self.family.gameServerNetPackHandle.PlayerAutoPath(201, 125)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, 758, 373)
                break
            
            #到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                gevent.sleep(3)
                selectType = random.randint(1, 2)
#                 selectType = 1#锁定选择
                if selectType == 1:#被拥抱
                    logging.debug("被拥抱")
                    self.family.SetState(STATE_GS_DOUBLEACTION_WAIT)
                    while self.family.GetState() == STATE_GS_DOUBLEACTION_WAIT:
                        self.family.gameServerNetPackHandle.ChatRequestByMsg(u'抱一抱', emChatChannelScene)
                        gevent.sleep(5)
                else:#拥抱他人
                    logging.debug("拥抱他人")
                    self.family.SetState(STATE_GS_DOUBLEACTION_STAY)
                break
            
            #抱人
            if case(STATE_GS_DOUBLEACTION_HUG):
                Id2Family = self.family.otherCharacterManager.getSceneId2FamilyidDict()
                playerid = self.family.doubleAction.GetHugPlayid()
                if playerid in Id2Family.keys():
                    if Id2Family[playerid]['state'] in [15, 16]:#角色已在拥抱状态
                        logging.debug("角色已在拥抱状态")
                        self.family.SetState(STATE_GS_DOUBLEACTION_WAIT)
                    else:#拥抱他
                        logging.debug("拥抱他")
                        self.family.gameServerNetPackHandle.GesturePlay(3, playerid)
                        self.family.SetState(STATE_GS_DOUBLEACTION_HUG_WAIT)
                else:
                    logging.debug("playid not in getSceneId2FamilyidDict !")
                    self.family.SetState(STATE_GS_DOUBLEACTION_STAY)
#                     self.family.behavior = Behavior.END
                break
                    
            #被抱
            if case(STATE_GS_DOUBLEACTION_HUGGED):
                self.family.SetState(STATE_GS_DOUBLEACTION_WAIT)
                gevent.sleep(5)
                stopHugType = random.randint(1, 2)
#                 stopHugType = 2#锁定选择
                if stopHugType == 1:#自己停止动作
                    self.family.SetState(STATE_GS_DOUBLEACTION_STOPHUG)
                else:#通知抱人者停止动作
                    while self.family.GetState() == STATE_GS_DOUBLEACTION_WAIT:
                        logging.debug("通知抱人者停止动作")
                        self.family.gameServerNetPackHandle.ChatRequestByMsg(u'放我下来', emChatChannelScene)
                        gevent.sleep(5)
                break
            
            #取消拥抱
            if case(STATE_GS_DOUBLEACTION_STOPHUG):
                self.family.gameServerNetPackHandle.GesturePlay(0, 0)
                self.family.SetState(STATE_GS_DOUBLEACTION_STOPHUG_WAIT)
                break
            
            if case(STATE_GS_END):
                logging.debug("双人付费休闲动作结束")
                self.family.behavior = Behavior.END
                break