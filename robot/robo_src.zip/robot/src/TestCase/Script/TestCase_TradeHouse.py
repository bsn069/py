#!/usr/bin/env python2.7
# coding:utf8
import math
import random
import gevent
import asyncore
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import VALUE_COIN_GOLD, VALUE_COIN_SILVER,\
    emAvatarGdplCount
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from Tools.Rand import Rand
from copy import deepcopy

'''
      拍卖行的TestCase
'''

TRADER_TIME_WAIT = 5
CUSTOMER_TIME_WAIT = 5
MAX_TRADER_SALE_LIMIT = 10
MAX_CUSTOMER_BUY_LIMIT = 8

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.priceConfig = dict(self.family.gameConfig.get_stone_config().items() + self.family.gameConfig.get_book_config().items() +self.family.gameConfig.get_consume_config().items())
        
        self.family.bag.tradeItemIdDict = self.tradeid_dict = (dict([('_'.join(str(y) for y in x), x) for x in self.GetTradeSaleItems()]))
        self.tradeid = None
        self.addedItems = 0
        self.tradeIndexidList = ["5_1001_0_0", "5_1002_0_0", "5_1003_0_0", "5_1004_0_0", "5_1005_0_0", "5_921_0_0", "2_0_0_0"]#保险券有bug没显示在奇珍异宝的全部里
        self.tradeIndexid = None
        self.tradeNpc = (86, 209)
        
        self.readySaleTradeIdDict = deepcopy(self.tradeid_dict)
        self.hasSaled = False
        self.isTraderTrading = False
        self.traderSaleCount = 0
        self.customerBuyCount = 0
        self.isFirstRefresh = True
        self.getTradeListCount = 0
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):  # 添加出售的物品
                self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_GETMYSALE_RESPONSE
                if not self.family.isNewRole:
#                     self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUST_CLEAN_SALELIST
#                     self.family.bag.needCleanSaleList = True
                    self.family.gameServerNetPackHandle.ClearItemRoom()#清空背包
                self.family.gameServerNetPackHandle.GM_GetTradeHouse_TradeItem(self.readySaleTradeIdDict.values())
                gevent.sleep(5)
                break
            
            if case(STATE_GS_TRADEHOUSE_GETMYSALE):  # 获得我的出售列表
                logging.debug('获得我的出售列表')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.TradeHouse_GetMySaleList()
                break
            
            if case(STATE_GS_TRADEHOUSE_GETMYSALE_RESPONSE):
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                lenTradeItem = len(self.family.gameServerNetPackHandle.tradeHouseMyTradeId)
                if lenTradeItem < 15:#销售者摊位不满时补充（目前摊位限制为8）
                    logging.debug("摊位不满16个商品（有%s个），准备补充" % lenTradeItem)
                    tradeKey = random.choice(self.tradeid_dict.keys())
                    self.tradeid = (tradeKey, self.tradeid_dict[tradeKey])
                    g, d, p, l = self.tradeid[1]
                    logging.info("[DataChecker][TradeItem]%s|%s|%s" % (self.family.familyId, self.family.userName, {self.tradeid[0] : 1}))
                    self.family.gameServerNetPackHandle.CallScriptAddStackItem(g, d, p, l, 1, False, 0)
                    self.family.SetState(STATE_GS_TRADEHOUSE_PUTONSALE)
                    self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_GETMYSALE_RESPONSE
                else:
                    self.family.SetState(STATE_GS_TRADEHOUSE_PUTOFFSALE)
                break


            if case(STATE_GS_TRADEHOUSE_TRADEHISTORY):  # 获得我的交易记录
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('获得我的交易记录')
                self.family.gameServerNetPackHandle.TradeHouse_GetTradeHistory()
                break

            if case(STATE_GS_TRADEHOUSE_PUTONSALE):  # 商品上架
                logging.debug('商品上架')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.CleanTradeLimit()#清除交易限制
                recommendPrice, price = self.GetPrice(self.tradeid[1])
                if price == 0:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_TradeHouse_GetPriceFail", isSuccess=False, exception="gdpl=%s" % self.tradeid[1])
                    self.family.SetState(STATE_GS_TRADEHOUSE_PUTONSALE)
                    break
                fee = self.GetFee(recommendPrice, price)
                self.family.gameServerNetPackHandle.GetEnoughMoney(VALUE_COIN_SILVER, fee)#补充刷新需消耗的货币
                self.family.gameServerNetPackHandle.TradeHouse_PutOnSale(self.tradeid[0], price=price)
                break

            if case(STATE_GS_TRADEHOUSE_PUTOFFSALE):  # 商品下架
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('1s后商品下架')
                gevent.sleep(1)
                self.family.gameServerNetPackHandle.TradeHouse_PutOffShelves()
                break

#             if case(STATE_GS_TRADEHOUSE_REPUTONSALE):  # 重新上架  #因为要24h之后才能执行，暂时不模拟
#                 logging.debug('重新上架')
#                 self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
#                 self.family.gameServerNetPackHandle.TradeHouse_RePutOn()
#                 break
            
            #刷新出售列表
            if case(STATE_GS_TRADEHOUST_REFRESH):
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('刷新出售列表')
                self.family.gameServerNetPackHandle.GetEnoughMoney(VALUE_COIN_GOLD, 30)#补充刷新需消耗的货币
                self.getTradeListCount = 0
                self.family.gameServerNetPackHandle.TradeHouse_Refresh()
                break
            
            if case(STATE_GS_TRADEHOUSE_GETTRADELIST):  # 获得商品类别
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('获得商品类别')
                self.tradeIndexid = self.tradeIndexidList[random.randint(0, len(self.tradeIndexidList)-1)]
                self.family.gameServerNetPackHandle.TradeHouse_GetTradeList(self.tradeIndexid)
                break

            if case(STATE_GS_TRADEHOUST_BUY):  # 商品购买
                logging.debug('商品购买')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.CleanTradeLimit()#清除交易限制
                self.family.gameServerNetPackHandle.TradeHouse_BuyGoods()
                break
            
            if case(STATE_GS_TRADEHOUST_JUDGE):
                self.family.SetState(STATE_GS_TRADEHOUSE_TRADEHISTORY)
                gevent.sleep(15)
                break
            
            if case(STATE_GS_TRADEHOUST_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_TradeHouse_Finish")
                logging.info("[DataChecker][Bag]%s|%s|%s" % (self.family.familyId, self.family.userName, self.family.bag.GetAllBag()))
                self.family.behavior = Behavior.END
                break
    
    def GetFee(self, recommendPrice, salePrice):
        if salePrice <= recommendPrice:
            fee = salePrice * 0.02
        else:
            overPercent = float(salePrice - recommendPrice)/float(recommendPrice)
            if 0 < overPercent < 0.1:
                fee = salePrice * 0.05
            elif 0.1 <= overPercent < 0.2:
                fee = salePrice * 0.06
            elif 0.2 <= overPercent < 0.3:
                fee = salePrice * 0.08
            elif 0.3 <= overPercent < 0.4:
                fee = salePrice * 0.11
            elif 0.4 <= overPercent <= 0.5:
                fee = salePrice * 0.15
            else:
                raise overPercent
        return fee
    
    #随机获取8个拍卖行DataChecker
    def GetTradeSaleItems(self):
#         canye = deepcopy(CANYE)
        tianwang_equip = self.GetUnIdedEquipmentsIdList(TIANWANG)
        tangmen_equip = self.GetUnIdedEquipmentsIdList(TANGMEN)
        emei_equip = self.GetUnIdedEquipmentsIdList(EMEI)
        tianren_equip = self.GetUnIdedEquipmentsIdList(TIANREN)
        wudang_equip = self.GetUnIdedEquipmentsIdList(WUDANG)
        baoshi = deepcopy(BAOSHILIST)
        treasures = deepcopy(TREASURES)
        #每种至少取一个
        mustSaleItems = self.GetRandomItemFromSomeList(tianwang_equip, tangmen_equip, emei_equip, tianren_equip, wudang_equip, baoshi, treasures)
        remainingItemList = tianwang_equip + tangmen_equip + emei_equip + tianren_equip + wudang_equip + baoshi + treasures
        #剩下的随机取
        randomSaleItems = random.sample(remainingItemList, 1)
        logging.debug("SaleItemList = %s" % str(mustSaleItems + randomSaleItems))
        return mustSaleItems + randomSaleItems
        # return [(5,28,4,2),]
    
    #根据传入的列表随机取出一个值（会删除原列表中该值）
    def GetRandomItemFromSomeList(self, *args):
        itemList = []
        for list in args:
            itemList.append(list.pop(random.randint(0, len(list)-1)))
        return itemList
    
    #获取职业未鉴定装备id列表
    def GetUnIdedEquipmentsIdList(self, faction):
        score = random.choice([1, 3, 4])
        quality = random.randint(1, 5)
        return [(self.family.bag.GetUnIdedEquipmentsId(score, quality, faction, part)) for part in EquipmentsPart]
    
    def GetPrice(self, gdpl_tuple):
        """
                        价格规则：data\script\TradeHouse\TradeHouse.lua
        TradeHouse.OpenDayPrice为根据开服天数而浮动的物品
                        例如:
        {5,3000,{
            {"5_1001_0_30",196,68,100,100},    --天王
            {"5_1002_0_30",196,68,100,100},    --唐门
            {"5_1003_0_30",196,68,100,100},    --峨眉
            {"5_1004_0_30",196,68,100,100},    --天忍
            {"5_1005_0_30",196,68,100,100},    --武当
        }},
                        表示开服5-3000天的时间段内，G为5（即装备），1000+门派，位置为0，等级为30级的物品
                        推荐价格为：(配置表的最低价格*1.96 + 配置表最高价格*0.68)/2
                        而价格区间则为：[推荐价格*100%，推荐价格*100]
        """
        if gdpl_tuple not in self.priceConfig:
            return 0
        minPrice, maxPrice, score = self.priceConfig[gdpl_tuple][0], self.priceConfig[gdpl_tuple][1], self.priceConfig[gdpl_tuple][2]
        minPercent = 0.5
        maxPercent = 1.5
        stepPercent = 0.25
        g, d, p, l = gdpl_tuple
        days = self.family.GetOpenDay()
        if (5 <= days <= 3000 and g == 5 and score == 30)\
        or (30 <= days <= 3000 and (gdpl_tuple == (5, 1, 26, 1) or  gdpl_tuple == (5, 4, 7, 1))):
            minPrice = minPrice * 1.96
            minPercent = 1
            maxPrice = maxPrice * 0.68
            maxPercent = 1

        recommendPrice = (minPrice + maxPrice) / 2
        percent = random.randint(int((minPercent - 1) / stepPercent), int((maxPercent - 1) / stepPercent))
        return recommendPrice, int(recommendPrice + percent * stepPercent * recommendPrice)
        

