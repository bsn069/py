#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import logging
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Config.CaseDefine import *
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *

"""
         世界流拍的TestCase
         
"""

class WorldLimitedCase(object):
    VALUE_COIN_SILVER       = 1 #银量
    
    def __init__(self, family):
        self.family = family
        self.true = True
        self.firstJoin = True
        shoptype =   {
                        1: 1,#门派装备
                        7: 1,#稀有宝石
                        8: 1 #奇珍异宝
                    } 
        self.shoptype = Rand.weighted_choice(shoptype)
#        self.shoptype = 7


    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        state = self.family.GetState()
        if self.family.GetState() == STATE_GS_WORLD_LIMITED_PLAYING:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)  
            
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_BEGIN:
            self.family.SetState(STATE_GS_WORLD_LIMITED_WAIT)
            self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "me:AddSilver(80000000, 1);")#增加金钱
            self.family.gameServerNetPackHandle.WorldlLimitedShopDataReq(self.shoptype ,0)
        
        elif self.family.GetState() == STATE_GS_WORLD_LIMITED_DATAVERSION_WAIT:
            self.family.SetState(STATE_GS_WORLD_LIMITED_WAIT)
            self.family.gameServerNetPackHandle.WorldlLimitedShopDataReq(self.shoptype ,self.family.limitedacution.dataVersion)
        
        elif self.family.GetState() == STATE_GS_WORLD_LIMITED_SHOPDATA_WAIT:
            self.family.SetState(STATE_GS_WORLD_LIMITED_WAIT)
            self.family.gameServerNetPackHandle.WorldlLimitedGoodsDataReq(self.family.limitedacution.auctioninformationlist[0][0],
                                                                          self.family.limitedacution.auctioninformationlist[0][1],
                                                                          self.shoptype,
                                                                          self.family.limitedacution.dataVersion)
            return
            
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_AUCTION:
            if len(self.family.limitedacution.auctioninformationlist)<1:
                logging.debug("世界竞拍没有商品")
                self.family.SetState(STATE_GS_LIMITED_AUCTION_FINISH)
                return
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            acution_Treatment = {
                                        1 : 1,         #一口价
                                        0 : 29,        #竞拍价
                                    }
            acution_changtype = Rand.weighted_choice(acution_Treatment)
            if acution_changtype == 1:          
                self.family.gameServerNetPackHandle.WorldlLimitedBidsGoodsReq(self.family.limitedacution.auctioninformationlist[0][0],
                                                                       self.family.limitedacution.auctioninformationlist[0][1],
                                                                       True,
                                                                       self.family.limitedacution.one_auctiondatainfolist[0])#物品价格ID                
            elif acution_changtype == 0:      
                self.family.gameServerNetPackHandle.WorldlLimitedBidsGoodsReq(self.family.limitedacution.auctioninformationlist[0][0],
                                                                       self.family.limitedacution.auctioninformationlist[0][1],
                                                                       False,
                                                                       self.family.limitedacution.one_auctiondatainfolist[2])
                return
                              
        elif self.family.GetState() ==  STATE_GS_LIMITED_AUCTION_FINISH:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_World_Limited_Finish")
            self.family.SetState(STATE_GS_WORLD_LIMITED_END)
            return
                

                         
