#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import asyncore
import logging
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Files.Shop import *
from Tools.Rand import *
from Config.RunConfig import Config
from TestCase_LimitedAuction import LimitedAuction
from TestCase_KinBase import KinBaseCase, KinMemberType
from account.account_service import account_kin
from account.account_def import AccountDef

"""
         家族系统的TestCase
         
         家族争夺 server\data\script\kin\kinwar\kinwar_def.lua
"""

class TestCase(KinBaseCase, LimitedAuction):

    KIN_ROLE_DISTRIBUTE = 0#使用分发的角色类型
    KIN_ROLE_RANDOM = 1#使用随机的角色类型
    
    ROLE_MODE =  KIN_ROLE_DISTRIBUTE

    def __init__(self, family):
        self.family = family
        self.family.kinMan.gameType = random.choice([KinFeastGame])#PS:族员的游戏类型会依据组长喊话决定
        self.family.kinMan.gameType = KinFeastGame #锁定家族盛宴
#        self.family.kinMan.gameType = KinWarGame #锁定家族争夺 皇陵
#         self.family.kinMan.gameType = KinWarRank #锁定填充家族争夺榜


        if TestCase.ROLE_MODE == TestCase.KIN_ROLE_DISTRIBUTE:
            role, kin_role_count = account_kin()
            role = int(role)
            KinBaseCase.KIN_RECRUIT_NUM = int(kin_role_count)
        else:
            memberDict = {
                                KinMemberType.LEADER  : 1,
                                KinMemberType.MEMBER : KinBaseCase.KIN_RECRUIT_NUM - 1
                          }
            role = Rand.weighted_choice(memberDict)
#             role = KinMemberType.LEADER#锁定为族长
#             role = KinMemberType.MEMBER#锁定为族员
        KinBaseCase.__init__(self, family, role)
        LimitedAuction.__init__(self,family)
        self.firstJoin = True
        self.isFinishedKindaily = False
        self.isFinishedKinfeast = False #盛宴完成状态
        self.isFinishedKinwar = False #争夺完成状态
        self.createKinTimes = 0
        self.family.kinMan.GetKinList()
        self.gmMove = True
        self.moveTarget = {
                           'id' : 0,
                           'pos' : (0, 0),
                           }
        self.godOfCookery = (102.33, 134.16) #食神坐标
        self.dinningRoom = (331.22, 73.0) #盛宴厅坐标
        self.defendPos = (120.93, 73.22) #家族盛宴打击Boss坐标
        self.warWaitPos = (58.9, 400.0)#家族争夺-秦始皇陵外等待点
        self.warEnterPos = (53.84, 398.39)#家族争夺-秦始皇陵入口点
        self.warPvePosDict = {
                            1 : (117.54, 67.62),#PVE1区
                            2 : (204.41, 64.07),#PVE2区
                            3 : (201.89, 155.34),#PVE3区
                          }
        self.warPveEnterIndex = 1
        self.warCheerPos = (65.92, 205.57)
        self.warCheerSearchPosList = [(76.53, 213.88), (30.38, 215.91), (30.03, 167.27), (77.74, 167.93)]
        self.warStoneList = ["5_4_228_1", "5_4_228_2", "5_4_228_3"]
        self.warNeiDianEntrancePos = (208.25, 201.62)
        self.warGeneralsPosDict = {
                                    "蒙恬" : (129.1, 91.2),
                                    "章邯" : (84.4, 150.57),
                                    "王翦" : (141.8, 179.6),
                                    "白起" : (177.38, 122.4),
                                    "秦始皇":(131.23, 134.39),
                                }
        self.family.kinMan.warGeneralNameList = self.warGeneralsPosDict.keys()
        self.warQinShiHuangArea = (131.23, 134.39)  
        self.hadDrank = False#是否喝过酒了
        

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        KinBaseCase._Action(self)
        LimitedAuction._Action(self)
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.isFinishedKinfeast and not self.isFinishedKindaily:#家族盛宴结束，还没有打家族关卡
                self.family.SetState(STATE_GS_KIN_DAILY)
                return
            
            if self.isFinishedKindaily or self.isFinishedKinwar:#家族日常/争夺结束，退出
                self.family.SetState(STATE_GS_KIN_LEAVE)
                return
 
            if self.firstJoin:
                self.family.SetState(STATE_GS_KIN_BEGIN)
                self.firstJoin = False
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("KGameSwitch.SetDebug(2,False);")#清除家族退出CD
#                if self.family.isNewRole:
#                    self.family.gameServerNetPackHandle.BecomeStronger()#穿装备

        #家族组建完成
        elif self.family.GetState() == STATE_GS_KIN_RECRUIT_FINISH:
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.family.kinMan.gameType == KinFeastGame:#家族盛宴
                self.family.SetState(STATE_GS_KIN_ENTER_FEAST)
            elif self.family.kinMan.gameType == KinWarGame:#家族争夺
                self.family.SetState(STATE_GS_KIN_WAR_MOVE_TO_ENTRANCE)
            else:
                logging.debug("can't find this kinGameType : %s" % self.family.kinMan.gameType)
        
        elif self.family.GetState() == STATE_GS_KIN_DAILY:  
            self.family.SetState(STATE_GS_KIN_POST_COMMON)

        elif self.family.GetState() == STATE_GS_SINGLE_MISSION_RELEASE_SKILLS:  # 释放技能
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.family.kinMan.gameType == KinWarGame:
                gevent.sleep(3)
                scene_template_id = self.family.gameServerNetPackHandle.sceneTemplateId
                if scene_template_id == SceneHuangLingWaiGong:
                    if self.family.kinMan.hasWarPvpDead:
                        logging.debug("释放技能中已阵亡，等待活动结束")
                        return
                    warEnemyPos = self.family.kinMan.GetWarEnemyPos()
                    if warEnemyPos:
                        logging.debug("warEnemyPos = %s" % str(warEnemyPos))
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *warEnemyPos)
                    else:
                        if self.family.kinMan.target == KinWarCheer:
                            logging.debug("找不到助威区里的敌人了 warEnemyDict=%s" % str(self.family.kinMan.warEnemyDict))
                            if self.family.kinMan.warDrumDict:
                                self.family.SetState(STATE_GS_KIN_WAR_COLLECT_DRUM)
                                return
                            else:
                                self.family.SetState(STATE_GS_KIN_WAR_SEARCH)
                                return
                        else:
                            logging.debug("找不到争夺PVE里的敌人了 warEnemyDict=%s" % str(self.family.kinMan.warEnemyDict))
                elif scene_template_id == SceneHuangLingNeiDian:
                    if self.family.kinMan.target == KinWarKillGenerals:
                        generalName = self.family.kinMan.warTargetGeneral["name"]
                        generalPos = self.family.kinMan.GetWarGeneralPos(generalName)
                        if generalPos:
                            logging.debug("generalName = %s, generalPos = %s" % (generalName, str(generalPos)))
                            self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *generalPos)
                        else:
                            logging.debug("目标点没有找到 %s , 继续查看其它大将" % generalName)
                            self.family.SetState(STATE_GS_KIN_WAR_KILL_GENERALS)
                            return
            elif  self.family.kinMan.gameType == KinFeastGame:
                defendBox = self.family.kinMan.defendBossMsg
                if defendBox:
                    logging.debug("移动至boss点")
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, defendBox["pos"][0], defendBox["pos"][1], defendBox["pos"][2])
            else:
                gevent.sleep(3)
            self.family.gameServerNetPackHandle.SkillCanBeReleased()
            
        
        #周末关卡移动
        elif self.family.GetState() == STATE_GS_MOVE_GO:
            if self.gmMove:#解开柱子的触发需要普通移动
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveTarget['pos'])
            else:
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveTarget['pos'])
#                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.moveTarget['pos'])
#                self.family.SetState(STATE_GS_MOVE_ARRIVAL)

        
        #移动至目标点
        elif self.family.GetState() == STATE_GS_MOVE_ARRIVAL:
            self.family.SetState(STATE_GS_KIN_WAIT)
            gevent.sleep(2)
            if self.family.kinMan.target == "移动至中央位置":
                logging.debug("到达中央位置")
                gevent.sleep(5)
                self.family.SetState(STATE_GS_KIN_FEAST_WAIT_DINNING)
                return
            elif self.family.kinMan.target == "移动至盛宴厅":
                logging.debug("到达盛宴厅")
                gevent.sleep(5)
                self.family.SetState(STATE_GS_KIN_FEAST_WAIT_SHOW_FOOD)
                return
            elif self.family.kinMan.target == "瞬移至秦始皇陵入口处":
                logging.debug("家族争夺等待系统开启提示")
                self.family.kinMan.target = "进入秦始皇陵"
                self.moveTarget["pos"] = self.warEnterPos
                self.gmMove = False
                self.family.SetState(STATE_GS_KIN_WAR_OPEN_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_WarEnterWait")
                return
            elif self.family.kinMan.target == "进入秦始皇陵":
                logging.debug("已到秦始皇陵入口")
                return
            elif self.family.kinMan.target == KinWarPveFight:
                logging.debug("到达PVE %s" % self.warPveEnterIndex)
                self.warPveEnterIndex += 1
                if self.warPveEnterIndex in self.warPvePosDict:#指定下一次移动的位置
                    self.moveTarget["pos"] = self.warPvePosDict[self.warPveEnterIndex]
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.canSkill = True
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                return
            elif self.family.kinMan.target == KinWarKillGenerals or self.family.kinMan.isdajiang:
                self.family.kinMan.isdajiang = False
                self.family.kinMan.target = KinWarKillGenerals
                if self.family.kinMan.hasWarPvpDead:
                    logging.debug("移动至大将过程中已阵亡，等待活动结束")
                elif self.family.kinMan.hasMoveToGeneral:
                    self.family.gameServerNetPackHandle.canSkill = True
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                else:
                    logging.debug("尚未移动至大将，现切回状态")
                    self.family.SetState(STATE_GS_KIN_WAR_KILL_GENERALS)
                return
            
            elif self.family.kinMan.target == KinWarCheer:
                logging.debug("已到达助威区")
                self.family.gameServerNetPackHandle.canSkill = True
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                return

        #进入家族盛宴（家族领地）
        elif self.family.GetState() == STATE_GS_KIN_ENTER_FEAST:
            self.family.SetState(STATE_GS_KIN_LAND)
            self.family.gameServerNetPackHandle.EnterKinLand()#进入家族领地
        
        #判断是否开启家族盛宴
        elif self.family.GetState() == STATE_GS_KIN_FEAST:
            if self.family.kinMan.GetFeastIsOpen:
                logging.debug("移动至中央位置")
                self.family.kinMan.target = "移动至中央位置"
                self.moveTarget["pos"] = self.defendPos
                self.family.SetState(STATE_GS_MOVE_GO)
                self.family.gameServerNetPackHandle.AddBuffInvincible()#无敌Buff
                self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害999倍
            else:
                logging.debug('家族盛宴没开启')
                self.family.SetState(STATE_GS_KIN_FEAST_END)
        
        #进入盛宴厅
        elif self.family.GetState() == STATE_GS_KIN_FEAST_ENTER_DINNING_ROOM:
            logging.debug("移动至盛宴厅")
            self.family.kinMan.target = "移动至盛宴厅"
            self.moveTarget["pos"] = self.dinningRoom
            self.family.SetState(STATE_GS_MOVE_GO)
        
        #享用食物
        elif self.family.GetState() == STATE_GS_KIN_FEAST_EAT_FOOD:
            if not self.hadDrank:
                self.hadDrank = True
                logging.debug("饮酒")
                self.family.gameServerNetPackHandle.KinFeastAskDrink(random.randint(1, 2))#饮酒
            logging.debug("享用食物")
            self.family.gameServerNetPackHandle.KinFeastGetDish()#享用食物
            self.family.SetState(STATE_GS_KIN_FEAST_WAIT_SHOW_FOOD)
        
        #家族盛宴结束
        elif self.family.GetState() == STATE_GS_KIN_FEAST_END:
            self.family.SetState(STATE_GS_KIN_WAIT)
            logging.debug("盛宴结束")
            self.family.kinMan.cooking = False
            self.isFinishedKinfeast = True
            self.family.gameServerNetPackHandle.Transfer2Map(SceneLinan)#返回主城
        
        #移动至秦始皇陵入口
        elif self.family.GetState() == STATE_GS_KIN_WAR_MOVE_TO_ENTRANCE:
            self.family.SetState(STATE_GS_KIN_WAR_ENTER_LISHANYIJI_WAIT)
            logging.debug("移动至秦始皇陵入口")
            self.family.gameServerNetPackHandle.Transfer2Map(SceneLiShanYiJi)#进入骊山遗迹
            self.family.kinMan.target = "瞬移至秦始皇陵入口处"
            self.moveTarget["pos"] = self.warWaitPos
            self.family.SetState(STATE_GS_MOVE_GO)
            return 
        
        #家族争夺
        elif self.family.GetState() == STATE_GS_KIN_WAR_ENTER_HUANGLING:
            self.family.SetState(STATE_GS_KIN_WAR_START_WAIT)
            self.family.gameServerNetPackHandle.AddBuffInvincible()#无敌Buff
            self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害999倍
            logging.debug("已进入皇陵外宫")
            gevent.sleep(5)
            self.family.gameServerNetPackHandle.KinWarOpenSignUpUI()
            gevent.sleep(3)
            if self.family.kinMan.GetLeader():#族长
                while self.family.GetState() == STATE_GS_KIN_WAR_START_WAIT:
                    gevent.sleep(5)
                    logging.debug("warMemberDict = %s" % str(self.family.kinMan.warMemberDict))
                    logging.debug("cheererCount = %s, assaulterCount  = %s/%s" % (self.family.kinMan.cheererCount, self.family.kinMan.assaulterCount, self.family.kinMan.assaulterUpperLimit))
                    PvPNeedCount = self.family.kinMan.GetChangePvpMemberCount()
                    logging.debug("PvPNeedCount = %s" % PvPNeedCount)
                    if PvPNeedCount:
                        familyIdList = self.family.kinMan.GetWarPveMemberIdList(PvPNeedCount)
                        logging.debug("待调到冲锋区的familyIdList = %s" % str(familyIdList))
                        for familyId in familyIdList:
                            self.family.gameServerNetPackHandle.KinWarApplyChangePvpType(familyId, KinWarAssaulter)
                            gevent.sleep(2)
                self.family.gameServerNetPackHandle.KinWarOnCloseSignUpUI()
            else:#组员
                #申请参加冲锋
                self.family.gameServerNetPackHandle.KinWarApplyAttendPvp()
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.KinWarOnCloseSignUpUI()
                
        elif self.family.GetState() == STATE_GS_KIN_WAR_START:
            logging.debug("冲锋者准备进入冲锋区")
            self.family.kinMan.UpdateWarMemberDict(self.family.familyId, [[self.family.familyId, KinWarAssaulter]])
            self.family.gameServerNetPackHandle.AddBuffBlock()#增加强力格挡
            self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#增加一击必杀
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_WarEnterAssaultArea")
            for gdpl in self.warStoneList:#为每个冲锋者添加长明灯的石头
                g, d, p, l = map(int, gdpl.split("_"))
                self.family.gameServerNetPackHandle.CallScriptAddStackItem(g, d, p, l, 1, False, 0)
            self.moveTarget["pos"] = self.warPvePosDict[self.warPveEnterIndex]
            self.family.SetState(STATE_GS_MOVE_GO)
        
        elif self.family.GetState() == STATE_GS_KIN_CHEER_START:
            logging.debug("助威者准备进入助威区")
            self.family.kinMan.UpdateWarMemberDict(self.family.familyId, [[self.family.familyId, KinWarCheerer]])
            self.family.gameServerNetPackHandle.AddBuffBlock()#增加强力格挡
            self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#增加一击必杀
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_WarEnterCheerArea")
            self.moveTarget["pos"] = self.warCheerPos
            self.family.SetState(STATE_GS_MOVE_GO)
        
        elif self.family.GetState() == STATE_GS_KIN_WAR_LAMP:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.moveTarget["pos"] = self.warNeiDianEntrancePos
            warLampDict = self.family.kinMan.warLampDict
            if warLampDict:
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *warLampDict["pos"])
                gevent.sleep(3)
                for i in range(3):
                    self.family.gameServerNetPackHandle.AskNpc_obj(warLampDict["id"])#往长明灯放入三种石头
                    gevent.sleep(10)
            else:
                logging.debug("找不到长明灯！！！！！！！")

        elif self.family.GetState() == STATE_GS_KIN_WAR_KILL_GENERALS:
            self.family.SetState(STATE_GS_KIN_WAIT)
            logging.debug("准备移动至大将区域")
            self.family.kinMan.hasMoveToGeneral = True
            generalNameList = self.family.kinMan.warGeneralNameList
            if generalNameList:
                generalName = self.family.kinMan.warTargetGeneral["name"] = random.choice(generalNameList)
                self.family.kinMan.warTargetGeneral["id"] = 0
                self.moveTarget["pos"] = self.warGeneralsPosDict[generalName]
                logging.debug("移动至大将 %s" % generalName)
                if generalName == "秦始皇":
                    self.family.gameServerNetPackHandle.RemoveBuffHeavyDamage()#消除一击必杀
                else:
                    self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#增加一击必杀
                self.family.SetState(STATE_GS_MOVE_GO)
            else:
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.warQinShiHuangArea)
                logging.debug("大将列表为空")
        
        elif self.family.GetState() == STATE_GS_KIN_WAR_COLLECT_DRUM:
            drumId, drumPos = self.family.kinMan.GetWarDrumMsg()
            if drumId:
                logging.debug("战鼓id=%s, pos=%s" % (drumId, str(drumPos)))
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *drumPos)
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.AskNpc_obj(drumId)
                gevent.sleep(8)
            else:
                logging.debug("找不到战鼓了")
                if self.family.kinMan.warEnemyDict:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                else:
                    self.family.SetState(STATE_GS_KIN_WAR_SEARCH)
                    
        elif self.family.GetState() == STATE_GS_KIN_WAR_SEARCH:
            self.moveTarget["pos"] = random.choice(self.warCheerSearchPosList)
            self.family.SetState(STATE_GS_MOVE_GO)
                
        elif self.family.GetState() == STATE_GS_KIN_WAR_OPEN_RANK_UI:
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.family.kinMan.warBoxDict:#打开皇陵宝箱
                boxId = self.family.kinMan.warBoxDict["id"]
                boxPos = self.family.kinMan.warBoxDict["pos"]
                logging.debug("打开皇陵宝箱 boxId=%s, pos=%s" % (boxId, str(boxPos)))
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *boxPos)
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.AskNpc_obj(boxId)
                gevent.sleep(10)
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_WarEnd")
            logging.debug("打完皇陵，打开计分面板")
            self.family.gameServerNetPackHandle.KinWarOpenRankUI(1)
            self.isFinishedKinwar = True
            gevent.sleep(30)
            self.family.gameServerNetPackHandle.Transfer2Map(SceneLinan)#返回主城
        
        elif self.family.GetState() == STATE_GS_LIMITED_KINDUNGEON_END:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.behavior = Behavior.END
            return
        
def isPatriarch(familyId, kinMember):
    if kinMember[familyId].post == 1:
        return True
    else:
        return False

