#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import asyncore
import logging
import math
import time
from cgi import log
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Files.Shop import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
"""
         限时竞拍的TestCase
         
"""

class LimitedAuction(object):
    def __init__(self, family):
        self.family = family
        self.total = 0 
        self.true = True
        self.firstJoin = True
        self.index = True

    def _reset(self):
        self.family.limitedacution.auctioninformationlist = []
        self.family.limitedacution.auctionshopdatalist=[]
        self.family.limitedacution.one_auctiondatainfolist=[]
        
    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        state = self.family.GetState()
#        if self.family.GetState() == STATE_GS_PLAYING:
#            self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
#            return
        
        if self.family.GetState() == STATE_GS_LIMITED_AUCTION_BEGIN and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            if self.firstJoin:
                self.firstJoin = False
#                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[KAuction.AddAuctionShopByAwardId({83001, 83301}, 109, {%d}, 0, \"AA\");]], \"familyid:%d\"})" % (self.family.familyId, self.family.familyId))
                gevent.sleep(5)
            self.family.gameServerNetPackHandle.AuctionConcernReq()
            return
        
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_CHANGE:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self.family.gameServerNetPackHandle.AuctionShopDataReq(self.family.limitedacution.auctioninformationlist[0],#shopid.hiId
                                                               self.family.limitedacution.auctioninformationlist[1],#shopid.lowId
                                                               self.family.limitedacution.auctioninformationlist[2])#版本号
            gevent.sleep(5)
            while len(self.family.limitedacution.auctionshopdatalist) == 0 : 
                gevent.sleep(5)
            self.family.SetState(STATE_GS_LIMITED_AUCTION_INFOREP)
            return  
                  
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_INFOREP:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self.index =False
            if self.family.limitedacution.sellneed == 0:
                self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
                return
            self.family.gameServerNetPackHandle.AuctionGoodsDataReq(self.family.limitedacution.auctioninformationlist[0],
                                                                    self.family.limitedacution.auctioninformationlist[1],
                                                                    self.family.limitedacution.auctioninformationlist[2],
                                                                    self.family.limitedacution.auctionshopdatalist[0])#物品ID
            return
            
        elif self.family.GetState() == STATE_GS_LIMITED_AUCTION_AUCTION and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            acution_Treatment = {
                                        1 : 1,         #一口价
                                        0 : 29,        #竞拍价
                                    }
            acution_changtype = Rand.weighted_choice(acution_Treatment)
            if acution_changtype == 1:       
                self.family.gameServerNetPackHandle.GetEnoughMoney(1, self.family.limitedacution.one_auctiondatainfolist[0]) 
                self.family.gameServerNetPackHandle.AuctionBidGoodsReq(self.family.limitedacution.auctioninformationlist[0],
                                                                       self.family.limitedacution.auctioninformationlist[1],
                                                                       self.family.limitedacution.auctionshopdatalist[0],
                                                                       True,
                                                                       self.family.limitedacution.one_auctiondatainfolist[0])#物品价格ID                
            elif acution_changtype == 0:     
                self.family.gameServerNetPackHandle.GetEnoughMoney(1, self.family.limitedacution.one_auctiondatainfolist[2])
                self.family.gameServerNetPackHandle.AuctionBidGoodsReq(self.family.limitedacution.auctioninformationlist[0],
                                                                       self.family.limitedacution.auctioninformationlist[1],
                                                                       self.family.limitedacution.auctionshopdatalist[0],
                                                                       False,
                                                                       self.family.limitedacution.one_auctiondatainfolist[2])   
            return
                              
        elif self.family.GetState() ==  STATE_GS_LIMITED_AUCTION_FINISH and self.family.limitedacution.distinguish == 0:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_WAIT)
            self._reset()
            gevent.sleep(2)
            self.family.gameServerNetPackHandle.AuctionConcernReq()               
            self.family.SetState(STATE_GS_LIMITED_AUCTION_END)

        elif (self.family.GetState() == STATE_GS_LIMITED_AUCTION_END or self.total == (len(self.family.limitedacution.auctionshopdatalist)+self.family.limitedacution.sellneed)) and self.family.limitedacution.distinguish == 0 :
            if self.family.limitedacution.sellneed == 0:
                logging.debug("全部商品都流拍")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_FlowShot")
            else:
                logging.debug("完成限时拍卖")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LimitedAcution_Finish")            
            self.family.limitedacution.distinguish +=1
            self._reset()
            logging.debug("完成限时竞拍模块，退出")
#            self.family.behavior = Behavior.END
            self.family.SetState(STATE_GS_LIMITED_KINDUNGEON_END)            
            return  