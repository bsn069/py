#coding=utf-8
__author__ = 'Administrator'

import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from TestCase.Script import TestCase_Guardian
from ModuleState import NotifyState

from threading import Thread
import functools
import time
import sys
import copy

'''
非法交易的TestCase
'''
class TestCase():
    SHOPS = [XiaYiShop]
    #SHOPS = [CommonShop, XiaYiShop]
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.family.gameServerNetPackHandle.Kin_Shop_bool = False
        self.shopType = random.choice(TestCase.SHOPS)
        self.shopGoodCount = 0

    def _WaitForNotifyState(self, state, timeout = 5):
        begin = time.time()
        while (time.time() - begin < timeout):
            if self.family.notifyState.check_state(state):
                return True
            gevent.sleep(1)
        return False

    def _GetShopInfo(self):
        self.family.notifyState.unset_state(NofityState.STATE_GS_SYNC_SHOP_GOODS_LIST)
        self.family.gameServerNetPackHandle.Do_ApplyGoodsList(self.shopType)
        if self._WaitForNotifyState(NofityState.STATE_GS_SYNC_SHOP_GOODS_LIST):
            self.shopGoodCount = len(self.family.shops[self.shopType])
            return True
        return False

    def _Run(self, name, send_protocol_handle, get_value_handle, compare_value_handle, timeout = 40, count = 1):
        old_value = get_value_handle()
        self.family.notifyState.unset_state(NotifyState.STATE_GS_SHOP_RESULT)
        send_protocol_handle(self)
        #等待回包
        self._WaitForNotifyState(NotifyState.STATE_GS_SHOP_RESULT)
        new_value = get_value_handle()
        result = compare_value_handle(old_value, new_value)
        asyncresult_manager.await(self.family, name, 10)
        gevent.sleep(1)
        asyncresult_manager.fire(self.family, name, result)

    def _GetValue(self):
        return (copy.deepcopy(self.family.valueCoin), copy.deepcopy(self.family.items))

    def _CompareValue(self, old_value, new_value):
        return old_value == new_value

    def _BuyNoEnoughMoney(self):
        def _send_protocol(self):
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(self.shopType, random.randint(0, self.shopGoodCount - 1), 1)

        self._Run(sys._getframe().f_code.co_name,
                  _send_protocol,
                  self._GetValue,
                  self._CompareValue)

    def _BuyIllegalGoodId(self):
        def _send_protocol(self):
            illegalIds = [self.shopGoodCount, self.shopGoodCount + 1]
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(self.shopType, random.choice(illegalIds), 1)

        self._Run(sys._getframe().f_code.co_name,
                  _send_protocol,
                  self._GetValue,
                  self._CompareValue)

    def _BuyIllegalShopId(self):
        def _send_protocol(self):
            illegalShopIds = [0, 9999]
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(random.choice(illegalShopIds), 0, 1)

        self._Run(sys._getframe().f_code.co_name,
                  _send_protocol,
                  self._GetValue,
                  self._CompareValue)

    def _BuyIllegalGoodsSequence(self):
        def _send_protocol(self):
            illegalSequence = [0, 9999]
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(self.shopType, random.randint(0, self.shopGoodCount - 1), random.choice(illegalSequence))

        self._Run(sys._getframe().f_code.co_name,
                  _send_protocol,
                  self._GetValue,
                  self._CompareValue)


    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        self._GetShopInfo()
        self._BuyNoEnoughMoney()
        for case in switch(self.shopType):
            if case(CommonShop):
                self.family.gameServerNetPackHandle.Add_Sliver()
                self._WaitForNotifyState(STATE_GS_SYNC_MONEY, 10)
                self.family.SetState(STATE_GS_WAIT)
                break
            if case(XiaYiShop):
                self.family.gameServerNetPackHandle.Add_Sliver()
                self._WaitForNotifyState(STATE_GS_SYNC_MONEY, 10)
                self.family.SetState(STATE_GS_WAIT)
                self.family.gameServerNetPackHandle.GM_FinishMainTaskToId(Task_TuBian)#完成主线开启日常
                self.family.gameServerNetPackHandle.Do_AcceptTask(13)
                self.family.gameServerNetPackHandle.LevelUp_Weapon()#武器升星
                self.family.gameServerNetPackHandle.Do_ApplyFinishMainTask(13) #完成专断装备
                self.family.gameServerNetPackHandle.ApplyAchieveAward()#完成成就任务
                self._WaitForNotifyState(STATE_GS_SYNC_MONEY, 10)
                self.family.SetState(STATE_GS_WAIT)
                break

        self._BuyIllegalGoodId()
        self._BuyIllegalShopId()
        self._BuyIllegalGoodsSequence()
