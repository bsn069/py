#!/usr/bin/env python2.7
# coding:utf8
import math
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Config.RoleFigures import * 
from TestCase_TeamBase import TeamBaseCase
from net.Common.ComDefine_pb2 import *
from Tools.Rand import Rand

'''
    运镖的TestCase
'''


class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    def __init__(self, family):
        GameTypes = {
                     Escort_Yabiao : 4,
                     Escort_Jiebiao : 1,
                     }
        self.gameType = Rand.weighted_choice(GameTypes)#根据权重分配游戏类型
        self.gameType =  Escort_Yabiao#锁定游戏类型
        
        TeamType = {
                    Escort_Yabiao : [TEAM_TYPE_YA_BIAO, TEAM_TYPE_YA_BIAO, u"押镖"],
                    Escort_Jiebiao : [TEAM_TYPE_FREE, TEAM_TYPE_JIE_BIAO, u"劫镖"]
                    }
        super(TestCase, self).__init__(family, TeamType[self.gameType][0], TeamType[self.gameType][1], TeamType[self.gameType][2])
        
        self.family = family
        self.npcSite = (574, 722)
        self.JieBiaoPos = [(127.81, 200.67)]#(120.65, 199.28)  
        EscortCarTypes = {
                                            Escort_Food : 1,
                                            Escort_Treasure : 3,
                                          }
        self.escortCar = Rand.weighted_choice(EscortCarTypes)
#         self.escortCar = Escort_Treasure#锁定镖车类型
        
        TeamTypes = {
                     Escort_JiebiaoSingle : 1,
                     Escort_JiebiaoTeam : 5,
                     }
        self.jieBiaoMemberType = Rand.weighted_choice(TeamTypes)#根据权重分配劫镖单人or组队
#         self.jieBiaoMemberType = Escort_JiebiaoTeam#锁定类型
        
        


    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_ESCORT_WAIT)
                if self.family.isNewRole==False:
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(116,3,0)")
                self.family.gameServerNetPackHandle.Add_EscortItme()
                self.family.escort.SetGameType(self.gameType)
                self.family.escort.SetJieBiaoMemberType(self.jieBiaoMemberType)
                
                if self.gameType == Escort_Yabiao:
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    logging.debug("进入龙门荒漠")
                    self.family.gameServerNetPackHandle.Transfer2Map(SceneLongmen)#进入龙门荒漠
                    gevent.sleep(5)
                    self.family.SetState(STATE_GS_MOVE_GO)
                gevent.sleep(1)
                break

            if case(STATE_GS_MOVE_GO):
                if self.gameType == Escort_Yabiao:
                    logging.debug('押镖移动')
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(True, self.npcSite[0], self.npcSite[1])
                else:
                    logging.debug('劫镖移动')
                    pos = random.choice(self.JieBiaoPos)
                    self.family.escort.jieBiaoPos = pos
                    self.family.gameServerNetPackHandle.PlayerAutoPath(pos[0], pos[1])
                break

            if case(STATE_GS_MOVE_ARRIVAL):
                if self.gameType == Escort_Yabiao:
                    self.family.SetState(STATE_GS_ESCORT_TEAM)
                else:
                    self.family.escort.jieBiaoIsArrived = True
                    if self.jieBiaoMemberType == Escort_JiebiaoSingle:
                        logging.debug("准备单人劫镖")
                        self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)
                    else:
                        logging.debug("准备组队劫镖")
                        self.family.SetState(STATE_GS_ESCORT_TEAM)
                break

            if case(STATE_GS_ESCORT_TEAM):
                self.family.gameServerNetPackHandle.Can_TeamJoinCheck = False
                self.family.gameServerNetPackHandle.TeamNotJoin = True
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                break

            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_ESCORT_WAIT)
                if self.gameType == Escort_Yabiao:
                    if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                        gevent.sleep(10)#等待队友传送过来
                        self.family.gameServerNetPackHandle.StartEscort(self.escortCar)
                    else:
                        logging.debug("传送至队长位置")
                        self.family.gameServerNetPackHandle.TransferToTeammate(self.family.team_manager.myteam.leaderFamilyId)
                else:
                    if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                        logging.debug("队长等待队友传送过来")
                        gevent.sleep(3)#等待队友传送过来
                        logging.debug("队长等待劫镖车")
                        self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)
                    else:
                        logging.debug("传送至队长位置")
                        self.family.gameServerNetPackHandle.TransferToTeammate(self.family.team_manager.myteam.leaderFamilyId)
                break

            #开始运镖
            if case(STATE_GS_ESCORT_START_NOW):
                logging.debug("开始运镖")
                self.family.gameServerNetPackHandle.StartEScortNow()
                self.family.SetState(STATE_GS_ESCORT_BUY_INSURANCE)
                break

            #买保险
            if case(STATE_GS_ESCORT_BUY_INSURANCE):
                logging.debug("买保险")
                self.family.gameServerNetPackHandle.BuyInsurance()
                self.family.SetState(STATE_GS_ESCORT_ING)
                break

            #进入战斗
            if case(STATE_GS_ESCORT_IN_COMBAT):
                self.family.SetState(STATE_GS_ESCORT_WAIT)
                logging.debug("进入战斗")
                if self.gameType ==  Escort_Yabiao and self.escortCar == Escort_Food:
                    self.family.gameServerNetPackHandle.AddBuffHeavyDamage()
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                break

            #释放下次技能
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_ESCORT_WAIT)
                logging.debug("释放下次技能")
                gevent.sleep(1.5)
                self.family.gameServerNetPackHandle.SkillCanBeReleased()
                break

            #奇遇操作后，恢复上一个操作的状态
            if case(STATE_GS_FORTUITOUS_MEETING):
                logging.debug('奇遇操作后，恢复上一个操作的状态')
                self.family.gameServerNetPackHandle.FortuitousMeeting(random.randint(1, 2))
                self.family.SetState(self.family.gameServerNetPackHandle.nowState)
                break

            #运镖结束
            if case(STATE_GS_ESCORT_FINISH):
                logging.debug("押镖结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Escort_Finish")
                self.family.behavior = Behavior.END
                break














