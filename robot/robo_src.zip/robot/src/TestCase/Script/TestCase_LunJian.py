#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from net.Common.ComDefine_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import * 

'''
      论剑的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.isTrain = True
        self.count = 0

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_LUNJIAN_WAIT)
                if self.isTrain:
                    logging.debug("请求训练")
                    self.family.gameServerNetPackHandle.Do_LunJianTrainReq()
                    gevent.sleep(3)
                    logging.debug("训练完成")
                    self.family.gameServerNetPackHandle.Do_LunJianTrainCompleteReq()
                    self.isTrain = False
                self.family.SetState(STAGE_GS_LUNJIAN_REFRESH_LIST)
                break

            if case(STAGE_GS_LUNJIAN_REFRESH_LIST):
                self.family.SetState(STATE_GS_LUNJIAN_WAIT)
                logging.debug("刷新挑战列表")
                self.family.gameServerNetPackHandle.Do_LunJianFreshList()
                # self.family.behavior = Behavior.END#退出
                break

            if case(STATE_GS_LUNJIAN_CHALLEGE):
                self.family.SetState(STATE_GS_LUNJIAN_WAIT)
                logging.debug("挑战家庭")
                self.family.gameServerNetPackHandle.Do_LunJianLunJianChallege()
                self.family.SetState(STATE_GS_LUNJIAN_SHOP)
                break

            if case(STATE_GS_LUNJIAN_SHOP):
                self.count = self.count + 1
                if self.count > 3:
                    logging.debug("次数>3，退出")
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_LunJian_Finish")
                    self.family.behavior = Behavior.END#退出
                    break
                self.family.SetState(STATE_GS_LUNJIAN_RANK)
                break

            if case(STATE_GS_LUNJIAN_RANK):
                self.family.SetState(STATE_GS_LUNJIAN_WAIT)
                logging.debug("论剑排行榜")
                self.family.gameServerNetPackHandle.ApplyRankingRank(rank_type=RANK_LIST_TYPE_LUN_JIAN)
                self.family.gameServerNetPackHandle.ApplyRankingList(rank_type=RANK_LIST_TYPE_LUN_JIAN)
                self.family.gameServerNetPackHandle.LunJianGetChallengeHistory()
                self.family.SetState(STAGE_GS_LUNJIAN_REFRESH_LIST)
                break
