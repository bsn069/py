#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
# from Tools.JxLog import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Config.CaseDefine import *
from account.account_def import AccountDef
from account.account_service import account_action
from net.Common.ComDefine_pb2 import *

"""
         玩家随机移动TestCase
"""




MOVE_PATH = {
             Move_LinanMove : [     
                                    [759.58, 375.41, 78.47],     
                                    [490.45, 737.37, 78.23],     
                                    [489.58, 811.25, 78.40],     
                                    [596.32, 940.45, 78.81],     
                                    [632.91, 835.41, 72.14],  
                                    [694.58, 949.16, 76.43],   
                                    [760.41, 937.50, 75.86],     
                                    [768.22, 842.60, 75.97],
                                    [891.13, 941.42, 92.44],
                                    [869.58, 832.50, 92.53],
                                    [604.57, 740.94, 78.23],
                                    [925.41, 801.25, 114.82],
                                    [928.75, 671.66, 114.83],
                                    [761.34, 600.26, 78.39],
                                    [816.25, 614.16, 87.77],
                                    [524.57, 631.84, 88.05],
                                    [607.34, 454.70, 91.53],
                                    [943.25, 419.54, 116.48],
                                    [757.31, 712.21, 86.60],
                               ],
             # GuangChangYuanQuan
             Move_LinanEquip : [
                                    [724.38, 723.36, 86.59],
                                    [756.99, 709.62, 86.59],
                                    [789.44, 739.28, 86.59],
                                    [760.71, 771.57, 86.59],
                                ],
             Move_MapleSkill : [
                                [151.37, 201.5, 62.66]
                                ],
             Move_LongmenSkill : [
                                [115, 125, 58.0]
                                ]
             }

RAND_MOVE = [
    [118, 217],
    [117, 144],
]

MAPLE_SKILL_LIMIT = random.randint(10,150000)#根据释放技能的次数可以控制下线
class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.fixed = True
        self.moveIndex = -1
        self.noLoop = random.randint(0, 1)
        self.isFirst = True
        
        '''
        Move_LinanMove -> 围绕临安城移动，建议案例时间>=60 * 25s
        Move_LinanEquip ->围绕临安城广场移动，建议案例时间>=25s
        Move_MapleSkill -> 骊山遗迹移动至地图中间放技能，可按照放技能次数来控制下线
        Move_LongmenSkill -> 龙门荒漠移动至地图中间放技能，可按照放技能次数来控制下线
        '''
        #进图的等级限制
        self.levelLimit = {
                           Move_LinanMove : 1,
                           Move_LinanEquip : 1,
                           Move_LongmenSkill : 20,
                           Move_MapleSkill : 40,#地图标的35但实际是23级
                           }
        self.mapleSkillCount = 0#释放技能次数
        self.gatherLineCrowds = True#是否聚集分线人数

#         TASK_LIST = [Move_LinanEquip, Move_MapleSkill]
        TASK_LIST = [Move_LinanMove, Move_LinanEquip, Move_LongmenSkill]

        if False:
            account = account_action()
            logging.debug("RandomMove account = %s" % account)
            self.Task = TASK_LIST[int(account)]
        else:
            self.Task = random.choice(TASK_LIST)
#            self.Task =Move_LinanEquip
        self.movePath = MOVE_PATH[self.Task]
        self.moveCount = len(self.movePath)

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_RANDOMMOVE_TASK_START)
                if self.isFirst and self.family.isNewRole:#特殊需求（仅执行一次）
                    self.isFirst = False
                    memberType = 1
                    gevent.spawn(self.family.gameServerNetPackHandle.LoopChat)#持续喊话
                    self.family.gameServerNetPackHandle.RandomAvatar(memberType)#穿时装
#                     gevent.spawn(self.family.gameServerNetPackHandle.LoopWearMiJi)#穿秘籍
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(self.levelLimit[self.Task], MaxLevel), memberType)#随机等级、装备和升星
                    gevent.sleep(5)
                    #装备技能
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                break
                    
            if case(STATE_GS_RANDOMMOVE_TASK_START):
                if self.Task in [Move_LinanMove, Move_LinanEquip]:
                    if self.gatherLineCrowds:
                        self.family.SetState(STATE_GS_RANDOMMOVE_LINEINFO)
                    else:
                        self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                elif self.Task == Move_MapleSkill:
                    if self.gatherLineCrowds:
                        self.family.SetState(STATE_GS_RANDOMMOVE_GATHER_MAPLE_ENTER_WAIT)
                    else:
                        self.family.SetState(STATE_GS_RANDOMMOVE_MAPLE_ENTER_WAIT)
                    self.family.gameServerNetPackHandle.Transfer2Map(SceneLiShanYiJi)#进入枫华山谷
                elif self.Task == Move_LongmenSkill:
                    if self.gatherLineCrowds:
                        self.family.SetState(STATE_GS_RANDOMMOVE_GATHER_LONGMEN_ENTER_WAIT)
                    else:
                        self.family.SetState(STATE_GS_RANDOMMOVE_LONGMEN_ENTER_WAIT)
                    self.family.gameServerNetPackHandle.Transfer2Map(SceneLongmen)#进入龙门荒漠
                break
            
            if self.family.GetState() == STATE_GS_RANDOMMOVE_LINEINFO:
                self.family.SetState(STATE_GS_RANDOMMOVE_WAIT)
                gevent.sleep(1)
                self.family.gameServerNetPackHandle.bossLine = True
                self.family.gameServerNetPackHandle.Get_LineInfo()#获取分线信息309
                break
                
                
            if self.family.GetState() == STATE_GS_LINE_LIST:
                self.family.SetState(STATE_GS_RANDOMMOVE_LINELIST)
                self.family.gameServerNetPackHandle.Get_LineList()#请求线路列表310
                break
            
            if self.family.GetState() == STATE_GS_LINE_SWITCH:#换线
                self.family.SetState(STATE_GS_LINE_SWITCH_WAIT)
                line_id = self.family.gameServerNetPackHandle.switchLineId
                self.family.gameServerNetPackHandle.Switch_SceneLine(line_id)#换线
                break
            
            if self.family.GetState() == STATE_GS_LINE_SWITCH_SUCCESS:#换线成功
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            if case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.movePath[0]))
                break
 
            if case(STATE_GS_MOVE_ARRIVAL):
                if self.Task in [Move_MapleSkill, Move_LongmenSkill]:
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                    break
                if self.noLoop and self.moveIndex + 1 == self.moveCount:
                    self.family.behavior = Behavior.END#
                    break
                self.moveIndex = (self.moveIndex + 1) % self.moveCount
                if self.fixed:
                    x, y, z= self.movePath[self.moveIndex]
                else:
                    x = random.randint(RAND_MOVE[0][0], RAND_MOVE[0][1])
                    y = random.randint(RAND_MOVE[1][0], RAND_MOVE[1][1])
                self.family.gameServerNetPackHandle.PlayerAutoPath(x, y, z)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Move_ArrivalPosition")
                break
            
            #进入战斗
            if case(STATE_GS_LEAGUEMATCH_SKILL):
                self.family.SetState(STATE_GS_RANDOMMOVE_WAIT)
                logging.debug("进入战斗")
                self.family.gameServerNetPackHandle.AddBuffTenfoldDamage()
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *(self.movePath[0]))
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                break

            #释放下次技能
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_RANDOMMOVE_WAIT)
                if self.mapleSkillCount > MAPLE_SKILL_LIMIT:
                    logging.debug("释放技能次数到达限制值，准备下线")
                    self.family.behavior = Behavior.END
                    break
                self.mapleSkillCount += 1
                logging.debug("释放下次技能")
                gevent.sleep(1.5)
                self.family.gameServerNetPackHandle.SkillCanBeReleased()
                break
                