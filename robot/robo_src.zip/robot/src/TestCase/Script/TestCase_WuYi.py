#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
import math
from ModuleState.StateDefine import *
from Config.RoleFigures import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *

"""
         五一的TestCase
"""

class TestCase(object):
    Move_Pos = [
                (693, 887, 76),
                (608, 736, 78),
                (532, 739, 78),
                (608, 736, 78),
                (644, 571, 78),
                (759, 601, 78),
                (759, 514, 78),
                (851, 516, 91),
                (788, 558, 97),
                (759, 637, 82),
                (758, 697, 86),
                (763, 873, 76),
                (872, 830, 92),
                (951, 930, 92),
                (848, 878, 92),
                (758, 887, 76),
                (691, 739, 81),
                ]
    def __init__(self, family):
        self.family = family
        self.target = ""
        self.moveTarget = {
                   'pos' : (0, 0, 0),
                   }
        self.npcpos = (775, 771, 86)
        self.isgetBirld = False
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.target = "找鸟"
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                if self.target == "找鸟":
                    pos = TestCase.Move_Pos[random.randint(0, len(TestCase.Move_Pos)-1)]
                    self.moveTarget['pos'] = pos
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *pos)
                    self.family.SetState(STATE_GS_WU_YI_WAIT)
                    break
                elif self.target == "返回NPC":
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.npcpos)
                    self.family.SetState(STATE_GS_WU_YI_WAIT)
                    break
#                self.family.gameServerNetPackHandle.PlayerAutoPath(*pos)
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_WU_YI_WAIT)
                if self.target == "返回NPC":
                    self.target = "等待奖励"
                break
            
            elif case(STATE_GS_WU_YI_START):
                self.family.SetState(STATE_GS_WU_YI_WAIT)
                if self.isgetBirld:
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                if math.fabs(nowX - self.family.wuyi.birldPos[0]) < 1 or math.fabs(nowY - self.family.wuyi.birldPos[1]) < 1:
                    self.family.gameServerNetPackHandle.AskNpc_obj(self.family.wuyi.birdId)
                    gevent.sleep(10)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_WuYi_Ask_Birld")
                break
            
            elif case(STATE_GS_WU_YI_BACK):
                self.family.SetState(STATE_GS_WU_YI_WAIT)
                self.target = "返回NPC"
                self.isgetBirld = True
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_WuYi_Get_Birld")
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_WU_YI_END):
                self.family.SetState(STATE_GS_WU_YI_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_WuYi_Finish")
                self.family.behavior = Behavior.END
                break