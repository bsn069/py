#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import math
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Config.RoleFigures import *
from Tools.Rand import Rand
from net.Common.ComDefine_pb2 import *

'''
    杀手的TestCase
'''

class TestCase(object):
    #sleepTime is sleep second
    def __init__(self, family):        
        self.family = family
        self.npcSite = (602, 504)
        self.mapSite = (34, 28)
        self.isInMiss = True
        
    def Excute(self):
        self._Action()
    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_KILLER_WAIT)
                self.family.gameServerNetPackHandle.Add_Sliver()
                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.GM_GetDesignation(11) #获得凌绝称号
                    self.family.gameServerNetPackHandle.BecomeStronger()
                    self.family.SetState(STATE_GS_MOVE_GO)
                elif self.family.isNewRole == False:
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    self.family.SetState(STATE_GS_KILLER_FINISH)
                break

            # 喊话
            if case(STATE_GS_KILLER_CHAT):
                self.family.SetState(STATE_GS_KILLER_WAIT)
                self.family.gameServerNetPackHandle.ChatRequestByMsg("Kill:" + self.family.mainName, emChatChannelScene)
                gevent.sleep(10)
                self.family.SetState(STATE_GS_KILLER_REWARD_PEOPLE)
                break

            # 悬赏其他玩家
            if case(STATE_GS_KILLER_REWARD_PEOPLE):
                logging.debug('悬赏其他玩家')
                reward_people = self.family.killer.GetRewardPeople()
                self.family.gameServerNetPackHandle.OpenJianghuWanted()
                if reward_people:
                    reward_familid = reward_people[0]
                    reward_name = reward_people[1]
                    self.family.gameServerNetPackHandle.Do_SearchFamilyReq(reward_name, 1)
                    gevent.sleep(2)
                    self.family.gameServerNetPackHandle.PublishOneTask(reward_familid)
                gevent.sleep(5)
                break

            if case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.npcSite)
                break
            
            if case(STATE_GS_MOVE_ARRIVAL):
                if self.isInMiss:
                    self.isInMiss = False
                    self.family.SetState(STATE_GS_KILLER_CHAT)
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break

            if case(STATE_GS_KILLER_CHANGE):
                logging.debug('接单')
                '''
                "0,14,10000,3,11,1515588793,0,0,1,},},}"
                0:表示可接单
                14：接单number
                11: 悬赏单需等待11s才可接受
                '''
                self.family.gameServerNetPackHandle.OpenJianghuWanted()
                if self.family.killer.killlist:
                    list = self.family.killer.killlist 
                    for i in range(len(list)):
                        killlist = list[i].split(",")  
                        if killlist[0] == '0' and killlist[4] == '0':
                            self.family.gameServerNetPackHandle.AcessOneTask(int(killlist[1]))
                            break
                gevent.sleep(10)
                break

            if case(STATE_GS_KILLER_IN_MISS):
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break

            # 释放下次技能
            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):#释放下次技能
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Killer_Skill")
                if math.fabs(nowX - 34)> 3 or math.fabs(nowY - 28) > 3:
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.mapSite)
                    gevent.sleep(1)
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                gevent.sleep(1)
                break

            if case(STATE_GS_KILLER_FINISH):
                logging.debug('kill succeed 杀手案例结束')
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Killer_Finish")
                self.family.behavior = Behavior.END
                break










