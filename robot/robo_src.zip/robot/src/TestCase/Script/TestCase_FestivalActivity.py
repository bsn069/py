# coding=utf8

__author__ = 'kingsoft'
import random
import gevent
import asyncore
from random import choice
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config


'''
      国庆节日活动的TestCase
'''


class TestCase():
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                # 领取（7天好礼）第一天礼包
                self.family.SetState(STATE_GS_GET_LOGIN7_REWARD_AWAIT)
                self.family.gameServerNetPackHandle.GetLogin7Reward()
                gevent.sleep(1)
                break

            if case(STATE_GS_GET_LOGIN7_REWARD_RESULT):
                self.family.SetState(STATE_GS_ADD_TOKEN)
                # 令牌类型，1：盛世令 2：欢腾令 3：中华令
                token_list = [1, 2, 3]
                token = token_list[random.randint(0, len(token_list)-1)]
                # GM添加令牌
                logging.debug('GM添加令牌: %d' % token)
                self.family.gameServerNetPackHandle.GM_GetToken(token)
                gevent.sleep(3)
                break

            # if case(STATE_GS_ADD_TOKEN):
            #     # 参加节日活动
            #     self.family.SetState(STATE_GS_JOIN_FESTIVAL_ACTIVITY)
            #     logging.debug('参加节日活动')
            #     self.family.gameServerNetPackHandle.Cli_Activity_Join()  # 参加国庆节日活动
            #     break

            if case(STATE_GS_ADD_TOKEN):   # 寻找乐乐NPC
                logging.debug('移动到乐乐NPC')
                dx = 203.100006104
                dy = 149.699996948
                self.family.gameServerNetPackHandle.PlayerAutoPath(dx, dy)
                break

            if case(STATE_GS_MOVE_ARRIVAL):  # 询问乐乐NPC
                self.family.SetState(STATE_GS_ASK_LELENPC)
                gevent.sleep(1)
                logging.debug('询问乐乐NPC')
                self.family.gameServerNetPackHandle.AskNpc("乐乐")    # 领取烟花
                gevent.sleep(5)
                break

            if case(STATE_GS_SET_UP_FIRE):  # 活动结束
                self.family.SetState(STATE_GS_END)
                break

            if case(STATE_GS_END):
                logging.debug("节日活动案例结束")
                self.family.behavior = Behavior.END
                break