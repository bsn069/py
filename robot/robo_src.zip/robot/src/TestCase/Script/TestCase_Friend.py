#coding=utf-8
#!/usr/bin/env python2.7
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from Config.RoleFigures import *

"""
         好友系统的TestCase
"""

ADD_FRIEND_LIMIT = 5
DEAL_FRIEND_LIMIT = 5
SEND_GIFT_LIMIT = 3
BLACK_FRIEND_LIMIT = 0

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.searchState = True
        self.addFriendCount = 0
        self.dealFriendCount = 0
        self.sendGiftCout = 0
        self.addBlackCount = 0
        self.giftDict = {
                         u"好友送礼-相思草" : {"id":Friend_MeiGuiHua, "Count":648,},
                         u"好友送礼-玫瑰花" : {"id":Friend_MeiGuiHua, "Count":162,},
                         u"好友送礼-一往情深" : {"id":Friend_YiWangQingShen, "Count":16,},
                         u"好友送礼-心心相印" : {"id":Friend_XinXinXiangYin, "Count":6,},
                         u"好友送礼-天长地久" : {"id":Friend_TianChangDiJiu, "Count":1,},
                         }

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            if self.family.isNewRole:
                logging.debug("等待5min后战力榜刷新")
                gevent.sleep(60 * 5)#等待战力榜刷新
            self.family.SetState(STATE_GS_FRIEND_SYNC_DATA)
            
        # 同步好友数据
        if self.family.GetState() == STATE_GS_FRIEND_SYNC_DATA:
            self.family.SetState(STATE_GS_FRIEND_WAIT_SEARCH)
            if self.sendGiftCout >= SEND_GIFT_LIMIT:
                logging.debug("送过%s次礼物了，准备5s后结束" % SEND_GIFT_LIMIT)
                gevent.sleep(5)
                self.family.behavior = Behavior.END
                return
            logging.debug('请求人际关系数据')
            logging.debug("\n\n\n【 FriendCout = %s ; familyId = %s ; username = %s ;】\n\n\n" % (len(self.family.friendMan.GetFriendIdList()), self.family.familyId, self.family.userName))
            gevent.sleep(5)
            self.addFriendCount = 0
            self.dealFriendCount = 0
            self.family.gameServerNetPackHandle.Do_ApplyRelationData()
#             self.family.gameServerNetPackHandle.Do_ApplyAddFriend(101305)
        
        if self.family.GetState() == STATE_GS_FRIEND_CLEAN_FRIENDS:
            self.family.friendMan.hasCleanFriends = True
            self.family.gameServerNetPackHandle.ClearItemRoom()#清空背包防止礼物过多导致收礼错误
            gevent.sleep(5)
            friend_id_list = self.family.friendMan.GetFriendIdList()
            logging.debug('clean friend_id_list : %s' % friend_id_list)
            for family_id in friend_id_list:
                logging.debug("清除好友id = %d" % family_id)
                self.family.gameServerNetPackHandle.Do_RemoveFriend(family_id)
                self.family.friendMan.RemoveFriendIdList(family_id)
                gevent.sleep(1.5)
            self.family.SetState(STATE_GS_FRIEND_SEARCH)
        
        # 搜索玩家
        if self.family.GetState() == STATE_GS_FRIEND_SEARCH:
            logging.debug('搜索玩家')
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            if self.searchState:
                self.searchState = False
            else:
                gevent.sleep(15)
            self.family.gameServerNetPackHandle.Do_SearchFamilyReq(u"男"+generate_chinese(5))
                
        # 获取推荐列表
        if self.family.GetState() == STATE_GS_FRIEND_RECOMMAND:
            logging.debug('获取推荐列表')
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            self.family.gameServerNetPackHandle.Do_RecommandFriendReq()
            # self.family.SetState(STATE_GS_FRIEND_APPLY)
            
        # 添加好友
        if self.family.GetState() == STATE_GS_FRIEND_ADD:
            self.family.SetState(STATE_GS_FRIEND_WAIT_ADD)
            recommand_id_list = self.family.friendMan.GetRecommandIdList()
            if recommand_id_list and self.addFriendCount < ADD_FRIEND_LIMIT:#限制不要一直加好友
                logging.debug('recommand_id_list : %s' % recommand_id_list)
                family_id = recommand_id_list[random.randint(0, len(recommand_id_list) - 1)]
                self.family.gameServerNetPackHandle.Do_ApplyAddFriend(family_id)
                logging.debug("请求添加好友id = %d" % family_id)
                self.family.friendMan.RemoveRecommandIdList(family_id)
                self.addFriendCount += 1
                return
            else:
                gevent.sleep(random.uniform(15, 25))#给于其他人加自己好友的时间
                logging.debug("推荐列表为空")
                self.family.SetState(STATE_GS_FRIEND_APPLY)
            
        # 同意好友请求或拒绝好友请求
        if self.family.GetState() == STATE_GS_FRIEND_APPLY:
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            gevent.sleep(random.uniform(0, 5))
            apply_id_list = self.family.friendMan.GetApplyIdList()
            if apply_id_list and self.dealFriendCount < DEAL_FRIEND_LIMIT:#限制不要一直处理请求
                logging.debug('apply_id_list : %s' % apply_id_list)
                family_id = apply_id_list[random.randint(0, len(apply_id_list) - 1)]
                if random.randint(0, 3) != 0:
                    self.family.gameServerNetPackHandle.Do_AgreeAddFriend(family_id)
                    logging.debug('同意好友申请id = %d' % family_id)
                else:
                    self.family.gameServerNetPackHandle.Do_RefuseAddFriend(family_id)
                    logging.debug('拒绝好友申请 = %d' % family_id)
                self.family.friendMan.RemoveApplyIdList(family_id)
                self.dealFriendCount += 1
                return
            else:
                logging.debug("请求加好友列表为空")
                self.family.SetState(STATE_GS_FRIEND_REMOVE)

        # 删除部分好友
        if self.family.GetState() == STATE_GS_FRIEND_REMOVE:
            logging.debug('删除部分好友')
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            friend_id_list = self.family.friendMan.GetFriendIdList()
            if friend_id_list:
                logging.debug('friend_id_list : %s' % friend_id_list)
                family_id = friend_id_list[random.randint(0, len(friend_id_list) - 1)]
                logging.debug("删除好友id = %d" % family_id)
                self.family.gameServerNetPackHandle.Do_RemoveFriend(family_id)
                self.family.friendMan.RemoveFriendIdList(family_id)
                return
            else:
                logging.debug("（删除好友）好友列表为空")
                self.family.SetState(STATE_GS_FRIEND_SEND_GIFT)
        
        #送好友礼物
        if self.family.GetState() == STATE_GS_FRIEND_SEND_GIFT:
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            friend_id_list = self.family.friendMan.GetFriendIdList()
            if friend_id_list:
                self.sendGiftCout += 1
                for family_id in friend_id_list:
                    logging.debug("赠送礼物好友id = %d" % family_id)
                    giftList = random.sample(self.giftDict.keys(), random.randint(1, len(self.giftDict.keys())))
                    for i in giftList:
                        self.family.gameServerNetPackHandle.SetGoldNumber()#获取足够元宝
                    gevent.sleep(3)
                    for giftDesc in giftList:
                        giftCount = random.randint(1, self.giftDict[giftDesc]["Count"])
                        self.family.gameServerNetPackHandle.SendGiftReq(receiverId=family_id, desc=giftDesc, shopId=FriendShop, goodId=self.giftDict[giftDesc]["id"], buyCount=giftCount, priceIndex=0)
                        gevent.sleep(1)
                    gevent.sleep(random.uniform(2, 5))
            else:
                logging.debug("（送好友礼物）好友列表为空")
            self.family.SetState(STATE_GS_REVENGEE_LIST)
                
        #获取仇人列表
        if self.family.GetState() == STATE_GS_REVENGEE_LIST:
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            logging.debug("获取仇人列表")
            self.family.gameServerNetPackHandle.ApplyRevengeeInfo()#STATE_GS_FRIEND_SYNC_DATA
        
        #添加黑名单
        if self.family.GetState() == STATE_GS_BLACK_LIST:
            self.family.SetState(STATE_GS_BLACK_LIST_WAIT)
            friend_id_list = self.family.friendMan.GetFriendIdList()
            if friend_id_list and self.addBlackCount < BLACK_FRIEND_LIMIT:
                self.addBlackCount += 1
                logging.debug('friend_id_list : %s' % friend_id_list)
                family_id = friend_id_list[random.randint(0, len(friend_id_list) - 1)]
                logging.debug("黑名单id = %d" % family_id)
                self.family.gameServerNetPackHandle.AddBlackList(family_id)
                self.family.friendMan.RemoveFriendIdList(family_id)
                return
            else:
                logging.debug("（黑名单）列表为空")
                self.family.SetState(STATE_GS_MAIL_LIST)
#        #删除黑名单
#        if self.family.GetState() == STATE_GS_REMOVE_BLACK_LIST:

        #获取邮件列表
        if self.family.GetState() == STATE_GS_MAIL_LIST:
            self.family.SetState(STATE_GS_FRIEND_WAIT)
            logging.debug("获取邮件")
            self.family.gameServerNetPackHandle.ApplyMailBox()#获取邮件
        
