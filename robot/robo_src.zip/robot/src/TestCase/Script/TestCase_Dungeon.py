# coding:utf-8
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *
from TestCase_TeamBase import TeamBaseCase,TeamCreateType
from account.account_def import AccountDef
from account.account_service import account_hengdaoshu
from TestCase_LimitedAuction import LimitedAuction

'''
    衡道书的TestCase
'''


class TestCase(TeamBaseCase, LimitedAuction):
    TYPE_SHENGLU_ORDINARY = 1
    TYPE_SHENGLU_HERO =4
    TYPE_DANSHU_ORDINARY = 7
    TYPE_DANSHU_HERO = 8
    
    KEY_GDPL = "5_1_109_2"
    
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE_BIG, TEAM_TYPE_FREE_BIG, u"衡道书",teamCreateType=TeamCreateType.FIXED)
        LimitedAuction.__init__(self,family)
        self.family = family
        self.isFirstEnter = True
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_hengdaoshu(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[Leaguage Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
       
        self.posDict = {
                        SceneDungeon1 : {
                                            1 : (101, 55, 109),
                                            2 : (41, 47, 116),
                                            3 : (31.13, 105.00, 118),#触发剧情地点，需等待
                                            4 : (27.47, 105.07, 118),
                                         },
                        SceneDungeon2 : {
                                            1 : (51.01, 18.76),
                                            2 : (104.89, 54.17),
                                            3 : (98.03, 89.78),#触发剧情地点，需等待
                                            4 : (95.76, 100.78),
                                         }
                        }
        
#        self.ChapterList = [TestCase.TYPE_SHENGLU_ORDINARY, TestCase.TYPE_SHENGLU_HERO, TestCase.TYPE_DANSHU_ORDINARY]
        self.ChapterList = [TestCase.TYPE_DANSHU_ORDINARY, TestCase.TYPE_DANSHU_HERO]
        self.Npcpos = (80, 93, 54)
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        LimitedAuction._Action(self)
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_HENG_WAIT)
                if self.isFirstEnter:
                    self.SelectChapter = self.ChapterList[random.randint(0, len(self.ChapterList)-1)]
                    if self.SelectChapter == TestCase.TYPE_SHENGLU_HERO:
                        self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 1, 109, 2, 1, False, 0)
                        gevent.sleep(10)
                        key_itemId = self.family.bag.consumeBag[TestCase.KEY_GDPL][False].keys()[0]
                        key_slotPosition = self.family.bag.consumeBag[TestCase.KEY_GDPL][False][key_itemId]["slotPosition"]
                        self.family.gameServerNetPackHandle.Do_UseItemBySlot(itemId = key_itemId, slotPosition = key_slotPosition)
                    if self.isFirstEnter:
                        self.isFirstEnter = False                                                   
                        for i in [13, 14, 15, 53, 54, 55]:
                            self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand","me:SetDataInt(1007,%d,1)" % (i))
                            gevent.sleep(3)
                        logging.debug("第一次进入衡道书")
                        if self.family.isNewRole:
                            self.family.gameServerNetPackHandle.BecomeStronger()#穿全部装备
                            gevent.sleep(5)
                        self.family.SetState(STATE_GS_HENG_ENTER_WAIT)
                        self.family.gameServerNetPackHandle.Transfer2Map(SenceMoXiangJu)#进入墨香居
                    else:#通过章节后再打需要清除一些状态
                        logging.debug("继续打衡道书章节%s " % self.SelectChapter)
                        self.family.dungeon.enterFightAreaCount = 0
                        self.family.dungeon.StateForArrival = STATE_GS_HENG_WAIT
                        gevent.sleep(5)
                        self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                else:
                    self.family.SetState(STATE_GS_HENG_END)
                break
            
            if case(STATE_GS_HENG_ENTER):
                self.family.gameServerNetPackHandle.TeamNotJoin = True
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                logging.debug("开始组队")
                break
            
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_HENG_WAIT)
                logging.debug("完成组队")
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False,176, 91)
                    gevent.sleep(2)
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                
                else:
                    logging.debug("传送至队长位置")
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.Npcpos)
                    gevent.sleep(5)
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)              
                return 
            
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_HENG_WAIT)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    logging.debug("等待队友传送过来")
                    self.family.gameServerNetPackHandle.ApplyOpenDungeonGame(self.SelectChapter)
                break
            
            if case(STATE_GS_MOVE_GO):
                self.family.SetState(STATE_GS_HENG_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Dungeon_MapMove")
                scene_template_id = self.family.gameServerNetPackHandle.sceneTemplateId
                if scene_template_id in self.posDict and self.family.dungeon.enterFightAreaCount in self.posDict[scene_template_id]:
                    logging.debug("移动至 : %s" % str(self.posDict[scene_template_id][self.family.dungeon.enterFightAreaCount]))
                    self.family.dungeon.isMoving = True
                    self.family.gameServerNetPackHandle.PlayerAutoPath(*(self.posDict[scene_template_id][self.family.dungeon.enterFightAreaCount]))
                else:
                    logging.debug("找不到对应的地点坐标，sceneTemplateId = %s, enterFightAreaCount = %s" % (scene_template_id, self.family.dungeon.enterFightAreaCount))
                break

            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_HENG_WAIT)
                logging.debug("到达目标点 count = %s" % self.family.dungeon.enterFightAreaCount)
                self.family.dungeon.isMoving = False
                if self.family.dungeon.enterFightAreaCount == 3:
                    logging.debug("等待45s")
                    gevent.sleep(45)
                    logging.debug("开始进入战斗区")
                    self.family.dungeon.enterFightAreaCount += 1
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    self.family.SetState(STATE_GS_HENG_SKILL)
#                    self.family.SetState(self.family.dungeon.StateForArrival)
                break
            
            if case(STATE_GS_HENG_SKILL):
                self.family.SetState(STATE_GS_HENG_WAIT)
                gevent.sleep(3)
                bosslist = self.family.dungeon.bossIdList.keys()
                logging.debug("判断逻辑 bossIdList = %s" % bosslist)
                self.family.dungeon.isMoving = False
                while bosslist:
                    targetId = bosslist.pop()
                    logging.debug("targetId = %s" % targetId)
                    self.family.gameServerNetPackHandle.GM_GetNpcKill(targetId)
                    self.family.gameServerNetPackHandle.AddBuffHeavyDamage()
                    self.family.gameServerNetPackHandle.AddBuffBlock()
#                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *(self.family.dungeon.bossIdList[targetId]))
#                    self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
#                    self.family.SetState(STATE_GS_HENG_SKILL)
                    if self.family.gameServerNetPackHandle.sceneTemplateId == SceneDungeon2 and self.family.dungeon.enterFightAreaCount == 4:
                        logging.debug("击杀后等后续boss刷出")
                        gevent.sleep(5)
                logging.debug("完成击杀")
                break
            
            if case(STATE_GS_HENG_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Dungeon_Finish")
                self.family.gameServerNetPackHandle.GetRecommendAward()#获取奖励宝箱
                gevent.sleep(2)
                logging.debug("衡道书案例结束")
                self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
                break
            
            if case(STATE_GS_LIMITED_KINDUNGEON_END):
                self.family.SetState(STATE_GS_HENG_WAIT)
                self.family.behavior = Behavior.END
                break
            