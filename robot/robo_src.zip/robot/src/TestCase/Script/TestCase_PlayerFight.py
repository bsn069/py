# coding:utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from gevent.hub import sleep
from quopri import ishex

'''
      互相切磋的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):
#             进入药王谷
            if case(STATE_GS_PLAYING):                
                self.family.SetState(STATE_GS_PK_CHANGMAP)
                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.BecomeStronger()#获取高级装备
                self.family.gameServerNetPackHandle.Transfer2Map(SceneLongmen)
                break
#             走向切磋区域
            if case(STATE_GS_PK_CHANGE_ARRIVAL):
#                 self.family.gameServerNetPackHandle.PlayerAutoPath(240+random.randint(0,10), 80+random.randint(0,10))
                self.family.gameServerNetPackHandle.PlayerAutoPath(123.28, 123.33)
                break

            
            #到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                selectType = random.randint(1, 2)
#                 selectType = 2 #锁定选择
                if selectType == 1:# A:等待被切磋
                    self.family.SetState(STATE_GS_PK_TALK)
                else:# B:等待切磋他人
                    self.family.SetState(STATE_GS_PK_WAIT)
                break
            # A:等待被切磋
            if case(STATE_GS_PK_TALK):
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.ChatRequestByMsg(u'切磋一下不', 4)
                break
            

            # B:请求切磋
            if case(STATE_GS_PK_ASKPK):
                self.family.gameServerNetPackHandle.ChatRequestByMsg(u'发起切磋', 4)
                self.family.gameServerNetPackHandle.Ask_PK()
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_PK_AskPK")
                self.family.SetState(STATE_GS_ASKPK_WAIT)
                break
            
            # A:接受切磋 之后,自动接受切磋了, 1/10的几率拒绝切磋,之后双方自动进入共同切磋状态
#             if case(STATE_GS_PK_AFTER_ANSWERPK):
#                 break
            
            # 双方共同进入切磋
            if case(STATE_GS_PK_START):
                self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_PK_StartPK")
                if random.randint(1, 5) == 1:
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(u'切磋中', 4)
                gevent.sleep(3)
                break
            #　放技能
            if case(STATE_GS_LEAGUEMATCH_SKILL):
                logging.debug("放技能")
                gevent.sleep(2)
                if random.randint(1, 5) == 1:
                    self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害999 Buff
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                break
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(False, 55.75, 56.79)
                self.family.gameServerNetPackHandle.SkillCanBeReleased()
                break
            
            # 切磋结束
            if case(STATE_GS_PK_END):
                self.family.gameServerNetPackHandle.ChatRequestByMsg(u'切磋结束了， 退出', 4)
                gevent.sleep(4)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_PK_FinishPK")
                self.family.behavior = Behavior.END
                break
