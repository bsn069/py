#!/usr/bin/env python2.7
# coding:utf8
import math
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase_TeamBase import TeamBaseCase

'''
    江湖风云录（打塔）的TestCase
'''

class TestCase(TeamBaseCase):
    def __init__(self, family):
        self.family = family
        self.hasStartBossChallenge = False
        
        self.movePosList = [(103.45, 25.35), (56.57, 59.17), (74.15, 106.77), (21.68, 84.73)]
        self.moveCount = 0
    
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                if not self.hasStartBossChallenge:
                    self.hasStartBossChallenge = True
                    self.family.SetState(STATE_GS_BOSSCHALLENGE_TARGET_WAIT)
                    self.family.gameServerNetPackHandle.AddBossChallengeTime()#增加挑战次数
                    gevent.sleep(3)
                    self.family.gameServerNetPackHandle.StartBossChallenge()
                else:
                    self.family.SetState(STATE_GS_END)
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.boss_challenge.needMove = False
                if self.moveCount <= len(self.movePosList)-1:
                    pos = self.movePosList[self.moveCount]
                    self.moveCount += 1
                    self.family.gameServerNetPackHandle.PlayerAutoPath(*pos)
                else:
                    logging.debug("[ERROR]无法找到下次移动的坐标点")
                    self.family.SetState(STATE_GS_BOSSCHALLENGE_TARGET_WAIT)
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                logging.debug("到达目标点")
                logging.debug("pos=(%s, %s)" % (self.family.characterCur.posX, self.family.characterCur.posY))
                if self.family.boss_challenge.needSkill:
                    self.family.SetState(STATE_GS_BOSSCHALLENGE_SKILL)
                else:
                    self.family.SetState(STATE_GS_BOSSCHALLENGE_TARGET_WAIT)
            
            #进入战斗
            elif case(STATE_GS_BOSSCHALLENGE_SKILL):
                self.family.SetState(STATE_GS_BOSSCHALLENGE_WAIT)
                logging.debug("进入战斗")
                self.family.boss_challenge.needSkill = False
                self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#一击必杀
                self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
                break

            #技能
            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):
                self.family.SetState(STATE_GS_BOSSCHALLENGE_WAIT)
                logging.debug("技能")
                gevent.sleep(1.5)
                bossPos, bossId = self.family.boss_challenge.GetBossDict()
                if bossPos:
                    if time.time() - self.family.boss_challenge.lastBossAppearTime > 30:
                        logging.debug("超过30s没杀掉boss, 使用Gm杀")
                        self.family.gameServerNetPackHandle.GM_GetNpcKill(bossId)
                        gevent.sleep(8)
                        self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                        break
                    nowX = self.family.characterCur.posX
                    nowY = self.family.characterCur.posY
                    if not (math.fabs(nowX - bossPos[0]) < 2 and math.fabs(nowY - bossPos[1]) < 2):
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *bossPos)
                    self.family.gameServerNetPackHandle.SkillCanBeReleased()
                else:
                    logging.debug("找不到boss了")
                    if self.family.boss_challenge.needMove:
                        self.family.SetState(STATE_GS_MOVE_GO)
                    else:
                        self.family.SetState(STATE_GS_BOSSCHALLENGE_TARGET_WAIT)
                break
            
            # 结束
            elif case(STATE_GS_END):
                logging.debug("江湖风云录案例结束")
                self.family.behavior = Behavior.END
                break
            