# coding:utf8
__author__ = 'kingsoft'
import random
import gevent
import asyncore
from random import choice
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config


'''
      称号系统的TestCase
'''


class TestCase():
    def __init__(self, family):
        self.family = family
        # 江湖称号
        self.jhList = [33,13,12,11,17,25,26,27,30,31,32,10,38,1,2,8,9,22,23,24,39,37,41,3,7,16,36,6,18,40,35,42,5,14,15,34,43,4]
        # 个性称号
        self.gxList = [201,219,220,221,202,222,223,224,203,225,226,227,228,229,204,205,207,230,231,210,211,212,213,232,214,215,233,216,217,218]
        # 炫光称号
        self.xgList = [401, 402]
        self.list=self.jhList+self.gxList +self.xgList
        self.ChengHaoNumber = 70
        self.index = 0
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()


        for case in switch(nState):

            # if case(STATE_GS_PLAYING):
            #     logging.debug('请求场景的当前线的信息（编号，负载）309')
            #     self.family.gameServerNetPackHandle.Get_LineInfo()
            #     gevent.sleep(1)

            if case(STATE_GS_PLAYING) and self.family.isNewRole == True:  # GM开启称号
                id = self.list.pop()
                logging.debug('GM开启称号: %d' % id)
                self.family.gameServerNetPackHandle.GM_GetDesignation(id)
                gevent.sleep(1)
                if len(self.list) == 0:
                    self.family.SetState(STATE_GS_GET_DESIGNATION)
                break
            
            if case(STATE_GS_WAIT_DESIGNATION):
                id = self.list.pop()
                if id not in self.family.family_designtion_list:   
                    logging.debug('GM开启称号: %d' % id)
                    self.family.gameServerNetPackHandle.GM_GetDesignation(id)
                gevent.sleep(1)
                if len(self.list) == 0:
                    self.family.SetState(STATE_GS_GET_DESIGNATION)
                break
            
            if self.index == 0:
                if self.family.isNewRole == False and len(self.family.family_designtion_list)==self.ChengHaoNumber:
                    self.family.SetState(STATE_GS_GET_DESIGNATION)
                else:
                    self.list.sort()
                    self.family.SetState(STATE_GS_WAIT_DESIGNATION)
                self.index += 1

            
            if case(STATE_GS_GET_DESIGNATION):   # 装备江湖称号
                self.family.SetState(STATE_GS_SET_JH_DESIGNATION_WAIT)  # 跳转到装备江湖称号等待状态
                JH_ID = self.jhList.pop()
                logging.debug('装备江湖称号: %d' % JH_ID)
                self.family.gameServerNetPackHandle.FamilyTitle_SetActive(JH_ID)
                gevent.sleep(5)
                if len(self.jhList) == 0:
                    self.family.SetState(STATE_GS_SET_JH_DESIGNATION)
                break

            if case(STATE_GS_SET_JH_DESIGNATION):  # 装备个性称号
                self.family.SetState(STATE_GS_SET_GX_DESIGNATION_WAIT)  # 跳转到装备个性称号等待状态
                self.GX_ID = random.sample(self.gxList, 2)
                logging.debug('装备个性称号: %d , %d' % (self.GX_ID[0], self.GX_ID[1]))
                self.family.gameServerNetPackHandle.FamilyTitle_SetActive(self.GX_ID[0], self.GX_ID[1])
                gevent.sleep(5)
                for id in self.gxList[:]:
                    if id in self.GX_ID:
                        self.gxList.remove(id)
                if len(self.gxList) == 0:
                    self.family.SetState(STATE_GS_SET_GX_DESIGNATION)
                break

            if case(STATE_GS_SET_GX_DESIGNATION):  # 装备炫光称号
                self.family.SetState(STATE_GS_SET_XG_DESIGNATION_WAIT)  # 跳转到装备炫光称号等待状态
                self.XG_ID = self.xgList.pop()
                logging.debug('装备炫光称号: %d' % self.XG_ID)
                self.family.gameServerNetPackHandle.FamilyTitle_SetActive(self.GX_ID[0], self.GX_ID[1], self.XG_ID)
                gevent.sleep(5)
                if len(self.xgList) == 0:
                    self.family.SetState(STATE_GS_SET_XG_DESIGNATION)
                    break
                break

            if case(STATE_GS_SET_XG_DESIGNATION):   # 卸下全部称号
                self.family.SetState(STATE_GS_UNSET_DESIGNATION_WAIT)  # 跳转到装备炫光称号等待状态
                logging.debug('卸下称号')
                self.family.gameServerNetPackHandle.FamilyTitle_SetActive()
                gevent.sleep(5)
                break
            
            if case(STATE_GS_UNSET_DESIGNATION_RESULT):  # 装备炫光称号结果
                self.family.SetState(STATE_GS_END)
                break

            if case(STATE_GS_END):
                logging.debug("称号系统案例结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Designation_Finish") 
                self.family.behavior = Behavior.END
                break