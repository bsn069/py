#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *

'''
      商店和任务的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.benterArena = True
        self.shoplist = [0,CommonShop,XiaYiShop,ArenaShop,BattleShop,LiuLiShop]
        self.shopindex = 0

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                if self.shopindex >= len(self.shoplist):
                    self.family.SetState(STATE_GS_END)
                    break
                for shop in switch(self.shoplist[self.shopindex]):
                    if shop(0):
                        logging.debug("完成成就任务")
                        self.family.gameServerNetPackHandle.ApplyAchieveAward()#完成成就任务
                        break
                    if shop(CommonShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("银两商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_SILVER, 500000)#增加银两
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(CommonShop, random.choice(SHOP_GOODS[CommonShop]), 1)#银两商店购买 self.family.shops[XiaYiShop].GetRandomGoodIndex(XiaYiShop)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(CommonShop, Rand.rand_uint8(), Rand.rand_uint8())
                    if shop(XiaYiShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("侠义商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_XIAYI, 50000)#增加侠义值
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(XiaYiShop, random.choice(SHOP_GOODS[XiaYiShop]), 1)#侠义商店购买 self.family.shops[XiaYiShop].GetRandomGoodIndex(XiaYiShop)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(XiaYiShop, Rand.rand_uint8(), Rand.rand_uint8())
                    if shop(ArenaShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("联赛商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_REPUTATION, 50000)#增加侠义值
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(ArenaShop, random.choice(SHOP_GOODS[ArenaShop]), 1)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(ArenaShop, Rand.rand_uint8(), Rand.rand_uint8())
                    if shop(BattleShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("演武商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_BATTLE_HONOR, 50000)#
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(BattleShop, random.choice(SHOP_GOODS[BattleShop]), 1)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(BattleShop, Rand.rand_uint8(), Rand.rand_uint8())
                    if shop(MasterShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("师徒商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_MASTER_COIN, 50000)#增加侠义值
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(MasterShop, random.choice(SHOP_GOODS[MasterShop]), 1)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(MasterShop, Rand.rand_uint8(), Rand.rand_uint8())
                    if shop(LiuLiShop):
                        self.family.SetState(STATE_GS_SHOP_WAIT_RESULT)
                        logging.debug("琉璃商店购买")
                        logging.debug("self.family.shops = {0}".format(self.family.shops))
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_TIANLANG, 50000)#增加九转琉璃值
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.ApplyBuyShopItem(LiuLiShop, random.choice(SHOP_GOODS[LiuLiShop]), 1)
                        if Config.is_illegaltest():
                            self.family.gameServerNetPackHandle.ApplyBuyShopItem(LiuLiShop, Rand.rand_uint8(), Rand.rand_uint8())
                    
                    if shop():
                        self.family.SetState(STATE_GS_SHOP_RESULT)
                        break

            if case(STATE_GS_SHOP_RESULT):
                self.shopindex += 1
                self.family.SetState(STATE_GS_PLAYING)
                break

            if case(STATE_GS_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Shop_Finish")
                self.family.behavior = Behavior.END
                break

