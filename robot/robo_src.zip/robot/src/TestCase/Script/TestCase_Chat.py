#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *

"""
         聊天系统的TestCase
"""

class TestCase(object):
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                ChatType = random.choice([emChatChannelWorld, emChatChannelScene, emChatChannelPrivate, emChatChannelTeam])
                if ChatType == emChatChannelWorld:
                    channel = emChatChannelWorld#世界
                    msg = u'Chat_世界[喝彩]'
                elif ChatType == emChatChannelPrivate:
                    channel = self.family.gameServerNetPackHandle.familyId#自己发给自己-私聊
                    msg = u'Chat_私聊[心动] %d' % self.family.gameServerNetPackHandle.familyId
                elif ChatType == emChatChannelTeam:
                    channel = emChatChannelTeam#队伍
                    msg = u'Chat_队伍[握手]'
                elif ChatType == emChatChannelScene:
                    channel = emChatChannelScene#附近
                    msg = u'Chat_附近[口水]'
                logging.debug("chat Msg = %s" % msg)
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, channel)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Chat_SendChat")
                gevent.sleep(5)#聊天冷却时间
                break
                