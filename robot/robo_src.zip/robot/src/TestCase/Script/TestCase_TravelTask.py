# coding=utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *


"""
         游历任务的TestCase
"""

class TestCase(object):
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_TRAVEL_GMTASK)
                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(20, 50), 1)#随机等级、装备和升星
                break
            
            if case(STATE_GS_TRAVEL_GMTASK):
                self.family.SetState(STATE_GS_TRAVEL_WAIT)
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddTodayTravelReputation(1000);")
                self.family.SetState(STATE_GS_TRAVEL_RECEIVE)
                break
            
            if case(STATE_GS_TRAVEL_RECEIVE):
                for i in range(3):
                    self.family.gameServerNetPackHandle.CallScript("PlayerCmd", "GetTravelReputationAward", i+1)   #领取游历任务箱子奖励
                    gevent.sleep(3)
                self.family.gameServerNetPackHandle.CallScript("TaskCmd", "ApplyFinishTask", 1.0)#领取额外任务奖励
                gevent.sleep(1)                
                self.family.SetState(STATE_GS_TRAVEL_END)
                
            if case(STATE_GS_TRAVEL_END):
                self.family.SetState(STATE_GS_TRAVEL_WAIT)
                logging.debug("退出")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_TravelTask_Finish")
                self.family.behavior = Behavior.END


            