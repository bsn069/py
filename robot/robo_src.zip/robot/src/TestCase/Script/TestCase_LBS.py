# encoding=utf-8

import gevent
import time
import traceback
from locust.asyncevent import asyncresult_manager
from NetPackHandle.LocationServerNetPackHandle import LocationServerNetPackHandle

class CaseType:
    FAMILY_SET = 0
    FAMILY_GET = 1
    KIN_SET = 2
    KIN_GET = 3

class TestCase(object):
    
    def __init__(self):
        self.__handle = LocationServerNetPackHandle()
        self.__caseType = {
            CaseType.FAMILY_SET:self.__handle.Do_SetLocationGeography,
            CaseType.FAMILY_GET:self.__handle.Do_GetLocationGeography,
            CaseType.KIN_SET:self.__handle.Do_SetKinLocationGeography,
            CaseType.KIN_GET:self.__handle.Do_GetKinLocationGeography,
            }
        
    
    def Run(self, server, runType, illegal=False):
        self.__handle.ConnectLocationServer(server)
        if not asyncresult_manager.wait(self.__handle, "ConnectLocationServer", 60):
            self.__handle.Uninit()
            return
        
        try:
            while True: 
                start_time = time.time()
                for i in range(500):
                    self.__caseType[runType](illegal)
#                     self.__handle.Do_SetKinLocationGeography()
                end_time = time.time() - start_time
                if end_time<1:
                    gevent.sleep(1-end_time)
        except Exception:
            print traceback.format_exc()
        finally:
            self.__handle.Uninit()