# coding:utf8
__author__ = 'kingsoft'
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
import math

'''
      在线商城的TestCase
'''


class TestCase():
    def __init__(self, family):
        self.family = family
        '''
            data/sheet/pay/cnyproduct.txt
        '''
        self.giftPackages = [
                                "jxsj2.meiri.rmb1",
                                "jxsj2.meiri.rmb3",
                                "jxsj2.meiri.rmb6",
#                                "jxsj2.meiri.rmb18",
#                                "jxsj2.meiri.rmb30",
#                                "jxsj2.meiri.rmb88",
#                                "jxsj2.meiri.rmb168",
#                                "jxsj2.meiri.rmb288",
#                                "jxsj2.zhoumo.rmb30",
#                                "jxsj2.zhoumo.rmb128",
#                                "jxsj2.zhoumo.rmb328",
#                                "jxsj2.baoshi.rmb30",
#                                "jxsj2.qianghua.rmb30",
#                                "jxsj2.xiulian.rmb30",
#                                "jxsj2.baoshi.rmb168",
#                                "jxsj2.qianghua.rmb168",
#                                "jxsj2.xiulian.rmb168",
#                                "jxsj2.jieri.rmb12",
#                                "jxsj2.jieri.rmb30",
#                                "jxsj2.jieri.rmb128",
#                                "jxsj2.jieri.rmb328",
#                                "jxsj2.jieri.rmb648",
                             ]

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_SHOP_ONLINE_GOLD_CHARGE_WAIT)  # 跳转到GM内部模拟充值等待状态
                #清除在线商城购买次数
                self.family.gameServerNetPackHandle.CleanShopOnlineBuyLimit()
                #清空背包
                self.family.gameServerNetPackHandle.ClearItemRoom()
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.GetEnoughMoney(VALUE_COIN_SILVER, 10000)
                if VALUE_COIN_GOLD not in self.family.valueCoin or self.family.valueCoin[VALUE_COIN_GOLD] < 6000:
                    logging.debug('GM内部模拟充值元宝')
                    self.family.gameServerNetPackHandle.SetGoldNumber()  # GM内部模拟充值
                else:
                    self.family.SetState(STATE_GS_SHOP_ONLINE_GOLD_CHARGE_RESULT)
                break

            if case(STATE_GS_SHOP_ONLINE_GOLD_CHARGE_RESULT):
                self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_GIFT_PACKAGE_WAIT)  # 跳转到GM内部模拟购买超值礼包等待状态
                logging.debug('GM内部模拟购买超值礼包')
                self.family.gameServerNetPackHandle.SetGoldNumber(random.choice(self.giftPackages))  # GM内部模拟购买超值礼包
                break

            if case(STATE_GS_SHOP_ONLINE_BUY_GIFT_PACKAGE_RESULT):   #GM内部模拟购买超值礼包结果
                self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_VIP_WAIT)  # 跳转到在线商城购买VIP等待状态
                logging.debug('在线商城购买VIP')
                shopId = 24
                goodIndex = random.randint(0, 1)
                self.family.gameServerNetPackHandle.ApplyBuyOnlineShopItem(shopId, goodIndex)
                break

            if case(STATE_GS_SHOP_ONLINE_BUY_VIP_RESULT):  # 在线商城购买VIP结果
                self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_GOLD_SHOP_WAIT)  # 跳转到在线商城购买鎏金宝阁等待状态
                logging.debug('在线商城购买鎏金宝阁商品')
                gevent.sleep(5)
                shopId = GoldShop
                goods = self.GetRandomShopGoods(shopId)
                for goodIndex in goods:
                    self.family.gameServerNetPackHandle.ApplyBuyOnlineShopItem(shopId, goodIndex)
                    gevent.sleep(1)
                break

            if case(STATE_GS_SHOP_ONLINE_BUY_GOLD_SHOP_RESULT):  # 在线商城购买鎏金宝阁商品结果
                self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_SILVER_SHOP_WAIT)  # 跳转到在线商城购买雪银宝阁商品等待状态
                logging.debug('在线商城购买雪银宝阁商品')
                shopId = SilverShop
                goods = self.GetRandomShopGoods(shopId)
                for goodIndex in goods:
                    self.family.gameServerNetPackHandle.ApplyBuyOnlineShopItem(shopId, goodIndex)
                    gevent.sleep(1)
                break

            if case(STATE_GS_SHOP_ONLINE_BUY_SILVER_SHOP_RESULT):  # 在线商城购买雪银宝阁商品结果
                self.family.SetState(STATE_GS_SHOP_ONLINE_CHANGE_NAME_WAIT)
#                 self.family.gameServerNetPackHandle.MarkTestCase("TestCase_ShopOnline_BuyPopular")
                gevent.sleep(1.5)
                self.family.gameServerNetPackHandle.ClientChangeRoleNameReq(generate_chinese(6))#修改名字
                break
            
            if case(STATE_GS_SHOP_ONLINE_CHANGE_NAME):#修改名字结果
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_ShopOnline_ChangeName")
                self.family.SetState(STATE_GS_END)
                break
            
            if case(STATE_GS_END):
                logging.debug("在线商城案例结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_ShopOnline_Finish")
                self.family.behavior = Behavior.END
                break
    
    #获取商店随机商品
    def GetRandomShopGoods(self, shopId):
        goods = SHOP_GOODS[shopId]
        randomLen = int(math.ceil(len(goods)/2.0))
        goods = random.sample(goods, randomLen)
        logging.debug("goods = %s" % goods)
        return goods
        