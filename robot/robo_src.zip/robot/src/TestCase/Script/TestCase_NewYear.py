# coding=utf-8
import gevent
import logging
import time
import random
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase.Files.NewYear import NewYear
from net.Common.ComDefine_pb2 import *
'''
      春节的TestCase
'''

class TestCase(object):
    NEWYEAR_PUT = 0 #发红包
    NEWYEAR_GET = 1 #收红包
    MAXREDNUMBER = 10 #最多收多少红包下线
    
    def __init__(self, family):
        self.family = family
        GameTypes = {
                     TestCase.NEWYEAR_PUT : 1,
                     TestCase.NEWYEAR_GET : 99,
                     }
        self.gameType = Rand.weighted_choice(GameTypes)#根据权重分配游戏类型
#        self.gameType =  TestCase.NEWYEAR_GET#锁定游戏类型
        self.list = ["5_3_91_1", "5_3_91_2", "5_3_92_1", "5_3_92_2"]
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_REDPACK_HISTORY_WAIT)
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:GainTitle(78)")
                self.family.gameServerNetPackHandle.QueryRedPacketHistoryReq()
                break
            
            elif case(STATE_GS_REDPACK_HISTORY_FINISHED):
                if self.gameType == TestCase.NEWYEAR_PUT:
                    type = self.family.newyear.gdpl[random.randint(1, 4)]
                    self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 3, type[0], type[1], 1, False, 0)
                    self.family.SetState(STATE_GS_ACTIVITY_NEWYEAR_PICK)
                elif self.gameType == TestCase.NEWYEAR_GET:
                    self.family.SetState(STATE_GS_ACTIVITY_NEWYEAR_REDPACKET_WAIT)
                break
            
            elif case(STATE_GS_ACTIVITY_NEWYEAR_PICK):
                self.family.SetState(STATE_GS_ACTIVITY_NEWYEAR_WAIT)
                while self.family.newyear.redpacketId == None:
                    for i in range(len(self.list)):
                        if self.list[i] in self.family.bag.consumeBag:
                            self.family.newyear.redpacketId = self.family.bag.consumeBag[self.list[i]][True].keys()[0]
                            continue
                    gevent.sleep(3)
                self.family.gameServerNetPackHandle.Do_UseItem(self.family.newyear.redpacketId)
                self.family.newyear.redpacketId = None
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Activity_NewYear_PutRedPacket")
                break
            
            elif case(STATE_GS_ACTIVITY_NEWYEAR_PICKED):
                if self.gameType == TestCase.NEWYEAR_PUT:
                    self.family.SetState(STATE_GS_ACTIVITY_NEWYEAR_BEGIN)
                break
            