 #!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase_TeamBase import *
'''
      护法的TestCase
'''

class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_GUARDIAN, u"护法")
#         super(TestCase, self).__init__(family, TEAM_TYPE_GUARDIAN, TEAM_TYPE_GUARDIAN, u"护法")
        self.family = family
        self.canRun = True
        
        self.guardian_dict = {
                              TIANWANG : [TangRuLevel, TangRuID, SceneTangMen],#唐芸、
                              TANGMEN : [KeXinLevel, KeXinID, SceneWuDang],#可心
                              EMEI : [RongTuLevel, RongTuID, SceneTianRen],#荣屠
                              TIANREN : [JiBanShuLevel, JiBanShuID, SceneTianWang],#季叔班
                              WUDANG : [ChouXueLevel, ChouXueID, SceneEMei],#仇雪
                              }
        
        self.firstgurdianinfor = {
                              TangRuID :  SceneTangMen,#唐芸
                              KeXinID : SceneWuDang,#可心
                              RongTuID : SceneTianRen,#荣屠
                              JiBanShuID : SceneTianWang,#季叔班
                              ChouXueID : SceneEMei,#仇雪
                              }
        
        self.guardianjingyan={
                                1: [1, 5,  9, 13, 17, 1300],#资质为1 的护法ID以及所对应的友好度
                                2: [2, 6, 10, 14, 18, 5000],#资质为2 的护法ID以及所对应的友好度
                                3: [3, 7, 11, 15, 19, 12000],#资质为3 的护法ID以及所对应的友好度
                                4: [4, 8, 12, 16, 20, 24000],#资质为4 的护法ID以及所对应的友好度
                                5: [21,22,23,24,25,26,27,28,29,30,35000],#资质为5 的护法ID以及所对应的友好度
                              }
        
        self.guardianxinwu={                                             #护法ID:[信物p值，护法所在场景ID]
                            3:[1, 1403], 4:[2, 1404], 1:[3,1401], 2:[4,1402], 7:[5, 1423], 
                            6:[6, 1422], 5:[7, 1421], 8:[8,1424],11:[9,1443],12:[10,1444],
                            10:[11,1442], 9:[12,1441],16:[13,1464],13:[14,1461],15:[15,1463], 
                            14:[16,1462],20:[17,1484],19:[18,1483],17:[19,1481],18:[20,1482],
#                             21:21, 22:22, 23:23,24:24, 25:25, 26:26, 27:27, 28:28, 29:29, 30:30
                            }
        
        self.unRecruit = [
                          4,    # 龙五公子
                          8,    # 轻舟老人
                          22,   # 叶芷琳
                          12,   # 独孤剑
                          16,   # 纳兰潜凛
                          26,   # 秦始皇
                          27,   # 白灵儿
                          28,   # 吉安
                          29,   # 太史丹
                          30    # 仇尸
                        ]
        
        self.dharma_kexin = 17      # 可心护法id
        self.occupation = self.family.GetCurCharacter().faction
        self.firstInstanceId = self.guardian_dict[self.occupation][0]
        self.firstGuardianId = self.guardian_dict[self.occupation][1]
        self.firstSceneId = self.guardian_dict[self.occupation][2]
        self.flagother = True
        self.target = "第一护法"
#         TeamMemberType.LEADER
        self.member_type = 1
        self.leaveFlag = 0
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
#        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_WAIT)

                if self.family.isNewRole:
                    self.family.gameServerNetPackHandle.BecomeStronger()#获取高级装备,达到挑战护法战力
                else:
                    self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:SetDataInt(103,1000,0);")
                self.family.SetState(STATE_GC_TEAM_CREATE)
                break


            elif case(STATE_GC_TEAM_CREATE):
                if self.family.team_manager.myteam.IsInTeam():
                    self.family.SetState(STATE_GC_TEAM_CREATE_FINISHED)
                else:
                    self.family.SetState(STATE_GC_TEAM_CREATE_WAIT)
                    self.family.team_manager.myteam.isBegin = True
                    self.family.gameServerNetPackHandle.TeamCreateReq()
                break

            elif case(STATE_GC_TEAM_CREATE_FINISHED):
                self.family.SetState(STATE_GS_WAIT)
                if self.canRun:
                    #挑战第一护法
                    logging.debug("self.firstInstanceId = %s, self.firstSceneId = %s" % (self.firstInstanceId, self.firstSceneId))
                    self.family.guardian.targetSceneId = self.firstSceneId
                    self.family.gameServerNetPackHandle.Transfer2Map(self.firstSceneId)
                    self.family.SetState(STATE_GS_GUARDIAN_TRANSFER)
                    gevent.sleep(3)
                
                        
            elif case(STATE_GS_GUARDIAN_START_MISSION):#挑战护法 
                self.family.SetState(STATE_GS_WAIT)
                if self.target == "第一护法":
                    self.family.gameServerNetPackHandle.Do_StartSingleMission(self.firstInstanceId)
                    gevent.sleep(5)#
                    #结算第一护法
                    self.family.gameServerNetPackHandle.Do_EndSingleMission(self.firstInstanceId)
                    #回到主场景
                    self.family.gameServerNetPackHandle.LeaveSingleMission()
                    #招募第一护法
                    if self.family.isNewRole:
                        self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 2, 19, 1, 5, False, 0)#添加可心信物
                        for i in range(3):
                            self.family.gameServerNetPackHandle.VisitGuardian(self.dharma_kexin)#通卡拜访
                        self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 2, self.guardianxinwu[self.firstGuardianId][0], 1, 5, False, 0)#添加可心信物
#                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Get_KeXin_Finish")
                        for i in range(3):
                            self.family.gameServerNetPackHandle.VisitGuardian(self.firstGuardianId)#通卡拜访
#                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Recruit_FirstGuardian_Finish")
                    else:
                        self.family.SetState(STATE_GS_GUARDIAN_ACTIVE)#护法拜访         
                elif self.target == "其他护法":
                    guarbian_template_id = self.guardianxinwu[self.guardianotherid][1]
                    self.family.gameServerNetPackHandle.Do_StartSingleMission(guarbian_template_id)
                    gevent.sleep(5)#
                    if self.guardianotherid in self.firstgurdianinfor.keys():
                        self.family.gameServerNetPackHandle.Do_EndSingleMission(guarbian_template_id)
                    else:
                        self.family.gameServerNetPackHandle.Do_EndSingleMission(guarbian_template_id, 20)
                    #回到主场景
                    self.family.gameServerNetPackHandle.LeaveSingleMission()
                    gevent.sleep(3)
                    self.family.SetState(STATE_GS_GUARDIAN_VISIT)#护法拜访
                else:
                    logging.debug("can't find target : %s" % self.target)
                    self.family.SetState(STATE_GS_GUARDIAN_END)
                break
                    
            elif case(STATE_GS_GUARDIAN_ACTIVE):#激活第一护法
                if self.flagother:
                    self.family.SetState(STATE_GS_WAIT)
                    self.family.gameServerNetPackHandle.ActiveGuardian(self.firstGuardianId, True)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Active_FirstGuardian_Finish")
                    self.family.SetState(STATE_GS_GUARDIAN_SECOND_TRANSFER)
                else:
                    self.family.SetState(STATE_GS_GUARDIAN_END)
                break
            
            elif case(STATE_GS_GUARDIAN_VISIT):#拜访第二护法
                self.family.SetState(STATE_GS_WAIT)
                logging.debug("拜访其他护法")
                Xinwuid = self.guardianxinwu[self.guardianotherid][0]       
                self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 2, int(Xinwuid), 1, 5, False, 0)
                gevent.sleep(3)
                for i in range(3):
                    self.family.gameServerNetPackHandle.VisitGuardian(self.guardianotherid)#通卡拜访
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Visit_OtherGuardian_Finish")
                self.family.SetState(STATE_GS_GUARDIAN_INACTIVE)
                self.flagother = True
                break
            
#             elif case(STATE_GS_GUARDIAN_SECOND_VISIT):#拜访后十个护法（新增）
#                 self.family.SetState(STATE_GS_WAIT)
#                 logging.debug("拜访后十护法")
#                 holeIndex = random.randint(21, 30)
#                 self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 2,holeIndex, 1, 5, False, 0)
#                 gevent.sleep(5)
#                 self.family.gameServerNetPackHandle.VisitGuardian(holeIndex)#通卡拜访
#                 break
            
            #下阵第一护法
            elif case(STATE_GS_GUARDIAN_INACTIVE):
                self.family.SetState(STATE_GS_WAIT)
                if self.flagother == False:
                    self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 1, 49, 1, 5, False, 0)#添加护法小经验丹
                    gevent.sleep(5)
                    self.family.gameServerNetPackHandle.ApplyGuardianUseExpItem(self.firstGuardianId)#护法使用经验丹
                    gevent.sleep(2)
                    self.family.gameServerNetPackHandle.CallScriptAddStackItem(5, 1, 50, 1, 5, False, 0)#添加护法洗髓丹
                    gevent.sleep(2)
                    self.family.gameServerNetPackHandle.ApplyGuardianResetAptitude(self.firstGuardianId)#护法使用洗髓丹
                    self.family.gameServerNetPackHandle.ApplySelectLastAptitude(self.firstGuardianId)#护法应用当前洗髓值
                    logging.debug("下阵第一护法")
                    self.family.gameServerNetPackHandle.ActiveGuardian(self.firstGuardianId, False)
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Replace_FirstGuardian_Finish")
                    self.leaveFlag += 1
                    break
                else:
                    self.family.SetState(STATE_GS_GUARDIAN_END)
                    break
            
            elif case(STATE_GS_GUARDIAN_SECOND_TRANSFER):
                self.flagother = False 
                isTureNum = True
                guardianlen = int(len(self.family.gameServerNetPackHandle.guardiansecondlist)-1)
                if self.family.isNewRole == False:
                    if guardianlen == 0:
                        isTureNum = False
                        self.guardianotherid = 0
                    while isTureNum:
                        guardianotherkey=random.randint(0, guardianlen)
                        self.guardianotherid=self.family.gameServerNetPackHandle.guardiansecondlist[guardianotherkey].guardianId
                        if self.guardianotherid not in self.unRecruit and self.guardianotherid <21:
                            isTureNum = False
                    #所有护法都以招募
                    if self.guardianotherid == 0:
                        self.family.SetState(STATE_GS_GUARDIAN_END)
                    for i in range(int( len(self.family.gameServerNetPackHandle.guardiansecondlist))):
                        list=self.guardianjingyan.get(self.guardianjingyan.keys()[i])
                        if int(self.guardianotherid) in list:
                            if self.family.gameServerNetPackHandle.guardiansecondlist[guardianotherkey].visitTimes == list[len(list)-1]:
                                self.family.SetState(STATE_GS_GUARDIAN_VISIT_OTHER)#招募护法
                                break
                            else:
                                self.family.SetState(STATE_GS_GUARDIAN_ACTIVE_OTHER)#拜访护法
                                break
                            
                else:
                     self.family.SetState(STATE_GS_GUARDIAN_INACTIVE)
                     break
                 
            elif case(STATE_GS_GUARDIAN_VISIT_OTHER):
                self.family.SetState(STATE_GS_WAIT)
                self.family.gameServerNetPackHandle.RecruitGuardian(self.guardianotherid)
                self.family.SetState(STATE_GS_GUARDIAN_END)
                break
            
            elif case(STATE_GS_GUARDIAN_ACTIVE_OTHER):#拜访
                self.family.SetState(STATE_GS_WAIT)
                self.family.gameServerNetPackHandle.CallScript("ApplyCurrGuardRefreshData")#刷新护法位置
                gevent.sleep(2)
                if self.guardianotherid in self.firstgurdianinfor.keys():
                    sceneId = self.firstgurdianinfor[self.guardianotherid]
                else:  
                    sceneId = self.guardianxinwu[self.guardianotherid][1]
                if sceneId:
                    self.target = "其他护法"
                    self.guardianotherid = 10
                    if str(self.guardianotherid) in self.family.guardian.guardianDict.keys():
                        self.family.SetState(STATE_GS_GUARDIAN_TRANSFER)
                        sceneId = self.family.guardian.guardianDict[str(self.guardianotherid)][0]
                        self.family.guardian.targetSceneId = sceneId
                        self.family.gameServerNetPackHandle.Transfer2Map(sceneId)
                    else:
                        self.family.SetState(STATE_GS_GUARDIAN_VISIT)
                    logging.debug("其他护法 sceneId = %s ; guardianId = %s" % (sceneId, self.guardianotherid))
                else:
                    logging.debug("guardian sceneId not in dict : %s" % sceneId)
                    gevent.sleep(5)
                break
            
            elif case(STATE_GS_GUARDIAN_END):
                logging.debug('结束')
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Guardian_Finish")
                self.family.behavior = Behavior.END
                break










