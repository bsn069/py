#coding=utf-8

import random
import gevent
import asyncore
import logging
import sys
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *

"""
         好友系统的TestCase
"""

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family

    def _random_familyid(self):
        return random.choice([self.family.familyId, 0, random.randint(1, sys.maxint)])

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        # 删除部分好友
        self.family.gameServerNetPackHandle.Do_RemoveFriend(self._random_familyid())
        # 搜索玩家
        self.family.gameServerNetPackHandle.Do_SearchFamilyReq("")
        # 添加玩家
        self.family.gameServerNetPackHandle.Do_ApplyAddFriend(self._random_familyid())
        # 同意好友请求
        self.family.gameServerNetPackHandle.Do_AgreeAddFriend(self._random_familyid())
        # 拒绝好友请求
        self.family.gameServerNetPackHandle.Do_RefuseAddFriend(self._random_familyid())

        gevent.sleep(5)
