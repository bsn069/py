# coding:utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from gevent.hub import sleep

'''
      助战的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.canEnterMission = True
        
        self.hasAssistRequest = False

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):
            #完成至战虎任务
            if case(STATE_GS_PLAYING):
                if self.canEnterMission:
                    self.canEnterMission = False
                    self.family.SetState(STATE_GS_ASSIST_WAIT)
                    while self.family.maintaskMan._Maintask__taskId!=10001:
                        self.family.gameServerNetPackHandle.CallScript("GMCmd", "DoCommand", "me:FinishMainTaskToId(0);")
                        self.family.gameServerNetPackHandle.Do_AcceptTask(10001)
                        gevent.sleep(7)#
                    self.family.gameServerNetPackHandle.GM_FinishMainTaskToId(Task_ZhanHu)
                    gevent.sleep(1)
                    self.family.SetState(STATE_GS_MOVE_GO)
                    break
                else:
                    self.family.SetState(STATE_GS_END)#从战虎副本退出，再次进入主场景后结束
                    break

            #走到长途车夫-马三
            if case(STATE_GS_MOVE_GO):
                logging.debug("走到长途车夫-马三")
#                 self.family.gameServerNetPackHandle.PlayerAutoPath(211.44, 144.82)
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True,  252.04, 205.13) 
                break
            
            #到达地点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_ASSIST_WAIT)
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.AskNpc("马三")#对话
                self.family.SetState(STATE_GS_ASSIST_ENTERMISSION)
                break
            
            #进入副本-请求助战
            if case(STATE_GS_ASSIST_ENTERMISSION):
                logging.debug("进入副本")
                self.family.SetState(STATE_GS_ASSIST_ASSISTREQUEST_WAIT)
                self.family.gameServerNetPackHandle.Do_StartSingleMission(1013)#战虎
                gevent.sleep(3)
                def timer():
                    while self.family and not self.hasAssistRequest: #已改为服务器不检查cd，可重复发起
                        logging.debug("请求助战")
                        self.family.gameServerNetPackHandle.SendApplyAssist()#请求助战
                        gevent.sleep(10)
                gevent.spawn(timer)
                break
            
            #得到助战-返回主场景
            if case(STATE_GS_ASSIST_ASSISTREQUEST_SUCCESS):
                self.family.SetState(STATE_GS_ASSIST_WAIT)
                logging.debug("得到助战-返回主场景")
                self.family.gameServerNetPackHandle.Do_EndSingleMission(1013)#结束战虎
                self.family.gameServerNetPackHandle.LeaveSingleMission()#返回到主场景
                break
            
            if case(STATE_GS_END):
                logging.debug("助战案例结束")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Assist_Finish")
                self.family.behavior = Behavior.END
                break