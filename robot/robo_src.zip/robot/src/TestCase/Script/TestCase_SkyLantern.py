#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.JxLog import *
from CaConfig.CaseDefinemport *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from RoConfig.RoleFiguresmport *
from TestCase_TeamBase import TeamBaseCase

'''
    活动-孔明灯的TestCase
'''


class TestCase(TeamBaseCase):
    HOPE_NPC_SITE = (201, 253)
    FRIENDSHIP_NPC_SITE = (122, 175)
    HOPE = 1
    FRIENDSHIP = 2
    LET_LANTERN_SITE = (221, 226)


    #sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_SKYLANTERN, u"孔明灯")
        self.family = family
        # self.way = random.choice([TestCase.HOPE, TestCase.FRIENDSHIP])
        self.way = TestCase.HOPE    # 现在只有希望之灯
        self.isLetLantern = 0
        self.isTeamLeader = random.randint(0, 1)

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            if case(STATE_GS_MOVE_GO):
                self.family.SetState(STATE_GS_SKYLANTERN_WAIT)
                if not self.isLetLantern:
                    if self.way == TestCase.HOPE:
#                         self.family.gameServerNetPackHandle.PlayerAutoPath(*TestCase.HOPE_NPC_SITE)
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *TestCase.HOPE_NPC_SITE)
                    elif self.way == TestCase.FRIENDSHIP:
#                         self.family.gameServerNetPackHandle.PlayerAutoPath(*TestCase.FRIENDSHIP_NPC_SITE)
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *TestCase.FRIENDSHIP_NPC_SITE)
                    else:
                        raise 'sky lantern way error'
                else:
#                     self.family.gameServerNetPackHandle.PlayerAutoPath(*TestCase.LET_LANTERN_SITE)
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *TestCase.LET_LANTERN_SITE)
                break

            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_SKYLANTERN_WAIT)
                if not self.isLetLantern:
                    gevent.sleep(3)
                    if self.way == TestCase.HOPE:
                        self.family.gameServerNetPackHandle.AskNpc("希子")
                    elif self.way == TestCase.FRIENDSHIP:
                        self.family.gameServerNetPackHandle.AskNpc("缘缘")
                else:
                    self.family.SetState(STATE_GS_SKYLANTERN_TEAM)
                break

            #领取孔明灯
            if case(STATE_GS_SKYLANTERN_GET_LANTERN):
                self.family.SetState(STATE_GS_SKYLANTERN_WAIT)
                logging.debug("领取孔明灯")
                self.family.gameServerNetPackHandle.GetLantern()
                break

            if case(STATE_GS_SKYLANTERN_GET_LANTERN_SUCCEED):
                self.isLetLantern = 1
                self.family.SetState(STATE_GS_MOVE_GO)
                break

            if case(STATE_GS_SKYLANTERN_TEAM):
                self.family.SetState(STATE_GC_TEAM_BEGIN)
                break

            #使用孔明灯
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GS_SKYLANTERN_WAIT)
                logging.debug("使用孔明灯")
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    self.family.gameServerNetPackHandle.UseLantern()
                break

            #响应队长使用孔明灯
            if case(STATE_GS_SKYLANTERN_PUT_LANTERN):
                logging.debug("响应队长使用孔明灯")
                self.family.SetState(STATE_GS_SKYLANTERN_WAIT)
                self.family.gameServerNetPackHandle.LanternReply()
                break

            if case(STATE_GS_SKYLANTERN_PUT_LANTERN_SUCCEED):
                logging.debug("孔明灯案例结束")
                self.family.behavior = Behavior.END
                break