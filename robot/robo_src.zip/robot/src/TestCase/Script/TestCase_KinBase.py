# coding:utf-8
import gevent
import random
import logging
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase.Files.Kin import Kin
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.GenerateChinese import generate_chinese

class KinMemberType(object):
    LEADER = 0
    MEMBER = 1

class KinCreateType(object):
    COMMON = 0
    DISTRIBUTE = 1

class KinBaseCase(object):
    
    KIN_RECRUIT_NUM = 40 #家族招募人数
    
    def __init__(self, family, memberType, createType=KinCreateType.COMMON):
        self.family = family
        self.kinMemberType = memberType
        self.createType = createType
        
    
    def _Action(self):
        if self.family.state == STATE_GS_KIN_BEGIN:
            if self.family.kinMan.id:#如果在家族中需要先离开家族
                self.family.kinMan.needLeaveKin = True
                if self.family.kinMan.isLeader:
                    self.family.SetState(STATE_GS_KIN_DISMISS)
                else:
                    self.family.SetState(STATE_GS_KIN_QUIT)
            else:
                self.family.SetState(STATE_GS_KIN_LIST)
            
        elif self.family.state == STATE_GS_KIN_LIST:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.Do_GetKinList()

            
        elif self.family.state == STATE_GS_KIN_LIST_RESULT:
            self.family.SetState(STATE_GS_KIN_WAIT)
            if self.kinMemberType == KinMemberType.LEADER:
                self.family.SetState(STATE_GS_CREATE_KIN)
            elif self.kinMemberType == KinMemberType.MEMBER:
                self.family.SetState(STATE_GS_KIN_LOOKUP)
        
        # 查找家族
        elif self.family.state == STATE_GS_KIN_LOOKUP:
            self.family.SetState(STATE_GS_KIN_WAIT)
            kin_list = self.family.kinMan.GetKinList()
            if len(kin_list):
                name = kin_list[random.randint(0, len(kin_list) - 1)].name
            else:
                name = generate_chinese(random.randint(1, 5))
            self.family.gameServerNetPackHandle.Do_ApplyLookUpKin(name)
        
        # 加入家族
        elif self.family.state == STATE_GS_KIN_APPLY_JOIN:
            if self.family.kinMan.inviteMsgDict:
                kin_id = self.family.kinMan.inviteMsgDict["id"]
                self.family.SetState(STATE_GS_KIN_WAIT_APPROVE)
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("KGameSwitch.SetDebug(2,False);")#清除家族退出CD
                self.family.gameServerNetPackHandle.Do_ApplyJoinKin(kin_id)
                def resetState():
                    gevent.sleep(15)
                    if self.family.GetState() == STATE_GS_KIN_WAIT_APPROVE:
                        self.family.SetState(STATE_GS_KIN_APPLY_JOIN_WAIT)
                gevent.spawn(resetState)
            else:
                self.family.SetState(STATE_GS_KIN_LIST)
        
        # 创建家族
        elif self.family.GetState() == STATE_GS_CREATE_KIN:
            self.family.SetState(STATE_GS_KIN_WAIT)
            name = generate_chinese(5)
            self.family.gameServerNetPackHandle.CallScriptGmDoCommand("KGameSwitch.SetDebug(2,False);")#清除家族退出CD
            self.family.gameServerNetPackHandle.Do_CreateKin(name)
            self.family.kinMan.SetLeader()
            self.family.kinMan.name = name
        
        # 升级家族/开启周末关卡
        elif self.family.GetState() == STATE_GS_KIN_UPGRADE:
            logging.debug('升级家族/开启周末关卡')
            self.family.gameServerNetPackHandle.GM_AddKinBuildPoint()  # 增加资产
            gevent.sleep(5)
            self.family.gameServerNetPackHandle.Do_KinUpgrade() # 家族升级
            gevent.sleep(5)
            if self.family.kinMan.gameType == KinFeastGame:
                logging.debug("GM开启家族盛宴")
                self.family.gameServerNetPackHandle.GM_OpenFeast()#GM开启家族盛宴
            elif self.family.kinMan.gameType == KinWarGame:
                logging.debug("家族争夺暂不由族长开启")
            elif self.family.kinMan.gameType == KinWarRank:
                logging.debug("填充家族争夺排行榜数据")
                self.family.gameServerNetPackHandle.AddKinWarRankMonthScore(2000)
                gevent.sleep(5)
                self.family.behavior = Behavior.END
                return
            else:
                logging.debug("[Leader] can't find this kinGameType : %s" % self.family.kinMan.gameType)
            self.family.SetState(STATE_GS_KIN_APPLY_SETTING)
        
        # 招募设定
        elif self.family.GetState() == STATE_GS_KIN_APPLY_SETTING:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.Do_KinApplySetting(needApprove=True, applyNotice=generate_chinese(random.randint(1, 5)))
        
        # 设置公告
        elif self.family.GetState() == STATE_GS_KIN_SET_NOTICE:
            self.family.SetState(STATE_GS_KIN_WAIT)
            notice = generate_chinese(7)
            self.family.gameServerNetPackHandle.Do_KinSetNotice(notice)
            logging.debug('设置公告')
        
        # 招募
        elif self.family.GetState() == STATE_GS_KIN_RECRUIT:
            # 如果家族少于KIN_MIN_NUM，就继续招募
            if not self.family.kinMan.isMemberEnough(KinBaseCase.KIN_RECRUIT_NUM):
                if self.createType == KinCreateType.COMMON:
                    msg = u"Robot:Kin:%d:%s:%d" % (self.family.kinMan.id, self.family.kinMan.name, self.family.kinMan.gameType)
                else:
                    assert self.family.kinMan.distKinId != 0
                    msg = u"Robot:Kin:%d:%d:%s:%d" % (self.family.kinMan.distKinId, self.family.kinMan.id, self.family.kinMan.name, self.family.kinMan.gameType)
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg=msg, channel=emChatChannelInvite)
                gevent.sleep(10)
                while self.family.kinMan.applyerList and not self.family.kinMan.isMemberEnough(KinBaseCase.KIN_RECRUIT_NUM):
                    applyIdList = self.family.kinMan.GetApplyerList(KinBaseCase.KIN_RECRUIT_NUM)
                    logging.debug("Do_ApplyKinApprove applyIdList=%s" % str(applyIdList))
                    for familyId in applyIdList:
                        self.family.gameServerNetPackHandle.Do_ApplyKinApprove(familyId, True)
                        gevent.sleep(2)
                        if self.family.kinMan.isMemberEnough(KinBaseCase.KIN_RECRUIT_NUM):
                            break
                    gevent.sleep(2)
            else:
                self.family.SetState(STATE_GS_KIN_SIGN)
                
        # 家族签到/许愿
        elif self.family.GetState() == STATE_GS_KIN_SIGN:
            self.family.SetState(STATE_GS_KIN_WAIT)
            logging.debug('家族签到/许愿')
            self.family.gameServerNetPackHandle.Do_KinBuyPray(random.randint(1, 20))
            self.family.SetState(STATE_GS_KIN_SHOP)

#        # 家族商店
        elif self.family.GetState() == STATE_GS_KIN_SHOP:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(shopId=KinShop, goodIndex=random.choice(SHOP_GOODS[KinShop]))

        # 购买成功
        elif self.family.GetState() == STATE_GS_SHOP_RESULT:
            self.family.SetState(STATE_GS_KIN_SKILL_USE)  # 家族使用技能

        # 家族技能使用
        elif self.family.GetState() == STATE_GS_KIN_SKILL_USE:
            self.family.SetState(STATE_GS_KIN_WAIT)
            logging.debug('家族技能使用')
            self.family.gameServerNetPackHandle.GM_AddKinBuildPoint()  # 增加资产
            gevent.sleep(2)
            self.family.gameServerNetPackHandle.Do_KinSkillUse()
        
        # 家族技能升级
        elif self.family.GetState() == STATE_GS_KIN_SKILL_UPGRADE:
            self.family.SetState(STATE_GS_KIN_WAIT)
            logging.debug('家族技能升级')
            self.family.gameServerNetPackHandle.Do_KinSkillUpgrade()
        
        # 家族加好友
        elif self.family.GetState() == STATE_GS_KIN_ADD_FIREND:
            self.family.SetState(STATE_GS_KIN_WAIT_ADD_FIREND)
            logging.debug('家族加好友')
            kin_member_familyid = self.family.kinMan.GetKinMember().keys()
#             if self.family.kinMan.gameType:#选用族长的游戏类型
#                 self.gameType = self.family.kinMan.gameType
            if len(kin_member_familyid) != 1:#如果家族人数>1
                kin_member_familyid.remove(self.family.familyId)
                logging.debug(kin_member_familyid)
#                 add_familyid = kin_member_familyid[len(kin_member_familyid)-1]
#                 # add_familyid = 100052 #--加固定的好友--#
#                 self.family.gameServerNetPackHandle.Do_ApplyAddFriend(add_familyid)
                for add_familyid in kin_member_familyid:
                    self.family.gameServerNetPackHandle.Do_ApplyAddFriend(add_familyid)
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Kin_RecruitFinish")
            self.family.SetState(STATE_GS_KIN_RECRUIT_FINISH)
        
        elif self.family.GetState() == STATE_GS_KIN_LEAVE:
            if self.kinMemberType == KinMemberType.LEADER:
                logging.debug('准备升级副组长后解散家族')
                self.family.SetState(STATE_GS_KIN_POST_VICE_LEADER)
            else:
                logging.debug('准备离开家族')
                self.family.SetState(STATE_GS_KIN_QUIT)
                
        # 升副族长
        elif self.family.GetState() == STATE_GS_KIN_POST_VICE_LEADER:
#             gevent.sleep(10)  # 等待其他人加入
            kin_member = self.family.kinMan.GetKinMember()
            logging.debug('升副组长%s,人数%s' % (kin_member, len(kin_member)))
            if len(kin_member) == 1:  # 没有其他人
                self.family.SetState(STATE_GS_KIN_DISMISS)
            else:
                for member in kin_member:
                    if kin_member[member].post == KinCommon:
                        self.family.SetState(STATE_GS_KIN_POST_VICE_LEADER_WAIT)
                        self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(kin_member[member].familyId, KinDeputyLeader)
                        return
                self.family.SetState(STATE_GS_KIN_POST_COMMON)
        
        # 撤除副族长
        elif self.family.GetState() == STATE_GS_KIN_POST_COMMON:
            self.family.SetState(STATE_GS_KIN_WAIT)
            gevent.sleep(5)
            kin_member = self.family.kinMan.GetKinMember()
            for member in kin_member:
                if kin_member[member].post == KinDeputyLeader:
                    self.family.gameServerNetPackHandle.Do_ApplyKinSetPost(kin_member[member].familyId, KinCommon)
                    return
            self.family.SetState(STATE_GS_KIN_DISMISS)
        
        # 解散家族
        elif self.family.GetState() == STATE_GS_KIN_DISMISS:
            logging.debug('解散家族')
            self.family.SetState(STATE_GS_KIN_WAIT)
            # gevent.sleep(20)#做完其他项后，在家族中停留时间
            kin_member = self.family.kinMan.GetKinMember()
            if len(kin_member) > 1:
                for member in kin_member:
                    if kin_member[member].post != 1:
                        self.family.gameServerNetPackHandle.Do_ApplyKinKick(kin_member[member].familyId)  # 踢全部人
                        return
            self.family.gameServerNetPackHandle.Do_ApplyDismissKin()
        
        # 退出家族
        elif self.family.GetState() == STATE_GS_KIN_QUIT:
            self.family.SetState(STATE_GS_KIN_WAIT)
            self.family.gameServerNetPackHandle.ApplyRankingRank(RANK_LIST_TYPE_KIN_ACTIVE)  # 查看家族排行
            self.family.gameServerNetPackHandle.ApplyRankingList(RANK_LIST_TYPE_KIN_ACTIVE)
            gevent.sleep(10)  # 做完其他项后，在家族中的停留时间
            logging.debug('退出家族')
            self.family.kinMan.kinKick = False
            self.family.gameServerNetPackHandle.Do_ApplyQuitKin()
        
        # 成功离开家族
        elif self.family.state == STATE_GS_KIN_LEAVE_FINISH:
            self.family.kinMan.id = 0
            self.family.kinMan.isLeader = False
            self.family.kinMan.CleanKinMsg()
            if self.family.kinMan.needLeaveKin:
                self.family.kinMan.needLeaveKin = False
                self.family.SetState(STATE_GS_KIN_BEGIN)
            else:
                self.family.behavior = Behavior.END
            
        