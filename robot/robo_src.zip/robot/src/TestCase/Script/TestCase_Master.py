# coding:utf-8
import uuid
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Tools.GenerateChinese import generate_chinese
from Config.RoleFigures import *
from Tools.Rand import Rand
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *

'''
      师徒的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.memberType = random.choice([MSTR_Master, MSTR_Apprentice])
#        self.memberType = MSTR_Master #锁定为师父
#         self.memberType = MSTR_Apprentice #锁定为徒弟
        
        self.taskMsgDict = {
                         MSTR_Master : {
                                        "文圣孔子" : {
                                                  "pos" : (74.29, 25.35),
                                                  "do" : True,
                                                  "taskName" : 9002.0
                                                  },
                                        "武圣关公" : {
                                                  "pos" : (37.06, 20.94),
                                                  "do" : True,
                                                  "taskName" : 9003.0
                                                  },
                                        "敬师堂" : {
                                                  "pos" : (15, 49),
                                                  "do" : False,
                                                  },
                                        "茶台" : {
                                                "pos" : (40.35, 84.20),
                                                }
                                       },
                         MSTR_Apprentice : {
                                        "文圣孔子" : {
                                                  "pos" : (74.29, 25.35),
                                                  "do" : False,
                                          },
                                        "武圣关公" : {
                                                  "pos" : (37.06, 20.94),
                                                  "do" : False,
                                                  },
                                        "敬师堂" : {
                                                  "pos" : (15, 49),
                                                  "do" : True,
                                                  "taskName" : 9008.0
                                                  },
                                        "茶台" : {
                                            "pos" : (40.35, 84.20),
                                            }
                                        }
                         }
        
        self.moveTask = {
                         "task" : "移动至陶立",
                         "pos" : (850.29, 919.57),
                         }
        
        self.leaveType = random.choice([MSTR_Quit, MSTR_Graduation])
#         self.leaveType = MSTR_Graduation  #锁定退出方式
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("师徒系统")
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            if case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveTask["pos"])
                break
            
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                if self.moveTask["task"] == "移动至陶立":
                    self.moveTask = {}#置空移动的信息
                    if self.memberType == MSTR_Master:
                        self.family.SetState(STATE_GS_MASTER_COMPLETE_TASK_WAIT)
                        logging.debug("师父，完成师道任务")
#                         self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_Start_Start")  
                        self.AddTaskValue(30504, 3510)      # 与陶立交谈
                        self.DoFinishTask(30504)            # 完成师道任务
#                         self.family.gameServerNetPackHandle.GM_CompleteMasterTask()#GM完成师道任务
                        gevent.sleep(3)
                    else:
                        logging.debug("徒弟先去设置搜索信息")
                        self.family.SetState(STATE_GS_MASTER_SEARCH)
                elif self.moveTask["task"] in ["文圣孔子", "武圣关公", "敬师堂"]:
                    self.family.SetState(STATE_GS_MASTER_PRIVATE_CHAT)
                    self.family.master.hasArrival = True
                    if self.memberType == MSTR_Master:
                            logging.debug("师父发消息")
                            channel = self.family.master.myApprenticeId
                    else:
                        logging.debug("徒弟发消息")
                        channel = self.family.master.myMasterId
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(u"已移动至师徒任务地点", channel=channel)
                    if self.family.master.hasOthersArrival:
                        self.family.SetState(STATE_GS_MASTER_DO_TASK)
                elif self.moveTask["task"] == "去陶立处开启传功":
                    self.moveTask = {}#置空移动的信息
                    self.family.SetState(STATE_GS_MASTER_START_TRAINING)
                elif self.moveTask["task"][:9] == "传功点":
                    self.family.SetState(STATE_GS_MASTER_TRAINING_CHAT)
                    self.family.master.hasArrival = True
                    if self.memberType == MSTR_Master:
                        channel = self.family.master.myApprenticeId
                    else:
                        channel = self.family.master.myMasterId
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(u"已移动至师徒传功地点", channel=channel)
                    if self.family.master.hasOthersArrival:
                        self.family.SetState(STATE_GS_MASTER_DO_TRAINING_TASK)
                break
            if case(STATE_GC_TEAM_CREATE):
                self.family.SetState(STATE_GC_TEAM_CREATE_WAIT)
                self.family.team_manager.myteam.isBegin = True
                self.family.gameServerNetPackHandle.TeamCreateReq()
                break
            if case(STATE_GC_TEAM_CREATE_FINISHED):
                self.family.SetState(STATE_GS_MASTER_SET_INFO)
                break
            #设置师门信息与师门公告
            if case(STATE_GS_MASTER_SET_INFO):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("设置师门信息与师门公告")
                self.family.gameServerNetPackHandle.SetSchoolAnnounceReq(uuid.uuid4().hex[:15])
                self.family.gameServerNetPackHandle.SetSchoolBaseInfoReq(uuid.uuid4().hex[:15], uuid.uuid4().hex[:10])
                break
            
            #设置搜索信息
            if case(STATE_GS_MASTER_SEARCH):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("设置搜索信息")
                if self.memberType == MSTR_Master:
                    beingStudent = False
                    recruit = u"收徒200一位"
                else:
                    beingStudent = True
                    recruit = u"老司机带带我"
                self.family.gameServerNetPackHandle.SchoolSetSearchReq(beingStudent, True, recruit)
                break
            
            #获取推荐
            if case(STATE_GS_MASTER_RECOMMAND):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("获取推荐")
                if self.memberType == MSTR_Master:
                    self.family.gameServerNetPackHandle.RecommandStudentReq()
                else:
                    self.family.gameServerNetPackHandle.RecommandMasterReq()
                break
            
            #发布招徒信息
            if case(STATE_GS_MASTER_SEND_MSG):
                logging.debug("发布招徒信息")
                while self.family.GetState() == STATE_GS_MASTER_SEND_MSG:
                    msg = u"[26B2F3,%s<收徒200一位>,school,%d,%d]" % (self.family.mainName, 0, self.family.familyId)
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(msg=msg,channel=emChatChannelInvite)
                    gevent.sleep(10)#消息冷却时间
                break

            #申请成为徒弟
            if case(STATE_GS_MASTER_SEND_REQ_TO_MASTER):
                logging.debug("申请成为徒弟")
                MasterMsgIdList = self.family.master.masterMsgIdList
                if MasterMsgIdList:
                    familyId = random.choice(MasterMsgIdList)
                    self.family.SetState(STATE_GS_MASTER_SEND_REQ_WAIT)
                    self.family.gameServerNetPackHandle.ApplySchoolReq(familyId, True)
                else:
                    logging.debug("招募信息师父id列表为空")
                    self.family.SetState(STATE_GS_MASTER_MSG_WAIT)#等待师父招募信息
                break
            
            #组队处理
            if case(STATE_GS_MASTER_TEAM_INVITE):
                self.family.SetState(STATE_GS_MASTER_TEAM_INVITE_STAY)
                logging.debug("师父邀请组队逻辑")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_leader")
                self.family.gameServerNetPackHandle.TeamInviteReq(self.family.master.myApprenticeId)
                break
            
            #进入桃李园
            if case(STATE_GS_MASTER_ENTER_TAOLIYUAN):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                npcName = "陶立"
                if npcName in self.family.gameServerNetPackHandle.sceneNPCDict:
                    logging.debug("进入桃李园")
                    npcId = self.family.gameServerNetPackHandle.sceneNPCDict[npcName]
                    self.family.gameServerNetPackHandle.AskNpc_obj(npcId)
                    self.family.gameServerNetPackHandle.Transfer2Map(SceneTaoLiYuan)
                else:
                    logging.debug("找不到NpcId，NpcName = "+npcName)
                    logging.debug(self.family.gameServerNetPackHandle.sceneNPCDict)
                break

            #传送至队长(师父)的位置
            if case(STATE_GS_MASTER_TRANSFER_TO_SERVER):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                gevent.sleep(3)
                member = self.family.master.myMasterMember
                logging.debug("传送至队长(师父)的位置 : gameServerId = %s, sceneTemplateId = %s, sceneInstanceId = %s" % (member.gameServerId, SceneTaoLiYuan, member.sceneInstanceId))
                self.family.gameServerNetPackHandle.TransferToServer(member.gameServerId, SceneTaoLiYuan, member.sceneInstanceId)
                break
            
            #处理拜师任务
            if case(STATE_GS_MASTER_DO_TASK):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                task = self.taskMsgDict[self.memberType][self.family.master.task]
                if not self.moveTask:
                    logging.debug("移动至任务目标地点")
                    self.moveTask["task"] = self.family.master.task
                    self.moveTask["pos"] = task["pos"]
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    self.moveTask = {}#置空移动的信息
                    self.family.master.hasArrival = False
                    self.family.master.hasOthersArrival = False
                    do = task["do"]
                    if do:#完成任务
                        gevent.sleep(5)
                        logging.debug("做任务：%s" % task["taskName"])
                        
                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_DoTask_%s" % task["taskName"])
#                        self.family.gameServerNetPackHandle.CharacterGesturePlay(0)
                        self.family.gameServerNetPackHandle.NofityTeammatePlaySequence(task["taskName"])
#                        self.family.gameServerNetPackHandle.Do_ApplySetTaskValue(47,0,1,0)
                    else:#等待对方完成任务
#                        self.family.gameServerNetPackHandle.Do_ApplySetTaskValue(47,0,1,0)
                        logging.debug("等待对方完成任务")
                break
            
            #所有拜师任务完成
            if case(STATE_GS_MASTER_TASK_FINISH):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                if self.memberType == MSTR_Master:
                    logging.debug("等待徒弟发送完成任务消息")
                else:    
                    logging.debug("徒弟发消息")
                    channel = self.family.master.myMasterId
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(u"徒弟完成拜师任务", channel=channel)
                    self.family.SetState(STATE_GS_APPRENTICE_TASK_FINISH)
                break    
            
            if case(STATE_GS_APPRENTICE_TASK_FINISH):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("师傅徒弟拜师完成")
                if self.memberType == MSTR_Master:
                    logging.debug("师父去陶立处开启传功")
                    self.moveTask["task"] = "去陶立处开启传功"
                    self.moveTask["pos"] = (64.44, 54.97)
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    logging.debug("徒弟等待师父开启传功")
                    self.family.SetState(STATE_GS_MASTER_START_TRAINING_WAIT)
                break
            
            #开启传功
            if case(STATE_GS_MASTER_START_TRAINING):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                gevent.sleep(2)
                npcName = "陶立"
                if npcName in self.family.gameServerNetPackHandle.sceneNPCDict:
                    logging.debug("开启传功")
                    npcId = self.family.gameServerNetPackHandle.sceneNPCDict[npcName]
                    self.family.gameServerNetPackHandle.AskNpc_obj(npcId)
                    self.family.gameServerNetPackHandle.ApplySchoolTrainingTask()
                else:
                    logging.debug("找不到NpcId，NpcName = "+npcName)
                    logging.debug(self.family.gameServerNetPackHandle.sceneNPCDict)
                break
            
            #移动至传功地点
            if case(STATE_GS_MASTER_DO_TRAINING_TASK):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                if not self.moveTask:
                    place = self.family.master.trainingPlace
                    if place:
                        logging.debug("移动至传功地点 : %s" % place[10:])
                        self.moveTask["task"] = place
                        self.moveTask["pos"] = self.taskMsgDict[self.memberType][place[10:]]["pos"]
                        self.family.SetState(STATE_GS_MOVE_GO)
                    else:
                        logging.debug("未获取到传功地点 : %s" % place)
                else:
                    self.family.master.hasArrival = False
                    self.family.master.hasOthersArrival = False
                    if self.memberType == MSTR_Master:
                        logging.debug("师父开始传功")
                        self.family.gameServerNetPackHandle.BeginSchoolTraining()
                    else:
                        logging.debug("徒弟等待师父开始传功")
                        self.family.SetState(STATE_GS_MASTER_TRAINING_BEGIN_WAIT)
                break
            
            #师父结束传功
            if case(STATE_GS_MASTER_TRAINING_FINISH):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("等待40s后师父结束传功")
                gevent.sleep(40)#师徒传功时间需要40s
                self.family.gameServerNetPackHandle.ApplyFinishSchoolTraining()
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_chuangong")
                break
            
            #师徒传功已完成
            if case(STATE_GS_MASTER_TRAINING_END):
                self.family.SetState(STATE_GS_MASTER_WAIT)
                logging.debug("师徒传功已完成")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_TrainingFinish")
                if self.memberType == MSTR_Master:
                    self.family.SetState(STATE_GS_MASTER_WAIT_APPRENTICE_LEAVE)
                else:
                    if self.leaveType == MSTR_Quit:
                        logging.debug("徒弟发出断绝关系请求")
                        self.family.gameServerNetPackHandle.SchoolQuitReq(self.family.master.myMasterId)
                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_DuanJueGuanXi")
                    elif self.leaveType == MSTR_Graduation:
                        logging.debug("徒弟出师")
                        gevent.sleep(3)
                        self.family.gameServerNetPackHandle.GraduationReq(self.family.master.myMasterId)
                        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_ChuShi")
                break
            
            #完成案例退出
            if case(STATE_GS_END):
                logging.debug("完成师徒案例，退出")
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_Finish")
                self.family.behavior = Behavior.END
                break
            
            
            
            
                
    def DoFinishTask(self, taskid):     #完成任务
        TASKID = []
        TASKID.append(taskid)
        self.family.gameServerNetPackHandle.Do_ApplyFinishMainTask(TASKID)
        self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Master_" + str(taskid))   
        self.family.SetState(STATE_GC_TEAM_CREATE)
    
    def AddTaskValue(self, taskId,stepId):      #设定步骤任务值
        self.family.gameServerNetPackHandle.Do_ApplySetTaskStepValue(taskId, stepId, 111, 1)   #应用添加任务值
        self.family.SetState(STATE_GS_MAIN_TASK_START)       