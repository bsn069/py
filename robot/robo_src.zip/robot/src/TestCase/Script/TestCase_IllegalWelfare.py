#coding=utf-8
'''
Created on 2015年12月15日

@author: zhangpengfei
'''
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine *
from cgi import log
from locust.asyncevent import asyncresult_manager
from GenTools.GenerateChineseport generate_chinese
from Config.RoleFigures import *
from TestCase.Script import TestCase_Guardian

from threading import Thread
import functools
import time
import sys

'''
福利协议重放的TestCase
'''
class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family

    def _WaitForStateChange(self, state, timeout = 10):
        begin = time.time()
        while (time.time() - begin < timeout):
            if (self.family.GetState() != state):
                return True
            gevent.sleep(1)
        return False
        
    def _Run(self, name, send_protocol_handle, get_value_handle, compare_value_handle, timeout = 10, count = 1):
        for i in range(count + 1):
            # 发送协议
            self.family.SetState(STATE_GS_WAIT)
            old_value = get_value_handle()
            send_protocol_handle(self)
            begin = time.time()
            #等待回包
            self._WaitForStateChange(STATE_GS_WAIT, timeout)
            if i < 1:
                continue
            new_value = get_value_handle()
            result = compare_value_handle(old_value, new_value)
            asyncresult_manager.await(self.family, name, 10)
            gevent.sleep(1)
            asyncresult_manager.fire(self.family, name, result)

    def _GetValue(self):
        return self.family.GetState()

    def _CompareValue(self, old_value, new_value):
        return old_value == new_value
        
    def _ApplySignIn(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.Daily_SignIn()
        
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol, 
                  self._GetValue,
                  self._CompareValue)
    
    def _GetLevelGift(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.GetLevelGift()

        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol, 
                  self._GetValue,
                  self._CompareValue)
        
    def _ApplyPray(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.ApplyPray()
        
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol,
                  self._GetValue,
                  self._CompareValue)
        
    def _MoneyTreeAward(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.GetMoneyTreeAward()
        
#         self.family.gameServerNetPackHandle.BuyMoneyTree()//木有摇钱树了
        gevent.sleep(0.5)
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol,
                  self._GetValue,
                  self._CompareValue)
    
    def _TeaRoom(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.ApplyGrabTeaRoomAward()
        
        benterArena = True
        bLoop = True
        while bLoop:
            nState = self.family.GetState()
            for case in switch(nState):
                logging.debug("*** case %d" %nState)
                if case(STATE_GS_PLAYING):
                    logging.debug("*** STATE_GS_PLAYING")
                    self.family.SetState(STATE_GS_WAIT)
                    if benterArena:
                        #茶馆-走到茶馆小二
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, 75, 113)
    #                         logging.debug('等待')
                        gevent.sleep(15)
                        #对话
                        NPCId = self.family.gameServerNetPackHandle.sceneNPCDict['贺察']
    #                         logging.debug('对话%s' % NPCId)
                        self.family.gameServerNetPackHandle.AskNpc(NPCId)
                        benterArena = False
                    logging.debug("*** STATE_GS_PLAYING End")
                    break
                
                
                elif case(STATE_GS_WELFARE_TEAROOM_NPC):#茶馆小二
                    logging.debug("*** STATE_GS_WELFARE_TEAROOM_NPC")
                    self.family.SetState(STATE_GS_WAIT)
                    self.family.gameServerNetPackHandle.ApplyEnterTeaRoom()#进入茶室
    #                     logging.debug('茶室')
                    break
                
                elif case(STATE_GS_WELFARE_ENTER_TEAROOM):#成功进入茶室
                    logging.debug("*** STATE_GS_WELFARE_ENTER_TEAROOM")
                    self.family.SetState(STATE_GS_WAIT)
                    break
                
                elif case(STATE_GS_WELFARE_GOOD_TEA):#领取稀有茶品
                    logging.debug("*** STATE_GS_WELFARE_GOOD_TEA")
                    bLoop = False
    #                     logging.debug('领取稀有茶品')
                    break
                else:
                    gevent.sleep(1)
        
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol(self),
                  self._GetValue,
                  self._CompareValue)
        
    def _Grardian(self):        
        def _SendProtocol(self):
            #结算第一护法
            self.family.gameServerNetPackHandle.Do_EndSingleMission(TangYunLevel)
        
        #获取高级装备,达到挑战护法战力
        self.family.gameServerNetPackHandle.BecomeStronger()

        #护法-侠义谱
        self.family.gameServerNetPackHandle.GM_FinishMainTaskToId(Task_XiaYiZhiPu)
        self.family.gameServerNetPackHandle.CallScript("TaskCmd", "SetTaskStepValue", Task_XiaYiZhiPu, Task_XiaYiZhiPu)
        gevent.sleep(1)
        #完成侠义之谱任务
        self.family.gameServerNetPackHandle.Do_ApplyFinishMainTask(Task_XiaYiZhiPu)
        #挑战第一护法
        self.family.gameServerNetPackHandle.Do_StartSingleMission(TangYunLevel)
        gevent.sleep(10)
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol,
                  self._GetValue,
                  self._CompareValue)

        #回到主场景
        self.family.gameServerNetPackHandle.LeaveSingleMission()


    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        self._ApplySignIn()
        # self._ApplyPray()
        # self._GetLevelGift()
        # self._MoneyTreeAward()
        # self._Grardian()
