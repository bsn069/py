#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
import math
from locust.events import *
from locust.asyncevent import asyncresult_manager
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from Tools.Enum import enum
from TestCase.Files.Battle import Battle
from TestCase_TeamBase import TeamBaseCase, TeamCreateType, TeamMemberType
from account.account_def import AccountDef
from account.account_service import account_battle
from _ast import Pass
from TestCase.Files.Team import TeamBaseInfo


'''
      战场的TestCase
'''


class TestCase(TeamBaseCase):
    MIN_LEVEL = 46
    
    NPC = {
           '午铭':(212.69, 222.80),
           '<襄北演武报名官>':(16.58, 35.02),
           }
    
    EVENT = enum(WUZI=1,
                 KUANGRE=2,
                 BENGTA=3,
                 )
    
    STATE = enum(NULL=0,
             MOVETO_WUMING=1,
             MOVETO_BAOMING=2,
             MOVETO_BASEPOINT=3,
             MOVETO_SKILLPOINT=4,
             MOVETO_EVENT=5,
             MOVETO_BAOXIANG=6,
             )
    
    POINT = {1: (196.63, 166.1),    # 东青岩
             2: (193.85, 88.95),    # 南朱岩
             3: (63.57, 88.03),     # 西白谷
             4: (63.57, 166.9),     # 北玄境
             5: (127.58, 127.93),   # 中央高地
             }
    SKILL_POINT = POINT[1]
    VALUE_COIN_BATTLE_HONOR = 6
    
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_BATTLE_MATCH, TEAM_TYPE_BATTLE_MATCH, u"襄北演武", teamCreateType=TeamCreateType.FIXED)
        self.family = family
        self.family.gameServerNetPackHandle.Kin_Shop_bool = False
        self.family.battle.isHandleEvent = True # 是否影响随机事件
        self.gmRevive = True
        self.skillPos = TestCase.SKILL_POINT
        
        self.state = TestCase.STATE.NULL
        self.battleEventId = None
        self.moveTo = (0, 0)
        self.state = TestCase.STATE.NULL
        self.battle_targets = {
            1 : [
                [self.DoMoveTo, TestCase.POINT[1]],
                [self.DoOccupy, (5,)],
            ],
            2 : [
                [self.DoMoveTo, TestCase.POINT[2]],
                [self.DoOccupy, (5,)],
            ],
            3 : [
                [self.DoMoveTo, TestCase.POINT[5]],
                [self.DoOccupy, (5,)],
            ],
            4 : [
                [self.DoMoveTo, TestCase.POINT[3]],
                [self.DoOccupy, (5,)],
            ],
            5 : [
                [self.DoMoveTo, TestCase.POINT[4]],
                [self.DoOccupy, (5,)],
            ],
        }
        
        self.battle_target = random.choice(self.battle_targets.keys())
        self.battle_step = 0
        
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_battle(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[Battle Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
            
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_BATTLE_WAIT)
                if self.member_type == AccountDef.TEAM_SINGLE: # 单人
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                else:  # 组队
                    self.family.SetState(STATE_GS_BATTLE_ENTER)
                    self.family.gameServerNetPackHandle.Transfer(SceneMoBeiCaoYuan)
                if self.family.isNewRole:
                    #装备技能
                    self.family.gameServerNetPackHandle.RandomEquip(random.randint(TestCase.MIN_LEVEL, MaxLevel))#随机等级、装备和升星
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                break


            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                if self.member_type == AccountDef.TEAM_SINGLE \
                or self.family.team_manager.myteam.IsLeader():
                    # 直接传送到准备场，走过去NPC太慢了
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                break
                
            if case(STATE_GS_BATTLE_JOIN):
                self.family.SetState(STATE_GS_BATTLE_WAIT)
                self.family.gameServerNetPackHandle.Cli_BattleFieldMatch_JoinRequest()
                break
            
            if case(STATE_GS_BATTLE_MOBEI):
                self.family.SetState(STATE_GS_WAIT)
                self.state = TestCase.STATE.MOVETO_BAOMING
                self.family.gameServerNetPackHandle.PlayerAutoPath(*(TestCase.NPC['<襄北演武报名官>']))
                break

            if case(STATE_GS_BATTLE_MATCHED):
                self.family.SetState(STATE_GS_START_FIGHT_WAIT)
                break

            if case(STATE_GS_START_FIGHT_BEGIN):
                self.family.gameServerNetPackHandle.ApplyBuyShopItem(
                    CommonShop,
                    random.choice(SHOP_GOODS[CommonShop]),
                    37)  #银两商店购买红药
                self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                self.state = TestCase.STATE.MOVETO_BASEPOINT
                break

            if case(STATE_GS_BATTLE_START_MOVE):#开始移动FIRST_STEP
                self.MoveSwitch()
                break

            if case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveTo)
#                 self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveTo)
                break

            # 到达任务点
            if case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_WAIT)
                state, self.state = self.state, TestCase.STATE.NULL
                if state == TestCase.STATE.MOVETO_WUMING:
                    self.family.gameServerNetPackHandle.AskNpc('午铭')
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Battle_WuMing")
                elif state == TestCase.STATE.MOVETO_BAOMING:
                    if self.member_type == AccountDef.TEAM_SINGLE:
                        self.family.SetState(STATE_GS_BATTLE_JOIN)
                    else:
                        self.family.SetState(STATE_GC_TEAM_BEGIN)
                elif state == TestCase.STATE.MOVETO_BASEPOINT:
                    self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                elif state == TestCase.STATE.MOVETO_SKILLPOINT:
                    self.family.SetState(STATE_GS_BATTLE_BEGIN_SKILL)
                elif state == TestCase.STATE.MOVETO_EVENT: # 移动到随机事件地点
                    if self.battleEventId == TestCase.EVENT.WUZI:
                        # 随机事件刷出物资，移动到宝箱
                        if Battle.BAOXIANG_NAME in self.family.gameServerNetPackHandle.sceneNPCDict.keys()\
                        and self.family.battle.baoxiangPos is not None:
                            self.state = TestCase.STATE.MOVETO_BAOXIANG
                            self.family.gameServerNetPackHandle.PlayerAutoPath(*self.family.battle.baoxiangPos)
                            self.family.battle.baoxiangPos = None
                        else:
                            self.battleEventId = None
                            self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                    elif self.battleEventId == TestCase.EVENT.KUANGRE \
                    or self.battleEventId == TestCase.EVENT.BENGTA:
                        self.battleEventId = None # 事件处理完毕
                        self.family.SetState(STATE_GS_BATTLE_BEGIN_SKILL)
                    else:
                        self.battleEventId = None
                        self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                elif state == TestCase.STATE.MOVETO_BAOXIANG: # 到达宝箱
                    if Battle.BAOXIANG_NAME in self.family.gameServerNetPackHandle.sceneNPCDict.keys():
                        self.family.gameServerNetPackHandle.AskNpc(Battle.BAOXIANG_NAME)
                        del self.family.gameServerNetPackHandle.sceneNPCDict[Battle.BAOXIANG_NAME]
                        gevent.sleep(20)
                    self.battleEventId = None
                    self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                break
            
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_BATTLE_JOIN)
                break

            if case(STATE_GS_BATTLE_BEGIN_SKILL):
                self.family.SetState(STATE_GS_WAIT)
                logging.debug('开始放技能~')
                self.family.gameServerNetPackHandle.canSkill = True
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break

            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):#释放下次技能
                self.family.SetState(STATE_GS_WAIT)
                if self.family.characterCur.state == CHAR_STATE_IDLE:
                    if self.family.battle.eventId is None:
                        nowX = self.family.characterCur.posX
                        nowY = self.family.characterCur.posY
                        if math.fabs(nowX - self.skillPos[0]) > 3 or math.fabs(nowY - self.skillPos[1]) > 3:
                            self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.skillPos)
                            self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                        else:
                            self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                    elif self.battleEventId is None:
                        self.family.gameServerNetPackHandle.canSkill = False
                        self.battleEventId, self.family.battle.eventId = self.family.battle.eventId, None
                        if TestCase.EVENT.WUZI <= self.battleEventId <= TestCase.EVENT.BENGTA:
                            if self.battleEventId == TestCase.EVENT.WUZI:
                                self.skillPos = TestCase.SKILL_POINT
                            elif self.battleEventId == TestCase.EVENT.KUANGRE \
                            or self.battleEventId == TestCase.EVENT.BENGTA:
                                self.skillPos = TestCase.POINT[self.family.battle.eventPosIdx]
                            self.state = TestCase.STATE.MOVETO_EVENT
                            self.family.gameServerNetPackHandle.PlayerAutoPath(*TestCase.POINT[self.family.battle.eventPosIdx])
                elif self.family.characterCur.state == CHAR_STATE_DEATH:
                    self.skillPos = TestCase.SKILL_POINT
                    self.family.gameServerNetPackHandle.canSkill = False
                    self.family.SetState(STATE_GS_BATTLE_WAIT_ALIVE)
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break

            if case(STATE_GS_BATTLE_WAIT_ALIVE):
                self.skillPos = TestCase.SKILL_POINT
                if self.family.characterCur.state == CHAR_STATE_IDLE:
                    if self.gmRevive:
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.skillPos)
                        gevent.sleep(2)
                        self.family.SetState(STATE_GS_BATTLE_BEGIN_SKILL)
                    else:
                        self.family.SetState(STATE_GS_BATTLE_START_MOVE)
                break

            if case(STATE_GS_BATTLE_SHOP):#联赛商店
                self.family.SetState(STATE_GS_BATTLE_WAIT)
                logging.debug("战场商店") 
                if self.family.valueCoin.has_key(VALUE_COIN_BATTLE_HONOR):#有战场功勋
                    if self.family.valueCoin[VALUE_COIN_BATTLE_HONOR]<2000:
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_BATTLE_HONOR, 28000)#获得战场功勋
                    else:
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_BATTLE_HONOR, 30000)#获得战场功勋
                gevent.sleep(3)
                self.family.gameServerNetPackHandle.ApplyBuyShopItem(BattleShop, random.choice(SHOP_GOODS[BattleShop]), 1)#战场商店购买
                self.family.gameServerNetPackHandle.ApplyRankingRank(RANK_LIST_TYPE_BATTLE_FIELD)#排行榜-3人
                self.family.gameServerNetPackHandle.ApplyRankingList(RANK_LIST_TYPE_BATTLE_FIELD)#排行榜-100人
                self.family.gameServerNetPackHandle.TeamLeaveReq()
                self.family.SetState(STATE_GS_END)
                break

            if case(STATE_GS_END):
                logging.debug("战场案例结束")
                self.family.behavior = Behavior.END # 退出
                break

    def MoveSwitch(self):
        task = self.battle_targets[self.battle_target]
        if self.battle_step < len(task):
            task[self.battle_step][0](*(task[self.battle_step][1]))
            self.battle_step += 1
        else:
            self.state = TestCase.STATE.MOVETO_SKILLPOINT
            self.DoMoveTo(*self.skillPos)

    def DoMoveTo(self, posX, posY):
        self.moveTo = (posX, posY)
        self.family.SetState(STATE_GS_MOVE_GO)
    
    def DoOccupy(self, time):
        gevent.sleep(time)