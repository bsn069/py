#!/usr/bin/env python2.7
# coding:utf-8
import gevent
import random
from locust.asyncevent import asyncresult_manager
from ModuleState.StateDefine import *
from GeTools.GenerateChinesemport generate_chinese
from locust.core import remotecall


"""
        kinwar匹配测试
         
"""
KINWAR_INDEX = 0
@remotecall
def get_kincreatnumber():
    global KINWAR_INDEX
    if KINWAR_INDEX < 10000:
        KINWAR_INDEX += 1
        return KINWAR_INDEX
    else:
        return -1

class TestCase(object):
    def __init__(self, family):
        self.family = family
        self.isfirst = True

        

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):         
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.gameServerNetPackHandle.Add_Sliver()
            if self.family.kinMan.id:#如果在家族中需要先离开家族
                self.family.SetState(STATE_GS_KINWAR_WAIT_MSG)
            else:
                self.family.SetState(STATE_GS_KINWAR_CREAT)
            return
             
        elif self.family.GetState() == STATE_GS_KINWAR_CREAT:
            self.family.SetState(STATE_GS_KINWAR_WAIT)
            name = generate_chinese(5)
            self.family.gameServerNetPackHandle.Do_CreateKin(name)
            return
        
        elif self.family.GetState() == STATE_GS_KIN_UPGRADE:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_KinWar_Create_Finish")
            self.family.SetState(STATE_GS_KINWAR_WAIT_MSG)
            return 
        
        elif self.family.GetState() == STATE_GS_KINWAR_WAIT_MSG:
            if self.isfirst:
                self.isfirst = False
                number = get_kincreatnumber()
                if number == -1:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_KinWar_Number_Finish")   
            gevent.sleep(5)
            return
        
        elif self.family.GetState() == STATE_GS_KINWAR_MSG:
            self.family.SetState(STATE_GS_KINWAR_WAIT)
            self.family.gameServerNetPackHandle.KinWarStartSignUp()
            return 
        
        elif self.family.GetState() == STATE_GS_KINWAR_END:
            self.family.SetState(STATE_GS_KINWAR_WAIT)
            self.family.behavior = Behavior.END
            return

                                
