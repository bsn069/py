#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *


'''
      换线的TestCase
'''


class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        self.family.gameServerNetPackHandle.isRecordGsChanged = True
        for case in switch(nState):
            if case(STATE_GS_PLAYING) or case(STATE_GS_1_PLAYING):
                self.family.SetState(STATE_GS_WAIT)
                gevent.sleep(1)
                logging.debug('获取分线信息309')
                self.family.gameServerNetPackHandle.Get_LineInfo()#获取分线信息309
                break

            if case(STATE_GS_LINE_LIST):
                self.family.SetState(STATE_GS_WAIT)
                logging.debug('请求线路列表310')
                self.family.gameServerNetPackHandle.Get_LineList()#请求线路列表310
                break

            if case(STATE_GS_LINE_SWITCH):#换线
                self.family.SetState(STATE_GS_LINE_SWITCH_WAIT)
                logging.debug('换线')
                line_id = self.family.gameServerNetPackHandle.switchLineId
                self.family.gameServerNetPackHandle.Switch_SceneLine(line_id)#换线
                # self.family.behavior = Behavior.END
                break

            if case(STATE_GS_LINE_SWITCH_SUCCESS):#换线成功
                gevent.sleep(5)
                logging.debug('换线成功')
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_ChangeLine_Success")
                self.family.SetState(STATE_GS_PLAYING)
                # self.family.behavior = Behavior.END
                break









