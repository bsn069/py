#!/usr/bin/env python2.7
# coding:utf8
import math
import random
import gevent
import asyncore
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import VALUE_COIN_GOLD, VALUE_COIN_SILVER
from Tools.JxLog import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from Tools.Rand import Rand
from copy import deepcopy

'''
      拍卖行数据校对的TestCase
'''

TRADER_TIME_WAIT = 5
CUSTOMER_TIME_WAIT = 15
MAX_TRADER_SALE_LIMIT = 10
MAX_CUSTOMER_BUY_LIMIT = 16

class TestCase():
    #sleepTime is sleep second
    def __init__(self, family):
        self.family = family
        self.priceConfig = dict(self.family.gameConfig.get_stone_config().items() + self.family.gameConfig.get_book_config().items() +self.family.gameConfig.get_consume_config().items())
        
        self.family.bag.tradeItemIdDict = self.tradeid_dict = (dict([('_'.join(str(y) for y in x), x) for x in self.GetTradeSaleItems()]))
        self.tradeid = None
        self.addedItems = 0

        self.tradeIndexidList = ["5_1001_0_0", "5_1002_0_0", "5_1003_0_0", "5_1004_0_0", "5_1005_0_0", "5_921_0_0", "2_0_0_0"]#保险券有bug没显示在奇珍异宝的全部里
        self.tradeIndexid = None
        self.tradeNpc = (86, 209)
        
        self.readySaleTradeIdDict = deepcopy(self.tradeid_dict)
        self.hasSaled = False
        self.isTraderTrading = False
        self.traderSaleCount = 0
        self.customerBuyCount = 0
        self.isFirstRefresh = True
        self.getTradeListCount = 0
        
        MemberTypes = {
                     Trade_Trader : 1,
                     Trade_Customer : 1,
                     }
        self.memberType = Rand.weighted_choice(MemberTypes)#根据权重分配人物类型
#         self.memberType = Trade_Trader #锁定
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):

            if case(STATE_GS_PLAYING):  # 添加出售的物品
                if self.family.isNewRole:
                    self.family.SetState(STATE_GS_TRADEHOUST_END)
                    gevent.sleep(5)
                    self.family.gameServerNetPackHandle.GM_GetTradeHouse_TradeItem(self.readySaleTradeIdDict.values(), MAX_TRADER_SALE_LIMIT+8)
                    self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_GOLD, 10000000)
                    logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"coin" : {VALUE_COIN_GOLD : 10000000}}))
                    self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_SILVER, MaxGMAddCoinValue*MAX_CUSTOMER_BUY_LIMIT)
                    logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"coin" : {VALUE_COIN_SILVER : MaxGMAddCoinValue*MAX_CUSTOMER_BUY_LIMIT}}))
                    gevent.sleep(10)
                else:
                    gevent.sleep(3)
                    self.family.bag.tradeItemIdDict = self.tradeid_dict = self.family.bag.GetAllTradeItemInfo()
                    self.readySaleTradeIdDict = deepcopy(self.tradeid_dict)
                    extraLen = len(self.readySaleTradeIdDict) - 8 #第一轮只能上架8个
                    if extraLen > 0:
                        for i in range(extraLen):
                            self.readySaleTradeIdDict.popitem()
                    logging.debug("readySaleTradeIdDict = %s" % self.readySaleTradeIdDict)
                    self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                break

            if case(STATE_GS_TRADEHOUSE_GETMYSALE):  # 获得我的出售列表
                logging.debug('获得我的出售列表')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.TradeHouse_GetMySaleList()
                self.isTraderTrading = False
                break

            if case(STATE_GS_TRADEHOUSE_TRADEHISTORY):  # 获得我的交易记录
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('获得我的交易记录')
                self.family.gameServerNetPackHandle.TradeHouse_GetTradeHistory()
                break

            if case(STATE_GS_TRADEHOUSE_GETPRICE):  # 获得上架交易价格
                logging.debug('获得上架交易价格')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                if self.isTraderTrading:
                    self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_TRADEHISTORY
                    self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                    return
                lenTradeItem = len(self.family.gameServerNetPackHandle.tradeHouseMyTradeId)
                if not self.hasSaled:
                    if self.readySaleTradeIdDict:
                        self.tradeid = self.readySaleTradeIdDict.popitem()
                        self.family.gameServerNetPackHandle.TradeHouse_GetTradePrice(self.tradeid[0])
                    else:
                        self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_PUTOFFSALE
                        self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                elif self.memberType == Trade_Customer:
                    logging.debug("消费者查看完交易记录了，准备退出")
                    self.family.SetState(STATE_GS_TRADEHOUST_END)
                elif self.traderSaleCount < MAX_TRADER_SALE_LIMIT:
                    if lenTradeItem < 8:#销售者摊位不满时补充（目前摊位限制为8）
                        self.isTraderTrading = True
                        self.traderSaleCount += 1
                        logging.debug("摊位不满8个商品（有%s个），准备补充" % lenTradeItem)
                        tradeKey = random.choice(self.tradeid_dict.keys())
                        self.tradeid = (tradeKey, self.tradeid_dict[tradeKey])
                        self.family.gameServerNetPackHandle.TradeHouse_GetTradePrice(self.tradeid[0])
                    else:
                        logging.debug("摊位有8个物品，%ss后再检查" % TRADER_TIME_WAIT)
                        gevent.sleep(TRADER_TIME_WAIT)
                        self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                else:
                    logging.debug("售卖次数：%s; 售卖限制次数：%s" % (self.traderSaleCount, MAX_TRADER_SALE_LIMIT))
                    self.family.SetState(STATE_GS_TRADEHOUST_END)
                break

            if case(STATE_GS_TRADEHOUSE_PUTONSALE):  # 商品上架
                logging.debug('商品上架')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.CleanTradeLimit()#清除交易限制
                TradePrice = self.family.gameServerNetPackHandle.tradeHouseTradePrice
                if self.tradeid[1] in self.priceConfig.keys():
                    configLowPrice = self.priceConfig[self.tradeid[1]][0]
                    configHighPrice = self.priceConfig[self.tradeid[1]][1]
                    recommendLowPrice = math.ceil(TradePrice/10000 * 0.5) * 10000
                    recommendHighPrice = math.floor(TradePrice/10000 * 1.5) * 10000
                    logging.debug("商品：%s的配置价格区间：%s~%s, 推荐价格区间：%s~%s" % (self.tradeid[0], configLowPrice, configHighPrice, recommendLowPrice, recommendHighPrice))
                    '''
                        价格区间需要计算，不是 [配置表最低价格, 配置表最高价格]：
                        推荐价格=（最小出售价+最大出售价）/2*0.7
                        玩家调价区间 = 推荐价格的±50%
                    '''
                    if not configLowPrice or not configHighPrice:
                        configLowPrice = recommendLowPrice
                        configHighPrice = recommendHighPrice
                    priceLowLimit = (recommendLowPrice if recommendLowPrice > configLowPrice else configLowPrice)
                    priceHighLimit = (recommendHighPrice if recommendHighPrice < configHighPrice else configHighPrice)
                    logging.debug("商品：%s，计算出价格区间应为为：%s~%s" % (self.tradeid[0], priceLowLimit, priceHighLimit))
                    value = []
                    value.append(priceLowLimit/10000)
                    value.append(priceHighLimit/10000)
                    price = random.randint(min(value), max(value))
                    price = price * 10000
                else:
                    price = 0
                gevent.sleep(2)
                fee = self.GetFee(TradePrice, price)
                if self.family.caseId == CaseManager.TRADEHOUSE_DATA and VALUE_COIN_SILVER in self.family.valueCoin and self.family.valueCoin[VALUE_COIN_SILVER] < fee:
                    logging.debug("TRADEHOUSE_DATA 没有足够金币上架商品")
                    self.family.SetState(STATE_GS_TRADEHOUST_END)
                    break
                self.family.gameServerNetPackHandle.TradeHouse_PutOnSale(self.tradeid[0], price=price)
                break

            if case(STATE_GS_TRADEHOUSE_PUTOFFSALE):  # 商品下架
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('30s后商品下架')
                gevent.sleep(30)
                self.family.gameServerNetPackHandle.TradeHouse_PutOffShelves()
                break

#             if case(STATE_GS_TRADEHOUSE_REPUTONSALE):  # 重新上架  #因为要24h之后才能执行，暂时不模拟
#                 logging.debug('重新上架')
#                 self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
#                 self.family.gameServerNetPackHandle.TradeHouse_RePutOn()
#                 break
            
            #刷新出售列表
            if case(STATE_GS_TRADEHOUST_REFRESH):
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                if self.family.caseId == CaseManager.TRADEHOUSE_DATA and VALUE_COIN_GOLD in self.family.valueCoin and self.family.valueCoin[VALUE_COIN_GOLD] < 30:
                    logging.debug("TRADEHOUSE_DATA 没有足够元宝刷新出售列表")
                    self.family.SetState(STATE_GS_TRADEHOUST_END)
                    break
                logging.debug('刷新出售列表')
                if self.isFirstRefresh:
                    self.isFirstRefresh = False
                else:
                    logging.debug("30s后刷新")
                    gevent.sleep(30)
                self.getTradeListCount = 0
                self.family.gameServerNetPackHandle.TradeHouse_Refresh()
                break
            
            if case(STATE_GS_TRADEHOUSE_GETTRADELIST):  # 获得商品类别
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                logging.debug('获得商品类别')
                gevent.sleep(2)
                if self.getTradeListCount >= 10:
                    self.family.SetState(STATE_GS_TRADEHOUST_REFRESH)
                    break
                self.getTradeListCount += 1
                self.tradeIndexid = self.tradeIndexidList[random.randint(0, len(self.tradeIndexidList)-1)]
                self.family.gameServerNetPackHandle.TradeHouse_GetTradeList(self.tradeIndexid)
                break

            if case(STATE_GS_TRADEHOUST_BUY):  # 商品购买
                logging.debug('商品购买')
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.family.gameServerNetPackHandle.CleanTradeLimit()#清除交易限制
                self.family.gameServerNetPackHandle.TradeHouse_BuyGoods()
                break
            
            if case(STATE_GS_TRADEHOUST_JUDGE):
                logging.debug("判断逻辑")
#                 self.family.SetState(STATE_GS_TRADEHOUST_END)
                self.family.SetState(STATE_GS_TRADEHOUSE_WAIT)
                self.hasSaled = True
                if self.memberType == Trade_Trader:
                    self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_TRADEHISTORY
                    self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                elif self.memberType == Trade_Customer:
                    if self.customerBuyCount < MAX_CUSTOMER_BUY_LIMIT:
                        gevent.sleep(CUSTOMER_TIME_WAIT)
                        logging.debug("购买次数%s < %s, 继续购买" % (self.customerBuyCount, MAX_CUSTOMER_BUY_LIMIT))
                        self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
                        self.customerBuyCount += 1
                    else:
                        logging.debug("消费者已买够次数了，准备查看一次交易记录")
                        self.family.SetState(STATE_GS_TRADEHOUSE_TRADEHISTORY)
                break
            
            if case(STATE_GS_TRADEHOUST_END):
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_TradeHouse_Finish")
                logging.info("[DataChecker][Bag]%s|%s|%s" % (self.family.familyId, self.family.userName, self.family.bag.GetAllBag()))
                self.family.behavior = Behavior.END
                break
    
    def GetFee(self, recommendPrice, salePrice):
        if salePrice <= recommendPrice:
            fee = salePrice * 0.02
        else:
            overPercent = float(salePrice - recommendPrice)/float(recommendPrice)
            if 0 < overPercent < 0.1:
                fee = salePrice * 0.05
            elif 0.1 <= overPercent < 0.2:
                fee = salePrice * 0.06
            elif 0.2 <= overPercent < 0.3:
                fee = salePrice * 0.08
            elif 0.3 <= overPercent < 0.4:
                fee = salePrice * 0.11
            elif 0.4 <= overPercent <= 0.5:
                fee = salePrice * 0.15
            else:
                raise
        return fee
    
    #随机获取8个拍卖行DataChecker
    def GetTradeSaleItems(self):
#         canye = deepcopy(CANYE)
        tianwang_equip = self.GetUnIdedEquipmentsIdList(TIANWANG)
        tangmen_equip = self.GetUnIdedEquipmentsIdList(TANGMEN)
        emei_equip = self.GetUnIdedEquipmentsIdList(EMEI)
        tianren_equip = self.GetUnIdedEquipmentsIdList(TIANREN)
        wudang_equip = self.GetUnIdedEquipmentsIdList(WUDANG)
        baoshi = deepcopy(BAOSHILIST)
        treasures = deepcopy(TREASURES)
        #每种至少取一个
        mustSaleItems = self.GetRandomItemFromSomeList(tianwang_equip, tangmen_equip, emei_equip, tianren_equip, wudang_equip, baoshi, treasures)
        remainingItemList = tianwang_equip + tangmen_equip + emei_equip + tianren_equip + wudang_equip + baoshi + treasures
        #剩下的随机取
        randomSaleItems = random.sample(remainingItemList, 1)
        logging.debug("SaleItemList = %s" % str(mustSaleItems + randomSaleItems))
        return mustSaleItems + randomSaleItems
    
    #根据传入的列表随机取出一个值（会删除原列表中该值）
    def GetRandomItemFromSomeList(self, *args):
        itemList = []
        for list in args:
            itemList.append(list.pop(random.randint(0, len(list)-1)))
        return itemList
    
    #获取职业未鉴定装备id列表
    def GetUnIdedEquipmentsIdList(self, faction):
        score = random.choice([1, 3, 4])
        quality = random.randint(1, 5)
        return [(self.family.bag.GetUnIdedEquipmentsId(score, quality, faction, part)) for part in EquipmentsPart]
        

