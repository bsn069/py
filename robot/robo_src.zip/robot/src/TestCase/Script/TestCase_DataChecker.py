#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *

"""
         数据校对的TestCase
"""

TRADE = 1
TRADEDETAIL = 2
ROLEDETAIL = 3

class TestCase(object):
    def __init__(self, family):
        self.family = family
        
#         self.task = TRADE
#         self.task = TRADEDETAIL
        self.task = ROLEDETAIL

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_DATACHECKER_WAIT)
                gevent.sleep(5)
                logging.info("[DataChecker][Bag]%s|%s|%s" % (self.family.familyId, self.family.userName, self.family.bag.GetAllBag()))
                logging.info("[DataChecker][Coin]%s|%s|%s" % (self.family.familyId, self.family.userName, self.family.valueCoin))
                if self.task == TRADE:
                    self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUST_END
                    self.family.gameServerNetPackHandle.TradeHouse_GetMySaleList()#获取出售列表
                elif self.task == TRADEDETAIL:
                    self.family.gameServerNetPackHandle.ApplyMailBox()
                    gevent.sleep(5)
                    self.family.gameServerNetPackHandle.tradeHouseGetMySaleState = STATE_GS_TRADEHOUST_END
                    self.family.gameServerNetPackHandle.TradeHouse_GetMySaleList()#获取出售列表
                elif self.task == ROLEDETAIL:
                    logging.info("[DataChecker][RoleDetail]%s|%s|{'member1Bag':%s, 'member2Bag':%s, 'member3Bag':%s, 'equipGridEnhance':%s, 'stoneEnchase':%s, 'skillList':%s, 'meridianSync':%s, 'bookExp':%s, 'coin':%s, 'consumeBag':%s, 'bookBag':%s, 'taskItemBag':%s, 'recycleBag':%s}" % (self.family.familyId, self.family.userName, self.family.bag.member1Bag, self.family.bag.member2Bag, self.family.bag.member3Bag, self.family.bag.equipGridEnhance, self.family.bag.stoneEnchase, self.family.GetCurCharacter().skillList, self.family.bag.meridianSync, self.family.bag.bookExp, self.family.valueCoin, self.family.bag.consumeBag, self.family.bag.bookBag, self.family.bag.taskItemBag, self.family.bag.recycleBag))
                    self.family.behavior = Behavior.END
                else:
                    self.family.behavior = Behavior.END
                break
            
            elif case(STATE_GS_TRADEHOUST_END):
                self.family.SetState(STATE_GS_DATACHECKER_WAIT)
                if self.task == TRADE:
                    allTradeItem = self.family.bag.GetAllTradeItemCount()
                    mySaleItem = self.family.bag.mySaleItemDict
                    if allTradeItem:
                        logging.info("[DataChecker][TradeItem]%s|%s|%s" % (self.family.familyId, self.family.userName, allTradeItem))
                    if mySaleItem:
                        logging.info("[DataChecker][TradeItem]%s|%s|%s" % (self.family.familyId, self.family.userName, mySaleItem))
                elif self.task == TRADEDETAIL:
                    mailAndBagItemDict = self.family.bag.MergeNonNestedDict(self.family.bag.GetAllTradeItemCount(), self.family.bag.tradeMailItemDict)
                    allCoin = self.family.bag.MergeNonNestedDict(self.family.valueCoin, self.family.bag.tradeMailCoinDict)
                    allItem = self.family.bag.MergeNonNestedDict(self.family.bag.mySaleItemDict, mailAndBagItemDict)
                    logging.info("[TRADE_DETAIL]%s|%s|valueCoin=%s|tradeMailCoinDict=%s" % (self.family.familyId, self.family.userName, self.family.valueCoin, self.family.bag.tradeMailCoinDict))
                    logging.info("[TRADE_DETAIL]%s|%s|GetAllTradeItemCount=%s|tradeMailItemDict=%s|mySaleItemDict=%s" % (self.family.familyId, self.family.userName, self.family.bag.GetAllTradeItemCount(), self.family.bag.tradeMailItemDict, self.family.bag.mySaleItemDict))
                    logging.info("[DataChecker][TradeItem]%s|%s|%s" % (self.family.familyId, self.family.userName, allItem))
                    logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"item" : allItem, "coin" : allCoin}))
                self.family.behavior = Behavior.END
                break
            
#             elif case(STATE_GS_DATACHECKER_TRADE_DETAIL):
#                 self.family.SetState(STATE_GS_DATACHECKER_WAIT)
#                 gevent.sleep(5)
#                 allCoin = self.family.bag.MergeNonNestedDict(self.family.valueCoin, self.family.bag.tradeMailCoinDict)
#                 allItem = self.family.bag.MergeNonNestedDict(self.family.bag.GetAllTradeItemCount(), self.family.bag.tradeMailItemDict)
#                 logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"item" : allItem, "coin" : allCoin}))
#                 self.family.behavior = Behavior.END
#                 break