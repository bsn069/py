#!/usr/bin/env python2.7
# coding:utf-8
import random
import gevent
import asyncore
import math
import time
import logging
from ModuleState.StateDefine import *
# from Tools.JxLog import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *
from TestCase_TeamBase import TeamBaseCase
from Tools.GenerateChinese import generate_chinese

"""
         观晴滩的TestCase
"""

class TestCase(TeamBaseCase):
    # sleepTime is sleep second
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_FREE, TEAM_TYPE_BEACH, u"观晴滩")
        self.family = family
        self.allBossPort = {#对应地图上的路径5->2->3->1->4->6
                            BeachBossPoint1 : [
                                     (76, 69),
                               ],
                            BeachBossPoint2 : [
                                     (207, 159),
                               ],
                            BeachBossPoint3 : [
                                     (264, 113),
                                 ],
                            BeachBossPoint4 : [
                                     (358, 109),
                                 ],
                            BeachBossPoint5 : [
                                     (411, 217)
                                 ],
                            BeachBossPoint6 : [
                                    (247, 196),
                                ],
                            }
        self.moveList = []
        self.awayFromBoss = True
        self.bossMoveTag = 1
        self.moveListIndex = 0
        
        self.memberType = random.randint(0, 3)#单人or组队
#         self.memberType = 0#锁定
        
    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """

    def _Action(self):
        super(TestCase, self)._Action()
        if self.family.GetState() == STATE_GS_PLAYING:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            self.family.gameServerNetPackHandle.Can_TeamJoinCheck = False
            self.family.gameServerNetPackHandle.CallScriptGcGmDoCommand("KTimeAxis.SetStage(3)", self.family.familyId)#推时间轴
            if self.family.isNewRole:#特殊需求（仅执行一次）
                gevent.spawn(self.family.gameServerNetPackHandle.LoopChat)#持续喊话
                self.family.gameServerNetPackHandle.BecomeStronger()#穿全部装备
            gevent.sleep(1)
            logging.debug("进入观晴滩")
            self.family.gameServerNetPackHandle.Transfer2Map(SceneBeach)#进入观晴滩
            
        # 开始移动
        if self.family.GetState() == STATE_GS_MOVE_GO:
            self.family.SetState(STATE_GS_MOVE_MOVING)
            if not self.moveList:#添加移动坐标列表
                self.moveList = self.allBossPort[self.bossMoveTag]
                
            if self.moveListIndex >= len(self.moveList):
                self.moveListIndex = 0
                self.moveList = []
                self.bossMoveTag += 1
                self.family.gameServerNetPackHandle.moveTag = False
                if self.awayFromBoss:
                    self.family.SetState(STATE_GS_BOSS_MOVE)#向Boss移动
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                return
            else:
                gevent.sleep(0.5)
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveList[self.moveListIndex])
#                 self.family.gameServerNetPackHandle.GM_MoveToPosition(True, *self.moveList[self.moveListIndex])

        # 到达坐标
        elif self.family.GetState() == STATE_GS_MOVE_ARRIVAL:
            self.moveListIndex += 1
            self.family.SetState(STATE_GS_MOVE_GO)
            
        #---换线---
        elif self.family.GetState() == STATE_GS_BOSS_LINE_INFO:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            gevent.sleep(1)
            self.family.gameServerNetPackHandle.bossLine = True
            self.family.gameServerNetPackHandle.Get_LineInfo()#获取分线信息309
                
                
        elif self.family.GetState() == STATE_GS_LINE_LIST:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            self.family.gameServerNetPackHandle.Get_LineList()#请求线路列表310
        
        elif self.family.GetState() == STATE_GS_LINE_SWITCH:#换线
            self.family.SetState(STATE_GS_LINE_SWITCH_WAIT)
            line_id = self.family.gameServerNetPackHandle.switchLineId
            self.family.gameServerNetPackHandle.Switch_SceneLine(line_id)#换线
        
        elif self.family.GetState() == STATE_GS_LINE_SWITCH_SUCCESS:#换线成功
            self.family.SetState(STATE_GC_BOSS_TEAM_LIST)  # 组队
            
        #---组队---
        #打开组队列表
        elif self.family.GetState() == STATE_GC_BOSS_TEAM_LIST:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            self.family.gameServerNetPackHandle.ApplyBuyShopItem(CommonShop, random.choice(SHOP_GOODS[CommonShop]), 37)#银两商店购买红药
            if self.memberType == 0: # 单人
                self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
            else:  # 组队
                self.family.SetState(STATE_GC_TEAM_BEGIN)

        elif self.family.GetState() == STATE_GC_TEAM_RECRUIT_FINISHED:
                self.family.SetState(STATE_GS_MOVE_GO)#开始移动
            
        #向Boss移动
        elif self.family.GetState() == STATE_GS_BOSS_MOVE:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            logging.debug("向Boss移动")
            boss_list = self.family.gameServerNetPackHandle.bossDict.values()
            logging.debug("bossDict = %s" % self.family.gameServerNetPackHandle.bossDict)
            if boss_list:
                now_posx = self.family.characterCur.posX
                now_posy = self.family.characterCur.posY
                boss_posx = boss_list[0].stateParam.posX
                boss_posy = boss_list[0].stateParam.posY
                self.family.gameServerNetPackHandle.fightBossPosX = boss_list[0].stateParam.posX
                self.family.gameServerNetPackHandle.fightBossPosY = boss_list[0].stateParam.posY
                logging.debug(boss_list[0])
                self.family.gameServerNetPackHandle.fightBossId = boss_list[0].id
                if math.fabs(boss_posx - now_posx) < 3 and math.fabs(boss_posy - now_posy) < 3:
                    logging.debug("在Boss旁，准备放技能")
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)
                else:
#                     logging.debug('auto Move %s' % boss_list[0])
                    logging.debug("移动到boss位置")
                    self.family.gameServerNetPackHandle.PlayerAutoPath(boss_posx, boss_posy)
#                     self.family.gameServerNetPackHandle.GM_MoveToPosition(True, boss_posx, boss_posy)
            else:
#                 logging.debug('boss_serch error')
                if self.bossMoveTag > len(self.allBossPort.keys()):
                    logging.debug("所有位置没有Boss，放技能吧")
                    self.family.SetState(STATE_GS_LEAGUEMATCH_SKILL)#所有位置没有Boss，放技能吧
                else:
#                     logging.debug('移动到下一个Boss坐标位置')
                    logging.debug('移动到下一个Boss坐标位置')
                    self.family.SetState(STATE_GS_MOVE_GO)#移动到下一个Boss坐标位置
        
        
        elif self.family.GetState() == STATE_GS_LEAGUEMATCH_SKILL:#准备开始放技能
            logging.debug('准备开始放技能')#
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Beach_Skill")
            self.family.gameServerNetPackHandle.AddBuffInvincible()#无敌Buff
#            self.family.gameServerNetPackHandle.AddBuffHeavyDamage()#伤害999倍
            gevent.sleep(1)
            self.family.gameServerNetPackHandle.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
        
        
        # 随机技能
        elif self.family.GetState() == STATE_GS_SINGLE_MISSION_RELEASE_SKILLS:
            self.family.SetState(STATE_GS_WAIT_SINGLE_MISSION)
            
            nowX = self.family.characterCur.posX
            nowY = self.family.characterCur.posY
            bossX = self.family.gameServerNetPackHandle.fightBossPosX
            bossY = self.family.gameServerNetPackHandle.fightBossPosY
#             logging.debug('(%s, %s), (%s, %s)' % (nowX, nowY, bossX, bossY))
            
            #如果在Boss范围内或没有检测到Boss
            if (math.fabs(nowX - bossX) < 3 and math.fabs(nowY - bossY) < 3) or bossX == 0:
                logging.debug('Boss范围内, 继续放技能')
                gevent.sleep(3)
                if self.memberType != 0:
                    self.family.gameServerNetPackHandle.ChatRequestByMsg(u'Chat_队伍[握手]放技能啦', emChatChannelTeam)#聊天
                self.family.gameServerNetPackHandle.SkillCanBeReleased()#技能
            else:
                self.awayFromBoss = False
                logging.debug('离开Boss范围, 我的坐标 : (%s, %s) ,Boss新坐标：(%s, %s)' % (nowX, nowY, bossX, bossY))
                self.moveListIndex = 0
                self.moveList = [(bossX, bossY)]
                self.family.SetState(STATE_GS_MOVE_GO)
        
    def DoMoveTo(self, posX, posY):
        self.move_to = (posX, posY)
        self.family.SetState(STATE_GS_MOVE_GO)
        