#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from net.Common.ComDefine_pb2 import *
from Tools.Switch import switch
from Config.CaseDefine import *
from cgi import log
from Config.RoleFigures import *
from TestCase.Files.IllegalCaseError import IllegalCaseError
from Tools.Rand import *
from Config.RunConfig import Config
import sys
import time
from TestCase_TeamBase import TeamBaseCase

'''
      福利的TestCase
'''


class TestCase(TeamBaseCase):
    #sleepTime is sleep second
    #参加类型
    SINGLE = 0
    TEAM = 1
    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_TEA, TEAM_TYPE_TEA, u"品茶")
        self.family = family
        self.benterArena = True
    def _WaitForStateChange(self, state, timeout = 10):
        begin = time.time()
        while (time.time() - begin < timeout):
            if (self.family.GetState() != state):
                return True
            gevent.sleep(1)
        return False

    def _Run(self, name, send_protocol_handle, get_value_handle, compare_value_handle, timeout = 10, count = 1):
        for i in range(count + 1):
            # 发送协议
            self.family.SetState(STATE_GS_WAIT)
            old_value = get_value_handle()
            send_protocol_handle(self)
            begin = time.time()
            #等待回包
            self._WaitForStateChange(STATE_GS_WAIT, timeout)
            if i < 1:
                continue
            new_value = get_value_handle()
            result = compare_value_handle(old_value, new_value)
            if not result:
                print old_value
                print new_value
                raise IllegalCaseError(name)

    def _GetValue(self):
        return self.family.GetState()

    def _CompareValue(self, oldValue, newValue):
        return oldValue == newValue
    
    def _GetLevelGift(self, level):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.GetLevelGift(level)

        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol,
                  self._GetValue,
                  self._CompareValue)

    def _CreatePayOrder(self):
        def _SendProtocol(self):
            self.family.SetState(STATE_GS_WAIT)
            self.family.gameServerNetPackHandle.CreatePayOrder()

        gevent.sleep(0.5)
        self._Run(sys._getframe().f_code.co_name,
                  _SendProtocol,
                  self._GetValue,
                  self._CompareValue)

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_WELFARE_WAIT)
                if self.benterArena:
                    #领取等级奖励
#                    for i in [15, 20, 25, 30, 35, 40, 45,50]:
#                        if Config.is_illegaltest():
#                            self._GetLevelGift(i)
#                        else:
#                            self.family.gameServerNetPackHandle.GetLevelGift(i)
                    #签到
                    self.family.gameServerNetPackHandle.ApplySignIn()
                    
                    #七日豪礼
                    self.family.gameServerNetPackHandle.GetLogin7Reward()
                    #创建充值订单
                    if Config.is_illegaltest():
                        self._CreatePayOrder()
                    else:
                        self.family.gameServerNetPackHandle.SetGoldNumber()     #GM内部模拟充值
                    
                    logging.debug("退出")
                    self.family.behavior = Behavior.END
                    break

