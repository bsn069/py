#!/usr/bin/env python2.7
# coding:utf8
import random
import gevent
import asyncore
import logging
import time
import math
from net.Common.ComDefine_pb2 import *
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Config.CaseDefine import *
from Config.RoleFigures import *
from TestCase_TeamBase import TeamBaseCase, TeamCreateType
from account.account_def import AccountDef
from account.account_service import account_leaguematch
from locust.events import request_failure
from locust.asyncevent import asyncresult_manager
"""
         武林联赛的TestCase
"""

class TestCase(TeamBaseCase):

    PVP_MAP = {
#         SceneArena1 : (53.5, 49.5),#这个版本废除的地图
#        SceneArena2 : (34.35, 32.03),#寒武遗迹
        SceneArena3 : (72.02, 63.28),#幽森密林
        SceneArena4 : (71.12, 63.63), #剑阁之殇
        SceneArena5 : (62.87, 52.00), #翠烟山谷
        SceneArena6 : (34.35, 32.03), #寒武遗迹
    }
    
    SCORE = {
             1:(1000, 1100),
             2:(1100, 1200),
             3:(1200, 1300),
             4:(1300, 1500),
             5:(1500, 1700),
             6:(1700, 1900),
             7:(1900, 2200),
             8:(2200, 2500),
             9:(2500, 9999)
             }
    
    
    VALUE_COIN_REPUTATION = 5
    LOOP_COUNT = 0

    def __init__(self, family):
        super(TestCase, self).__init__(family, TEAM_TYPE_LEAGUE_MATCH, TEAM_TYPE_LEAGUE_MATCH, u"武林联赛", teamCreateType=TeamCreateType.FIXED)
        self.family = family
        self.skillPos = None
        self.loopCount = 0
        
        (result,
         self.family.team_manager.myteam.accountId,
         self.family.team_manager.myteam.leaderFamilyId,
         self.family.team_manager.myteam.memberLimit,
         self.member_type,
         self.family.team_manager.myteam.leadergroupid) = account_leaguematch(self.family.familyId, self.family.serverGroupId)
        if result == AccountDef.RESULT_EMPTY:
            request_failure.fire(request_type='get', name="[Leaguage Account Empty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
       
#         # 设置随机积分和段位
#         stage = random.Choice(TestCase.SCORE.keys())
#         score = random.randint(*TestCase.SCORE[stage])
#         self.family.gameServerNetPackHandle.SetLeagueStage(stage)
#         self.family.gameServerNetPackHandle.SetLeagueScore(score)

    def Excute(self):
        self._Action()
    
    """
        override _Action method which you can control TestCaseMain.py
    """    
    def _Action(self):
        super(TestCase, self)._Action()
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_LEAGUEMATCH_TASK_START)
                if self.family.isNewRole:
                    #装备技能
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                break
            
            if case(STATE_GS_LEAGUEMATCH_TASK_START):
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT_ENTER_READY_SCENE)
                self.family.gameServerNetPackHandle.Transfer(SenceShiJianTai)
                break
            
            if case(STATE_GS_LEAGUEMATCH_CHECKOVER):#检查完毕，开始匹配 
                if self.member_type == AccountDef.TEAM_SINGLE:
                    logging.debug("一个人的武林")
                    self.family.SetState(STATE_GS_LEAGUEMATCH_JOIN)
                else:  # 组队
                    self.family.SetState(STATE_GC_TEAM_BEGIN)
                break    
            
            if case(STATE_GC_TEAM_RECRUIT_FINISHED):
                self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    self.family.SetState(STATE_GC_TEAM_MEMBERCALL_BEGIN)
                break
            
            if case(STATE_GC_TEAM_MEMBER_CALL_FINISHED):
                self.family.SetState(STATE_GS_LEAGUEMATCH_JOIN)
                break
            
            if case(STATE_GS_LEAGUEMATCH_JOIN):
                self.family.SetState(STATE_GS_LEAGUEMATCH_JOIN_WAIT)
                self.family.gameServerNetPackHandle.Cli_LeagueMatch_JoinRequest()
                break
            
            if case(STATE_GS_LEAGUEMATCH_MATCHING):
                # 一定比例取消匹配
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT)
                if random.randint(0, 100) < -1:#取消匹配
                    logging.debug("取消匹配")
                    self.family.gameServerNetPackHandle.Cli_LeagueMatch_CancelRequest()
                gevent.sleep(3)
                break
            
            
            if case(STATE_GS_LEAGUEMATCH_START_FIGHT):
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT)
                self.family.gameServerNetPackHandle.canSkill = True
                logging.debug("开始战斗，准备移动")
                sceneId = self.family.gameServerNetPackHandle.sceneTemplateId
                if TestCase.PVP_MAP.has_key(sceneId):
                    self.skillPos = TestCase.PVP_MAP[sceneId]
#                     self.family.gameServerNetPackHandle.PlayerAutoPath(*self.skillPos)
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.skillPos)
                    gevent.sleep(2)
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                else:
                    self.skillPos = (self.family.characterCur.posX, self.family.characterCur.posY)
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break
            
            if case(STATE_GS_MOVE_ARRIVAL):
                logging.debug("到达目标点，准备放技能")
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break
            
            if case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):#释放下次技能
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT)
                if self.family.characterCur.state == CHAR_STATE_DEATH:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_League_Death")
                    self.family.gameServerNetPackHandle.canSkill = False
                else:
                    nowX = self.family.characterCur.posX
                    nowY = self.family.characterCur.posY
                    if math.fabs(nowX - self.skillPos[0]) > 3 or math.fabs(nowY - self.skillPos[1]) > 3:
                        self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *self.skillPos)
                        gevent.sleep(1)
                    self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                break
            
            if case(STATE_GS_LEAGUEMATCH_BACK_READY_SCENE):
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT)
                logging.debug('打完回到准备场')
                if self.family.valueCoin.has_key(VALUE_COIN_REPUTATION):#有联赛威望值
                    if self.family.valueCoin[VALUE_COIN_REPUTATION]<2000:
                        self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_REPUTATION, 28000)#增加联赛威望值
                else:
                    self.family.gameServerNetPackHandle.GM_AddValueCoin(VALUE_COIN_REPUTATION, 30000)#增加联赛威望值
                gevent.sleep(3)
                # 购买商店物品
                self.family.gameServerNetPackHandle.ApplyBuyShopItem(ArenaShop, random.choice(SHOP_GOODS[ArenaShop]))
                # 查看联赛排行榜（3人）
                self.family.gameServerNetPackHandle.ApplyRankingRank(RANK_LIST_TYPE_LEAGUE_MATCH)
                # 查看联赛前100名
                self.family.gameServerNetPackHandle.ApplyRankingList(RANK_LIST_TYPE_LEAGUE_MATCH)
                gevent.sleep(1)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_League_Finished")
                self.loopCount += 1
                if self.loopCount > self.LOOP_COUNT:
                    self.family.behavior = Behavior.END
                else:
                    if self.member_type == AccountDef.TEAM_LEADER:
                        gevent.sleep(5)
                        self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                    elif self.member_type == AccountDef.TEAM_SINGLE:
                        self.family.SetState(STATE_GS_LEAGUEMATCH_JOIN)
                break








