#!/usr/bin/env python2.7
# coding=utf-8
import random
import gevent
import asyncore
import logging
from ModuleState.StateDefine import *
from Tools.Switch import switch
from Tools.GenerateChinese import generate_chinese
from Config.CaseDefine import *
from Tools.Rand import *
from Config.RunConfig import Config
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *

"""
         离线聊天系统的TestCase
"""

class TestCase(object):
    def __init__(self, family):
        self.family = family
        if not self.family.offlinechat.member:
            self.family.offlinechat.member = random.choice([OfflineChat_Relogin, OfflineChat_Reply])
#             self.family.offlinechat.member = OfflineChat_Relogin#锁定
#             self.family.offlinechat.member = OfflineChat_Reply#锁定
        

    def Excute(self):
        self._Action()

    """
        override _Action method which you can control TestCaseMain.py
    """
    def _Action(self):
        nState = self.family.GetState()

        for case in switch(nState):

            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_OFFLINE_WAIT)
                if self.family.offlinechat.member == OfflineChat_Relogin:
                    gevent.sleep(5)
                    self.family.gameServerNetPackHandle.SyncOfflineMsgReq()
                elif self.family.offlinechat.member == OfflineChat_Reply:
                    self.family.SetState(STATE_GS_OFFLINE_REPLY_WAIT)
                break
                
            if case(STATE_GS_OFFLINE_REPLY):
                self.family.SetState(STATE_GS_OFFLINE_WAIT)
                gevent.sleep(10)#等待目标下线
                channel = self.family.offlinechat.targetId
                msg = u'OfflineChat_私聊[心动] I\'m %d' % self.family.familyId
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, channel)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_OfflineChat_Reply")
                self.family.SetState(STATE_GS_OFFLINE_REPLY_WAIT)
                break
            
            if case(STATE_GS_OFFLINE_RELOGIN):
                channel = emChatChannelScene#附近
                msg = u'OfflineChat_附近'
                self.family.gameServerNetPackHandle.ChatRequestByMsg(msg, channel)
                self.family.roleLoop = True
                self.family.behavior = Behavior.END
                break
                