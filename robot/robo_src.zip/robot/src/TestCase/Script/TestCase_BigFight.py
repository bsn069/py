#!/usr/bin/env python2.7
# coding:utf8
import random
import math
import gevent
import asyncore
from net.Common.ComDefine_pb2 import *
from Tools.JxLog import *
from Config.CaseDefine import  *
from Tools.Switch import switch
from ModuleState.StateDefine import *
from Tools.GenerateChinese import  generate_chinese
from Config.RoleFigures import * 

'''
      大乱斗TestCase（浴火争锋）
'''


class TestCase():
    
    NPC = {
           '浴火争锋报名官':(45.69, 20.73),
           }
    
    Buffer_Pos = {
                   1:(88.1, 63.6),
                   2:(63.6, 88.1),
                   3:(39.0, 63.6),
                   4:(63.3, 38.8),
                   5:(63.8, 63.8),
                  }
    
    def __init__(self, family):
        self.family = family
        self.isTrain = True
        self.count = 0
        self.moveTarget = {
                           'pos' : (0, 0),
                           }
        self.BufferPosList = TestCase.Buffer_Pos.keys()
    def Excute(self):
        self._Action()

    def _Action(self):
        nState = self.family.GetState()
        for case in switch(nState):
            if case(STATE_GS_PLAYING):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                self.family.gameServerNetPackHandle.CallScriptGmDoCommand("me:AddValueCoin(2,500,0)")
                if self.family.isNewRole:
                    #装备技能
                    self.family.gameServerNetPackHandle.EquipCharacterSkill()
                self.family.SetState(STATE_GS_BIGFIGHT_ENTER)
                self.family.gameServerNetPackHandle.Transfer(SceneMoBeiCaoYuan)
                break

            elif case(STATE_GS_BIGFIGHT_MOBEI):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                self.moveTarget["pos"] = TestCase.NPC['浴火争锋报名官']
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_MOVE_GO):
                self.family.gameServerNetPackHandle.PlayerAutoPath(*self.moveTarget["pos"])
                break
            
            elif case(STATE_GS_MOVE_ARRIVAL):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                if self.count == 0:
                    self.family.gameServerNetPackHandle.Do_ChaosFightCmd()
                    self.count += 1
                elif self.count == 1:
                    self.count += 1
                    self.moveTarget["pos"] = TestCase.Buffer_Pos[5]
                    self.family.SetState(STATE_GS_MOVE_GO)
                else:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break
            
            elif case(STATE_GS_BIGFIGHT_SIGNUP_SUCCESS):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Bight_SignUp")
                break
            
            elif case(STATE_GS_BIGFIGHT_ENTER_SENCE):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                id  = random.choice(self.BufferPosList)
                self.moveTarget["pos"] = TestCase.Buffer_Pos[id]
                self.family.SetState(STATE_GS_MOVE_GO)
                break
            
            elif case(STATE_GS_BIGFIGHT_DEATH):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Bight_Death")
#                self.family.gameServerNetPackHandle.Revival_BigFight()
                gevent.sleep(8)
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                break
             
            elif case(STATE_GS_BIGFIGHT_END):
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                gevent.sleep(5)
                self.family.gameServerNetPackHandle.CallScript("ChaosFightCmd", "EndQuit")#退出
                gevent.sleep(2)
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Bight_End")
                self.family.behavior = Behavior.END
                break
            
            elif case(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS):#释放下次技能
                self.family.SetState(STATE_GS_BIGFIGHT_WAIT)
                nowX = self.family.characterCur.posX
                nowY = self.family.characterCur.posY
                if math.fabs(nowX - 70)> 3 or math.fabs(nowY - 65.8) > 3:
                    self.family.gameServerNetPackHandle.GM_MoveToPosition(False, *TestCase.Buffer_Pos[5])
                    gevent.sleep(1)
                self.family.gameServerNetPackHandle.SkillCanBeReleased(self.family.skill.skillReleaseList)
                break
