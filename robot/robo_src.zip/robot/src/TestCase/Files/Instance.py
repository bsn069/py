# -*- coding:utf8 -*-
import random

class Instance(object):

    def __init__(self):
        self.businessmanDict = {} #行商信息
        self.goldDict = {}
        self.isBusinessmanBuy = True
        self.npcId = None
        self.isfight = False    #判断矿车出现后再中间进行PK
        self.isfirst = True     #判断人员是否是中途参与活动
        self.isBegin = True     #判断人员是否是第一次参与逐鹿金滩活动
        self.isend = False      #判断活动是否结束
    def setbusinessman(self, Id, posX, posY, posZ):
        if self.businessmanDict.has_key(Id):
            pass
        else:
            self.businessmanDict[Id] = {"pos" : (posX, posY, posZ)}
    
    def setgoldDict(self, Id, posX, posY, posZ):
        if self.goldDict.has_key(Id):
            pass
        else:
            self.goldDict[Id] = {"pos" : (posX, posY, posZ)}
    
    def getgoldDict(self):
        if self.goldDict:
            goldId = self.goldDict.keys()[0]
            return self.goldDict[goldId]["pos"]
        else:
            return ()
        
    def getbusinessman(self):
        if self.businessmanDict:
            businessmanId = random.choice(self.businessmanDict.keys())
            return businessmanId
        else:
            return None