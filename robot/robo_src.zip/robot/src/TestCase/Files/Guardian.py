# coding:utf-8

class Guardian(object):
    def __init__(self):
        self.guardianDict = {}
        self.targetSceneId = 0
    
    def GetGuardianScene(self, guardianId):
        if str(guardianId) in self.guardianDict.keys():
            return int(self.guardianDict[str(guardianId)][0])
        else:
            return 0