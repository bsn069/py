# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import random
from Config.RoleFigures import *

class Character(object):

    def __init__(self):
        self.playerId = None
        self.belongFamilyId = None
        self.familyMemberType = None
        self.name = None
        self.faction = None
        self.series = None
        self.level = None
        self.sex = None
        self.faceData = None
        self.Adult = None
        self.state = None
        
        self.time = None
        self.speed = 4.5
        self.dir = None
        self.posX = None
        self.posY = None
        self.posH = None
        self.tick = 0
        self.dstPoxX = 0
        self.dstPosY = 0
        self.faction = random.choice([TIANWANG, TANGMEN, EMEI, TIANREN, WUDANG])
        self.attackList = []
        self.skillList = []
        
    def Updata(self, CharacterState):
        self.state = CharacterState.state
        self.time = CharacterState.info.time
        self.speed = CharacterState.info.speed
        self.dir = CharacterState.info.dir
        self.posX = CharacterState.info.posX
        self.posY = CharacterState.info.posY
        self.posH = CharacterState.info.posH 
        self.tick = CharacterState.info.tick

        if CharacterState.info.dstPosX:
            self.dstPoxX = CharacterState.info.dstPosX
        if CharacterState.info.dstPosY:
            self.dstPoxY = CharacterState.info.dstPosY

    def SyncSceneCharacterInfo(self, syncInfo):
        self.state = syncInfo.state
        self.speed = syncInfo.stateParam.speed
        self.posX = syncInfo.stateParam.posX
        self.posY = syncInfo.stateParam.posY
            
    def GetCharacterDir(self):
        return self.dir 
    
    def GetCharacterposX(self):
        return self.posX 
    
    def GetCharacterposY(self):
        return self.posY 
    
    def GetCharacterposH(self):
        return self.posH
    
    def GetCharacterId(self):
        return self.playerId 
    
    def GetCharacterTick(self):
        return self.tick

    def GetCharacterSpeed(self):
        return self.speed

    def GetTick(self):
        if self.time is None or self.tick == 0:
            return 0

    def GetDstPos(self):
        return (self.dstPoxX, self.dstPosY)

    def SetDstPos(self, dstPosX, dstPosY):
        self.dstPoxX = dstPosX
        self.dstPoxY = dstPosY
