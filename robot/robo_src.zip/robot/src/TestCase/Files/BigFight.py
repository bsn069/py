# coding:utf-8
from Config.RoleFigures import *
import logging

class BigFight(object):
    
    def __init__(self):
        self.entermember = 0
        self.memberinfo = []