# coding:utf-8
import random
import math
from Tools.Enum import enum

class Valentine():
    def __init__(self):
        self.familyid = None
        self.yuexialaoer = None
        self.yanhua = None
        self.fire = None
        self.fireX = None
        self.fireY = None
        self.fireZ = None
        self.leader_lineId = None