# coding:utf-8
import random
import logging

class EatChicken(object):
    def __init__(self):
        #吃鸡毒圈圆心坐标
        self.movepos = {
                        'pos':(0, 0, 0)
                        }
        #判定是否位移
        self.ismove = False
        #活动地图中带有所有中文坐标点
        self.place_txt = [
                            (166,3.84,836),             #漓水滩
                            (1654.8,74,1743.261),       #九黎遗迹
                            (246,7.37,221),             #黑沙古城
                            (833.3,47.1,980.3),         #无心树
                            (1260,44.2,1778.3),         #林枫村
                            (309.5,64,1693),            #向岩村
                            (1386.6,5.78,455),          #渔港码头
                            (614.8,18.9,148.68),        #荒庙
                            (978.8,6.5,1295.088),       #响马营地
                            (1346,77.45,1184.87),       #盘龙谷
                            (1791,121.8,810.6),         #狼啸坡
                            (488,20,1030),              #无尽戈壁
                            (1734.28,47,996),           #盏酒客栈
                            (1471,41.6,360),            #鸣沙山
                            (1655,83,656),              #山神祭场
                            (191.3,2.7,1179.5),         #寂城
                            (623.5,1,590),              #侍剑阁
                            (482,15,1391.5),            #积风
                          ]
        #捡装备的信息
        self.equip = {
                      'id': 0,
                      'pos':(0, 0, 0),
                      'take':False
                      }
        self.isdeath = False
        
    def SetMovePos(self, PosX, PosY, PosZ):
        self.movepos = {
                'pos':(0, 0, 0)
                }
        self.movepos['pos'] = (PosX, PosY, PosZ) 
        self.ismove = True
    
    def SetEquip(self, id, PosX, PosY, PosZ):
        self.equip['pos'] = (PosX, PosY, PosZ) 
        self.equip['id'] = id
        self.equip['take'] = True