# coding:utf-8
import logging
import random
from Config.RoleFigures import *

class LimitedAcution(object):
    def __init__(self):
        self.auctioninformationlist = []
        self.auctionshopdatalist = []
        self.one_auctiondatainfolist = []
        self.go_place = None
        self.sellneed = -1
        self.dataVersion = 0
        self.distinguish = 0 
        self.totalshopinf={}
        self.isFirstCalculation = True    
        self.totalGoodsCount = 0    
        #骊山遗迹
        self.allBossPort_lishan = [#机器人运动路线1->2->3
                                     (130.5, 148.00),
                                     (85.875, 225.74),
                                     (216.37, 342.55)
                            ]
        #枫华谷
        self.allBossPort_fenghua = [#对应地图上的路径4->3->2->1->6->5
                                   (40.39, 94.67),                 
                                   (76.70, 71.41),         
                                   (102.29, 80.41),       
                                   (93.63, 109.07),     
                                   (35.81, 27.09),  
                                  (99.74, 38.6),                     
                            ]     
        #龙门荒漠
        self.allBossPort_longmen = [#对应地图上的路径5->2->3->1->4->6
                                     (36.54, 118.4),
                                     (75, 154.46),
                                     (123.28, 123.33),
                                     (172.64, 169.32),
                                     (155.91, 80.70),
                                    (115.2, 39.61),
                            ]   
        self.allBossPort= {
                           SceneLongmen:self.allBossPort_longmen ,
                           SceneLiShanYiJi:self.allBossPort_lishan,
                           SceneFenghua:self.allBossPort_fenghua,
                           }