# coding:utf-8
__author__ = 'Administrator'

import sys
sys.path.append("../..")
from Tools import enum

class ValueCoin(object):

    ValueCoinType = enum.enum(VALUE_COIN_NULL = 0,
                                                         VALUE_COIN_SILVER = 1,
                                                         VALUE_COIN_GOLD = 2,
                                                         VALUE_COIN_BIND_GOLD = 3,
                                                         VALUE_COIN_XIAYI = 4,
                                                         VALUE_COIN_REPUTATION = 5,
                                                         VALUE_COIN_BATTLE_HONOR = 6,
                                                         VALUE_COIN_LUN_JIAN_PRESTIGE = 7)

    def __init__(self):
        self.coins = {}


if __name__=="__main__":
    print ValueCoin.ValueCoinType.__dict__
