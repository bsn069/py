# coding:utf-8
import random
import logging
from ModuleState.StateDefine import *

class Dungeon(object):
    def __init__(self):
        self.enterFightAreaCount = 1
        self.bossIdList = {}
        self.isMoving = False
        self.stateForArrival = STATE_GS_HENG_WAIT
        self.index = 0
        
    def SetBossIdList(self, monsterId, posX, posY, posH):
        if monsterId not in self.bossIdList.keys():
#            self.bossIdList.append(id)
            self.bossIdList = {
                               monsterId : (posX, posY, posH)
                              }
