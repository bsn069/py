# coding:utf-8
import time
import random
import logging

class BossChallenge(object):
    def __init__(self):
        self.bossDict = {}
        self.needMove = False
        self.needSkill = False
        self.lastBossAppearTime = 0
        
    
    def SetBossDict(self, bossId, posX, posY):
        self.lastBossAppearTime = time.time()
        self.bossDict[bossId] = {
                                       "pos" : (posX, posY)
                                       }
        
    def GetBossDict(self):
        if self.bossDict:
            bossId = random.choice(self.bossDict.keys())
            return self.bossDict[bossId]["pos"], bossId
        else:
            return (), 0