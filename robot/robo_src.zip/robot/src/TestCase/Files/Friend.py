# -*- coding:utf8 -*-
from Config.CaseDefine import *
import logging

class Friend(object):

    def __init__(self, family):
        self.family = family
        self.__ReSetSyncData()
        self.__ReSetRecommand()
        self.hasCleanFriends = False
        
        
    def __ReSetSyncData(self):
        self.__friendIdList = []
        self.__applyIdList = []
        self.__revengeeIdList = []
        
    def __ReSetRecommand(self):
        self.__recommandIdList = []
        
    def UpdateSyncData(self, data):
#         self.__ReSetSyncData()
        for friend in data.relationInfo.friendList:
            family_id = friend.familyInfo.familyId
            if family_id and family_id not in self.__friendIdList:
                self.__friendIdList.append(family_id)
        for apply in data.relationInfo.applyList:
            family_id = apply.familyInfo.familyId
            if family_id and family_id not in self.__applyIdList:
                self.__applyIdList.append(family_id)
                if self.family.caseId == CaseManager.JIAZU:#家族案例处理添加好友请求
                    self.family.Do_AgreeAddFriend(family_id)
        for revengee in data.relationInfo.revengeeList:
            family_id = revengee.familyInfo.familyId
            if family_id and family_id not in self.__revengeeIdList:
                self.__revengeeIdList.append(family_id)
        
        if data.removedFriendList:
            self.RemoveFriendIdList(data.removedFriendList[0])
        if data.removedReveneeList:
            self.RemoveRevengeeIdList(data.removedReveneeList[0])
        if data.removedApplyList:
            self.RemoveApplyIdList(data.removedApplyList[0])
            
    def UpdateRecommand(self, data):
#         self.__ReSetRecommand()
        for family in data.familyList:
            if family.familyId not in self.__recommandIdList:
                self.__recommandIdList.append(family.familyId)
            
    def GetFriendIdList(self):
        return self.__friendIdList
    
    def GetApplyIdList(self):
        return self.__applyIdList
    
    def GetRevengeeIdList(self):
        return self.__revengeeIdList
    
    def GetRecommandIdList(self):
        return self.__recommandIdList
    
    def RemoveFriendIdList(self, familyId):
        if familyId in self.__friendIdList:
            self.__friendIdList.remove(familyId)
    
    def RemoveApplyIdList(self, familyId):
        if familyId in self.__applyIdList:
            self.__applyIdList.remove(familyId)
    
    def RemoveRevengeeIdList(self, familyId):
        if familyId in self.__revengeeIdList:
            self.__revengeeIdList.remove(familyId)
        
    def RemoveRecommandIdList(self, familyId):
        if familyId in self.__recommandIdList:
            self.__recommandIdList.remove(familyId)
