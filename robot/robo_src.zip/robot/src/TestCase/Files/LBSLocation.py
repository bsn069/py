# -*- coding:utf8 -*-
import gevent
import logging
import random
import time
from Tools.Rand import Rand
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from Family import Family
from Tools.GenerateChinese import generate_chinese
from ModuleState.StateDefine import *

class LocationInfo(object):  
    def __init__(self):
        self.id = 0
        self.startTime = None
        self.longitude = 0
        self.latitude = 0
    

class Coordinate(object):
    LATITUDE_MAX = 49.0    #最大纬度
    LATITUDE_MIN = 22.0    #最小纬度
    LATITUDE_DIS = 3.0    #纬度距离
    
    LONGITUDE_MAX = 134.0   #最大经度
    LONGITUDE_MIN = 77.0    #最小经度
    LONGITUDE_DIS = 0.9    #经度距离
    
    ONELEVEL = 1
    TWOLEVEL = 2
    THREELEVEL = 3
    CASES = {
             ONELEVEL   : 30,       #重点区域
             TWOLEVEL   :  5,       #次级区域
             THREELEVEL :  1,       #全区
             }     
        
    def __init__(self):                 
        latitudeList = self.__GetList(self.LATITUDE_MAX, self.LATITUDE_MIN, self.LATITUDE_DIS)
        longigudeList = self.__GetList(self.LONGITUDE_MAX, self.LONGITUDE_MIN, self.LONGITUDE_DIS)
        self.totalBox = self.__GetBox(latitudeList, longigudeList) 
        
    def GetLocation(self):
        info = LocationInfo()
        info.id = random.randint(10000, 110000) #记录总量按10万来测就差不多
        level = Rand.weighted_choice(self.CASES)#根据权重分配单人or组队
        info.latitude, info.longitude = self.__GetXY(level)
        return info
    
    def GetIllLocation(self):
        info = LocationInfo()
        info.id = random.randint(10000, 110000) #记录总量按10万来测就差不多
        info.latitude, info.longitude = random.randint(-360, -360), random.randint(-360, -360)
        return info
    
    def __GetRandNumber(self, maxValue, number):
        return round(random.uniform(0, maxValue), number)
        
    def __GetXY (self, level):
        if  level == self.ONELEVEL:               #当为重点区域
            onelevel = self.totalBox[0:10]
            number = random.randint(0, len(onelevel)-1)
            x, y = onelevel[number][0], onelevel[number][1],
        elif level == self.TWOLEVEL:
            twolevel = self.totalBox[11:100]
            number = random.randint(0, len(twolevel)-1)
            x, y = twolevel[number][0], twolevel[number][1],
        else:
            threelevel = self.totalBox[100:]
            number = random.randint(0, len(threelevel)-1)
            x, y = threelevel[number][0], threelevel[number][1],
            
        return x + self.__GetRandNumber(self.LONGITUDE_DIS, 3), y + self.__GetRandNumber(self.LATITUDE_DIS, 3)

     
    def __GetList(self, maxValue, minValue, distance):
        list1 = []
        while minValue <= maxValue:
            list1.append(round(minValue, 3) )
            minValue += distance
        return  list1
    
    def __GetBox(self, listX, listY):
        list1 = []
        for x in range(len(listX)):
            for y in range(len(listY)):
                list1.append((listX[x], listY[y]))
        return list1
    
GetLocation = Coordinate().GetLocation
GetIllLocation = Coordinate().GetIllLocation


    
# class Location(object):    
#     def __init__(self, timeout=180):
#         self.timeout = timeout
#         self.locationServerNetPackHandle = LocationServerNetPackHandle(self)
#         
#     
#     def ConnectLocationServer(self, address):
#         self.locationServerNetPackHandle.ConnectLocationServer(address)
#         
#     def Uninit(self):
#         if self.locationServerNetPackHandle:
#             self.locationServerNetPackHandle.Uninit()
#             self.locationServerNetPackHandle = None
# 
#     
#     def SetLocationGeography(self, familyId):
#         self.family.locationServerNetPackHandle.Do_SetLocationGeography(familyId)
#     
#     #得到玩家位置信息
#     def GetLocationGeography(self, familyId):
#         self.family.locationServerNetPackHandle.Do_GetLocationGeography(familyId)
#                   
#     #设置玩家位置信息
#     def SetKinLocationGeography(self, familyId):
#         self.family.locationServerNetPackHandle.Do_SetKinLocationGeography(familyId)
#         
#     #得到玩家位置信息
#     def GetKinLocationGeography(self, familyId):
#         self.family.locationServerNetPackHandle.Do_GetKinLocationGeography(familyId)
#         
#     def ILLDo_SetLocationGeography(self, familyId):
#         self.family.locationServerNetPackHandle.ILLDo_SetLocationGeography(familyId)
#         
#     def LocationServerStart(self): 
#         paly = Coordinate()
#         self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
#         self.SetLocationGeography(self.family.Play[paly.familyId]['familyId'])
#     
#     def ILL_LocationServerStart(self):
#         paly = Coordinate()
#         self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
#         self.ILLDo_SetLocationGeography(self.family.Play[paly.familyId]['familyId'])
#     
#     def ILL_SetKinLocationGeography(self):
#         paly = Coordinate()
#         self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
#         self.family.locationServerNetPackHandle.ILLDo_SetKinLocationGeography(self.family.Play[paly.familyId]['familyId'])
