# coding:utf-8
from Config.RoleFigures import *
import logging

class LineInfo(object):
    def __init__(self):
        self.lineInfo = None
        self.lineList = None
        
    def GetHotlineId(self, maxPlayerCount=150):
        if self.lineList:
            curMaxPalyerCount = 0
            curMaxPlayerCountLineId = 0
            for line in self.lineList.lines:
                maxCount = min(maxPlayerCount, line.max_player_count)
                if line.player_count < maxCount and curMaxPalyerCount < line.player_count:
                    curMaxPalyerCount = line.player_count
                    curMaxPlayerCountLineId = line.line_id
            return curMaxPlayerCountLineId
        else:
            return None
        
    def IsIdLegal(self, id):
        if self.lineList:
            for line in self.lineList.lines:
                if id == line.line_id:
                    return True
        return False
        
    def GetCurLineId(self):
        if self.lineInfo:
            return self.lineInfo.line_id
        return None
    