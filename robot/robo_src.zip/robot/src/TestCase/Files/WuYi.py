# -*- coding:utf8 -*-
class WuYi(object):

    def __init__(self):
        self.birdId = None
        self.birldPos = (0, 0, 0,) 
        self.sleeptime = 0
        
    def SetBirldId(self, birdId):
        self.birdId = birdId
    
    def SetBirldPos(self, PosX, PosY, PosZ):
        self.birldPos = (int(PosX), int(PosX), int(PosX)) 
