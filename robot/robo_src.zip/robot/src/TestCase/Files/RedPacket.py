# coding:utf-8
from Config.RoleFigures import *
import logging

class RedPacket(object):
    def __init__(self):
        self.redpacket = None
        self.channel = None
        self.member = None
        self.recvPackIds = {}
    