# coding:utf-8
import random
import logging

class Escort(object):
    def __init__(self):
        self.gameType = -1
        self.jieBiaoMemberType = -1
        self.jieBiaoCount = 0
        self.jieBiaoIsArrived = False
        self.jieBiaoPos = ()
        self.jieBiaoLastNpcId = 0
    
    def SetGameType(self, gameType):
        self.gameType = gameType
        
    def SetJieBiaoMemberType(self, memberType):
        self.jieBiaoMemberType = memberType

    def GetJieBiaoPos(self):
        return self.jieBiaoPos[0], self.jieBiaoPos[1]
        