# coding:utf-8
from Config.RoleFigures import *
import logging
import random

class CrossFriend(object):
    def __init__(self):
        self.askfriendgroupid = None
        self.familyid = None

