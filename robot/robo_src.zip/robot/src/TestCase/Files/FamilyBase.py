__author__ = 'Administrator'


class FamilyBase(object):
    def __init__(self):
        self.familyId = 0
        self.mainSex = 0
        self.mainName = ""
        self.coupleName = ""
        self.kidName = ""
        self.retire = False