# coding:utf-8
from Config.RoleFigures import *
import logging

class Appearance(object):
    def __init__(self, family):
        self.family = family
        self.allFashionIdList = self.GetAllFashionIdOrHairIdList(FashionList)
        self.allHairIdList = self.GetAllFashionIdOrHairIdList(HairList)
        self.allMountsIdList = [mid for mid in range(1, 12)]
        self.allPendantIdList = PendantList
        self.allBeltIdList = self.GetAllBeltIdList(BeltList)
        self.allHeaddressIdList = HeaddressList
        self.allQiBingIdList = self.GetAllQiBingIdList(QiBingList)
        self.AppearanceDict = {#每个value可能存在"avatarId"、"key"的key
                                    Appearance_Fashion : {},
                                    Appearance_Hair : {},
                                    Appearance_Mounts : {},
                                    Appearance_Pendant : {},
                                    Appearance_Belt : {},
                                    Appearance_Headdress : {},
                                    Appearance_QiBing : {},
                               }
    
    def GetRandomFaceBoneData(self):
        faceBone = self.family.gameConfig.get_face_bone_config()
        itemDict = {}
        for opid in faceBone:
            defaultValue = 0
            minValue = faceBone[opid][0]
            maxValue = faceBone[opid][1]
            default = int(round((defaultValue - minValue)/(maxValue - minValue) * 10000, 4))
            itemDict[opid]= {"default": default,
                                            "min" : 0,
                                            "max" : 10000}
        return itemDict
    
    def GetRandomFaceLookData(self):
        face_look = self.family.gameConfig.get_face_look_config()
        return face_look
    
    def GetAllFashionIdOrHairIdList(self, itemIdList):
        othersIdList = []
        for itemId in itemIdList:
            for increment in [100, 200, 300]:
                othersIdList.append(itemId+increment)
        return itemIdList + othersIdList
    
    def GetAllBeltIdList(self, itemIdList):
        othersIdList = []
        for itemId in itemIdList:
            if itemId in SpecialBeltList:
                for faction in FactionList:
                    idx = faction - 1
                    if idx:
                        othersIdList.append(itemId + idx * 5)
        return itemIdList + othersIdList
    
    def GetAllQiBingIdList(self, itemIdList):
        othersIdList = []
        for itemId in itemIdList:
            for faction in FactionList:
                    idx = faction - 1
                    if idx:
                        othersIdList.append(itemId + idx * 200)
        return itemIdList + othersIdList
    
    def SetAllAvatarsData(self, avatarList):
        for avatar in avatarList:
            avatarId = avatar.avatarId
            key = avatar.key
            if avatarId in self.allFashionIdList:
                self.AppearanceDict[Appearance_Fashion]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Fashion]["key"] = key
            elif avatarId in self.allHairIdList:
                self.AppearanceDict[Appearance_Hair]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Hair]["key"] = key
            elif avatarId in self.allMountsIdList:
                self.AppearanceDict[Appearance_Mounts]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Mounts]["key"] = key
            elif avatarId in self.allPendantIdList:
                self.AppearanceDict[Appearance_Pendant]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Pendant]["key"] = key
            elif avatarId in self.allBeltIdList:
                self.AppearanceDict[Appearance_Belt]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Belt]["key"] = key
            elif avatarId in self.allHeaddressIdList:
                self.AppearanceDict[Appearance_Headdress]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_Headdress]["key"] = key
            elif avatarId in self.allQiBingIdList:
                self.AppearanceDict[Appearance_QiBing]["avatarId"] = avatarId
                self.AppearanceDict[Appearance_QiBing]["key"] = key
            else:
                logging.error("avatarId %d can't find in Appearance SetAllAvatarsData method" % avatarId)