# coding:utf-8
import logging
import random

class Master(object):
    def __init__(self):
        self.masterMsgIdList = []
        self.apprenticeMsgIdList = []
        self.myMasterId = 0
        self.myApprenticeId = 0
        self.myMasterMember = {}
        self.task = ""
        self.hasArrival = False
        self.hasOthersArrival = False
        self.trainingPlaceDict = {
                                  "0" : "传功点-茶台",
                                  "1" : "传功点-敬师堂",
                                  "2" : "传功点-武圣关公",
                                  "3" : "传功点-文圣孔子"
                                  }
        self.trainingPlace = ""
        self.hasLeave = False
    
    #设置师徒招募信息
    def SetSchoolMsgIdList(self, type, id):
        if type == 0:
            if id not in self.masterMsgIdList:
                self.masterMsgIdList.append(id)
        elif type == 1:
            if id not in self.apprenticeMsgIdList:
                self.apprenticeMsgIdList.append(id)
        else:
            logging.debug("[SchoolMsgIdList error] Can not find this type !")
    
    #移除师父招募id
    def RemoveMasterMsgIdList(self, id):
        if id in self.masterMsgIdList:
            self.masterMsgIdList.remove(id)
    
    #移除徒弟招募id
    def RemoveApprenticeMsgIdList(self, id):
        if id in self.apprenticeMsgIdList:
            self.apprenticeMsgIdList.remove(id)
    
    #设置传功地点
    def SetTrainingPlace(self, place):
        if place in self.trainingPlaceDict.keys():
            self.trainingPlace = self.trainingPlaceDict[place]
        else:
            logging.debug("Can not find Training Place : %s" % place)
    
    