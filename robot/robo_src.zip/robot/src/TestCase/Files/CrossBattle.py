# coding:utf-8
from Config.RoleFigures import *
import logging
import random

class CrossBattle(object):
    def __init__(self):
        self.CrossroomID = 0
        self.SencePos = {
                         SenceYouBiShenLin:(72.04, 62.64),
                         SenceHenXuJingShenMu:(60.01, 64.88),
                         SenceJianGeZhiShang1:(73.60, 51.06),
                         SenceHenXuJingXuanBin:(60.11, 64.39),
                         SenceHenXuJingJiaoZhuo:(63.04, 60.42),
                         SenceCuiYan:(53.48, 50.72),
                         SenceJianGeZhiShang2:(74.81, 54.39),
                         SenceHanWuYiJi:(35.70, 30.31),
                         }
        self.index = 0
        self.maxindex = random.randint(10, 20)
        self.type = False
