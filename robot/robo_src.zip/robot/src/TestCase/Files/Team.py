# -*- coding:utf-8 -*-
__author__ = 'Administrator'
import random
import logging
from net.ProtoBuffer.ComProtocol_pb2 import *
from Config.RoleFigures import *

class Team(object):

    TEAM_MEMBER_LIMIT = {
        TEAM_TYPE_FREE:(2, 5),
        TEAM_TYPE_FISH:(1, 5),
        TEAM_TYPE_YA_BIAO:(3, 5),
#        TEAM_TYPE_TAN_BAO:(3, 5),
        TEAM_TYPE_LEAGUE_MATCH:(1, 3),
        TEAM_TYPE_BATTLE_MATCH:(1, 5),
#        TEAM_TYPE_KINDAILY:(2,5),
#        TEAM_TYPE_XOYO_LOW:(2, 5),
#        TEAM_TYPE_XOYO_MID:(3, 5),
#        TEAM_TYPE_XOYO_HIGH:(3, 5),
        TEAM_TYPE_TEA:(1, 3),
        TEAM_TYPE_HENG_XU_JING:(5, 5),
        TEAM_TYPE_FREE_BIG:(15,15),
        # 以下为自定义队伍类型
        TEAM_TYPE_LONGMEN:(2, 2),
        TEAM_TYPE_Lishan:(2,2),
        TEAM_TYPE_MAPLE:(2, 5),
        TEAM_TYPE_MAINTASK:(2, 5),
        TEAM_TYPE_SKYLANTERN:(2, 2),
        TEAM_TYPE_JIE_BIAO:(2, 5),
        TEAM_TYPE_HENG_DAO_SHU:(5, 5),
        TEAM_TYPE_ACTIVITY_LUCKSTAR:(3, 5),
        TEAM_TYPE_BEACH:(2, 5),
        TEAM_TYPE_SKILLTEST:(5, 5),
        TEAM_TYPE_XIAOMIJING:(3, 5),
        TEAM_TYPE_PUHISHEVIL:(1,1),
        TEAM_TYPE_GUARDIAN:(1,5),
        TEAM_TYPE_VALENTINE:(2,2),
    }

    def __init__(self, family):
        self.isLoginSync = True
        self.family = family
        self.id = 0
        self.leaderFamilyId = 0
        self.type = TEAM_TYPE_FREE
        self.typeEx = TEAM_TYPE_FREE
        self.memberList = {}
        self.memberCheckList = []
        self.inviteId = 0
        self.memberLimit = 0
        self.accountId = 0 # 分发账号的逻辑队伍ID
        self.teamCreateType = 0
        self.isBegin = False
        self.leaderinf = None
        self.leadergroupid = None
    def Update(self, teamInfoSync):
#         if self.isLoginSync:
#             self.isLoginSync = False
#             return
        if self.isBegin:
            self.leaderFamilyId = teamInfoSync.leaderFamilyId
        self.id = teamInfoSync.teamid
        lastMemberIdList = self.memberList.keys()
        self.memberList = {}
        newMemberList = []
        for member in teamInfoSync.memberList:
            if member.familyId != self.family.familyId and member.familyId not in lastMemberIdList:
                newMemberList.append(member.familyId)
            self.memberList[member.familyId] = member
            
        if self.IsLeader(self.family.familyId) and newMemberList:#队长邀请新队友进入队伍频道
            logging.debug("队长邀请新队友进入队伍频道, newMemberList = %s" % newMemberList)
            self.family.gameServerNetPackHandle.ChatRoomInviteMember(self.family.chatroom.roomId, newMemberList)

    def SyncTeamMember(self, teamMemberInfoSync):
        synMember = teamMemberInfoSync.member
        familyId = synMember.familyId
        dataMark = synMember.dataMark
        member = None
                
        if self.id != teamMemberInfoSync.teamid:
            return
        if familyId in self.memberList:
            member = self.memberList[familyId]
        if member is None:
            return
            
        # 注：根据标志位来区分哪些数据有更新
        if (dataMark & (1 << SyncTeamMemberInfo_gameServerId)) != 0:
            member.gameServerId = synMember.gameServerId;
        if (dataMark & (1 << SyncTeamMemberInfo_member)) != 0:
            member.member = synMember.member;
        if (dataMark & (1 << SyncTeamMemberInfo_kinId)) != 0:
            member.kinId = synMember.kinId;
        if (dataMark & (1 << SyncTeamMemberInfo_faction)) != 0:
            member.faction = synMember.faction;
        if (dataMark & (1 << SyncTeamMemberInfo_name)) != 0:
            member.name = synMember.name;
        if (dataMark & (1 << SyncTeamMemberInfo_portrait)) != 0:
            member.portrait = synMember.portrait;
        if (dataMark & (1 << SyncTeamMemberInfo_fight)) != 0:
            member.fight = synMember.fight;
        if (dataMark & (1 << SyncTeamMemberInfo_level)) != 0:
            member.level = synMember.level;
        if (dataMark & (1 << SyncTeamMemberInfo_hp)) != 0:
            member.hp = synMember.hp;
        if (dataMark & (1 << SyncTeamMemberInfo_maxhp)) != 0:
            member.maxhp = synMember.maxhp;
        if (dataMark & (1 << SyncTeamMemberInfo_sceneType)) != 0:
            member.sceneType = synMember.sceneType;
        if (dataMark & (1 << SyncTeamMemberInfo_sceneName)) != 0:
            member.sceneName = synMember.sceneName;
        if (dataMark & (1 << SyncTeamMemberInfo_sceneTemplateId)) != 0:
            member.sceneTemplateId = synMember.sceneTemplateId;
        if (dataMark & (1 << SyncTeamMemberInfo_sceneInstanceId)) != 0:
            member.sceneInstanceId = synMember.sceneInstanceId;
        if (dataMark & (1 << SyncTeamMemberInfo_lineId)) != 0:
            member.lineId = synMember.lineId;
        if (dataMark & (1 << SyncTeamMemberInfo_posX)) != 0:
            member.posX = synMember.posX;
        if (dataMark & (1 << SyncTeamMemberInfo_posY)) != 0:
            member.posY = synMember.posY;
        if (dataMark & (1 << SyncTeamMemberInfo_fightState)) != 0:
            member.fightState = synMember.fightState;
        if (dataMark & (1 << SyncTeamMemberInfo_isOnline)) != 0:
            member.isOnline = synMember.isOnline;
        if (dataMark & (1 << SyncTeamMemberInfo_isCanSignUp)) != 0:
            member.isCanSignUp = synMember.isCanSignUp;
        if (dataMark & (1 << SyncTeamMemberInfo_failSignUpCode)) != 0:
            member.failSignUpCode = synMember.failSignUpCode;
        if (dataMark & (1 << SyncTeamMemberInfo_leagueScore)) != 0:
            member.leagueScore = synMember.leagueScore;
        if (dataMark & (1 << SyncTeamMemberInfo_leagueStage)) != 0:
            member.leagueStage = synMember.leagueStage;
        if (dataMark & (1 << SyncTeamMemberInfo_equipSkill1)) != 0:
            member.equipSkill1 = synMember.equipSkill1;
        if (dataMark & (1 << SyncTeamMemberInfo_equipSkill2)) != 0:
            member.equipSkill2 = synMember.equipSkill2;
        if (dataMark & (1 << SyncTeamMemberInfo_equipSkill3)) != 0:
            member.equipSkill3 = synMember.equipSkill3;
        if (dataMark & (1 << SyncTeamMemberInfo_equipSkill4)) != 0:
            member.equipSkill4 = synMember.equipSkill4;

    def IsAllSigned(self):
        is_all_signup = True
        for id, member in self.memberList.items():
            if not member.isSignUp:
                is_all_signup = False
                break
        return is_all_signup

    def IsInTeam(self):
        return self.id != 0

    def MemberCount(self):
        return len(self.memberList)

    def IsLeader(self, family_id=None):
        if family_id:
            return family_id == self.leaderFamilyId
        else:
            return self.family.familyId == self.leaderFamilyId
    
    def SetTeamLimit(self, count):
        self.memberLimit = count

    def GetTeamLimit(self):
        return self.memberLimit
    
    def IsAllNearby(self):
        scene_id = -1
        instance = -1
        for member in self.memberList.values():
            if scene_id == -1 or instance == -1:
                scene_id = member.sceneTemplateId
                instance = member.sceneInstanceId
            elif scene_id != member.sceneTemplateId or instance != member.sceneInstanceId:
                return False
        return True
    
    def SceneTemplateId(self):
        return self.memberList[self.family.familyId].sceneTemplateId
    
    def SceneInstanceId(self):
        return self.memberList[self.family.familyId].sceneInstanceId

class TeamBaseInfo(object):
    def __init__(self, teamId, teamType, leaderFamilyId, groupId, memberCount=5):
        self.id = teamId
        self.type = teamType
        self.leaderFamilyId = leaderFamilyId
        self.groupId = groupId
        self.memberCount = memberCount


class TeamManager(object):
    def __init__(self, family):
        self.myteam = Team(family)
        self.recruitList = {}
        self.applyList = {}
