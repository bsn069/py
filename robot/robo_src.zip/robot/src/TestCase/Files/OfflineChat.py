# coding:utf-8
from Config.RoleFigures import *
import logging

class OfflineChat(object):
    def __init__(self):
        self.member = None
        self.targetId = 0