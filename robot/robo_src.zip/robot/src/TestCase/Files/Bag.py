# coding:utf-8
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from Config.RoleFigures import *
import logging

class Bag(object):
    def __init__(self, family):
        self.family = family
        self.consumeBag = {}
        self.taskItemBag = {}
        self.bookBag = {}
        self.recycleBag = {}
        self.member1Bag = {
                                "Equip" : {},
                                "Suite" : {},
                                "Book" : {},
                           }
        self.member2Bag = {
                                "Equip" : {},
                                "Suite" : {},
                                "Book" : {},
                           }
        self.member3Bag = {
                                "Equip" : {},
                                "Suite" : {},
                                "Book" : {},
                           }
        self.memberType2Bag = {
                               FAMILY_MEMBER_TYPE_MAIN : 'self.member1Bag',
                               FAMILY_MEMBER_TYPE_COUPLE : 'self.member2Bag',
                               FAMILY_MEMBER_TYPE_KID : 'self.member3Bag',
                               }
        self.roomType2MemberBagKey = {
                                        emMemberRoomEquip : "Equip",
                                        emMemberRoomSuite : "Suite",
                                        emMemberRoomBook : "Book",
                                   }
        self.roomType2Bag = {
                               emPublicRoomBag : 'self.consumeBag',
                               emPublicRoomTask : 'self.taskItemBag',
                               emPublicRoomBook : 'self.bookBag',
                               emPublicRoomRecycle : 'self.recycleBag'
                               }
        self.g2Bag = {
                            emItemGEquip : {'bag' : 'self.consumeBag', 'pb' : EquipDbData},
                            emItemGStone : {'bag' : 'self.consumeBag', 'pb' : ItemSerializeInfoBase},
                            emItemGBook : {'bag' : 'self.bookBag', 'pb' : BookDbData},
                            emItemGMedicine : {'bag' : 'self.consumeBag', 'pb' : ItemSerializeInfoBase},
                            emItemGConsume : {'bag' : 'self.consumeBag', 'pb' : ItemSerializeInfoBase},
                            emItemGTask : {'bag' : 'self.taskItemBag', 'pb' : ItemSerializeInfoBase},
                            emItemGRandequip : {'bag' : 'self.consumeBag', 'pb' : RandEquipDbData},
                            emItemGRandStone :{'bag' : 'self.consumeBag', 'pb' : RandStoneDbData },
                      }
        #GDPL与itemid的映射，用于更新item的数量
        self.bagMapping = {}
        #拍卖行
        self.tradeItemList = ['_'.join(str(y) for y in x) for x in BAOSHILIST+TREASURES+[self.GetUnIdedEquipmentsId(score, quality, faction, part) for part in EquipmentsPart for faction in FactionList for quality in range(1, 6) for score in range(1, 6)]]
        self.tradeItemIdDict = {}
        self.mySaleItemDict = {}
        self.tradeMailCoinDict = {} #拍卖行邮件银两统计
        self.tradeMailItemDict = {} #拍卖行邮件物品统计
        self.needCleanSaleList = False
        #角色数据
        self.equipGridEnhance = {}
        self.stoneEnchase = {}
        self.meridianSync = {}
        self.bookExp = {}
    
    def SetBagItem(self, itemData, itemPos, isRecycle):
        if itemData.itemId in self.bagMapping:
            logging.debug("item %s has existed in self.bagMapping %s" % (itemData.itemId, self.bagMapping))
            return
        g = itemData.itemIndex.g
        gdpl = "{g}_{d}_{p}_{l}".format(
                g=itemData.itemIndex.g,
                d=itemData.itemIndex.d,
                p=itemData.itemIndex.p,
                l=itemData.itemIndex.l)
        
        if str(itemData).find("itemSerializeInfo") != -1:
            itemSerializeInfo = itemData.itemSerializeInfo
        else:
            itemSerializeInfo = ""
            
        if g in self.g2Bag:
            if itemSerializeInfo:
                pb = self.g2Bag[g]['pb']
                if isRecycle:
                    bagDict = self.recycleBag
                    bagName = self.roomType2Bag[emPublicRoomRecycle]
                else:
                    bagDict = eval(self.g2Bag[g]['bag'])
                    bagName = self.g2Bag[g]['bag']
                item = self.GetItemSerializeInfo(itemSerializeInfo, pb)
                if str(item).find("baseData") != -1:
                    bind = item.baseData.bind
                    count = item.baseData.count
                else:
                    bind = item.bind
                    count = item.count
                    
                if itemPos:
                    equipData = {}
                    bookData = None
                    if g == emItemGRandequip:
                        equipData["holeData"] = item.holeData
                    elif g == emItemGBook:
                        if str(item).find("book") != -1:
                            bookData = item.book.bookPart
                    self.SetItemByMemberType(itemPos, itemData.itemId, gdpl, bind, count, equipData=equipData, bookData=bookData)
                else:
                    if isRecycle:
                        slotPosition = self.GetSortRecycleItemSlotPosition()
                    else:
                        slotPosition = self.GetSortItemSlotPosition(gdpl, bagDict)
                    self.MergeBagDict(bagDict, {gdpl : {bind : {itemData.itemId : {"count" : count, "slotPosition" : slotPosition}}}})
                self.bagMapping[itemData.itemId] = {"gdpl" : gdpl, "bind" : bind, "bag" : bagName}
            else:
                logging.debug("gdpl %s item's itemSerializeInfo is none; itemData = %s" % (gdpl, itemData))
        else:
            logging.error("[ERROR] g2Bag Can not find key g %s !" % g)
    
    #计算物品在背包里的位置，且更新其他物品的位置
    def GetSortItemSlotPosition(self, gdpl, bagDict):
        g, d, p, l = map(int, gdpl.split("_"))
        idx = -1
        if not bagDict:
            idx = 0
        else:
            for b_gdpl in bagDict:
                b_g, b_d, b_p, b_l = map(int, b_gdpl.split("_"))
                if g<b_g or (g==b_g and d<b_d) or (g==b_g and d==b_d and p < b_p) or (g==b_g and d==b_d and p == b_p and l < b_l):#新物品排在当前物品前
                    for bind in bagDict[b_gdpl]:
                        for itemId in bagDict[b_gdpl][bind]:
                            slotPosition = bagDict[b_gdpl][bind][itemId]['slotPosition']
                            if idx == -1 or slotPosition < idx:
                                idx = slotPosition
                            bagDict[b_gdpl][bind][itemId]['slotPosition'] += 1
                else:#新物品排在当前物品后面
                    for bind in bagDict[b_gdpl]:
                        for itemId in bagDict[b_gdpl][bind]:
                            slotPosition = bagDict[b_gdpl][bind][itemId]['slotPosition']
                            if idx == -1 or slotPosition >= idx:
                                idx = slotPosition+1
        return idx
    
    #计算物品子啊回购背包内的位置
    def GetSortRecycleItemSlotPosition(self):
        idx = 0
        for gdpl in self.recycleBag:
            for bind in self.recycleBag[gdpl]:
                for itemId in self.recycleBag[gdpl][bind]:
                    idx += 1
        return idx
    
    #获取不分类物品的位置信息
    def GetUnSortItemSlotPosition(self, g, d):
        if g in [1, 7]:
            slotPosition = d - 1
            return slotPosition
    
    #根据itemId查找其对应的背包位置
    def GetItemSlotPositionByItemId(self, itemId):
        bag = self.GetMappingBag(itemId)
        gdpl = self.bagMapping[itemId]["gdpl"]
        bind = self.bagMapping[itemId]["bind"]
        return bag[gdpl][bind][itemId]["slotPosition"]
    
    def SetItemByMemberType(self, itemPos, itemId, gdpl, bind, count, equipData={}, bookData=None):
        memberType = itemPos.memberType
        roomType = itemPos.roomType
        slotPosition = itemPos.slotPosition
        if memberType:
            memberBag = eval(self.memberType2Bag[memberType])
            memberBagKey =  self.roomType2MemberBagKey[roomType]
            bagDict =  memberBag[memberBagKey]
            if equipData:
                logging.debug("gdpl = %s, equipData['holeData'] = %s" % (gdpl, equipData["holeData"]))
                if memberType not in self.stoneEnchase:
                    self.stoneEnchase[memberType] = {}
                memberEquipData = self.stoneEnchase[memberType]
                for idx, holeData in enumerate(equipData["holeData"]):
                    if holeData.stone.g and holeData.stone.d and holeData.stone.p and holeData.stone.l:
                        if slotPosition not in memberEquipData:
                            memberEquipData[slotPosition] = {}
                        equipHoleData = memberEquipData[slotPosition]
                        e_gdpl = "_".join((str(x) for x in [holeData.stone.g, holeData.stone.d, holeData.stone.p, holeData.stone.l]))
                        equipHoleData[idx] = e_gdpl
                if not memberEquipData:
                    del self.stoneEnchase[memberType]
            elif bookData:
                logging.debug("gdpl = %s, bookData = %s" % (gdpl, bookData))
                if memberType not in self.bookExp:
                    self.bookExp[memberType] = {}
                memberBookData = self.bookExp[memberType]
                level = bookData[0].level
                exp = bookData[0].exp 
                if not (level==1 and exp==0):
                    if slotPosition not in memberBookData:
                        memberBookData[slotPosition] = {}
                    bookSlotData = memberBookData[slotPosition]
                    totalExp = 0
                    for l in range(2, level+1):
                        if l == 1:
                            break
                        totalExp += self.family.equip.bookExpList[i - 2] 
                    totalExp += exp
                    bookSlotData["gdpl"] = gdpl
                    bookSlotData["totalExp"] = totalExp
        else:
            bagDict = eval(self.roomType2Bag[roomType])
        
        self.MergeBagDict(bagDict, {gdpl : {bind : {itemId : {"count" : count, "slotPosition" : slotPosition}}}})
            
    def GetItemSerializeInfo(self, itemSerializeInfo, pb):
        try:
            item = pb()
            item.ParseFromString(itemSerializeInfo)
        except Exception, e:
            logging.error("[ERROR] Bag GetItemSerializeInfo Error : %s" % e)
        return item
    
    def UpdateItemCount(self, itemId, change):
        try:
            mapping = self.bagMapping[itemId]
            bag = self.GetMappingBag(itemId)
            bag[mapping["gdpl"]][mapping["bind"]][itemId]["count"] += change
        except Exception, e:
            logging.error("[ERROR] Bag UpdateItemCount Error : %s" % e)
    
    #使用物品后的背包信息同步
    def UseItemSync(self, respond):
        itemId = respond.itemId
        if itemId in self.bagMapping.keys():
            logging.debug("Use itemid = %s, gdpl = %s" % (itemId, self.bagMapping[itemId]["gdpl"]))
            if self.bagMapping[itemId]["bag"] in self.memberType2Bag.values():
                logging.debug("因为有个穿装备会发两条协议的bug, 所以需要在此跳出一下")
                return
            gdpl = self.bagMapping[itemId]["gdpl"]
            g, d, p, l = map(int, gdpl.split("_"))
            if g in [emItemGEquip, emItemGRandequip]:#武器的使用会跑到对应的人物装备栏
                memberType = respond.member
                newBag = self.memberType2Bag[memberType]
                newBagKey = self.roomType2MemberBagKey[respond.itemPos.roomType]
                bagDict = eval(newBag)[newBagKey]
                self.DelBagItem(itemId, newBag=newBag, newBagKey=newBagKey)
                ##查找是不是有相同部位的装备已穿上
                for equip_gdpl in bagDict.keys():
                    e_g, e_d, e_p, e_l = map(int, equip_gdpl.split("_"))
                    if e_d == d:#将已穿上的装备信息更换到物品背包里
                        e_itemId = bagDict[equip_gdpl][True].keys()[0]
                        self.DelBagItem(e_itemId, isUnSort=True, newBag=self.g2Bag[e_g]['bag'])
                        slotPosition = self.GetSortItemSlotPosition(equip_gdpl, self.consumeBag)
                        self.MergeBagDict(self.consumeBag, {equip_gdpl : {True : {e_itemId : {"count" : 1, "slotPosition" : slotPosition}}}})
                #将物品加到人物装备栏
                slotPosition = self.GetUnSortItemSlotPosition(g, d)
                self.MergeBagDict(bagDict, {gdpl : {True : {itemId : {"count" : 1, "slotPosition" : slotPosition}}}})
    
    #装备秘籍后背包信息同步
    def UseBookSync(self, respond, isUnEquip=False):
        itemId = respond.itemId
        slotPosition = respond.slotPos.slotPosition
        memberType = respond.slotPos.memberType
        gdpl = self.bagMapping[itemId]["gdpl"]
        if isUnEquip:
            b_g, b_d, b_p, b_l = map(int, gdpl.split("_"))
            self.DelBagItem(itemId, isUnSort=True, newBag=self.g2Bag[b_g]['bag'])
            b_slotPosition = self.GetSortItemSlotPosition(gdpl, self.bookBag)
            self.MergeBagDict(self.bookBag, {gdpl : {True : {itemId : {"count" : 1, "slotPosition" : b_slotPosition}}}})
        else:
            newBag = self.memberType2Bag[memberType]
            newBagKey = self.roomType2MemberBagKey[respond.slotPos.roomType]
            bagDict = eval(newBag)[newBagKey]
            self.DelBagItem(itemId, newBag=newBag, newBagKey=newBagKey)
            #查找是不是有相同部位的秘籍已穿上
            for book_gdpl in bagDict.keys():
                b_g, b_d, b_p, b_l = map(int, book_gdpl.split("_"))
                for b_itemId in bagDict[book_gdpl][True]:
                    if bagDict[book_gdpl][True][b_itemId]["slotPosition"] == slotPosition:
                        self.DelBagItem(b_itemId, isUnSort=True, newBag=self.g2Bag[b_g]['bag'])
                        b_slotPosition = self.GetSortItemSlotPosition(book_gdpl, self.bookBag)
                        self.MergeBagDict(self.bookBag, {book_gdpl : {True : {b_itemId : {"count" : 1, "slotPosition" : b_slotPosition}}}})
            #将物品加到人物秘籍栏
            self.MergeBagDict(bagDict, {gdpl : {True : {itemId : {"count" : 1, "slotPosition" : slotPosition}}}})
    
    #更新删除物品后背包内其他物品的位置
    def DelItemSlotPositionSync(self, bag, slotPosition):
#         logging.debug("Del修改前：%s" % bag)
        for gdpl in bag:
            for bind in bag[gdpl]:
                for itemId in bag[gdpl][bind]:
                    if bag[gdpl][bind][itemId]["slotPosition"] > slotPosition:
                        bag[gdpl][bind][itemId]["slotPosition"] -= 1
#         logging.debug("Del修改后：%s" % bag)
    
    #删除背包物品
    def DelBagItem(self, itemId, isUnSort=False, newBag="", newBagKey=""):
#         logging.debug("DelBagItem itemId=%s" % itemId)
        try:
            if itemId in self.bagMapping.keys():
                logging.debug("Del itemid = %s, gdpl = %s" % (itemId, self.bagMapping[itemId]["gdpl"]))
                bag = self.GetMappingBag(itemId)
                gdpl = self.bagMapping[itemId]["gdpl"]
                bind = self.bagMapping[itemId]["bind"]
                slotPosition = bag[gdpl][bind][itemId]["slotPosition"]
                if len(bag[gdpl][bind]) == 1:
                    if len(bag[gdpl]) == 1:
                        del bag[gdpl]
                    else:
                        del bag[gdpl][bind]
                else:
                    del bag[gdpl][bind][itemId]
                    
                if not isUnSort:#删除的不为人物不分类的物品
                    #更新删除物品后背包内其他物品的位置
                    self.DelItemSlotPositionSync(bag, slotPosition)
                if newBag:#是否为更换背包的操作
                    self.bagMapping[itemId]["bag"] = newBag
                    if newBag in self.memberType2Bag.values():
                        assert newBagKey
                        self.bagMapping[itemId]["key"] = newBagKey
                    elif "key" in self.bagMapping[itemId]:
                        del self.bagMapping[itemId]["key"]
                else:
                    del self.bagMapping[itemId]
                
        except Exception, e:
                logging.error("[ERROR] Bag DelBagItem Error : %s" % e)
    
    #获取映射字典中对应的背包
    def GetMappingBag(self, itemId):
        bagName = self.bagMapping[itemId]["bag"]
        if bagName in self.memberType2Bag.values():
            bagKey = self.bagMapping[itemId]["key"]
            bag = eval(bagName)[bagKey]
        else:
            bag = eval(bagName)
        return bag
    
    def GetItemId(self, g, d, p, l):
        """
            获取第一个ItemId
        """
        gdpl = "{g}_{d}_{p}_{l}".format(g=g, d=d, p=p, l=l)
        for itemId in self.bagMapping.keys():
            if self.bagMapping[itemId]['gdpl'] == gdpl:
                return itemId
        return None

    def GetItemCount(self, g, d, p, l):
        """
        :return: 消耗品背包的物品总数
        """
        result = 0
        gdpl = "{g}_{d}_{p}_{l}".format(g=g, d=d, p=p, l=l)
        if gdpl in self.consumeBag:
            for item_ids in self.consumeBag[gdpl].values():
                for item in item_ids.values():
                    if 'count' in item:
                        result += item['count']
        return result
    
    #获取全部背包物品
    def GetAllBag(self):
        bagDict = {}
        for d in [self.consumeBag, self.taskItemBag, self.member1Bag, self.member2Bag, self.member3Bag]:
            bagDict.update(d)
        return bagDict
    
    #获取拍卖行相关物品
    def GetTradeBag(self):
        tradeDict = {}
        bagDict = self.GetAllBag()
        for gdpl in self.tradeItemIdDict:
            if gdpl in bagDict and False in bagDict[gdpl]:
                tradeDict[gdpl] = bagDict[gdpl][False].keys()
        return tradeDict
    
    #获取拍卖行相关物品与数量
    def GetAllTradeItemCount(self):
        allTradeDict = {}
        bagDict = self.GetAllBag()
        for gdpl in bagDict:
            if gdpl in self.tradeItemList:
                for bind in bagDict[gdpl]:
                    for itemId in bagDict[gdpl][bind]:
                        if gdpl in allTradeDict:
                            allTradeDict[gdpl] += bagDict[gdpl][bind][itemId]["count"] 
                        else:
                            allTradeDict[gdpl] = bagDict[gdpl][bind][itemId]["count"] 
        return allTradeDict
    
    #获取拍卖行相关物品信息
    def GetAllTradeItemInfo(self):
        allTradeItemInfo = {}
        bagDict = self.GetAllBag()
        for gdpl in bagDict:
            if gdpl in self.tradeItemList and False in bagDict[gdpl]:
                allTradeItemInfo[gdpl] = tuple(map(eval, gdpl.split("_")))
        return allTradeItemInfo
    
    #计算未鉴定装备id
    def GetUnIdedEquipmentsId(self, score, quality, faction, part):
        '''    装备等级（score）、品质（quality）    '''
        l = (score - 1) * 5 + quality
        p = part * 100 + faction
        return 5, 20+part, faction, l
    
    #保存装备强化的数据
    def SetEquipGridEnhanceData(self, respond):
        memberType = respond.member
        if memberType not in self.equipGridEnhance:
            self.equipGridEnhance[memberType] = {}
        enhanceData = self.equipGridEnhance[memberType]
        equipD = respond.equipD
        if equipD in enhanceData:
            enhanceData[equipD] += 1
        else:
            enhanceData[equipD] = 1
    
    #保存宝石镶嵌的数据
    def SetStoneEnchaseData(self, respond):
        memberType = respond.equipPos.memberType
        slotPosition = respond.equipPos.slotPosition 
        if memberType not in self.stoneEnchase:
            self.stoneEnchase[memberType] = {}
        memberEquipData = self.stoneEnchase[memberType]
        if slotPosition not in memberEquipData:
            memberEquipData[slotPosition] = {}
        equipHoleData = memberEquipData[slotPosition]
        for idx, holeData in enumerate(respond.holeData):
            if idx == respond.holeIndex:
                gdpl = "_".join((str(x) for x in [holeData.stone.g, holeData.stone.d, holeData.stone.p, holeData.stone.l]))
                equipHoleData[idx] = gdpl
        
    #保存经脉同步信息
    def SetMerdianSyncData(self, meridianList):
        for meridian in meridianList:
            if meridian.member not in self.meridianSync:
                self.meridianSync[meridian.member] = {}
            memberData = self.meridianSync[meridian.member]
            for idx, meridianItem in enumerate(meridian.meridianItem):
                if idx not in memberData:
                    memberData[idx] = {}
                memberData[idx]["acupointLevel"] = meridianItem.acupointLevel
                memberData[idx]["valve"] = meridianItem.valve
                memberData[idx]["failedCount"] = meridianItem.failedCount
    
    #保存秘籍经验值
    def SetBookExpData(self, respond):
        itemId = respond.bookItemId
        bag = self.GetMappingBag(itemId)
        gdpl = self.bagMapping[itemId]["gdpl"]
        bind = self.bagMapping[itemId]["bind"]
        slotPosition = bag[gdpl][bind][itemId]["slotPosition"]
        memberType = self.family.gameServerNetPackHandle.memberType
        exp = respond.exp
        if memberType not in self.bookExp:
            self.bookExp[memberType] = {}
        memberBookData = self.bookExp[memberType]
        if slotPosition not in memberBookData:
            memberBookData[slotPosition] = {
                                                "gdpl" : gdpl,
                                                "totalExp" : exp,
                                            }
        else:
            #TODO:暂时没有处理秘籍卸下、重装操作导致的经验值处理的问题
            memberBookData[slotPosition]["totalExp"] += exp

    #将新物品合并到背包中
    def MergeBagDict(self, bagDict, newItemDict):
        mergeDict = self.Merge(bagDict, newItemDict)
#         logging.debug("合并前：%s" % bagDict)
        bagDict.clear()
        for key in mergeDict:
            bagDict[key] = mergeDict[key]
#         logging.debug("合并后：%s" % bagDict)
    
    #合并嵌套字典
    def Merge(self, a,b):
        ak = set(a.keys())
        bk = set(b.keys())
        c = ak & bk
        d = ak - bk
        e = bk - ak
        fd = {}
        for c0 in c:
            fd[c0] = self.Merge(a[c0],b[c0])
        for d0 in d:
            fd[d0] = a[d0]
        for e0 in e:
            fd[e0] = b[e0]
        return fd
    
    #合并非嵌套数值字典
    def MergeNonNestedDict(self, dictA, dictB):
        dictC = {}
        allKeyList = list(set(dictA.keys()+dictB.keys()))
        for key in allKeyList:
            if key in dictA and key in dictB:
                value = dictB[key] + dictA[key]
                if value != 0:
                    dictC[key] = value
            elif key in dictA:
                dictC[key] = dictA[key]
            else:
                dictC[key] = dictB[key]
        return dictC