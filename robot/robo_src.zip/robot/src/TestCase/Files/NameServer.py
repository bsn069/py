# -*- coding:utf8 -*-
import gevent
import logging
import random
import time
from NetPackHandle.NameServerNetPackHandle import *
from ModuleState.StateDefine import *
        
class Server(object):    
    def __init__(self, server):
        self.server = server
        self.ServerNetPackHandle = None
        self.state = 0
                
    def Uninit(self):
        if self.ServerNetPackHandle:
            self.ServerNetPackHandle.Uninit()
            self.ServerNetPackHandle = None
    
    def ConnectServer(self):
        self.ServerNetPackHandle = ServerNetPackHandle(self.server, self)
        self.ServerNetPackHandle.ConnectServer(self.server)
        
    def AskRoleNameRequest(self):
        self.ServerNetPackHandle.AskRoleNameRequest()
