# -*- coding:utf8 -*-
import random

class HomeLand(object):

    def __init__(self):
        self.myBoardMsg = []
        self.otherBoardMsg = []
        self.myMoodMsg = []
        self.otherMoodMsg = []
        self.otherFamilyId = []

    def UpdateMyBoard(self, data):
        self._ResetMyBoard()
        for msg in data.msgLst:
            self.myBoardMsg.append(msg)

    def UpdateOtherBoard(self, data):
        self._ResetOtherBoard()
        for msg in data.msgLst:
            self.otherBoardMsg.append(msg)

    def UpdateMyMood(self, data):
        self._ResetMyMood()
        for msg in data.msgLst:
            self.myMoodMsg.append(msg)

    def UpdateOtherMood(self, data):
        self._ResetOtherMood()
        for msg in data.msgLst:
            self.otherMoodMsg.append(msg)

    def _ResetMyBoard(self):
        self.myMoodMsg = []

    def _ResetOtherBoard(self):
        self.otherBoardMsg = []

    def _ResetMyMood(self):
        self.myMoodMsg = []

    def _ResetOtherMood(self):
        self.otherMoodMsg = []

    def AddOtherFamilyId(self, familyId):
        self.otherFamilyId.append(familyId)

    # 看自己的空间有没有其他人留言，用于回复判断
    def IfHaveOtherBoard(self, myFamilyId):
        if self.myBoardMsg:
            for msg in self.myBoardMsg:
                if not msg.senderId == myFamilyId and msg.ownerId == myFamilyId:
                    return msg.senderId, msg.msgId
        return None, None

    # 看自己的心情有没有其他人留言，用于回复判断
    def IfMoodHaveOtherReply(self, myFamilyId):
        if self.myMoodMsg:
            for msg in self.myMoodMsg:
                for commentLst in msg.commentLst:
                    if not commentLst.senderId == myFamilyId:
                        return commentLst.senderId, msg.msgId, commentLst.commentId
        return None, None, None

    def GetOtherFamily(self):
        if self.otherFamilyId:
            return self.otherFamilyId[random.randint(0, len(self.otherFamilyId)-1)]
        else:
            return None

    def GetOtherMood(self):
        if self.otherMoodMsg:
            return self.otherMoodMsg[random.randint(0, len(self.otherMoodMsg)-1)]
        else:
            return None

    def GetMyOneBoard(self):
        if self.myBoardMsg:
            return self.myBoardMsg[random.randint(0, len(self.myBoardMsg)-1)]
        else:
            return None

    def GetMyOneMood(self):
        if self.myMoodMsg:
            return self.myMoodMsg[random.randint(0, len(self.myMoodMsg)-1)]
        else:
            return None



