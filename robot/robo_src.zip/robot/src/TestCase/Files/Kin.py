# -*- coding:utf8 -*-
import logging
import random
from Config import RoleFigures
from net.Common.ComDefine_pb2 import KIN_LAND_COMMON, KIN_LAND_DEFEND_FEAST

class Kin(object):

    WEEK_HUMAN_ROOM = 1
    WEEK_LAND_ROOM = 2
    WEEK_GOD_ROOM = 3

    def __init__(self):
        self.__kinList = []
        self.__kinMember = {}
        self.__weekRoomPlayerCount = {}
        self.isLeader = False
        self.needLeaveKin = False
        self.feastIsOpen = False
        self.name = None
        self.id = 0
        self.kinKick = True
        self.inviteMsgDict = {}
        self.applyerList = []
        self.hasAppliedKinIdList = []
        self.target = ""
        self.collectFoodnWave = 0
        self.nNeedCommitFoodCount = 0
        self.commitTaskList = []
        self.cooking = False
        self.feastActionDict = {"吃肉":13, "喝酒":14}
        self.defendBossMsg = {}
        self.cheererCount = 0#助威人数
        self.assaulterCount = 0#冲锋人数
        self.assaulterUpperLimit = 0#冲锋人数上限
        self.warMemberDict = {}
        self.warMemberType = RoleFigures.KinWarCheerer
        self.warEnemyDict = {}
        self.warTargetEnemyId = 0
        self.warLampDict = {}
        self.warGeneralNameList = []
        self.warGeneralsDict = {}
        self.warTargetGeneral = {
                                 "name" : "",
                                 "id" : 0
                                 }
        self.warDrumDict = {}
        self.warBoxDict = {}
        self.hasMoveToGeneral = False
        self.hasSetQinShiHuangPos = False
        self.hasWarPvpDead = False
        self.gameType = 0
        self.distKinId = 0
        self.isdajiang = False
    def UpdateKinList(self, kinlist):
        for kin in kinlist:
            if kin.memberMax > kin.memberCount:
                self.__kinList.append(kin)
                
    def GetKinList(self):
        return self.__kinList
    
    def SetKinMember(self, key, val):
        self.__kinMember[key] = val
        
    def DelKinMember(self, key):
        if key in self.__kinMember:
            del self.__kinMember[key]
        
    def GetKinMember(self):
        return self.__kinMember
    
    #清除家族信息
    def CleanKinMsg(self):
        self.id = 0
        self.name = None
        self.isLeader = False
        self.__kinList = []
        self.__kinMember = {}
        self.__weekRoomPlayerCount = {}
    
    def UpdateWeekRoomPlayerCount(self, room_player_count):
        assert len(room_player_count) == 3
        self.__weekRoomPlayerCount[Kin.WEEK_HUMAN_ROOM] = room_player_count[0]
        self.__weekRoomPlayerCount[Kin.WEEK_LAND_ROOM] = room_player_count[1]
        self.__weekRoomPlayerCount[Kin.WEEK_GOD_ROOM] = room_player_count[2]
    
    #设置家族盛宴任务信息
    def SetCommitTaskList(self, msg):
        self.collectFoodnWave = msg["nWave"]
        self.nNeedCommitFoodCount = msg["nNeedCommitFoodCount"]
        self.commitTaskList = msg["tbCommitTask"]

    #获取家族盛宴任务物品信息
    def GetFeastTaskItem(self):
        for item in self.commitTaskList:
            if item["nCount"] < self.nNeedCommitFoodCount:
                logging.debug("nCount = %s , commitTaskList = %s" % (item["nCount"], self.nNeedCommitFoodCount))
                return item["tbItem"]
        return {}
        
    def SetLeader(self, is_leader=True):
        self.isLeader = is_leader

    def GetLeader(self):
        return self.isLeader
    
    def SetKinGameIsOpen(self, gameType):
        if type == KIN_LAND_DEFEND_FEAST:
            self.feastIsOpen = True
            
    def GetFeastIsOpen(self):
        return self.feastIsOpen

    def SetApplyerList(self, familyId):
        if familyId not in self.applyerList:
            self.applyerList.append(familyId)
    
    def GetApplyerList(self, limitNum):
        memberCount = len(self.__kinMember)
        applerIdList = []
        if memberCount < limitNum:#是否招够了人数
            needCount = limitNum - memberCount
            applyerCount = len(self.applyerList)
            logging.debug("GetApplyerList self.applyerList = %s" % str(self.applyerList))
            if needCount <= applyerCount:#申请的人数是否大于缺少的人数
                popCount = needCount
            else:
                popCount = applyerCount
            for i in range(popCount):
                applerIdList.append(self.applyerList.pop())
        return applerIdList
    
    #是否已招够人数
    def isMemberEnough(self, limitNum):
        if len(self.__kinMember) < limitNum:
            return False
        else:
            return True
    
    def SetInviteMsgDict(self, id, name, GameType):
        self.inviteMsgDict["id"] = id
        self.inviteMsgDict["name"] = name
        self.inviteMsgDict["GameType"] = GameType
        
    def UpdateKinGameType(self):
        self.gameType = self.inviteMsgDict["GameType"]
    
    def UpdateWarMemberCount(self, cheerer, assaulter, upperLimit):
        self.cheererCount = cheerer
        self.assaulterCount = assaulter
        self.assaulterUpperLimit = upperLimit
    
    #获取需要调到冲锋区的人数
    def GetChangePvpMemberCount(self):
        if self.assaulterUpperLimit:
            if self.cheererCount and self.assaulterCount < self.assaulterUpperLimit:
                needAssaulterCount = self.assaulterUpperLimit - self.assaulterCount
                if needAssaulterCount < self.cheererCount:
                    return needAssaulterCount
                else:
                    return self.cheererCount
            else:
                logging.debug("cheererCount = %s, assaulterCount  = %s/%s" % (self.cheererCount, self.assaulterCount, self.assaulterUpperLimit))
                return 0
        else:
            logging.debug("GetChangePvpMemberCount assaulterUpperLimit no value")
            return 0
    
    def UpdateWarMemberDict(self, myFamilyId, memberList):
        for member in memberList:
            familyId = int(member[0])
            memberType =  int(member[1])
            if familyId == myFamilyId:
                self.warMemberType = memberType
            self.warMemberDict[familyId] = memberType
    
    def GetWarPveMemberIdList(self, needCount):
        memberIdList = []
        recommendIdList = [747764]#进入冲锋区
        unRecommendIdList = [747736]#进入助威区
        intersectIdList = [i for i in recommendIdList if i in self.warMemberDict.keys()]
        differentIdList = [i for i in self.warMemberDict.keys() if i not in intersectIdList and i not in unRecommendIdList]
#         logging.debug("GetWarPveMemberIdList intersectIdList=%s, differentIdList=%s" % (intersectIdList, differentIdList))
        for idList in [intersectIdList, differentIdList]:
            for memberId in idList:
                if len(memberIdList) >= needCount:
                    break
                if self.warMemberDict[memberId] == RoleFigures.KinWarCheerer:
                    memRoleFiguresppend(memberId)
        return memberIdList
    
    def SetWarEnemyDict(self, enemyId, posX, posY):
        self.warEnemyDict[enemyId] = {
                                        "pos" : (posX, posY)
                                      }
        
    def GetWarEnemyPos(self):
        if self.warEnemyDict:
            if self.warTargetEnemyId not in self.warEnemyDict:
                self.warTargetEnemyId = random.choice(self.warEnemyDict.keys())
            return self.warEnemyDict[self.warTargetEnemyId]["pos"]
        else:
            return ()
    
    def SetWarGeneralsDict(self, generalId, generalName, posX, posY):
        self.warGeneralsDict[generalId] = {
                                             "name" : generalName,
                                             "pos" : (posX, posY)}
    
    def GetWarGeneralPos(self, generalName):
        pos = ()
        if self.warGeneralsDict:
            generalId = self.warTargetGeneral["id"] 
            if generalId in self.warGeneralsDict:
                pos = self.warGeneralsDict[generalId]["pos"]
            else:
                for gid in self.warGeneralsDict:
                    if self.warGeneralsDict[gid]["name"] == generalName:
                        self.warTargetGeneral["id"] = gid
                        pos = self.warGeneralsDict[gid]["pos"]
                        break 
        return pos
    
    def UpdateWarGeneralNameList(self, name):
        if name in self.warGeneralNameList:
            logging.debug("移除UpdateWarGeneralNameList中被击杀的大将%s" % name)
            self.warGeneralNameList.remove(name)
            
    def SetWarDrumDict(self, drumId, posX, posY):
        self.warDrumDict[drumId] = {
                                        "pos" : (posX, posY)
                                      }
        
    def GetWarDrumMsg(self):
        if self.warDrumDict:
            drumId = random.choice(self.warDrumDict.keys())
            return drumId, self.warDrumDict.pop(drumId)["pos"]
        else:
            return 0, ()
