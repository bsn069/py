# coding:utf-8
import pprint
import random
import logging

class XiaoMiJing(object):
    def __init__(self):
        self.bossDict = {}
        self.boxMsg = {}
        self.teammateIdList = []
        self.switchDict = {} #天罗地网的唐门机关
        self.hasEnterShuiYunJing = False
        self.hasSwitch = False
    
    def SetBossDict(self, bossId, posX, posY, name):
        self.bossDict[bossId] = {
                                       "pos" : (posX, posY),
                                       "name" :name.encode('unicode-escape').decode('string_escape')
                                       }
    
    def GetBossPos(self):
        if self.bossDict:
            bossId = random.choice(self.bossDict.keys())
            return self.bossDict[bossId]["pos"]
        else:
            return ()
        
    def SetTeammateIdList(self, teammateId):
        if teammateId not in self.teammateIdList:
            self.teammateIdList.append(teammateId)
    
    def SetSwitchDict(self, switchId, posX, posY):
        self.switchDict[switchId] = {
                                       "pos" : (round(posX, 2), round(posY, 2))
                                       }
    
    def GetSwitchId(self):
        if self.switchDict:
            switchId = random.choice(self.switchDict.keys())
            return switchId
        else:
            return None
    
