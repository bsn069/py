# -*- coding:utf8 -*-
class Killer():

    def __init__(self):
        self.task = {}
        self.bossId = 0
        self.killlist = []
        self.rewardPeople = []

    def SetRewardPeople(self, familid, name):
        self.rewardPeople.append((familid, name))

    def GetRewardPeople(self):
        if self.rewardPeople:
            return self.rewardPeople.pop()
        else:
            return None
