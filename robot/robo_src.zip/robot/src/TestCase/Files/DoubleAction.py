# coding:utf-8
class DoubleAction(object):
    def __init__(self):
        self.hugPlayid = 0
    
    def SetHugPlayid(self, Playid):
        self.hugPlayid = Playid
    
    def GetHugPlayid(self):
        return self.hugPlayid