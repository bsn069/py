# coding:utf-8
from Config.RoleFigures import *
import logging

class Camp(object):
    def __init__(self):
        self.campTag = None
        self.teamTag = None
    