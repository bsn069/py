# -*- coding:utf8 -*-
class Maintask(object):

    def __init__(self):
        self.__taskId = None
        self.__isAward = False
        self.__awardList = None
        
        self.ismeijiu = False
        self.meijiuId = None
        self.meijiuIdX = -1
        self.meijiuIdY = -1
        
        self.fengzhengId = None
        self.fengzhengX = -1
        self.fengzhengY = -1
        
        self.liangcaoId = None
        self.liangcaoX = -1
        self.liangcaoY = -1
         
        self.yingcaoId = []
        
        self.isequip = False
        
    def Update(self, respond):
        if len(respond.taskAwardList._values) > 0:
            MaintaskState = respond.taskAwardList._values[0]
            self.__taskId = MaintaskState.taskId
            self.__isAward = MaintaskState.isAward
            self.__awardList = MaintaskState.awardList
            
    def GetMaintaskTaskID(self):
        return self.__taskId
    
    def IsAward(self):
        return self.isAward
    
    def GetMaintaskTaskParam(self):
        return self.__awardList
    
    