# -*- coding:utf8 -*-
import gevent
import logging
import random
import time
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from NetPackHandle.ZoneServerNetPackHandle import *
#from locust.events import *
from Family import Family
from Tools.GenerateChinese import generate_chinese
from ModuleState.StateDefine import *
        
class Server(object):    
    def __init__(self, server):
        self.server = server
        self.ServerNetPackHandle = None
        self.state = 0
        
    def Uninit(self):
        if self.ServerNetPackHandle:
            self.ServerNetPackHandle.Uninit()
            self.ServerNetPackHandle = None
    
    def ConnectServer(self):
        self.ServerNetPackHandle = ServerNetPackHandle(self.server, self)
        self.ServerNetPackHandle.ConnectServer(self.server)
        
    def Register(self):
        self.ServerNetPackHandle.Register()
        
    def Do_ChaosFight(self):
        self.ServerNetPackHandle.ChaosFight()

    def Match_Battle_JoinMatchRequest(self, members):
        self.ServerNetPackHandle.Match_Battle_JoinMatchRequest(members)
    
    def LiveGameJoinReq(self, members):
        self.ServerNetPackHandle.LiveGameJoinReq(members)