# coding:utf-8
__author__ = 'Administrator'

import time
import datetime

class ServerTime(object):    
    def __init__(self):
        self.serverTick = 0
        self.serverUnixMsec = 0
        self.start = time.time()

    def UpdateServerTick(self, serverTick, unixMsec):
        self.serverTick = serverTick
        self.serverUnixMsec = unixMsec
        self.start = time.time()

    def GetTick(self):
        if self.serverTick == 0:
            return 0;
        return (long)(self.serverTick + time.time() - self.start)
    
    def UnixSec(self):
        if self.serverUnixMsec != 0:
            return self.UnixMSec() / 1000
        else:
            return time.time()
        
    def UnixMSec(self):
        if  self.serverUnixMsec != 0 and self.start is not None:
            return self.serverUnixMsec + (time.time() - self.start) * 1000
        else:
            return time.time() * 1000
            