﻿# coding=utf-8

__author__ = 'Administrator'

import random
SHOPID_KIN = [4, 5, 6] # 4,5,6 都是家族商店，这里只处理4的吧

class Good(object):
    def __init__(self, good):
        self.id = good.goodsId
        self.count = good.goodsCount

class Shop(object):
    def __init__(self, shop):
        self.id = shop.shopId
        self.goods_sequence = shop.goodsSequence
        self.goods = []
        for good in shop.goodsInfo:
            self.goods.append(Good(good))

    def GetRandomGoodIndex(self):
        indexs = [i for i in range(0, len(self.goods)) if (self.goods[i].count > 0)]
        if not indexs:
            indexs = [0]
        return random.choice(indexs)
