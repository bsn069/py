# -*- coding:utf8 -*-
import random

class GraveDigger():

    def __init__(self):
        self.mapid = None
        self.siteList = []
        self.isDigger = 0
        self.xiangziId = None
        self.digongId = None
        
        self.isEnterDiGongFirstFloor = False
        self.isEnterDiGongSecondFloor = False
        
        self.bonfirePox = (0, 0)
        self.hasFindBonfire = False
        
        self.diGongNpcInfo = {}

    def GetMapId(self):
        return self.mapid

    def UpdateSite(self, *args):
        for i in args:
            self.siteList.append(i)

    def GetSite(self):
        if self.siteList:
            return self.siteList.pop()
        else:
            return ""

    def SiteLen(self):
        return len(self.siteList)

    def HavaDigger(self, digger_type):
        self.isDigger = digger_type

    def GetDigger(self):
        return self.isDigger

    def SetDiGongNpcInfo(self, npcId, posX, posY):
        self.diGongNpcInfo[npcId] = {
                                     "id" : npcId,
                                     "pos" : (posX, posY)
                                 }
    
    def GetDiGongNpcInfo(self):
        if self.diGongNpcInfo:
            key = random.choice(self.diGongNpcInfo.keys())
            return self.diGongNpcInfo[key]
        else:
            return ""
        



