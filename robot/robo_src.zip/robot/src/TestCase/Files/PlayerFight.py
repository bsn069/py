# coding:utf-8
class PlayerFight(object):
    def __init__(self):
        self.match_Playid = 0
    
    def SetMatchPlayid(self, Playid):
        self.match_Playid = Playid
    
    def GetMatchPlayid(self):
        return self.match_Playid