# -*- coding:utf8 -*-
import logging
import random
from Config.RoleFigures import *
from net.Common.ComDefine_pb2 import *

class Grave(object):
    
    def __init__(self):
        self.memberIdList = []
        self.weekRoomId = 0
        self.target = ""
        self.grassIdDict = {} #存花字典
        self.countList = [0, 0, 0]
        self.monsterDict = {} #怪物信息
        self.postDict = {}
        self.postTarget = ""#当前要开的机关柱子
        self.bossDict = {}

    def SetWeekRoomId(self, posX):
        grovepos = {
                    1: [155.23, 165,23],
                    2: [5.43, 15.43],
                    3: [239.01, 249.01]
             }
        for i in  range(len(grovepos.keys())):
            if  grovepos[i+1][0]<posX<grovepos[i+1][1]:
                self.weekRoomId = i+1
    
    def GetWeekRoomId(self):
        return self.weekRoomId

    #添加敌人信息
    def SetMonsterInfo(self, monsterId, posX, posY):
        self.monsterDict[monsterId] = {
                                       "id" : monsterId,
                                       "pos" : (posX, posY)
                                       }
        
    def GetMonsterInfo(self):
        key = random.choice(self.monsterDict.keys())
        return self.monsterDict[key]
    
    #添加机关柱子信息
    def SetPostInfo(self, postName, postId, posX, posY):
        self.postDict[postName] = {
                                       "id" : postId,
                                       "pos" : (posX, posY)
                                       }
#         logging.debug("机关柱子：%s" % self.postDict)
    #添加一同进图组员信息
    def SetMemberInfo(self, id):
        if id not in self.memberIdList:
            self.memberIdList.append(id)
            self.memberIdList.sort(reverse=True)
            
    #添加夜光草信息
    def SetGrassInfo(self, GrassId, posX, posY):
        self.grassIdDict[GrassId] = {
                                   "id" : GrassId,
                                   "pos" : (posX, posY)
                                   }
        
    def GetGrassInfo(self):
        key = random.choice(self.grassIdDict.keys())
        return self.grassIdDict.pop(key)

    #添加制尸者Boss信息
    def SetBossInfo(self, bossId, posX, posY):
        self.bossDict[bossId] = {
                                 "id" : bossId,
                                 "pos" : (posX, posY)
                             }
#         logging.debug("Boss信息：%s" % self.bossDict)
    
    def GetBossInfo(self):
        key = random.choice(self.bossDict.keys())
        return self.bossDict.pop(key)