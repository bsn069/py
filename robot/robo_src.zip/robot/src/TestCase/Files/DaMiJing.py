# coding:utf-8
from Config.RoleFigures import *
import logging

class JoinType:
    NORMAL = 0
    ROB = 1

class DaMiJing(object):
    def __init__(self):
        self.npcDict = {}
        self.baoXiang = {}
        self.taishidanId = None
        self.missionId = 0
        self.level = 0
        self.hasEnterShuiYunJing = False
        self.hasBeRob = False
        self.refreshNPC = False
        self.robList = {}
        self.joinType = JoinType.NORMAL
        
    def UpdateRobList(self, robList):
        self.robList = {}
        for rob in robList._values:
            self.robList[rob.szMissionId] = rob.floor
            
    def GetRobMIddsionId(self):
        for id, floor in self.robList.items():
            if floor < self.level:
                del self.robList[id]
                return id
        return None
            