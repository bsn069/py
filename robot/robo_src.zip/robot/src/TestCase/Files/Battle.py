# coding:utf-8
from Config.RoleFigures import *
import logging

class Battle(object):
    BAOXIANG_NAME = '行军物资'
    MATCH_TIME = 60 * 10
    MATCH_COUNT = 3
    
    def __init__(self):
        self.baoxiangPos = None
        self.isHandleEvent = True
        self.eventPosIdx = None
        self.eventId = None
        self.beginMatchTime = None
