# coding:utf-8
from Config.RoleFigures import *
import logging

class ChatRoom(object):
    def __init__(self):
        self.roomId = 0
        self.roomType = 0
        self.memberDict = {}
        self.kinRoomId = 0
        self.newRoomId = 0
        
    def SetInfo(self, chatroom_info):
        self.roomId = chatroom_info.roomId
        self.roomType = chatroom_info.roomType
        for member_info in chatroom_info.memberlist:
            self.memberDict[member_info.familyId] = member_info
    
    def Update(self, change_info):
        if change_info.changeList:
            for member_info in change_info.changeList:
                self.memberDict[member_info.familyId] = member_info
        
        if change_info.familyList:
            for familyId in change_info.familyList:
                del self.memberDict[familyId]