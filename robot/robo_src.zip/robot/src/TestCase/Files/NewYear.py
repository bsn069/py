# -*- coding:utf8 -*-
import random
import math
from Tools.Enum import enum

class NewYear(object):
    '''
    #春节
    '''
    
    def __init__(self):
        self.gdpl = {1:[91, 1],
                     2:[91, 2],
                     3:[92, 1],
                     4:[92, 2],
                     }
        self.redpacketId = None
        self.numberid = {}
    def SetRedPacket(self, number):
        self.redpacketId = number