# -*- coding:utf8 -*-
import gevent
import logging
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
#from locust.events import *
from Family import Family
from Tools.GenerateChinese import generate_chinese
from ModuleState.StateDefine import *

def execute(func):
    def _func(self, *args):
        try:
            g = gevent.spawn(asyncresult_manager.wait, self.family, func.__name__, self.timeout)
            func(self, *args)
            g.join()
            if not g.value:
                self.Uninit()
                return False
            return True
        except Exception as e:
            asyncresult_manager.fire(self.family, func.__name__, False, error=str(e))
            self.Uninit()
            return False
    return _func


class Portal(object):    
    def __init__(self, server, family=None, timeout=180):
        if family is None:
            self.family = Family(ip=None,
                        port=None,
                        userName=None,
                        account=None,
                        serverGroupId=None)
        else:
            self.family = family
        self.server = server
        self.timeout = None
    
    def Uninit(self):
        if self.family and self.family.portalServerNetPackHandle:
            self.family.portalServerNetPackHandle.Uninit()
            self.family.portalServerNetPackHandle = None
    
    @execute
    def ConnectPortalServer(self):
        self.family.ConnectPortalServer(self.server)
    
    @execute  
    def ReportLocalState(self):
        self.family.portalServerNetPackHandle.Do_ReportLocalState()
    
    @execute  
    def SelectServerRecord(self):
        self.family.portalServerNetPackHandle.Do_SelectServerRecord()
    
    @execute
    def ApplyLoginTimeReq(self):
        self.family.portalServerNetPackHandle.Do_ApplyLoginTimeReq()
        
    def Run(self):
        self.family.SetState(STATE_PS_ONE)  
        asyncresult_manager.await(self.family, "All_PortalServer", self.timeout)
        result = False
        if not self.ConnectPortalServer():
            return
        
        if not self.ReportLocalState():
            return
        
        if not self.SelectServerRecord():
            return
        while result == False:
            if self.ApplyLoginTimeReq():
                if self.family.state == STATE_PS_FOUR:
                    asyncresult_manager.fire(self.family, "All_PortalServer", True)
                    gevent.sleep(self.family.loginWaitTime)
                    result = True
        self.Uninit()
        return result
