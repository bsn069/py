# -*- coding:utf8 -*-
import gevent
import logging
import random
import time
from Tools.Rand import Rand
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from Family import Family
from GenerateChinese import generate_chinese
from ModuleState.StateDefine import *


ONELEVEL = 1
TWOLEVEL = 2
THREELEVEL = 3


class Coordinate(object):
    def __init__(self):
        self.Xmax = 49.0    #最大纬度
        self.Xmin = 22.0    #最小纬度
        self.Ymax = 134.0   #最大经度
        self.Ymin = 77.0    #最小经度
        self.Y_dis = 0.9    #经度距离
        self.X_dis = 3.0    #纬度距离
        
        self.state = 0
        self.StartTime = 0
        self.familyId = random.randint(10000, 110000) #记录总量按10万来测就差不多
                 
        self.x_list = self.get_list(self.Xmax, self.Xmin, self.X_dis)
        self.y_list = self.get_list(self.Ymax, self.Ymin, self.Y_dis)
        self.totalbox = self.get_box(self.x_list, self.y_list) 
        cases = {
                     ONELEVEL   : 30,       #重点区域
                     TWOLEVEL   :  5,       #次级区域
                     THREELEVEL :  1,       #全区
                     }
        self.type = Rand.weighted_choice(cases)#根据权重分配单人or组队
        self.latitude, self.longitude = self.get_x_y(self.type)
        
    def get_x_y (self, Type):
        if  Type == ONELEVEL:               #当为重点区域
            onelevel = self.totalbox[0:10]
            number = random.randint(0, len(onelevel)-1)
            return onelevel[number][0], onelevel[number][1],
        elif Type == TWOLEVEL:
            twolevel = self.totalbox[11:100]
            number = random.randint(0, len(twolevel)-1)
            return twolevel[number][0], twolevel[number][1],
        else:
            threelevel = self.totalbox[100:]
            number = random.randint(0, len(threelevel)-1)
            return threelevel[number][0], threelevel[number][1],
     
    def get_list(self, max, min, distance):
        list1 = []
        while min <= max:
            list1.append(round(min, 3) )
            min += distance
        return  list1
    
    def get_box(self, list_x, list_y):
        list1 = []
        for x in range(len(list_x)):
            for y in range(len(list_y)):
                list1.append((list_x[x], list_y[y]))
        return list1
class Loction(Coordinate):    
    def __init__(self, server, familyid,family=None, timeout=180):
        if family is None:
            self.family = Family(ip=None,
                        port=None,
                        userName=None,
                        account=None,
                        serverGroupId=None)
        else:
            self.family = family
        self.family.familyId = familyid
        self.server = server
        self.timeout = timeout
        self.family.Play = {}
        
    def Uninit(self):
        if self.family and self.family.locationServerNetPackHandle:
            self.family.locationServerNetPackHandle.Uninit()
            self.family.locationServerNetPackHandle = None
    
    def ConnectLocationServer(self):
        self.family.ConnectLocationServer(self.server)
    
    def SetLocationGeography(self, familyId):
        self.family.locationServerNetPackHandle.Do_SetLocationGeography(familyId)
    
    #得到玩家位置信息
    def GetLocationGeography(self, familyId):
        self.family.locationServerNetPackHandle.Do_GetLocationGeography(familyId)
                  
    #设置玩家位置信息
    def SetKinLocationGeography(self, familyId):
        self.family.locationServerNetPackHandle.Do_SetKinLocationGeography(familyId)
        
    #得到玩家位置信息
    def GetKinLocationGeography(self, familyId):
        self.family.locationServerNetPackHandle.Do_GetKinLocationGeography(familyId)
        
    def ILLDo_SetLocationGeography(self, familyId):
        self.family.locationServerNetPackHandle.ILLDo_SetLocationGeography(familyId)
        
    def LocationServerStart(self): 
        paly = Coordinate()
        self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
        self.SetLocationGeography(self.family.Play[paly.familyId]['familyId'])
    
    def ILL_LocationServerStart(self):
        paly = Coordinate()
        self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
        self.ILLDo_SetLocationGeography(self.family.Play[paly.familyId]['familyId'])
    
    def ILL_SetKinLocationGeography(self):
        paly = Coordinate()
        self.family.Play[paly.familyId] = {'familyId':paly.familyId, 'StartTime':paly.StartTime, 'longitude':paly.longitude, 'latitude':paly.latitude}
        self.family.locationServerNetPackHandle.ILLDo_SetKinLocationGeography(self.family.Play[paly.familyId]['familyId'])
