# coding:utf-8


class Menu(object):
    def __init__(self, name, text):
        self.name = name
        self.text = text
        
class Option(object):
    def __init__(self, index, text):
        self.index = index
        self.text = text
    
class DialogInfo(object):
    '''
    classdocs
    '''

    def __init__(self):
        self.type = None
        self.id = None
        self.title = None
        self.npc_id = None
        self.npc_template_id = None
        self.custom = None
#         self.menus = []
#         self.options = []
        
    def Update(self, info):
        self.type = info.dialogType
#        self.id = info.dialogId
        self.title = info.dialogTitle
#        self.npc_id = info.npcId
#        self.npc_template_id = info.npcTemplateId
#        self.custom = info.custom
#         self.meuns = []
#         self.options = []
#         
#         for menu in info.menuList:
#             self.menus.appned(Menu(menu.btnName, menu.btnText))
#         for option in info.options:
#             self.options.append(Option(option.optionIndex, option.optionText))
        