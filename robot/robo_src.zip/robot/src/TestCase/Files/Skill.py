# coding:utf-8
from account.account_service import account_skillid
from account.account_def import AccountDef
from Config.RoleFigures import *
import logging

class Skill(object):
    def __init__(self, family):
        self.family = family
        self.skillDict = {}
        self.finalSkillList = []
        self.originalState = None
        self.isFinalMember = False
        self.designatedSkillList = []
        self.skillReleaseList = []
        self.isLastSkill = False
        self.lastSkillId = 0
        self.replaceSkill = 0
        self.notWaitingReplaceSkill = 0
        self.isWaitingSkillCombo = False
        self.isWaitingSkillResult = False
        self.emeiSkillPointQinyi = 0
        self.emeiSkillPointLianhua = 0
        self.tianrenSunSkillPoint = 100
        self.tianrenMoonSkillPoint = 100
        self.costSkillKeyDict = {}
        self.hasEquipedSkillCharacters = []
        self.skillTargetDict = {}
        self.hasReleaseRepeatSkill = False
        self.originSkillOfRepeatSkill = 0
        self.needCommonAttack = True
        '''
            data\sheet\skill.csv UIRow、UIColumn这两列分别是1,1、2,1、3,1、4,1就是前四个技能
        '''
        self.originSkillDict = {
                                    TIANWANG: [11061, 11021, 11071, 11081],
                                    TANGMEN: [12011, 12021, 12041, 12081],
                                    EMEI: [13051, 13041, 13061, 13031],
                                    TIANREN: [14011, 14021, 14031, 14041],
                                    WUDANG: [15081, 15071, 15021, 15061],
                                }
    
    def _GetSkillId(self, faction):
        skillId = account_skillid(faction)
        return int(skillId)
    
    #获取指定的技能
    def GetDesignatedSkill(self, faction):
        designatedSkillDict = {
            TIANWANG: [11062],
            TANGMEN: [12021],
            EMEI: [13051],
            TIANREN: [103],
            WUDANG: [15064],
        }
        designatedSkillList = []#使用随机技能
#         designatedSkillList = designatedSkillDict[faction]#使用指定技能
#         designatedSkillList = [self._GetSkillId(faction)]#使用分发技能
        if not self.family.isNewRole:
            self.family.skill.skillReleaseList = designatedSkillList
        return designatedSkillList
    
    def SetSkillTargetDict(self, npcId, posX, posY):
        self.skillTargetDict[npcId] = {
                                       "pos" : (posX, posY)
                                       }
    