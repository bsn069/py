# -*- coding:utf8 -*-
from Config.RoleFigures import *

#龙门荒漠和枫华谷BossId
LongmenAndMapleBossId1 = 8001
LongmenAndMapleBossId2 = 8002
LongmenAndMapleBossId3 = 8003
LongmenAndMapleBossId4 = 8004
LongmenAndMapleBossId5 = 8011
LongmenAndMapleBossId6 = 8012
LongmenAndMapleBossId7 = 8013
LongmenAndMapleBossId8 = 8014
LongmenAndMapleBossId9 = 8021
LongmenAndMapleBossId10 = 8022
LongmenAndMapleBossId11 = 8023
LongmenAndMapleBossId12 = 8024
LongmenAndMapleBossId13 = 8031
LongmenAndMapleBossId14 = 8032
LongmenAndMapleBossId15 = 8033
LongmenAndMapleBossId16 = 8034
#观晴滩BossId
BeachMonsterNian = 8073
  
class RandomBoss(object):
    def __init__(self):
        self.__data = None
        self.BossIdList = [LongmenAndMapleBossId1, LongmenAndMapleBossId2, LongmenAndMapleBossId3,
                                       LongmenAndMapleBossId4, LongmenAndMapleBossId5, LongmenAndMapleBossId6,
                                       LongmenAndMapleBossId7, LongmenAndMapleBossId8, LongmenAndMapleBossId9,
                                       LongmenAndMapleBossId10, LongmenAndMapleBossId11, LongmenAndMapleBossId12,
                                       LongmenAndMapleBossId13, LongmenAndMapleBossId14, LongmenAndMapleBossId15,
                                       LongmenAndMapleBossId16, BeachMonsterNian]
        
    def Update(self, data):
        if data.id == 268435481:
            self.__data = data
        # if data.info.speed == 5:
        #     self.__data = data
            
    def GetData(self):
        return self.__data

    