#!/usr/bin/env python2.7
# coding=gb18030
'''
Created on 2014-7-31

@author: yangmingbang
'''
import os
import time
import logging

def InitLog():
    FOLDER_NAME =  time.strftime('%Y-%m-%d',time.localtime(time.time()))
    PATH_NAME = r'log/' + FOLDER_NAME
    TIME_NAME = str(int(time.time()))
    FILE_NAME = PATH_NAME + r'/' + TIME_NAME + r'.log'
    if not os.path.isdir(PATH_NAME):
        os.makedirs(PATH_NAME)
    
    logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                datefmt='%a, %d %b %Y %H:%M:%S',
                filename=FILE_NAME,
                filemode='w')