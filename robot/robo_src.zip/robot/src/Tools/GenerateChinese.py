# coding:utf-8
import random
from LimitNameList import LimitNameList

class RandomChinese(object):
        
    def Generate(self, Chinese_Len):
        username = ''
        while len(username) < Chinese_Len:
            head = random.randint(0xB0, 0xF7)
            tail = random.randint(0xA1, 0xFE)
            val = (head << 8) | tail
            word = "%x" % val
            SingleWord = word.decode('hex').decode('gbk', 'ignore')
            if SingleWord.encode('utf8') in LimitNameList:
                continue
            else:
                username += SingleWord
        return username
            
    
generate_chinese = RandomChinese().Generate

if __name__ == '__main__':
    print generate_chinese(1)