# coding:utf-8
__author__ = 'Administrator'


def enum(**enums):
    return type('Enum', (), enums)
