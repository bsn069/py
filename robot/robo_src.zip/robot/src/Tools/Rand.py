#coding=utf-8
__author__ = 'Administrator'

import random

UINT32_MAX = 4294967295
UINT8_MAX = 255
INT32_MIN = -2147483648
INT32_MAX = 2147483647

class Rand():
    STR = ("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!",
           "@#$%^&*()_+=-[]{}|\\\"\';:,./<>?%“‘；￥#&*《》")

    def __init__(self):
        pass

    @classmethod
    def rand_percent(cls, percent):
        if random.randint(1, 99) < percent:
            return True
        else:
            return False

    @classmethod
    def rand_uint8(cls):
        return random.randint(0, UINT8_MAX)

    @classmethod
    def rand_uint32(cls):
        return random.randint(0, UINT32_MAX)

    @classmethod
    def bound_uint32(cls, begin = 0, end = UINT32_MAX):
        assert begin >= 0 and end <= UINT32_MAX
        result = []
        for n in [begin - 1, begin, begin + 1, end - 1, end, end + 1]:
            if (n >= 0) and (n <= UINT32_MAX) and (n not in result):
                result.append(n)
        return random.choice(result)

    @classmethod
    def bound_int32(cls, begin = INT32_MIN, end = INT32_MAX):
        assert begin >= INT32_MIN and end <= INT32_MAX
        result = []
        for n in [begin - 1, begin, begin + 1, end - 1, end, end + 1]:
            if (n >= INT32_MIN) and (n <= INT32_MAX) and (n not in result):
                result.append(n)
        return random.choice(result)

    @classmethod
    def randint_in(cls, begin, end):
        return random.choice([begin, random.randint(begin + 1, end -1), end])

    @classmethod
    def randint_ex(cls, begin, end):
        return random.choice([random.randint(begin - cls.UINT8_MAX, begin - 1),
                              begin,
                              end,
                              random.randint(end + 1, end + cls.UINT8_MAX)])

    @classmethod
    def rand_string(cls, n):
        sa = []
        for i in range(n):
            sa.append(random.choice(cls.STR))
        return ''.join(sa)

    @classmethod
    def weighted_choice(cls, weights):
        rnd = random.random() * sum(weights.values())
        for key, w in weights.items():
            rnd -= w
            if rnd < 0:
                return key
