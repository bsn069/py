__author__ = 'yujie'
import os
import sys

def InsertIncludeDir(relativePath):
    curpath = os.path.abspath(relativePath)
    sys.path.insert(0, curpath)
    # print sys.path