"""
setup.py
"""
 
from distutils.core import setup, Extension
from platform import system
import sys

if '--module' in sys.argv:
	index = sys.argv.index('--module')
	sys.argv.pop(index)
	module = "_" + sys.argv.pop(index)
else:
	print "--module module_name, need module name"
	sys.exit(0)

if system() == 'Windows':
	encrypt_module = Extension( module ,
		sources=[ 'encrypt_wrap.cxx' , 
			'../utility/char_operation.cpp',
			'../os/win/time.cpp',
			'../os/win/directory.cpp', 
			'../os/win/debug.cpp',
			'../os/win/file.cpp',
			'../os/win/mutex.cpp',
			'../os/win/thread.cpp',
			'../utility/Profiler.cpp',
			'../utility/log.cpp',
			'auth_crypt.cpp',
			'base64.cpp',
			'CHMAC_SHA1.cpp',
			'CSHA1.cpp',
			'hash.cpp',
			'md5.cpp',
			'rc4.cpp',
			'sha1.cpp',
			'tea.cpp',
			'TableReplace.cpp',
			'encrypt.cpp'],
			)
else:
	encrypt_module = Extension( module ,
		sources=[ 'encrypt_wrap.cxx' , 
			'../utility/char_operation.cpp',
			'../os/linux/thread.cpp',
			'../os/linux/time.cpp',
			'../os/linux/directory.cpp', 
			'../os/linux/debug.cpp',
			'../os/linux/file.cpp',
			'../os/linux/mutex.cpp',
			'../utility/Profiler.cpp',
			'../utility/log.cpp',
			'auth_crypt.cpp',
			'base64.cpp',
			'CHMAC_SHA1.cpp',
			'CSHA1.cpp',
			'hash.cpp',
			'md5.cpp',
			'rc4.cpp',
			'sha1.cpp',
			'tea.cpp',
			'TableReplace.cpp',
			'encrypt.cpp'],
			)
 
setup (name =  module ,
        version =  '0.1' ,
        author      =  "SWIG Docs" ,
        description =  "" "encrypt interface for swordm3d" "" ,
        ext_modules = [encrypt_module],
        py_modules = [ module ],
        )
