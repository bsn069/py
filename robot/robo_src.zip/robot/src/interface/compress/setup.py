"""
setup.py
"""
 
from distutils.core import setup, Extension
from platform import system
import sys

if '--module' in sys.argv:
	index = sys.argv.index('--module')
	sys.argv.pop(index)
	module = "_" + sys.argv.pop(index)
else:
	print "--module module_name, need module name"
	sys.exit(0)

compress_module = Extension( module ,
	sources=[ 'compress_wrap.cxx' ,
		'lzf/lzf_c.c',
		'lzf/lzf_d.c',
		'compress.cpp'],
		)
 
setup (name =  '_compress' ,
        version =  '0.1' ,
        author      =  "SWIG Docs" ,
        description =  "" "compress interface for swordm3d" "" ,
        ext_modules = [compress_module],
        py_modules = [ module ],
        )
