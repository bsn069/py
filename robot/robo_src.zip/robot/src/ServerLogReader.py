# coding:utf-8
import os
import re
import pprint
import logging
import traceback
from copy import deepcopy

class ServerLogReader():
    def __init__(self, serverLogPath, outputFilePath):
        self.serverLogPath = serverLogPath
        self.outputFilePath = outputFilePath
    
    def WriteFile(self, str):
        f = open(self.outputFilePath, "w+")
        f.write(str)
        f.close()
    
    def GetLogFileList(self, path):
#         return [os.path.join(path, file) for file in os.listdir(path) if os.path.splitext(file)[1] == ".log"]
        return [os.path.join(dirpath, filename) for dirpath, dirnames, filenames in os.walk(os.getcwd()) for filename in filenames if os.path.splitext(filename)[1] == '.log']
    
    def SetTradeItemDict(self, msgDict, familyId, count, item, iType):
        if familyId in msgDict:
            if iType in msgDict[familyId]:
                if item in msgDict[familyId][iType]:
                    msgDict[familyId][iType][item] += count
                    if msgDict[familyId][iType][item] == 0:
                        del msgDict[familyId][iType][item]
                else:
                    msgDict[familyId][iType][item] = count
            else:
                msgDict[familyId][iType] = {item : count}
        else:
            msgDict[familyId] = {iType : {item : count}}
        return msgDict
    
    def SetLastMsgDict(self, msgDict, lastMsgDict, familyId):
        if familyId in lastMsgDict and familyId in msgDict:
            lastMsgDict[familyId] = deepcopy(msgDict[familyId])
        else:
            lastMsgDict[familyId] = {}
    
    def TradeLogMatch(self, msgDict, lastMsgDict, line):
        '''
            server\code\source\GameServer\TradeHouse\TradeHouseGSMgr.cpp
        '''
        #上架物品
        PutOnMatch = re.match(".*\TradeHouseGSMgr::PutOnSale\s:\s1;(\d+);\d+;(\d+_\d+_\d+_\d+);(\d+);\d+;(\d+)", line)
        if PutOnMatch:
            familyId = PutOnMatch.group(1)
            gdpl = PutOnMatch.group(2)
            count = int(PutOnMatch.group(3))
            fee = int(PutOnMatch.group(4))
            self.SetLastMsgDict(msgDict, lastMsgDict, familyId)
#             msgDict.update(self.SetTradeItemDict(msgDict, familyId, -count, gdpl, iType="item"))
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, -count*fee, 1, iType="coin"))
            return
        #上架物品失败
        OnPutOnMatch = re.match(".*\TradeHouseGSMgr::OnPutOnSale\s:\s0;(\d+);\d+;(\d+_\d+_\d+_\d+);(\d+);\d+;(\d+)", line)
        if OnPutOnMatch:
            familyId = OnPutOnMatch.group(1)
            gdpl = OnPutOnMatch.group(2)
            count = int(OnPutOnMatch.group(3))
            fee = int(OnPutOnMatch.group(4))
            self.SetLastMsgDict(msgDict, lastMsgDict, familyId)
#             msgDict.update(self.SetTradeItemDict(msgDict, familyId, count, gdpl, iType="item"))
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, count*fee, 1, iType="coin"))
            return
        #下架物品
#         OnPutOffMatch = re.match(".*\TradeHouseGSMgr::OnPutOffShelves\s:\s1;(\d+);\d+;{.*};(\d+_\d+_\d+_\d+);(\d+);\d+", line)
#         if OnPutOffMatch:
#             familyId = OnPutOffMatch.group(1)
#             gdpl = OnPutOffMatch.group(2)
#             count = int(OnPutOffMatch.group(3))
#             self.SetLastMsgDict(msgDict, lastMsgDict, familyId)
#             msgDict.update(self.SetTradeItemDict(msgDict, familyId, count, gdpl, iType="item"))
#             return
        #购买物品
        OnBuyGoods1Match = re.match(".*\TradeHouseGSMgr::OnBuyGoods1\s:\s1;(\d+);\d+;(\d+_\d+_\d+_\d+);(\d+);(\d+)", line)
        if OnBuyGoods1Match:
            familyId = OnBuyGoods1Match.group(1)
            gdpl = OnBuyGoods1Match.group(2)
            count = int(OnBuyGoods1Match.group(3))
            price = int(OnBuyGoods1Match.group(4))
            self.SetLastMsgDict(msgDict, lastMsgDict, familyId)
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, count, gdpl, iType="item"))
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, -count*price, 1, iType="coin"))
            return
        #售出物品
        OnBuyGoods2Match = re.match(".*\TradeHouseGSMgr::OnBuyGoods2\s:\s1;\d+;\d+;{.*};(\d+_\d+_\d+_\d+);(\d+);(\d+);(\d+);\d+", line)
        if OnBuyGoods2Match:
            gdpl = OnBuyGoods2Match.group(1)
            count = int(OnBuyGoods2Match.group(2))
            price = int(OnBuyGoods2Match.group(3))
            familyId = OnBuyGoods2Match.group(4)
            self.SetLastMsgDict(msgDict, lastMsgDict, familyId)
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, -count, gdpl, iType="item"))#以拍卖行上架数与背包总和计算时只有购买和售出需要更改物品个数
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, count*price*0.92, 1, iType="coin"))#售出商品要收8%交易税
            return
        #刷新物品列表
        RefreshMatch = re.match(".*\TradeHouseGSMgr::Refresh\s:\s(\d+);1", line)
        if RefreshMatch:
            familyId = RefreshMatch.group(1)
#             self.SetLastMsgDict(msgDict, lastMsgDict, familyId)#刷新物品列表暂不计入失败的情况
            lastMsgDict.update(self.SetTradeItemDict(lastMsgDict, familyId, -30, 3, iType="coin"))
            msgDict.update(self.SetTradeItemDict(msgDict, familyId, -30, 3, iType="coin"))#刷新一次物品列表消耗30非绑定元宝
            return
    
    def TradeLogConver(self, matchMethod):
        logList = self.GetLogFileList(self.serverLogPath)
        if logList:
            try:
                msgDict = {}
                lastMsgDict = {}
                for log in logList:
                    for line in open(log, "r"):
                        matchMethod(msgDict, lastMsgDict, line)
                msgDict = {"origin" : msgDict}
                msgDict["last"] = lastMsgDict
                pprint.pprint(msgDict)
                self.WriteFile("ServerLogDict ={\n %s" % pprint.pformat(msgDict)[1:])
            except Exception, e:
                logging.error("[ERROR] %s" % e)
                logging.error("[ERROR] %s" % traceback.print_exc())
        else:
            logging.error("[ERROR]Can not fing log file in path %s" % self.serverLogPath)
        
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    serverLogPath = os.path.join(os.getcwd(), "slog")
    outputFilePath = os.path.join(os.getcwd(), "ServerLog.py")
    r = ServerLogReader(serverLogPath, outputFilePath)
    r.TradeLogConver(r.TradeLogMatch)#拍卖行log转换