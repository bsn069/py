# -*- coding:utf8 -*-
import gevent
import random
import time
from locust import Locust, TaskSet, task
from locust.asyncevent import asyncresult_manager
from TestCase.Files.ZoneServer import Server as ZoneServer
from TestCase.Files.MatchServer import Server as MatchServer
from ModuleState.StateDefine import *


class ZoneTest(TaskSet):
    TIMEOUT = 60
    PEOPLE_COUNT_PER_SEC = 100 
#    ZONE_SERVER = ('10.11.82.36', 9270)
#    MATCH_SERVER = ('10.11.82.36', 9276)
    
    ZONE_SERVER = ('10.11.66.161', 9270)
    MATCH_SERVER = ('10.11.66.161', 9276)

#    ZONE_SERVER = ('192.168.32.2', 9270)
#    MATCH_SERVER = ('192.168.32.2', 9276)
    
    
    def on_start(self):
        gevent.sleep(1)
        
    @task(0)
    def test_livegame(self): 
        team_max = 5
        zoneserver = ZoneServer(self.ZONE_SERVER)
        zoneserver.ConnectServer()
        if not asyncresult_manager.wait(zoneserver.ServerNetPackHandle, "ZoneServerConnected", ZoneTest.TIMEOUT):
            zoneserver.Uninit()
            return
        zoneserver.Register()
        if not asyncresult_manager.wait(zoneserver.ServerNetPackHandle, "ZoneServerRegister", ZoneTest.TIMEOUT):
            zoneserver.Uninit()
            return
        people_num = 0
        start_time = time.time()
        while zoneserver.state == STATE_ZO_LOGINING:
            if people_num + team_max > ZoneTest.PEOPLE_COUNT_PER_SEC:
                eatchicken_members = ZoneTest.PEOPLE_COUNT_PER_SEC - people_num
            else:
                eatchicken_members = random.randint(1, team_max)
            if eatchicken_members < 1:
                gevent.sleep(1- (time.time() - start_time))
                start_time = time.time()
                people_num = 0
            else:
                people_num += eatchicken_members
                zoneserver.LiveGameJoinReq(eatchicken_members)
            gevent.sleep(0)
            
    @task(1)
    def test_battle_chaosfight(self): 
        team_max = 1
        zoneserver = ZoneServer(self.ZONE_SERVER)
        zoneserver.ConnectServer()
        if not asyncresult_manager.wait(zoneserver.ServerNetPackHandle, "ZoneServerConnected", ZoneTest.TIMEOUT):
            zoneserver.Uninit()
            return
        zoneserver.Register()
        if not asyncresult_manager.wait(zoneserver.ServerNetPackHandle, "ZoneServerRegister", ZoneTest.TIMEOUT):
            zoneserver.Uninit()
            return
        
        start_time = time.time()
        people_num = 0
        while zoneserver.state == STATE_ZO_LOGINING:
            if people_num + team_max > ZoneTest.PEOPLE_COUNT_PER_SEC:
                battle_members = ZoneTest.PEOPLE_COUNT_PER_SEC - people_num
            else:
                battle_members = random.randint(1,team_max)
                # battle_members = 2
            if battle_members < 1:
                gevent.sleep(1- (time.time() - start_time))
                start_time = time.time()
                people_num = 0
            else:
                people_num += battle_members
#                zoneserver.Match_Battle_JoinMatchRequest(battle_members)
                zoneserver.Do_ChaosFight()

            gevent.sleep(0)
     
    @task(0)
    def test_league(self):
        team_max = 3
        matchserver = MatchServer(self.MATCH_SERVER)
        matchserver.ConnectServer()
        if not asyncresult_manager.wait(matchserver.ServerNetPackHandle, "MatchServerConnected", ZoneTest.TIMEOUT):
            matchserver.Uninit()
            return
        matchserver.Register_MatchServer()
        gevent.sleep(5)
        people_num = 0
        matchserver.state = STATE_ZO_LOGINING
        start_time = time.time()
        while matchserver.state == STATE_ZO_LOGINING:
            if people_num + team_max > ZoneTest.PEOPLE_COUNT_PER_SEC:
                leage_members = ZoneTest.PEOPLE_COUNT_PER_SEC - people_num
            else:
                leage_members = random.randint(1, team_max)
                
            if leage_members < 1:
                gevent.sleep(1- (time.time() - start_time))
                start_time = time.time()
                people_num = 0
            else:
                people_num += leage_members
                matchserver.Match_League_JoinMatchRequest(leage_members)
            gevent.sleep(0)    
            
class WebsiteUser(Locust):
    task_set = ZoneTest
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0
    

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
  
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)

    sys.argv.extend(["-f", __file__, "--no-web",   "-H", "dddss", "-r", "2", "-c", "1"])
    locust.main.main()
