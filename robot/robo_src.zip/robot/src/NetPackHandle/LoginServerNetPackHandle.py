# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import net
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from net.ProtoBuffer.LoginAndClient_pb2 import *
from Family import *
from ModuleState.StateDefine import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success

TIMEOUT = 30

class LoginServerNetPackHandle(object):
    def __init__(self, address, family):
        self.lsConnect = None
        self.lsAddress = address
        
        self.family = family
        self.uuid = self.family.uuid
        self.imei = self.family.imei
        self.userName = self.family.userName

        self.userId = None
        self.token = None
        self.channelId = None
        self.loginToken = None
        self.isFirstLoginRep = True
    
        self.respondL2CHandler = {}
        self.requestC2LHandler = {}
        self.RegeditHandle()

    def RegeditHandle(self):
        for (protocolId, name) in L2CProtocol.items():
            func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
            self.respondL2CHandler[protocolId] = func  
            
    def Init(self):
        self.ConnectLoginServer()
            
    #LoginServer Correlation function
    def ConnectLoginServer(self):
        self.lsConnect = NetConnecter(self.OnLsConnect, self.OnLsDisConnect, self.OnLsProtocol, self.DoLsProtocol)
        self.lsConnect.connect(self.lsAddress)
        asyncresult_manager.await(self, "ConnectLoginServer", TIMEOUT)
        
        
    def DoLsProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnLsProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd

        if cmd_id in L2CProtocol:
            protobuf = L2CProtocol[cmd_id]()
            protobuf.ParseFromString(buffer)
            
        if cmd_id in self.respondL2CHandler:
            self.respondL2CHandler[cmd_id](protobuf)

    def CheckVersionReq(self):
        request = CheckVersionReq()
        request.protocolVersion = 16
        request.imei = self.imei
#         request.resourceVersion = 1
        request.resourceMajorVersion = 1
        request.resourceMinorVersion = 4
        request.resourceBuildVersion = 6136
        request.programMajorVersion = 1
        request.programMinorVersion = 4
        request.programBuildVersion = 6136
        self.lsConnect.send_protocol(CLI_TO_LGI_CHECK_VERSION, request)
        
        asyncresult_manager.await(self, "CheckVersionReq", TIMEOUT)
        
        
    def On_CheckVersionRsp(self, respond):
        # print 'CheckVersionRsp_respond : %s' % respond
        if respond.result == 1:
            asyncresult_manager.fire(self, "CheckVersionReq", True)
            self.loginToken = respond.loginToken
            self.AccountLoginReq()
        elif respond.result == 3: # CheckVersionRsp_Result_SERVER_LOAD_IS_FULL
            asyncresult_manager.fire(self, "CheckVersionReq", True)
            request_success.fire(request_type='get', name="ServerLoadIsFull", response_time=0, response_length=0)
            gevent.sleep(30)
            self.CheckVersionReq()
        else:
            asyncresult_manager.fire(self, "CheckVersionReq", False, error = respond.result)
            asyncresult_manager.fire(self.family, "All_LoginServer", False)

    def AccountLoginReq(self):
        request = AccountLoginReq()
        request.appGUID = self.uuid
        # print self.userName
        if self.family.authToken:
            request.authInfo = self.family.authToken
        else:
            xgsdk_key = r"E@61~26*/9B&*%6^$F#N"
            request.authInfo = xgsdk_key + "<%s>" % self.userName
        request.loginToken = self.loginToken
        request.deviceID = self.imei
        self.lsConnect.send_protocol(CLI_TO_LGI_ACCOUNT_LOGIN, request)
        asyncresult_manager.await( self, "AccountLoginReq", 60)
    
    
    def On_AccountLoginRsp(self, respond):
        # print 'On_AccountLoginRsp %s' %respond
        if respond.result == 1:  # ACCOUNT_LOGIN_SUCCESS
            if self.isFirstLoginRep or self.family.authToken is not None:
                self.isFirstLoginRep = False
                asyncresult_manager.fire(self, "AccountLoginReq", True)
            self.channelId = respond.channelID
            self.userId = respond.channelUser
            self.groupID = respond.groupID
            self.centerID = respond.centerID
            self.token = respond.gameToken
            self.family.channelId = self.channelId
            self.family.userId = self.userId
            self.family.groupId = self.groupID
            self.family.centerID = self.centerID
            self.family.token = self.token
            self.family.gsAddress = (str(respond.gameIp), respond.gamePort)
            self.family.msAddress = (str(respond.mediaIp), respond.mediaPort)
            self.family.encryptKey = respond.encryptKey
            asyncresult_manager.fire(self.family, "All_LoginServer", True)

            self.LSUninit()
            self.family.SetState(STATE_GS_LOGINING)
        elif respond.result == 5:  # GAME_FULL_WAITTING
            if self.isFirstLoginRep:
                self.isFirstLoginRep = False
                asyncresult_manager.fire(self, "AccountLoginReq", True)
                request_success.fire(request_type='get', name="GameFullWaiting", response_time=0, response_length=0)
            print "********* %d" % respond.waitNumber
        
#         asyncresult_manager.fire(self.family, "All_LoginServer", False)

    # 客户端先发起心跳
    def PingServer(self):
        # while True:
        #     if self.gsConnect and self.gsConnect.connected:
        #         request = PingServer()
        #         request.clientTick = int(time.time())
        #         self.gsConnect.send_protocol(304, request)
        #         gevent.sleep(9)

        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(CLI_TO_LGI_PING)
            gevent.sleep(9)
            # 心跳回包

    def On_ReplyPingClient(self, respond):
        self.family.serverTime.UpdateServerTick(respond.serverTick, respond.unixMSec)
        pass

    def OnLsConnect(self):
        asyncresult_manager.fire(self, "ConnectLoginServer", True)
#         self.LOGIN_NOTIFY_APP_GUID_REQ()
        self.CheckVersionReq()
        gevent.spawn(self.PingServer)
        
    def OnLsDisConnect(self):
        logging.debug("login server disconnect")
        
    def LSUninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
