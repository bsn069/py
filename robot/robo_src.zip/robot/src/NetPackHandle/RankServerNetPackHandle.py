# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import net
import random
import time
import sys
import logging
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from ctypes import *
from struct import pack, unpack
from ctypes import *
from ModuleState.StateDefine import *
from net.NetDefine import *
from net.ProtoBuffer.RankingProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from locust.core import remotecall


RANKING_PROTOCOL_PING_REQ = 800
RANKING_PROTOCOL_UPDATE_DATA_REQ = 802
RANKING_PROTOCOL_GET_RANKING_LIST_REQ = 810
RANKING_PROTOCOL_GET_RANKING_LIST_RSP = 811
RankProtocol = {
                RANKING_PROTOCOL_GET_RANKING_LIST_RSP:GetRankingListResponse,
                }

MEMBER_FAMILY = 50000 
FAMILY_BATCH = 50000 

@remotecall
def get_familyid():
    global MEMBER_FAMILY
    MEMBER_FAMILY += FAMILY_BATCH
    return MEMBER_FAMILY

class ServerNetPackHandle(object):
    
    def __init__(self, address, rankserver):
        self.lsConnect = None
        self.respondR2CHandler = {}
        self.RegeditHandle() 
        self.address = address
        self.server = rankserver
        self.indexid = get_familyid()
        self.startid = self.indexid
        self.member = {}
        
    def RegeditHandle(self):
        for (protocolId, name) in RankProtocol.items(): 
            func = getattr(self, "On_" + str(name).split(".")[-1].rstrip("'>"))
            self.respondR2CHandler[protocolId] = func
            
    def ConnectServer(self, address):
        self.lsConnect = NetConnecter(self.OnConnect, self.OnDisConnect, self.OnProtocol, self.DoProtocol, is_encrypt=False)
        self.lsConnect.connect(address)        

    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
    
        if cmd_id in RankProtocol:
            if True:
                protobuf = RankProtocol[cmd_id]()
                try:
                    protobuf.ParseFromString(buffer)
                except Exception, e:
                    logging.debug("command id = %d, buffer len=%d, trackback = %s" % (cmdId, len(buffer), traceback.format_exc()))
                    return
            else:
                protobuf = buffer
                 
            if cmd_id in self.respondR2CHandler:
                self.respondR2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        self.server.state = STATE_ZO_LOGINING
        asyncresult_manager.fire(self, "RankServerConnected", True)
        gevent.spawn(self.PingServer)
            
    def PingServer(self):
        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(RANKING_PROTOCOL_PING_REQ)
            gevent.sleep(9)
    
    def OnDisConnect(self):
        request_success.fire(request_type='get', name="OnDisConnect", response_time=0, response_length=0) 
        self.server.state = STATE_ZO_DISCONET
        logging.debug("rank server disconnect")
        
    def Uninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
    
    
    def GetRankingListRequest(self, rankListType):
        if rankListType == RANK_LIST_TYPE_COUNT:
            rankListType = RANK_LIST_TYPE_FAMILY_FIGHTING
        request = GetRankingListRequest()
        if rankListType in [1, 10, 11]:
            request.getType = 2
        else:
            request.getType = 1
        request.familyId = self.indexid
        request.rankListType = rankListType
        request.beginIndex = 0
        request.maxCount = 100
        request.myKey = random.randint(1024, 99999)
        self.member[request.familyId] = {"time":time.time()}
        if self.indexid > self.startid + FAMILY_BATCH:
            self.indexid = self.startid
        else:
            self.indexid += 1
        self.lsConnect.send_protocol(RANKING_PROTOCOL_GET_RANKING_LIST_REQ, request)

    def On_GetRankingListResponse(self, respond):
        logging.debug('On_GetRankingListResponse respond=%s' % respond)
        if respond.result == True:
            request_success.fire(request_type='get', name="GetRankingListSuccess", response_time=time.time()-self.member[respond.familyId]["time"], response_length=0) 
        else:
            request_failure.fire(request_type='get', name="GetRankingListSuccess", response_time=0, exception=str(respond.rankListType)) 
        self.UpdateRankDataRequest(respond.familyId ,random.choice(RANK_LIST_TYPE.values()))
        
    def UpdateRankDataRequest(self, familyid, rankListType):
        if rankListType == RANK_LIST_TYPE_COUNT:
            rankListType = RANK_LIST_TYPE_FAMILY_FIGHTING
        request = UpdateRankDataRequest()
        if rankListType in [1, 10, 11]:
            request.rankDataType = 2
        else:
            request.rankDataType = 1
        request.rankListType = rankListType
        request.key = familyid
        request.value = random.randint(1024, 99999)
        request.property = ""
        self.lsConnect.send_protocol(RANKING_PROTOCOL_UPDATE_DATA_REQ, request)
        request_success.fire(request_type='get', name="UpdateRankDataRequest", response_time=0, response_length=0) 

        


        
        
        
