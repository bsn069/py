# -*- coding:utf-8 -*-
from Tools.IncludeDir import InsertIncludeDir
InsertIncludeDir("./net")
from net.ProtoBuffer.LoginAndClient_pb2 import *
from net.ProtoBuffer.ClientToGC_pb2 import *
from net.ProtoBuffer.GCToClient_pb2 import *
from net.ProtoBuffer.GSToClient_pb2 import *
from net.ProtoBuffer.ClientToGS_pb2 import *

from net.ProtoBuffer.LoginAndClientCmd_pb2 import*
from net.ProtoBuffer.ClientToGSCmd_pb2 import *
from net.ProtoBuffer.GSToClientCmd_pb2 import *
from net.ProtoBuffer.ClientToGCCmd_pb2 import *
from net.ProtoBuffer.CliMediaProtocol_pb2 import *
from net.ProtoBuffer.CliMediaCmd_pb2 import *
from net.ProtoBuffer.GameServerProtocol_pb2 import *
from net.ProtoBuffer.PortalProtocol_pb2 import *

from net.ProtoBuffer.ComProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *

#客户端到登陆服务器
C2LProtocol = {
    #old protocol
#     CLI_TO_LGI_NOTIFY_APP_GUID:LOGIN_NOTIFY_APP_GUID_REQ,
#     CLI_TO_LGI_LOGIN_VERIFY:LOGIN_VERIFY_REQ,
    #new protocol
    CLI_TO_LGI_CHECK_VERSION:CheckVersionReq,
    CLI_TO_LGI_ACCOUNT_LOGIN:AccountLoginReq,
    
}

#登陆服务器到客户端
L2CProtocol = {
    #old protocol
#     LGI_TO_CLI_NOTIFY_APP_GUID:LOGIN_NOTIFY_APP_GUID_RSP,
#     LGI_TO_CLI_PROTOCOL_VERIFY:LOGIN_VERIFY_RSP,
    #new protocol
    LGI_TO_CLI_CHECK_VERSION:CheckVersionRsp,
    LGI_TO_CLI_ACCOUNT_LOGIN:AccountLoginRsp,
}

#客户端到游戏服务GS
# C2SProtocol = {
# #     CLI_TO_GS_TRANSFER:PlayerTransfer,
#     CLI_TO_GS_ENTER_GAME:EnterGame,
#     CLI_TO_GS_LEAVE_GAME:LeaveGame,
#     CLI_TO_GS_LOGIN_GAME:AccountLoginReq,
#     CLI_TO_GS_FAMILIY_LIST:ClientFamilyListRequest,
#     CLI_TO_GS_CREATE_FAMILY:ClientCreateFamilyRequest,
#     CLI_TO_GS_ASK_ROLE_NAME:ClientAskRoleNameRequest,
#     CLI_TO_GS_PING:PingServer,
#     #rank
#     CLI_TO_GS_CALL_SCRIPT:C2SCallScript,
#     CLI_TO_GS_GM_COMMAND:C2SGMCommand,
#     CLI_TO_GS_USE_ITEM:UseItem,
#     CLI_TO_GS_APPLY_RANKING_RANK:ApplyRankingRank,
#     CLI_TO_GS_APPLY_RANKING_LIST:ApplyRankingList,
#
#     #新增
#     CLI_TO_GS_ASK_NPC:AskNpc,
#     CLI_TO_GS_FINISH_MAINTASK:ApplyFinishMainTask,
#     CLI_TO_GS_APPLY_TALKTO_NPC:ApplyTalkToNpc,
#     CLI_TO_GS_PLAYER_MOVE:PlayerMove,
#     CLI_TO_GS_PLAYER_STOP:PlayerStop,
#     CLI_TO_GS_PLAYER_TURN:PlayerTurn,
#
#     # 家族
#     CLI_TO_GS_CREATE_KIN:CreateKin,
#     CLI_TO_GS_KIN_LIST:GetKinList,
#     CLI_TO_GS_APPLY_JOIN_KIN:ApplyJoinKin,
#     CLI_TO_GS_QUIT_KIN:ApplyQuitKin,
#     CLI_TO_GS_DISMISS_KIN:ApplyDismissKin,
#     CLI_TO_GS_LOOKUP_KIN:ApplyLookUpKin,
# #     CLI_TO_GS_APPLY_JOIN_KIN_LIST:ApplyJoinKinList,
#     CLI_TO_GS_KIN_KICK:ApplyKinKick,
#     CLI_TO_GS_KIN_APPROVE:ApplyKinApprove,
#     CLI_TO_GS_KIN_APPLY_SETTING:KinApplySetting,
#     CLI_TO_GS_KIN_SET_POST:ApplyKinSetPost,
#     CLI_TO_GS_KIN_SET_NOTICE:KinSetNotice,
#
# }

#客户端到游戏服GC 
C2GCProtocol = {
    #好友
#     CLI_TO_GC_APPLY_RELATION_DATA:ApplyRelationData,
    CLI_TO_GC_SEARCH_FAMILY:SearchFamilyReq,
    CLI_TO_GC_ADD_FRIEND:ApplyAddFriend,
    CLI_TO_GC_AGREE_ADD_FRIEND:AgreeAddFriend,
    CLI_TO_GC_REFUSE_ADD_FRIEND:RefuseAddFriend,
    CLI_TO_GC_REMOVE_FRIEND:RemoveFriend,
    CLI_TO_GC_RECOMMAND_FRIEND:RecommandFriendReq,
}
from net.ProtoBuffer.GSToClientCmd_pb2 import GC_TO_CLI_CREATE_PAY_ORDER_RSP
#游戏服务器GS到客户端
S2CProtocol = {
    GS_TO_CLI_SYNC_DROP_INFO:SyncSceneDropInfo,
    GS_TO_CLI_CHARACTER_ENTER_SCENE:CharacterSyncInfo,
    GS_TO_CLI_CHARACTER_LEAVE_SCENE:CharacterLeaveScene,
    GS_TO_CLI_SYNC_CHARACTER_SHOUTING:SyncCharacterShouting,
    GS_TO_CLI_SKILL_CD_INDEX_LEFT_TIME:SkillCDInfoList,
    GS_TO_CLI_NOTIFY_PAY_SUCCESS:NotifyPaySuccess,
    GS_TO_CLI_SYNC_FAMILY_ACTIVE_MEMBER:SyncActiveMember,
    GS_TO_CLI_PLAYER_ENTER_SCENE:PlayerEnterScene,
    GS_TO_CLI_PLAYER_LEAVE_SCENE:PlayerLeaveScene,
    GS_TO_CLI_SYNC_CHARACTER_STATE:SyncCharacterState,
    GS_TO_CLI_SYNC_PLAYER_ALL_SKILL:SyncPlayerSkillData,
    GS_TO_CLI_SYNC_ALL_CHARACTER_INFO:SyncSceneCharacterInfo,
    GS_TO_CLI_HAND_SHAKE_RSP:LoginGameHandShakeResponse,
    GS_TO_CLI_LOGIN_GAME:ClientLoginGameResponse,
    GS_TO_CLI_NOTIFY_CLIENT_STATE:NotifyClientState,
    GS_TO_CLI_FAMILIY_LIST:ClientFamilyListResponse,
    GS_TO_CLI_CREATE_FAMILIY:ClientCreateFamilyResponse,
    GS_TO_CLI_ASK_ROLE_NAME:ClientAskRoleNameResponse,
    # GS_TO_CLI_PING:PingClient,
    GS_TO_CLI_SYNC_FAMILY_DATA_SET:SyncFamilyDataSet,
    GS_TO_CLI_SYNC_CHARACTER_DATA_COMMON:SyncDataCommon,
    GS_TO_CLI_SYNC_CURRENT_PLAYER:CurrentPlayer,
    GS_TO_CLI_SYNC_CURRENT_FAMILY:CurrentFamily,
    GS_TO_CLI_SYNC_ADD_ITEM:SyncAddItem,
    GS_TO_CLI_SYNC_USE_ITEM_RESULT:SyncUseItemResult,
    GS_TO_CLI_RANKING_RANK_RESULT:RankingRankResult,
    GS_TO_CLI_RANKING_LIST_RESULT:RankingListResult,
    GS_TO_CLI_LOGOUT_GAME:NotifyLogoutGame,
    GS_TO_CLI_SYNC_CURRENT_FAMILY:CurrentFamily,
    # GS_TO_CLI_SYNC_CURRENT_PLAYER:CurrentPlayer,
    GS_TO_CLI_PLAYER_ENTER_SCENE:PlayerEnterScene,
    GS_TO_CLI_RETIRE:ClientRetireRsp,
    GS_TO_CLI_UNRETIRE:ClientRetireRsp,

    #心跳
    GS_TO_CLI_REPLY_PING:ReplyPingClient,
    
    #炼化
    GS_TO_CLI_SYNC_ALCHEMY:SyncAlchemyItem,
    
    #装备
    GS_TO_CLI_SYNC_EQUIPGRID_ENHANCE_RES:SyncEquipGridEnhanceResult,
    GS_TO_CLI_SYNC_GRID_ENHANCE_DATA:EquipGridEnhance,
    GS_TO_CLI_SYNC_ENCHANT_RESULT:SyncEnchantResult,
    #新增
#     GS_TO_CLI_SYNC_MAINTASK_STATE:SyncMainTaskState,
#     GS_TO_CLI_FINISH_MAINTASK_RESULT:FinishMainTaskResult,
    #GS_TO_CLI_SYNC_TASK_STATE:SyncTaskStateChanged,
    
    #聊天
    GS_TO_CLI_CHAT:SyncChatMsg,
    GC_TO_CLI_SYNC_OFFLINE_MSG_RSP:SyncOfflineMsgRsp,
    
    #打坐获取精气
    GS_TO_CLI_SYNC_MERIDIAN:SyncMeridian,


    #时装\挂件
    GS_TO_CLI_BUY_AVATAR_RESULT:BuyAvatarResult,
    GS_TO_CLI_TAKE_OFF_AVATAR_RESULT:TakeOffAvatarResult,
    GS_TO_CLI_PUT_ON_AVATAR_RESULT:PutOnAvatarResult,

    #秘籍
    GS_TO_CLI_SYNC_EQUIP_BOOK:SyncEquipBookResult,
    GS_TO_CLI_SYNC_UNEQUIP_BOOK_RESULT:SyncUnEquipBookResult,
    GS_TO_CLI_SYNC_BOOK_ADD_EXP:SyncAddBookExp,
    
    GS_TO_CLI_SYNC_DEL_ITEM:SyncDelItem,
    GS_TO_CLI_SYNC_ITEM_SELL_REUSLT:SyncItemSellResult,

    #坐骑
    GS_TO_CLI_BUY_RIDE_RESULT:BuyAvatarResult,
    GS_TO_CLI_PUT_ON_RIDE_RESULT:PutOnAvatarResult,
    GS_TO_CLI_TAKE_OFF_RIDE_RESULT:TakeOffAvatarResult,

    #同步avater相关
    GS_TO_CLI_SYNC_ALL_AVATAR:FamilyAvatarData,

    GS_TO_CLI_PLAYER_ENTER_SCENE:PlayerEnterScene,
    
    GS_TO_CLI_SYNC_FAMILY_DATA_COMMON:SyncDataCommon,
    
    # 家族
    GS_TO_CLI_CREATE_KIN_RESULT:SyncCreateKinResult,
    GS_TO_CLI_GET_KIN_LIST_RESULT:SyncKinListResult,
    GS_TO_CLI_APPLY_JOIN_KIN_RESULT:SyncJoinKinResult,
    GS_TO_CLI_QUIT_KIN_RESULT:SyncQuitKinResult,
    GS_TO_CLI_DISMISS_KIN_RESULT:SyncDismissKinResult,
    GS_TO_CLI_SYNC_KIN_DATA_ALL:SyncKinData,
    GS_TO_CLI_SYNC_KIN_DATA_BASE:SyncKinBaseData,
    GS_TO_CLI_KIN_MEMBER_CHANGE:SyncKinMemberChange,
    GS_TO_CLI_KIN_APPLYER_CHANGE:SyncKinApplyerChange,
    GS_TO_CLI_KIN_LOOKUP_RESULT:SyncKinLookupResult,
#     GS_TO_CLI_APPLY_JOIN_KIN_LIST_RESULT:SyncJoinKinListResult,
    GS_TO_CLI_KIN_KICK_RESULT:SyncKinKickResult,
    GS_TO_CLI_KIN_APPLY_SETTING_RESULT:SyncKinSettingResult,
    GS_TO_CLI_KIN_SET_POST_RESULT:SyncKinSetPostResult,
#     GS_TO_CLI_KIN_ARRPOVE_RESULT:SyncKinApproveResult,
    GS_TO_CLI_KIN_SET_NOTICE_RESULT:SyncKinSetNoticeResult,
    GS_TO_CLI_SYNC_GOODS_LIST:SyncShopGoodsList,#218
    GS_TO_CLI_SYNC_KIN_WEEK_ROOM_INFO:SyncKinWeekGameInfo,
    
    # 好友
    GS_TO_CLI_SYNC_RELATION_DATA:SyncRelationData,
    GS_TO_CLI_SEARCH_FAMILY_RESULT:SearchFamilyRsp,
    GS_TO_CLI_ADD_FRIEND_RESULT:AddFriendRsp,
    GS_TO_CLI_AGREE_ADD_FRIEND_RESULT:AgreeAddFriendRsp,
    GS_TO_CLI_REFUSE_ADD_FRIEND_RESULT:RefuseAddFriendRsp,
    GS_TO_CLI_REMOVE_FRIEND_RESULT:RemoveFriendRsp,
    GS_TO_CLI_RELATION_RECOMMAND_RESULT:RecommandFamilyRsp,
    GS_TO_CLI_SEARCH_FAMILY_GLOBAL_RSP:GlobalSearchFamilyRsp,
    GS_TO_CLI_PUSH_RELATION_DATA:SyncRelationData,
    GC_TO_CLI_REMOVE_BLACKLIST_RESULT:RemoveBlackListRsp,

    #仇人
    GS_TO_CLI_RELATION_SYNC_REVENGEE_INFO:SyncRevengeeInfo,

    #开穴
    GS_TO_CLI_OPEN_ACUPOINT_RESULT:SyncOpenAcuPointResult,

    #宝石结果
    GS_TO_CLI_SYNC_ENCHASE_STONE_RESULT:SyncEnchaseStoneResult,
    GS_TO_CLI_SYNC_STONE_PEEL_REULST:SyncPeelStoneResult,

    #道具减少
    GS_TO_CLI_SYNC_ITEM_COUNT_CHANGE:SyncItemCountChange,
    GS_TO_CLI_SYNC_EQUIP_DEV_RESULT:SyncEquipDevelopResult,

    #武林联赛
    GS_TO_CLI_LEAGUE_MATCH_CHECK_JOIN_RESPONSE:LeagueMatch_CheckJoinResponse,
    GS_TO_CLI_LEAGUE_MATCH_JOIN_RESPONSE:LeagueMatch_JoinResponse,
    GS_TO_CLI_LEAGUE_MATCH_CANCEL_RESPONSE:LeagueMatch_CancelResponse,
    GS_TO_CLI_LEAGUE_MATCH_MATCH_STATE_NOTIFY:LeagueMatch_MatchStateNotify,#当前匹配状态
#     GS_TO_CLI_LEAGUE_MATCH_FIGHT_INFO_NOTIFY:LeagueMatch_FightInfo,#当前战场信息通知
#     GS_TO_CLI_LEAGUE_MATCH_FIGHT_RESULT:LeagueMatch_FightResult,#比赛结果
#     GS_TO_CLI_LEAGUE_MATCH_FIGHT_SCENE_STATE:LeagueMatch_SceneState,#当前战场状态
    #战场
    GS_TO_CLI_BATTLEFIELD_MATCH_JOIN_RESPONSE:BattleFieldMatch_JoinResponse,
    GS_TO_CLI_BATTLEFIELD_MATCH_CANCEL_RESPONSE:BattleFieldMatch_CancelResponse,
    GS_TO_CLI_BATTLEFIELD_MATCH_MATCH_STATE_NOTIFY:BattleFieldMatch_MatchStateNotify,#562当前匹配状态
    GS_TO_CLI_BATTLEFIELD_MATCH_FIGHT_INFO_NOTIFY:BattleFieldMatch_FightInfo,#563当前战场信息通知
#     GS_TO_CLI_BATTLEFIELD_MATCH_FIGHT_RESULT:BattleFieldMatch_FightResult,#564比赛结果  协议被废弃  
    
#    GS_TO_CLI_TEAM_INVITE_JOIN_YABIAO:TeamInviteJoinYabiao,

######### 旧proto(GS2C)
#     GS_TO_CLI_LEAGUE_MATCH_MATCH_TEAMMATER:LeagueMatch_MatchTeammaterResponse,
#     GS_TO_CLI_LEAGUE_MATCH_CANCEL_MATCH_TEAMMATER:LeagueMatch_CancelMatchTeammaterResponse,
#     GS_TO_CLI_LEAGUE_MATCH_INVATE_TEAMMATER:LeagueMatch_InviteTeammaterResponse,
#     GS_TO_CLI_LEAGUE_MATCH_BE_INVATE_TEAMMATER:LeagueMatch_BeInviteTeammaterRequest,
#     GS_TO_CLI_LEAGUE_MATCH_MATCH_COMPETITOR:LeagueMatch_MatchCompetitorsResponse,
#     GS_TO_CLI_LEAGUE_MATCH_CANCEL_MATCH_COMPETITOR:LeagueMatch_CancelMatchCompetitorsResponse,
#     GS_TO_CLI_LEAGUE_MATCH_MATCH_STATE_NOTIFY:LeagueMatch_MatchStateNotify,
#     GS_TO_CLI_LEAGUE_MATCH_FIGHT_RESULT:LeagueMatch_FightResult,
#########

    # 副本
    GS_TO_CLI_ANS_START_SINGLE_MISSION:AnsStartSingleMission,
    GS_TO_CLI_ANS_END_SINGLE_MISSION:AnsEndSingleMission,
    GS_TO_CLI_SYNC_CAST_SKILL:SyncCastSkill,
    GS_TO_CLI_SKILL_HIT:SkillHit,
    GS_TO_CLI_REPLACE_SKILL:ReplaceSkill,
    GS_TO_CLI_SYNC_SKILL_STATE:SyncSkillState,
    GS_TO_CLI_SYNC_SKILL_RESULT:SyncSkillResult,
    GS_TO_CLI_SKILL_MISSILE_LAUNCH:SkillMissileLaunch,
    
    #福利
    GS_TO_CLI_ENTER_TEA_ROOM_RESULT:SyncEnterTeaRoomRes,
    GS_TO_CLI_LEAVING_TEA_ROOM_RESULT:SyncLeavingTeaRoom,
    GS_TO_CLI_SYNC_TASTE_TEA_STATE:SyncTasteTeaState,
    GS_TO_CLI_SYNC_TASTE_TEA_AWARD:SyncTasteTeaAward,
    GS_TO_CLI_SYNC_TALKINT_TEA_CONTENT:SyncTeaRoomTalkingContent,

    GC_TO_CLI_CREATE_PAY_ORDER_RSP:CreatePayOrderMsg,
    GS_TO_CLI_SYNC_GRAB_TEA_AWARD_INFO:SyncGrabTeaInfo,

    
    #换线(场景线路信息等)
    GS_TO_CLI_GET_SCENE_LINE_INFO:SceneLineInfo,
    GS_TO_CLI_GET_SCENE_LINE_LIST:SceneLineListResult,
    GS_TO_CLI_SWITCH_SCENE_LINE_ERROR:"SwitchSceneLineError",
    #护法
    GS_TO_CLI_SYNC_GUARDIAN_ACTIVE_RES:ActiveGuardianResult,#211
    GS_TO_CLI_SYNC_GUARDIAN_ADD_EXP:SyncGuardianAddExp,#212
    GS_TO_CLI_SYNC_GUARDIAN_VISIT_RES:VisitGuardianResult,#213
    GS_TO_CLI_SYNC_GUARDIAN_FULL_SYNC:FamilyGuardianDbData,#214
    GS_TO_CLI_SYNC_UNLOCK_GUARDIAN:SyncGuardianUnLock,#215
    GS_TO_CLI_SYNC_GUARDIAN_SLOT_OPEN:SyncGuardianSlotOpen,#217
    GS_TO_CLI_SYNC_GUARDIAN_RECRUIT_RES:SyncGuardianRecruitRes,#223
    
    GS_TO_CLI_SYNC_KIN_SKILL_USE_RESULT:SyncKinSkillUseResult,#523技能使用结果
    GS_TO_CLI_SYNC_KIN_SKILL_UPGRADE_RESULT:SyncKinSkillUpgradeResult,#524技能升级结果

    #商店
    GS_TO_CLI_BUY_SHOP_ITEM_RESULT:BuyShopItemResult,#403

    
    #NPC对话
    GS_TO_CLI_NPC_SAY:DialogInfo,#700
    GS_TO_CLI_CHAT_RESULT:SyncChatResult,#371

    # 任务
    # GS_TO_CLI_SYNC_GM_TASK_AWARD = 469,
    GS_TO_CLI_SYNC_UPDATE_TASK: SyncUpdateTask,
    GS_TO_CLI_SYNC_REMOVE_TASK: SyncRemoveTask,
    GS_TO_CLI_SYNC_TASK_AWARD:SyncTaskAward,
    
    #组队
    GS_TO_CLI_TEAM_INFO_SYNC:TeamInfoSync,                       # 530; //同步队伍信息
    GS_TO_CLI_TEAM_MEMBER_INFO_SYNC:TeamMemberInfoSync,
    GS_TO_CLI_TEAM_APPLY_LIST_SYNC:TeamApplyListSync,           # 532; //同步队伍申请列表信息
    GS_TO_CLI_TEAM_INVITE_LIST_SYNC:TeamInviteListSync,       # 533; //同步队伍邀请列表信息
    GS_TO_CLI_TEAM_LIST_QUERY_RESULT:TeamListResult,
    GS_TO_CLI_TEAM_TIPS:TeamTips, #//队伍相关tips
#     GS_TO_CLI_TEAM_CHECK_JOIN_ACTIVITY_RSP:TeamCheckJoinActivityRsp,# 543; //检查队员能否参加活动回复
#     GS_TO_CLI_TEAM_STATE_SYNC:TeamStateSync,
    GS_TO_CLI_TEAM_INVITE_JOIN_ACTIVITY:TeamInviteJoinActivity,               # 544; //邀请队员参加活动
    # GS_TO_CLI_TEAM_INVITE_JOIN_ACTIVITY_REPLY:TeamInviteJoinActivityReply,    # 545; //邀请队员参加活动回复
    # GC_TO_CLIE_TEAM_SYNC:SyncTeamInfo,#1026
    # GC_TO_CLIE_TEAM_LIST_RES:TeamListRes,#1027
    # GC_TO_CLIE_TEAM_APPLY_LIST_SYNC:TeamApplyListSync,#1028
    # GC_TO_CLIE_TEAM_INVITE_LIST_SYNC:TeamInviteListSync,#1029
    # GC_TO_CLIE_TEAM_CHECK_JOIN_RESULT:TeamJoinCheckResult,#1030
    GS_TO_CLI_TEAM_MEMBER_CALL_CHECK_RESULT:TeamMemberCallCheckResult, # 队伍召唤检查结果 
    GS_TO_CLI_TEAM_MEMBER_CALL:TeamMemberCall,
    
    #跨服约战
    GS_TO_CLI_NVN_CREATE_ROOM_RSP:NVNResult,
    GS_TO_CLI_NVN_JOIN_ROOM_RSP:NVNResult,
    GS_TO_CLI_NVN_ROOMLIST_RSP:NVNRoomList,
    
    #扫荡
#    GS_TO_CLI_ANS_SWEEP_SINGLE_MISSION:AnsSweepSingleMission,#104
    #通知支线完成
#     GS_TO_CLI_APPLY_ACHIEVE_AWARD:SyncTaskAwardPreview,#426
    
    #同步日常任务列表
    #GS_TO_CLI_SYNC_DAILYTASK_LIST:SyncFamilyTaskList,#452
    
    #调用客户端脚本
    GS_TO_CLI_CALL_SCRIPT:ClientScript,#323
    
    #副本结算时响应
    GS_TO_CLI_SYNC_FAMILY_AWARD_INFO:FamilyAddAwardInfo,#94

    #角色位置
    GS_TO_CLI_SYNC_CHARACTER_POSITION:SyncCharacterPosition,
    
    #表情
    # GS_TO_CLI_SYNC_GESTURE_PLAY:SyncGesturePlay,
    # GS_TO_CLI_SYNC_GESTURE_STOP:SyncGestureStop,

    #拍卖行
    GS_TO_CLI_TRADEHOUSE_PUTON:TradeHouse_PutOnSale_Result,#230
    GS_TO_CLI_TRADEHOUSE_PUTOFF:TradeHouse_PutOffShelves_Result,#231
    GS_TO_CLI_TRADEHOUSE_BUYGOODS:TradeHouse_BuyGoods_Result,#232
    GS_TO_CLI_TRADEHOUSE_GETTRADELIST:TradeHouse_GetTradeList_Result,#233
    GS_TO_CLI_TRADEHOUSE_GETTRADEHISTORY:TradeHouse_GetTradeHistory_Result,#234
    GS_TO_CLI_TRADEHOUSE_GETSALELIST:TradeHouse_GetMySaleList_Result,#235
    GS_TO_CLI_TRADEHOUSE_GETTRADEPRICE:TradeHouse_GetTradePrice_Result,#236
    GS_TO_CLI_TRADEHOUSE_REPUTON:TradeHouse_RePutOn_Result,#237
    GS_TO_CLI_TRADEHOUSE_REFRESH:TradeHouse_Refresh_Result,
    GC_TO_CLI_SYNC_RED_PACKET:SyncRedPacketRsp,
    GC_TO_CLI_SYNC_RED_PACKET_HISTORY:SyncRedPacketHistoryRsp,
    #限时竞拍
    GS_TO_CLI_CHAT:SyncChatMsg,
    GC_TO_CLI_AUCTION_BASEINFO_RSP:AuctionBaseInfoRsp,#1610
    GC_TO_CLI_AUCTION_SHOPDATA_RSP:AuctionShopDataRsp,#1611
    GC_TO_CLI_AUCTION_GOODSDATA_RSP:AuctionGoodsDataRsp,#1612
    GC_TO_CLI_AUCTION_BID_RSP:AuctionBidGoodsRsp,       #1613
    GC_TO_CLI_AUCTION_BID_SYNC:SyncAuctionBidSuccess,#1614
    GC_TO_CLI_AUCTION_SELLOUT_SYNC:SyncAuctionSellout, #1615
    # 钓鱼
#     GS_TO_CLI_BUY_FISH_BAIT_RES:SyncFishBaitResult,
#     GS_TO_CLI_SYNC_FISH_IN_HOOKIKNG:SyncNewFishInHooking,
#     GS_TO_CLI_SYNC_FISH_TASK_AWARD:SyncFishTaskAward,
#     GS_TO_CLI_SYNC_ACCEPT_TASK_RES:SyncAcceptFishTaskRes,
#     GS_TO_CLI_SYNC_GET_ONE_FISH:SyncGetOneFish,
    # 邮件
    GS_TO_CLI_REMOVE_MAIL:RemoveMailRsp,
    GS_TO_CLI_READED_MAIL:ReadedMailRsp,
    # GS_TO_CLI_MAILBOX_LOADED:MailBoxLoaded,
    GS_TO_CLI_NEW_MAIL:NewMailNotify,
    GS_TO_CLI_GET_MAIL_ATTACHMENT:GetMailAttachmentRsp,
    GS_TO_CLI_SYNC_MAILBOX:SyncMailBox,
    # GS_TO_CLI_EXPIRED_MAIL:RemoveMailRsp,

    # 论剑
    GS_TO_CLI_LUN_JIAN_RSP_CHALLENGE_LIST:LunJianRspChallengeList,    # 论剑 刷新挑战列表
    # GS_TO_CLI_LUN_JIAN_GET_CHALLENGE_HISTORY_RES    = 801;        # 论剑 获取挑战记录
    # GS_TO_CLI_LUN_JIAN_GET_FAMILY_MEMBERS_RES    = 802;        # 论剑 获取家庭成员数据
    # GS_TO_CLI_LUN_JIAN_FIGHT_POWER_PROTECTED    = 803;        # 论剑 战力保护

    #助战
    GS_TO_CLI_ON_RECEIVE_ASSIST_REQUEST:ReceiveAssistRequest,
    GS_TO_CLI_ANS_ASSIST_RESULT:AnswerAssistRequestRsp,
    GC_TO_CLI_ASSIST_REQUEST_ANSWERED:AssistAnswerNotify,
#     ProtoBuffer.GSToClientCmd_pb2.GC_TO_CLI_ASSIST_REQUEST_ANSWERED:AssistAnswerNotify,
    GS_TO_CLI_GET_FAMILY_LOCATION_RSP:SvrGetFamilyLocationRsp,
    #送礼
    GS_TO_CLI_GIFT_SEND_RESULT:SendGiftRsp,

    #染色
    GS_TO_CLI_SYNC_ALL_COLORING_DATA:FamilyColoringData,
    GS_TO_CLI_COLORING_ITEM_RSP:SyncColoringItemRsp,
    GS_TO_CLI_CHANGE_COLORING_PLAN:SyncUseColoringPlanRsp,
    GS_TO_CLI_DEL_COLORING_PLAN:SyncDelColoringPlanRsp,
    
    #易容
    GS_TO_CLI_SYNC_CUSTOM_FACE_STANDALONE:SyncCustomFaceStandAlone,
    GS_TO_CLI_SYNC_MODIFY_FACE_RESULT:SyncSetCustomFaceResult,

     #休闲动作
    GS_TO_CLI_START_DOUBLE_ACTION:StartDoubleAction,
    GS_TO_CLI_STOP_DOUBLE_ACTION:StopDoubleAction,
    
    #改名
    GS_TO_CLI_CHANGE_ROLE_NAME:ChangeRoleNameRsp,
    
    #礼物相关
    GS_TO_CLI_GIFT_SYNC_LIST:SyncGiftListRsp,#902        // 礼物列表信息
    GS_TO_CLI_GIFT_SYNC_ONE:SyncOneGiftRsp,#903        // 礼物详细信息
    GS_TO_CLI_GIFT_GET_RSP:GetOneGiftRsp,#904        // 获取礼物结果
    GS_TO_CLI_GIFT_RECV_NEW:SyncGiftListRsp,#905        // 收到新礼物
#     GS_TO_CLI_GIFT_THANKS:ThanksForGift,#906 // 答谢礼物
    #密友
    GS_TO_CLI_ADD_CLOSEFRIEND_RESULT:AddCloseFriendRsp,
    GS_TO_CLI_AGREE_ADD_CLOSEFRIEND_RESULT:AgreeAddCloseFriendRsp,
#     GS_TO_CLI_REFUSE_ADD_CLOSEFRIEND_RESULT:RefuseAddCloseFriendRsp,
    GS_TO_CLI_REMOVE_CLOSEFRIEND_RESULT:RemoveCloseFriendRsp,
    
    GS_TO_CLI_SYNC_KIN_LAND_INFO:SyncKinLandInfo,
    
    #师徒
    GS_TO_CLI_SCHOOL_APPLY_RSP:ApplySchoolRsp,
    GS_TO_CLI_SCHOOL_REPLY_RSP:ReplySchoolApplyRsp,
    GS_TO_CLI_SCHOOL_GRADUATION_RSP:GraduationRsp,
    GS_TO_CLI_SCHOOL_QUIT_RSP:SchoolQuitRsp,
    GS_TO_CLI_SCHOOL_QUIT_AGREE_RSP:SchoolQuitAgreeRsp,
    GS_TO_CLI_SCHOOL_RECOMMAND_MASTER_RSP:RecommandMasterRsp,
    GS_TO_CLI_SCHOOL_RECOMMAND_STUDENT_RSP:RecommandStudentRsp,
    GS_TO_CLI_SCHOOL_NOTIFY_COMPLETE_MASTER_TASK:NotifyCompleteMasterTask,
    GS_TO_CLI_SCHOOL_SET_BASE_INFO_RSP:SetSchoolBaseInfoResult,
    GS_TO_CLI_SCHOOL_MODIFY_ANNOUNCE_RESULT:SetSchoolAnnounceResult,
    GS_TO_CLI_SCHOOL_SET_SEARCH_RESULT:SchoolSetSearchRsp,
    GS_TO_CLI_SCHOOL_CANCEL_QUIT_RSP:SchoolCancelQuitRsp,
    
    #聊天室
    GC_TO_CLI_ACTIVE_CHATROOM:FindChatRoomResult,
    GC_TO_CLI_FIND_CHATROOM_RSP:FindChatRoomResult,
    GCS_TO_CLI_SYNC_CHATROOM_INFO:ChatRoomInfo,
    GCS_TO_CLI_MEMBER_CHANGE_INFO:MemberChangeInfo,
    GCS_TO_CLI_INVITE_FAMILY:InviteEnterRoomRsp,
    GCS_TO_CLI_OPTERATE_RES:ChatRoomOperateInfo,
    GS_TO_CLI_SYNC_CHATROOM_APPID:SyncRoomChatAppID,
    GS_TO_CLI_ARQ_PACK:"RecvARQPack",
    
    #大秘境
    GS_TO_CLI_DAMIJING_ROB_LIST:DaMiJingRobListRsp,
    GS_TO_CLI_DAMIJING_ROB_SEARCH:DaMiJingRobListRsp,
    GS_TO_CLI_DAMIJING_APPLY_ROB_RESUILT:DaMiJingApplyRobResult,
    
    # 成就奖励
    GS_TO_CLI_SYNC_NEW_ACHIEVE_COMPLETE:SyncNewAchieveComplete,
    GC_TO_CLI_CHECK_JOIN_TEAM_IN_GC_RESULT:PbCheckJoinTeamInGc,
    GC_TO_CLI_CHECK_JOIN_TEAM_IN_GS_RESULT:PbCheckJoinTeamInGs,
    
    # LBS
    GS_TO_CLI_SET_FAMILY_LOCATION_RSP: SvrSetFamilyLocationRsp,
    
    # 同步时间
    GS_TO_CLI_SYNC_TIME_FRAME:SyncTimeFrame,
}

#Media服务器到客户端
M2CProtocol = {
    #家园
    MEDIA_TO_CLI_REGISTER_RSP:CliRegisterMediaRsp,
    MEDIA_TO_CLI_GET_OWNERINFO_RSP:GetOwnerInfoRsp,
    MEDIA_TO_CLI_SET_BLOGDECLARE_RSP:SetBlogDeclareRsp,
    MEDIA_TO_CLI_ADD_BLOGLIKE_RSP:AddBlogLikeRsp,
    MEDIA_TO_CLI_GET_BOARD_RSP:GetBoardMsgRsp,
    MEDIA_TO_CLI_ADD_BOARD_RSP:AddBoardMsgRsp,
    MEDIA_TO_CLI_DEL_BOARD_RSP:DelBoardMsgRsp,
    MEDIA_TO_CLI_GET_MOOD_RSP:GetMoodMsgRsp,
    MEDIA_TO_CLI_ADD_MOOD_RSP:AddMoodMsgRsp,
    MEDIA_TO_CLI_DEL_MOOD_RSP:DelMoodMsgRsp,
    MEDIA_TO_CLI_ADD_MOODCOMMENT_RSP:AddMoodCommentRsp,
    MEDIA_TO_CLI_DEL_MOODCOMMENT_RSP:DelMoodCommentRsp,
    MEDIA_TO_CLI_ADD_MOODLIKE_RSP:AddMoodLikeRsp,
}

C2ProtalProtocol = {
    client_to_portal_report_local_state:ReportLocalState,
    client_to_portal_select_group_id:SelectServerRecord,
    client_to_portal_ping:PingPortal,
    client_to_portal_get_login_time:ApplyLoginTimeReq,
}

Protal2CProtocol = {
    portal_to_client_sync_recommend:SyncRecommendServer,
    portal_to_client_sync_server_list:ClientServerList,
    portal_to_client_sync_billboard:SyncBillboard,
    # portal_to_client_sync_server_state = 2004,
    portal_to_client_ping:PingPortal,
    portal_to_client_get_login_time:ApplyLoginTimeRsp,
}