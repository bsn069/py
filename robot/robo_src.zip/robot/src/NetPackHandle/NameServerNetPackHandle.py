# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import net
import random
import time
import sys
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from Family import *
from ctypes import *
from struct import pack, unpack
from ctypes import *
from ModuleState.StateDefine import *
from net.NetDefine import *
from net.ProtoBuffer.NameProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from GenerateChinese import generate_chinese
from locust.core import remotecall


NAME_SERVER_PROTOCOL_PING_REQ = 600
NAME_SERVER_PROTOCOL_ASK_ROLE_NAME_REQ = 601

NAME_SERVER_PROTOCOL_ASK_ROLE_NAME_RSP = 602
NAME_SERVER_PROTOCOL_LOCK_ROLE_NAME_LITTLE_TIME_REQ = 603

NAME_SERVER_PROTOCOL_LOCK_ROLE_NAME_LITTLE_TIME_RSP = 604
NameProtocol = {
                NAME_SERVER_PROTOCOL_ASK_ROLE_NAME_RSP:AskRoleNameResponse,
                NAME_SERVER_PROTOCOL_LOCK_ROLE_NAME_LITTLE_TIME_RSP:LockRoleNameRsp,
                }

MEMBER_FAMILY = 50000 #起始familyid
FAMILY_BATCH = 50000  #每个GS链接的发送量

@remotecall
def get_familyid():
    global MEMBER_FAMILY
    MEMBER_FAMILY += FAMILY_BATCH
    return MEMBER_FAMILY

class ServerNetPackHandle(object):
    
    def __init__(self, address, nameserver):
        self.lsConnect = None
        self.respondN2CHandler = {}
        self.RegeditHandle() 
        self.address = address
        self.server = nameserver
        self.indexid = get_familyid()
        self.member = {}
        
    def RegeditHandle(self):
        for (protocolId, name) in NameProtocol.items(): 
            func = getattr(self, "On_" + str(name).split(".")[-1].rstrip("'>"))
            self.respondN2CHandler[protocolId] = func
            
    def ConnectServer(self, address):
        self.lsConnect = NetConnecter(self.OnConnect, self.OnDisConnect, self.OnProtocol, self.DoProtocol, is_encrypt=False)
        self.lsConnect.connect(address)        

    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
    
        if cmd_id in NameProtocol:
            if True:
                protobuf = NameProtocol[cmd_id]()
                try:
                    protobuf.ParseFromString(buffer)
                except Exception, e:
                    logging.debug("command id = %d, buffer len=%d, trackback = %s" % (cmdId, len(buffer), traceback.format_exc()))
                    return
            else:
                protobuf = buffer
                 
            if cmd_id in self.respondN2CHandler:
                self.respondN2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        self.server.state = STATE_ZO_LOGINING
        asyncresult_manager.fire(self, "NameServerConnected", True)
        gevent.spawn(self.PingServer)
            
    def PingServer(self):
        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(NAME_SERVER_PROTOCOL_PING_REQ)
            gevent.sleep(9)
    
    def OnDisConnect(self):
        request_success.fire(request_type='get', name="OnDisConnect", response_time=0, response_length=0) 
        self.server.state = STATE_ZO_DISCONET
        logging.debug("zone server disconnect")
        
    def Uninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
    
    def AskRoleNameRequest(self):
        request = AskRoleNameRequest()
        request.idtype = NAME_REQUEST_ID_TYPE_CONNID
        request.source = NAME_SOURCE_MODULE_CREATE_CHARACTER
        request.count = 30
        request.sexuality = NAME_GENDER_TYPE_MALE
        request.isverify = False
        request.id = self.indexid
        self.member[request.id] = {"time":time.time(), "type":True, "Name": u"一号"}
#        self.member.setdefault(request.id, time.time())
        self.indexid += 1
        self.lsConnect.send_protocol(NAME_SERVER_PROTOCOL_ASK_ROLE_NAME_REQ, request)

        
    def On_AskRoleNameResponse(self, respond):
        logging.debug("On_AskRoleNameResponse respond = %s" % respond)
        request_success.fire(request_type='get', name="AskRoleNameSucess", response_time=time.time()- self.member[int(respond.id)]["time"], response_length=0) 
        self.member[respond.id]["Name"] = respond.name[:2][1]
        self.LockRoleNameReq(respond.id, respond.name[:2][0])
        
    def LockRoleNameReq(self, user_id, name = None):
        request = LockRoleNameReq()
        request.name = name
        request.user_id = u"%s"% str(user_id)
        request.__setattr__("from", 1)
        request.request_id = user_id
        self.member[user_id]["time"] = time.time()
        self.lsConnect.send_protocol(NAME_SERVER_PROTOCOL_LOCK_ROLE_NAME_LITTLE_TIME_REQ, request)

    def On_LockRoleNameRsp(self, respond):
        '''
            lock_role_name_result_success                = 0;
            lock_role_name_result_fail_name_exsit        = 1;  // 名字重复
            lock_role_name_result_fail_name_length       = 2;  // 长度不符合要求
            lock_role_name_result_fail_name_illegal      = 3;  // 包含非法字符
            lock_role_name_result_fail_server_not_found  = 4;  // 名字服务器不存在
            lock_role_name_result_fail_game_server_error = 5;  // GameServer出错
            lock_role_name_result_fail_redis_not_connect = 6;  // Redis已经断开连接
            lock_role_name_result_fail_redis_lock        = 7;  // 锁定名字失败
            lock_role_name_result_fail_redis_write       = 8;  // 写入名字出错
            lock_role_name_result_fail_redis_get_reply   = 9;  // 获取Redis返回内容出错
            lock_role_name_result_fail_redis_do_command  = 10; // 执行Redis命令出错
            lock_role_name_result_fail_name_server_error = 11; // 名字服务器出错
        '''
        logging.debug("On_LockRoleNameRsp respond = %s" % respond)
        if respond.result == 0:
            request_success.fire(request_type='get', name="LockRoleNameSuccess", response_time = time.time()- self.member[int(respond.request_id)]["time"], response_length=0) 
        else:
            request_failure.fire(request_type='get', name="LockRoleNameSuccess", response_time = time.time()- self.member[int(respond.request_id)]["time"], exception = respond.result) 
        if self.member[int(respond.request_id)]["type"]:
            self.member[int(respond.request_id)]["type"] = False
            self.LockRoleNameReq(int(respond.request_id), self.member[respond.request_id]["Name"])


        
        
        
