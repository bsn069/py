# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import net
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from net.ProtoBuffer.CliMediaProtocol_pb2 import *
from net.ProtoBuffer.CliMediaCmd_pb2 import *
from Family import *
from ModuleState.StateDefine import *
from locust.asyncevent import asyncresult_manager

TIMEOUT = 30


class MediaServerNetPackHandle(object):

    def __init__(self, address, family):
        self.msConnect = None
        self.msAddress = address
        # print self.msAddress
        self.family = family
        self.respondM2CHandler = {}
        self.RegeditHandle()

    def RegeditHandle(self):
        for (protocolId, name) in M2CProtocol.items():
            func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
            self.respondM2CHandler[protocolId] = func

    def DoMsProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnMsProtocol(self, header, buffer = None):
        if header.cmd in M2CProtocol:
            protobuf = M2CProtocol[header.cmd]()
            try:
                if buffer:
                    protobuf.ParseFromString(buffer)
            except Exception, e:
                return
            if header.cmd in self.respondM2CHandler:
                self.respondM2CHandler[header.cmd](protobuf)

    def CliPingMediaReq(self):
        while self.msConnect and self.msConnect.connected:
            if self.family.familyId:
                request = CliPingMediaReq()
                request.familyId = self.family.familyId
                self.msConnect.send_protocol(CLI_TO_MEDIA_HBT_REQ, request)
                gevent.sleep(9)
            else:
                logging.debug("[ERROR] Media Can Not Find familyId")
                break

    def ClientMediaGameRequest(self):
        request = CliRegisterMediaReq()
        request.token = self.family.token
        request.channelId = self.family.channelId
        request.userId = self.family.userId
        request.groupId = self.family.groupId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_REGISTER_REQ, request)
        asyncresult_manager.await(self, "CliRegisterMedia", TIMEOUT)

    def On_CliRegisterMediaRsp(self, respond):
        logging.debug('On_CliRegisterMediaRsp %s' % respond)
        if respond.loginResult == 0:
            asyncresult_manager.fire(self, "CliRegisterMedia", True)
            gevent.spawn(self.CliPingMediaReq)
        else:
            asyncresult_manager.fire(self, "CliRegisterMedia", False)
            logging.debug('On_CliRegisterMediaRsp fail %s' % respond)

    # -- 家园相关 -- #
    # 获取个人信息
    def GetOwnerInfoReq(self):
        request = GetOwnerInfoReq()
        request.familyId = self.family.familyId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_GET_OWNERINFO_REQ, request)

    def On_GetOwnerInfoRsp(self, respond):
        logging.debug('On_GetOwnerInfoRsp:%s' % respond)
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_SET_BOARD)
        else:
            logging.debug('On_GetOwnerInfoRsp fail %s' % respond)

    # 设置个人说明
    def SetBlogDeclareReq(self, msg):
        request = SetBlogDeclareReq()
        request.ownerId = self.family.familyId
        request.declare = msg
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_SET_BLOGDECLARE_REQ, request)

    def On_SetBlogDeclareRsp(self, respond):
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_GET_OTHER_FAMILY)
        else:
            logging.debug('On_SetBlogDeclareRsp fail %s' % respond)

    # 家园点赞
    def AddBlogLikeReq(self, ownerId):
        request = AddBlogLikeReq()
        request.sendId = self.family.familyId
        request.ownerId = ownerId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_ADD_BLOGLIKE_REQ, request)

    def On_AddBlogLikeRsp(self, respond):
        if respond.retCode == 0:
            pass
        else:
            logging.debug('On_AddBlogLikeRsp fail %s' % respond)


    # 留言相关
    def GetBoardMsgReq(self, familyId):
        request = GetBoardMsgReq()
        request.familyId = familyId
        request.beginMsgId = 0
        request.toBack = True
        request.msgNum = 10
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_GET_BOARD_REQ, request)

    def On_GetBoardMsgRsp(self, respond):
        if respond.retCode == 0:
            if respond.familyId == self.family.familyId:
                self.family.homeland.UpdateMyBoard(respond)
                self.family.SetState(STATE_MS_HOMELAND_UPDATE_MY_BOARD_SUCCEED)
            else:
                self.family.homeland.UpdateOtherBoard(respond)
                self.family.SetState(STATE_MS_HOMELAND_UPDATE_OTHER_BOARD_SUCCEED)
        else:
            logging.debug('On_GetBoardMsgRsp fail %s' % respond)

    def AddBoardMsgReq(self, receiverId, ownerId, content):
        request = AddBoardMsgReq()
        request.senderId = self.family.familyId
        request.receiverId = receiverId
        request.ownerId = ownerId
        request.content = content
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_ADD_BOARD_REQ, request)

    def On_AddBoardMsgRsp(self, respond):
        if respond.retCode == 0:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_HomeLand_AddBoardMsg")
            self.family.SetState(STATE_MS_HOMELAND_ADD_BOARD_SUCCEED)
        else:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_HomeLand_AddBoardMsg", isSuccess=False, exception="retCode=%s" % respond.retCode)
            logging.debug('On_AddBoardMsgRsp fail %s' % respond)

    def DelBoardMsgReq(self, senderId, msgId):
        request = DelBoardMsgReq()
        request.senderId = senderId
        request.msgId = msgId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_DEL_BOARD_REQ, request)

    def On_DelBoardMsgRsp(self, respond):
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_DEL_BOARD_SUCCEED)
        else:
            logging.debug('On_DelBoardMsgRsp fail %s' % respond)

    #心情相关
    def GetMoodMsgReq(self, familyId, getmsgby=FamilyId):
        request = GetMoodMsgReq()
        request.familyId = familyId
        request.beginMsgId = 0
        request.toBack = True
        request.msgNum = 10
        request.likeNum = 100
        request.gcSvrId = self.family.centerID
        request.getMsgBy = getmsgby
        if getmsgby == MsgId:
            request.msgNum = 1
        self.msConnect.send_protocol(CLI_TO_MEDIA_GET_MOOD_REQ, request)

    def On_GetMoodMsgRsp(self, respond):
        if respond.retCode == 0:
            if respond.familyId == self.family.familyId:
                self.family.homeland.UpdateMyMood(respond)
                self.family.SetState(STATE_MS_HOMELAND_UPDATE_MY_MOOD_SUCCEED)
            else:
                self.family.homeland.UpdateOtherMood(respond)
                self.family.SetState(STATE_MS_HOMELAND_UPDATE_OTHER_MOOD_SUCCEED)
        else:
            logging.debug('On_GetMoodMsgRsp fail %s' % respond)

    def AddMoodMsgReq(self, msg):
        request = AddMoodMsgReq()
        request.familyId = self.family.familyId
        request.Content = msg
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_ADD_MOOD_REQ, request)

    def On_AddMoodMsgRsp(self, respond):
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_ADD_MOOD_SUCCEED)
        else:
            logging.debug('On_AddMoodMsgRsp fail %s' % respond)

    def DelMoodMsgReq(self, msgId):
        request = DelMoodMsgReq()
        request.MsgId = msgId
        request.familyId = self.family.familyId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_DEL_MOOD_REQ, request)

    def On_DelMoodMsgRsp(self, respond):
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD_SUCCEED)
        else:
            logging.debug('On_DelMoodMsgRsp fail %s' % respond)

    def AddMoodLikeReq(self, receiverId, msgId):
        request = AddMoodLikeReq()
        request.familyId = receiverId
        request.msgId = msgId
        request.senderId = self.family.familyId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_ADD_MOODLIKE_REQ, request)

    def On_AddMoodLikeRsp(self, respond):
        if respond.retCode == 0:
            pass
        else:
            logging.debug('On_AddMoodLikeRsp fail %s' % respond)

    def AddMoodCommentReq(self, receiverId, msgId, msg):
        request = AddMoodCommentReq()
        request.familyId = receiverId
        request.msgId = msgId
        request.senderId = self.family.familyId
        request.receiverId = receiverId
        request.Content = msg
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_ADD_MOODCOMMENT_REQ, request)

    def On_AddMoodCommentRsp(self, respond):
        if respond.retCode == 0:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_HomeLand_AddMoodComment")
            self.family.SetState(STATE_MS_HOMELAND_ADD_MOOD_COMMENT_SUCCEED)
        else:
            self.family.gameServerNetPackHandle.MarkTestCase("TestCase_HomeLand_AddMoodComment", isSuccess=False, exception="retCode=%s" % respond.retCode)
            logging.debug('On_AddMoodCommentRsp fail %s' % respond)

    def DelMoodCommentReq(self, ownerId, msgId, commentId, senderId):
        request = DelMoodCommentReq()
        request.familyId = ownerId
        request.msgId = msgId
        request.commentId =commentId
        request.senderId = senderId
        request.gcSvrId = self.family.centerID
        self.msConnect.send_protocol(CLI_TO_MEDIA_DEL_MOODCOMMENT_REQ, request)

    def On_DelMoodCommentRsp(self, respond):
        if respond.retCode == 0:
            self.family.SetState(STATE_MS_HOMELAND_DEL_MOOD_COMMENT_SUCCEED)
        else:
            logging.debug('On_DelMoodCommentRsp fail %s' % respond)


    # -- 连接相关的 -- #
    #mediaServer Correlation function
    def ConnectMediaServer(self):
        self.msConnect = NetConnecter(self.OnMsConnect, self.OnMsDisConnect, self.OnMsProtocol, self.DoMsProtocol, is_encrypt=False)
        self.msConnect.connect(self.msAddress)
        asyncresult_manager.await(self, "ConnectMediaServer", TIMEOUT)

    def OnMsConnect(self):
        asyncresult_manager.fire(self, "ConnectMediaServer", True)
        self.ClientMediaGameRequest()
        
    def OnMsDisConnect(self):
        logging.debug("media server disconnect")
        
    def MSUninit(self):
        if self.msConnect:
            self.msConnect.close()
            self.msConnect = None
