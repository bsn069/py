# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import logging
import gevent
from locust.events import request_success, request_failure
from locust.asyncevent import asyncresult_manager
from Family import *
from ModuleState.StateDefine import *
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from net.ProtoBuffer.PortalProtocol_pb2 import *
import uuid
import random

TIMEOUT = 50

class PortalServerNetPackHandle(object):
    def __init__(self, family):
        self.__isFirstConnect = True
        self.__respondS2CHandler = {}
        self.__regeditHandle()
        self.__groupId = None
        self.connect = None
        self.isReady = False
        self.family = family

    def __regeditHandle(self):
        for (protocolId, name) in Protal2CProtocol.iteritems():
            func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
            self.__respondS2CHandler[protocolId] = func

    def ConnectPortalServer(self, address):
        self.connect = NetConnecter(self.OnConnect, self.OnDisconnect, self.OnProtocol, self.DoProtocol, self)
        self.connect.connect(address)

    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
        if cmd_id in self.__respondS2CHandler and cmd_id in Protal2CProtocol:
            protobuf = Protal2CProtocol[cmd_id]()
            protobuf.ParseFromString(buffer)
            self.__respondS2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        self.isReady = True
        if self.__isFirstConnect:
            self.__isFirstConnect = False
            asyncresult_manager.fire(self.family, "ConnectPortalServer", True)
        gevent.spawn(self.PingServer)

    def OnDisconnect(self):
        logging.debug("Portal server disconnect")

    def Uninit(self):
        self.isReady = False
        if self.connect:
            self.connect.close()
            request_success.fire(request_type='get', name="PortalServerConnectClose", response_time=0, response_length=0)                
            del self.connect

    def On_SyncPortalInfoRsp(self, respond):
        logging.debug("I don't care this message, respond = %s" % respond)
    
    def Do_ReportLocalState(self):
        request = ReportLocalState()
        request.device_id = uuid.uuid4().hex
        request.channel_id = 'jxm3dinner'
        request.local_server_list_version = 0
        request.local_billboard_version = 0
        request.is_need_recommend = True
#         request.applicat_major_version = 1
#         request.applicat_minor_version = 4
#         request.applicat_build_version = 4007
        self.connect.send_protocol(client_to_portal_report_local_state, request)

    # 客户端先发起心跳
    def PingServer(self):

        while self.isReady and self.connect and self.connect.connected:
            request = PingPortal()
            request.ack = 0
            self.connect.send_protocol(client_to_portal_ping, request)
            gevent.sleep(25)

    def On_PingPortal(self, respond):
        pass
    
    def On_ClientServerList(self, respond):
        if hasattr(respond, 'server_record'):
            self.channel_info_array = respond.server_record._values
#            logging.debug("On_ClientServerList respond = %s" % respond)
            logging.debug("channel_info_array = %s" % self.channel_info_array)
            asyncresult_manager.fire(self.family, "ReportLocalState", True) 
        else:
            asyncresult_manager.fire(self.family, "ReportLocalState", False, error='no channel_info_array')
            return
        
    def On_SyncRecommendServer(self, respond):
        pass
    
    def On_SyncBillboard(self, respond):
        pass
        
    def Do_SelectServerRecord(self):
        result = False
        if self.family.authAddress and self.family.authAddress[0] and self.family.serverGroupId:
            ip = self.family.authAddress[0]
            groupid = self.family.serverGroupId
            for group in self.channel_info_array:
                if ip == group.ip and groupid == group.group_id:
                    self.__groupId = groupid
                    break         
        else:
            group = random.choice(self.channel_info_array)
            self.family.authAddress = (group.ip, group.group_id)
#            self.__groupId = group.group_id
            self.__groupId = 7            
        gevent.sleep(0)
        if self.__groupId:
            request = SelectServerRecord()
            request.group_id = self.__groupId
            request.local_state = 0
            self.connect.send_protocol(client_to_portal_select_group_id, request)
            asyncresult_manager.fire(self.family, "SelectServerRecord", True) 
        else:
            asyncresult_manager.fire(self.family, "SelectServerRecord", False, error='no group id')
        
        
    def Do_ApplyLoginTimeReq(self):
        request = ApplyLoginTimeReq()
        request.groupId = self.__groupId
        self.connect.send_protocol(client_to_portal_get_login_time, request)

    def On_ApplyLoginTimeRsp(self, respond):

        """
        ApplyLoginTimeRsp result: GET_TIME_SUCCESS
        time: 0
        connectIndex: 1

        [result]
        GET_TIME_SUCCESS        = 0;       // 获取时间成功
        LOGIN_UNLIMITED         = 1;       // 无登陆时间限制
        WAIT_NEXT_TIME          = 2;       // 人满，等待下一轮分配
        SERVER_MAINTENANCE      = 3;       // 服务器未开放
        REQUEST_TIMEOUT         = 4;       // 请求超时
        OTHER_ERROR             = 5;       // 其它错误，如global宕机等
        """
#        if respond.result in [0, 3]:
#            self.family.loginWaitTime = respond.time
#            

#            self.family.SetState(STATE_PS_FOUR)  

        if respond.result in [0, 3]:
            self.family.loginWaitTime = respond.time
            asyncresult_manager.fire(self.family, "ApplyLoginTimeReq", True)
            if  respond.time  > 0 and self.family.state == STATE_PS_ONE:
                request_success.fire(request_type='get', name="NeedQueue", response_time=0, response_length=0)
            elif respond.time == 0 and self.family.state == STATE_PS_ONE:
                request_success.fire(request_type='get', name="NormalLogin", response_time=0, response_length=0)
            if self.family.state == STATE_PS_SEC:
                request_success.fire(request_type='get', name="AgainQueue", response_time=0, response_length=0)                
                gevent.sleep(respond.time)
            self.family.SetState(STATE_PS_FOUR)  
        else:
            if respond.result == 2 and self.family.state == STATE_PS_ONE:
                asyncresult_manager.fire(self.family, "FullNextRound", True)
            self.family.SetState(STATE_PS_SEC)
            self.Do_ApplyLoginTimeReq()
