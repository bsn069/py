# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import random
import time
import logging
import sys
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from Family import *
from ctypes import *
from struct import pack, unpack
from ctypes import *
from ModuleState.StateDefine import *
from net.NetDefine import *
from net.ProtoBuffer.ZoneProtocol_pb2 import *
from net.ProtoBuffer.MatchProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success
from locust.core import remotecall


MEMBER_FAMILY = 100000 #��ʼfamilyid
FAMILY_BATCH = 1000  #ÿ��GS���ӵķ�����

@remotecall
def get_familyid():
    global MEMBER_FAMILY
    MEMBER_FAMILY += FAMILY_BATCH
    return MEMBER_FAMILY

GAME_GROUPID = 520 + 10
GAME_SERVERID = 3000 * 10000 + 520 + 11
@remotecall
def get_groupid_serverid():
    global GAME_GROUPID, GAME_SERVERID
    GAME_GROUPID += 1
    GAME_SERVERID += 1
    return GAME_GROUPID, GAME_SERVERID

TIMEOUT = 30
GAME_SERVER = 4
MATCH_PROTOCOL_PING_REQ = 1600
MATCH_PROTOCOL_REGISTER_SERVICE_REQ = 1601
MATCH_PROTOCOL_LEAGUE_MATCH_JOIN_REQUEST = 1606
MATCH_PROTOCOL_LEAGUE_MATCH_CANCEL_REQUEST = 1607
MATCH_PROTOCOL_LEAGUE_MATCH_MATCH_STATE_NOTIFY = 1608
matchProtocol = {
                MATCH_PROTOCOL_LEAGUE_MATCH_MATCH_STATE_NOTIFY:LeagueMatch_MatchStateNotify,
                }

class ServerNetPackHandle(object):
    
    def __init__(self, address, zoneserver):
        self.lsConnect = None
        self.respondZ2CHandler = {}
        self.RegeditHandle() 
        self.groupid, self.server_id = get_groupid_serverid()
        self.address = address
        self.server = zoneserver
        self.familyid =  get_familyid()
        self.startfamilyid = self.familyid
        self.familyId_start_time = {}

    def is_cancel(self):
#         return False
        if random.randint(0, 10) is 0:
            return True
        else:
            return False
        
        
    def RegeditHandle(self):
        for (protocolId, name) in matchProtocol.items(): 
            func = getattr(self, "On_" + str(name).split(".")[-1].rstrip("'>"))
            self.respondZ2CHandler[protocolId] = func
            
    def ConnectServer(self, address):
        self.lsConnect = NetConnecter(self.OnConnect, self.OnDisConnect, self.OnProtocol, self.DoProtocol, is_encrypt=False)
        self.lsConnect.connect(address)        

    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
    
        if cmd_id in matchProtocol:
            # 协议ID对应的如果是ProtoBuffer，则进行解析；如果对应的是str，说明该协议只有头
            if isinstance(matchProtocol[cmd_id], GeneratedProtocolMessageType):
                protobuf = matchProtocol[cmd_id]()
                try:
                    protobuf.ParseFromString(buffer)
                except Exception, e:
                    logging.debug("command id = %d, buffer len=%d, trackback = %s" % (cmdId, len(buffer), traceback.format_exc()))
                    return
            else:
                protobuf = buffer
                 
            if cmd_id in self.respondZ2CHandler:
                self.respondZ2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        asyncresult_manager.fire(self, "MatchServerConnected", True)
        gevent.spawn(self.PingMatchServer)

    def PingMatchServer(self):
        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(MATCH_PROTOCOL_PING_REQ)
            gevent.sleep(9)   
    
    def OnDisConnect(self):
        request_success.fire(request_type='get', name="OnDisConnect", response_time=0, response_length=0) 
        self.server.state = STATE_ZO_DISCONET
        logging.debug("match server disconnect")
        
    def Uninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
        
    def Register_MatchServer(self):
        request = RegisterServiceRequest() 
        request.service_type = GAME_SERVER
        request.group_id = self.groupid
        request.service_id = self.server_id 
        request.listen_ip = listen_ip = self.address[0]
        request.listen_port = listen_port = self.address[1]
#        request.outer_encrypt_key = 
        self.lsConnect.send_protocol(MATCH_PROTOCOL_REGISTER_SERVICE_REQ, request)
        
    def Match_League_JoinMatchRequest(self, members):
        request = Gs_LeagueMatch_JoinRequest()
        for i in range(members):
            players = Gs_LeagueMatch_Player() 
            players.gameserver_id = self.server_id
            players.group_id = self.groupid
            players.family_id = self.familyid
            players.user_id = "testUserID"
            players.name = "testPlayerName"
            players.member = FAMILY_MEMBER_TYPE_MAIN
            series_faction = random.randint(1, 5)            
            players.series = series_faction #����
            players.fight_power = 150000 #ս��
            # players.league_match_score = random.randint(1000, 1780)#��������
            players.league_match_score = random.randint(1000, 5000)#��������
            players.league_match_stage = 1 #������λ
            players.faction = series_faction #����
            players.gender = GENDER_TYPE_MALE #��
            players.portrait = 1007 #ͷ��
            players.apperanceRoleType = random.randint(1, 3)   
            players.playCount = random.randint(0, 30)
            players.streakWinCount = random.randint(0, players.playCount)  #��ʤ����
            players.streakLoseCount = random.randint(0, players.playCount-players.streakWinCount)  #���ܴ���
            players.lastGameResult = random.randint(0, 2) 
            request.players.extend([players])
            request_success.fire(request_type='get', name="LeagueMatch_People", response_time=0, response_length=0) 
            self.familyId_start_time.setdefault(self.familyid, time.time())
            if self.familyid  > self.startfamilyid + FAMILY_BATCH - 1:
                request_success.fire(request_type='get', name="[AccountEmpty]", response_time=0, response_length=0) 
                gevent.sleep(999999)
            else:
                self.familyid += 1
        self.lsConnect.send_protocol(MATCH_PROTOCOL_LEAGUE_MATCH_JOIN_REQUEST, request)
        if self.is_cancel():
            familyid = random.choice(request.players).family_id
            self.Gs_LeagueMatch_CancelRequest(familyid)
        
    def On_LeagueMatch_MatchStateNotify(self, respond):
        '''
        FAIL                  = 0;
        CANCEL                = 1;        // �Լ�ȡ��ƥ��
        TEAMMATER_CANCEL      = 2;        // ����ȡ��ƥ��
        MATCHED_TEAMMATE_CANCEL = 3;    // ƥ�䵽�Ķ���ȡ��ƥ��
        BEGIN_MATCH_TEAMMATER = 4;        // ������ʼƥ�����
        MATCHED_TEAMMATER     = 5;        // ƥ����ѳɹ�����ʼƥ�����
        MATCHED_COMPETITOR    = 6;        // ƥ����ֳɹ���������ʼ����ս��
        '''
        logging.debug("On_LeagueMatch_MatchStateNotify respond = %s" % respond)
        if self.is_cancel():
            self.Gs_LeagueMatch_CancelRequest(respond.family_id)
        if respond.state == LeagueMatch_MatchStateNotify.FAIL:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_FAIL", response_time = 0, response_length=0) 
        elif respond.state == LeagueMatch_MatchStateNotify.CANCEL:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_Quit_BySelf", response_time = time.time() - self.familyId_start_time[respond.family_id], response_length=0) 
        elif respond.state == LeagueMatch_MatchStateNotify.TEAMMATER_CANCEL or respond.state == LeagueMatch_MatchStateNotify.MATCHED_TEAMMATE_CANCEL:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_Quit_ByMember", response_time = time.time() - self.familyId_start_time[respond.family_id], response_length=0) 
        elif respond.state == LeagueMatch_MatchStateNotify.BEGIN_MATCH_TEAMMATER:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_Friend_Begin", response_time = time.time() - self.familyId_start_time[respond.family_id], response_length=0) 
        elif respond.state == LeagueMatch_MatchStateNotify.MATCHED_TEAMMATER:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_Friend_End", response_time = time.time() - self.familyId_start_time[respond.family_id], response_length=0) 
        elif respond.state == LeagueMatch_MatchStateNotify.MATCHED_COMPETITOR:
            request_success.fire(request_type='get', name="LeagueMatch_MatchStateNotify_MATCHED_COMPETITOR", response_time = time.time() - self.familyId_start_time[respond.family_id], response_length=0)
        
    def Gs_LeagueMatch_CancelRequest(self, family_id):
        request = Gs_LeagueMatch_CancelRequest()
        request.family_id = family_id
        self.lsConnect.send_protocol(MATCH_PROTOCOL_LEAGUE_MATCH_CANCEL_REQUEST, request)






                                     



        



        
        
        
