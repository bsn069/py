# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''

import random
import time
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from net.ProtoBuffer.LocationProtocol_pb2 import *
from ModuleState.StateDefine import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure
from TestCase.Files.LBSLocation import GetLocation, GetIllLocation

TIMEOUT = 30

class LocationServerProtocol:
    LOCATION_SERVER_PROTOCOL_PING_REQ = 1000
    #设置family位置信息
    LOCATION_SERVER_SET_FAMILY_LOCATION_REQ = 1001
    LOCATION_SERVER_SET_FAMILY_LOCATION_RSP = 1002
    #得到family位置信息
    LOCATION_SERVER_GET_FAMILY_LOCATION_REQ = 1003
    LOCATION_SERVER_GET_FAMILY_LOCATION_RSP = 1004
    #设置家族kin位置信息
    LOCATION_SERVER_SET_KIN_LOCATION_REQ = 1005
    LOCATION_SERVER_SET_KIN_LOCATION_RSP = 1006
    #得到家族kin位置信息
    LOCATION_SERVER_GET_KIN_LOCATION_REQ = 1007
    LOCATION_SERVER_GET_KIN_LOCATION_RSP = 1008
    
    LOCATION_SERVER_SET_GAME_LOCATION_REQ = 1009
    LOCATION_SERVER_SET_GAME_LOCATION_RSP = 1010
    
    LOCATION_SERVER_GET_GAME_LOCATION_REQ = 1011
    LOCATION_SERVER_GET_GAME_LOCATION_RSP = 1012
    
    LOCATION_SERVER_DEL_GAME_LOCATION_REQ = 1013 
    LOCATION_SERVER_DEL_GAME_LOCATION_RSP = 1014
    
    LOCATION_SERVER_DEL_KIN_LOCATION_REQ = 1015
    LOCATION_SERVER_DEL_KIN_LOCATION_RSP = 1016
    
    LOCATION_SERVER_SET_FAMILY_HIDE_REQ = 1017
    LOCATION_SERVER_SET_FAMILY_HIDE_RSP = 1018
    
    LOCATION_SERVER_GET_NEARBY_FAMILIES_REQ = 1019
    LOCATION_SERVER_GET_NEARBY_FAMILIES_RSP = 1020


    LocationProtocol = {
                            LOCATION_SERVER_SET_FAMILY_LOCATION_RSP : SetFamilyLocationRsp,
                            LOCATION_SERVER_GET_FAMILY_LOCATION_RSP : GetFamilyLocationRsp,
                            LOCATION_SERVER_SET_KIN_LOCATION_RSP : SetKinLocationRsp,
                            LOCATION_SERVER_GET_KIN_LOCATION_RSP : GetKinLocationRsp,
                        }
class Type(object):
        def __init__(self):
            self.state = random.randint(10000, 10000000)
        
class LocationServerNetPackHandle(object):
    def __init__(self):
        self.lsConnect = None
        self.range = 500
        self.respondL2CHandler = {}
        self.RegeditHandle()
        self.isDiffCheck = True
        self.locations = {}
        self.setFamilyLocations = {}
        self.getFamilyLocations = {}
        self.setKinLocations = {}
        self.getKinLocations = {}

    def RegeditHandle(self):
        for (protocolId, name) in LocationServerProtocol.LocationProtocol.items():
            func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
            self.respondL2CHandler[protocolId] = func  
            
    def ConnectLocationServer(self,address):
        self.lsConnect = NetConnecter(self.OnConnect, self.OnDisConnect, self.OnProtocol, self.DoProtocol, is_encrypt=False)
        self.lsConnect.connect(address)
        
    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd

        if cmd_id in LocationServerProtocol.LocationProtocol:
            protobuf = LocationServerProtocol.LocationProtocol[cmd_id]()
            protobuf.ParseFromString(buffer)
            
        if cmd_id in self.respondL2CHandler:
            self.respondL2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        asyncresult_manager.fire(self, "ConnectLocationServer", True)
        gevent.spawn(self.PingServer)
        
    def PingServer(self):
        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_PROTOCOL_PING_REQ)
            gevent.sleep(9)
    
    def OnDisConnect(self):
        request_success.fire(request_type='get', name="OnDisConnect", response_time=0, response_length=0) 
        self.family.SetState(STATE_PS_SEC)
        logging.debug("location server disconnect")
        
    def Uninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
            
    def Do_SetLocationGeography(self, illegal=False):
        if illegal:
            location = GetIllLocation()
        else:
            location = GetLocation()
        location.startTime = time.time()
        self.setFamilyLocations[location.id] = location
        
        request = SetFamilyLocationReq()
        request.info.familyId = location.id
        request.info.longitude = location.longitude
        request.info.latitude = location.latitude
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_SET_FAMILY_LOCATION_REQ,request)
        
    def ILLDo_SetLocationGeography(self, familyId):
        self.Type = Type()
        request = SetFamilyLocationReq()
        request.info.familyId = familyId
        request.info.longitude = 200
        request.info.latitude = 200
        self.family.Play[familyId]['StartTime'] = time.time()
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_SET_FAMILY_LOCATION_REQ,request)
        
    def On_SetFamilyLocationRsp(self,respond):
        logging.debug("On_SetFamilyLocationRsp respond = %s" % respond) 
        if respond.retCode == 0:
            request_success.fire(request_type='get', name="SetFamilyLocation", response_time=time.time()-self.setFamilyLocations[respond.familyId].startTime, response_length=0)                
        else:
            request_failure.fire(request_type='get', name="SetFamilyLocation", response_time=0, exception="other result") 

    def Do_GetLocationGeography(self, illegal=False):
        if illegal:
            location = GetIllLocation()
        else:
            location = GetLocation()
        location.startTime = time.time()
        self.getFamilyLocations[location.id] = location
        
        request = GetFamilyLocationReq()
        request.familyId = location.id
        request.longitude = location.longitude
        request.latitude = location.latitude
        request.rangeLevel = 17  # 2^(17-rangeLevel) * 1000m, maxValue: 17
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_GET_FAMILY_LOCATION_REQ,request)
    
    def ILLDo_GetLocationGeography(self, familyId):
        request = GetFamilyLocationReq()
        request.familyId = familyId 
        request.longitude = 210
        request.latitude = 210
        request.rangeLevel = 17  # 2^(17-rangeLevel) * 1000m, maxValue: 17
        self.family.Play[familyId]['StartTime'] = time.time()
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_GET_FAMILY_LOCATION_REQ,request)

    def On_GetFamilyLocationRsp(self,respond):
        logging.debug("On_GetFamilyLocationRsp respond = %s" % respond) 
        if respond.retCode == 0:
            request_success.fire(request_type='get', name="GetFamilyLocationRsp", response_time=time.time()-self.getFamilyLocations[respond.familyId].startTime, response_length=0) 
        elif respond.retCode == -1:
            request_failure.fire(request_type='get', name="GetFamilyLocationRsp", response_time=0, exception="Get familyLocation failed!") 
    
    def Do_SetKinLocationGeography(self, illegal=False):
        if illegal:
            location = GetIllLocation()
        else:
            location = GetLocation()
        location.startTime = time.time()
        self.setKinLocations[location.id] = location
        
        request = SetKinLocationReq()
        request.familyId = location.id
        request.info.longitude = location.longitude
        request.info.latitude = location.latitude
        request.info.kinId = location.id/100
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_SET_KIN_LOCATION_REQ,request)
        
    def ILLDo_SetKinLocationGeography(self, familyId):
        request = SetKinLocationReq()
        request.familyId = familyId
        request.info.longitude = 200
        request.info.latitude = 200
        request.info.kinId = familyId/100
        self.family.Play[familyId]['StartTime'] = time.time()
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_SET_KIN_LOCATION_REQ,request)
        
    def On_SetKinLocationRsp(self,respond):
        logging.debug("On_SetKinLocationRsp respond = %s" % respond) 
        if respond.retCode == 0:
            request_success.fire(request_type='get', name="SetKinLocationRsp", response_time=time.time()-self.setKinLocations[respond.familyId].startTime, response_length=0) 
        else:
            request_failure.fire(request_type='get', name="SetKinLocationRsp", response_time=0, exception= str(respond.desc)) 
            
    def get_randnumber(self, max, number):
        a = random.uniform(0, max)
        return round(a, number)
    
    def Do_GetKinLocationGeography(self, illegal=False):
        if illegal:
            location = GetIllLocation()
        else:
            location = GetLocation()
        location.startTime = time.time()
        self.getKinLocations[location.id] = location
        
        request = GetKinLocationReq()
        request.familyId = location.id
        request.longitude = location.longitude
        request.latitude = location.latitude
        request.rangeLevel = 17  # 2^(17-rangeLevel) * 1000m, maxValue: 17
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_GET_KIN_LOCATION_REQ,request)
    
    def ILLDo_GetKinLocationGeography(self, familyId):
        request = GetKinLocationReq()
        request.familyId = familyId
        request.longitude = 210
        request.latitude = 210
        request.rangeLevel = 17  # 2^(17-rangeLevel) * 1000m, maxValue: 17
        self.family.Play[familyId]['StartTime'] = time.time()
        self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_GET_KIN_LOCATION_REQ,request)
    
    def On_GetKinLocationRsp(self,respond):
        logging.debug("On_GetKinLocationRsp respond = %s" % respond) 
        if respond.retCode == 0:
            request_success.fire(request_type='get', name="GetKinLocationRsp", response_time=time.time()-self.getKinLocations[respond.familyId].startTime, response_length=0) 
        else:
            request_failure.fire(request_type='get', name="GetKinLocationRsp", response_time=0, exception= str(respond.desc)) 

#     # 暂时不需要测试这个借口
#     def Do_GetNearbyFamilies(self, familyId):
#         request = GetNearbyFamiliesReq()
#         request.initFamilyId = familyId
# #         repeated uint32 familyIdLst = 2;
#         request.rangeLevel = 17 # 2^(17-rangeLevel) * 1000m, maxValue: 17
#         self.family.Play[familyId]['StartTime'] = time.time()
#         self.lsConnect.send_protocol(LocationServerProtocol.LOCATION_SERVER_GET_NEARBY_FAMILIES_REQ, request)
#         pass
#     
#     def On_SvrGetNearbyFamiliesRsp(self, respond):
#         pass
