# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import random
import time
import logging
import sys
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from Family import *
from ctypes import *
from struct import pack, unpack
from ctypes import *
from ModuleState.StateDefine import *
from net.NetDefine import *
from net.ProtoBuffer.ZoneProtocol_pb2 import *
from net.ProtoBuffer.MatchProtocol_pb2 import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from locust.asyncevent import asyncresult_manager
from locust.events import request_success
from locust.core import remotecall


MEMBER_FAMILY = 100000 #起始familyid
FAMILY_BATCH = 1000  #每个GS链接的发送量

@remotecall
def get_familyid():
    global MEMBER_FAMILY
    MEMBER_FAMILY += FAMILY_BATCH
    return MEMBER_FAMILY

GAME_GROUPID = 520 + 10
GAME_SERVERID = 3000 * 10000 + 520 + 11
@remotecall
def get_groupid_serverid():
    global GAME_GROUPID, GAME_SERVERID
    GAME_GROUPID += 1
    GAME_SERVERID += 1
    return GAME_GROUPID, GAME_SERVERID

TIMEOUT = 30
GAME_SERVER = 4
ZONE_PROTOCOL_PING_REQ = 1200
ZONE_PROTOCOL_REGISTER_SERVICE_REQ = 1202
ZONE_PROTOCOL_REGISTER_SERVICE_RSP = 1221
ZONE_PROTOCOL_BATTLEFIELD_MATCH_JOIN_REQUEST = 1206
ZONE_PROTOCOL_BATTLEFIELD_MATCH_CANCEL_REQUEST = 1207
ZONE_PROTOCOL_BATTLEFIELD_MATCH_STATE_NOTIFY = 1208
ZONE_PROTOCOL_SEND_GAME_SERVER_SCRIPT = 1210
ZONE_PROTOCOL_GAME_SERVER_SEND_SCRIPT = 1212
zoneProtocol = {
                ZONE_PROTOCOL_REGISTER_SERVICE_RSP:RegisterServiceToZoneRsp,
                ZONE_PROTOCOL_BATTLEFIELD_MATCH_STATE_NOTIFY:Match_MatchStateNotifyEx,
                ZONE_PROTOCOL_SEND_GAME_SERVER_SCRIPT:"RecvGSScript"
                }

class ServerNetPackHandle(object):
    
    def __init__(self, address, zoneserver):
        self.lsConnect = None
        self.respondZ2CHandler = {}
        self.RegeditHandle() 
        self.groupid, self.server_id = get_groupid_serverid()
        self.address = address
        self.server = zoneserver
        self.familyid =  get_familyid()
        self.startfamilyid = self.familyid
        self.familyId_start_time = {}

    def is_cancel(self):
#         return False
        if random.randint(0, 10) is 0:
            return True
        else:
            return False
        
        
    def RegeditHandle(self):
        for (protocolId, name) in zoneProtocol.items(): 
            func = getattr(self, "On_" + str(name).split(".")[-1].rstrip("'>"))
            self.respondZ2CHandler[protocolId] = func
            
    def ConnectServer(self, address):
        self.lsConnect = NetConnecter(self.OnConnect, self.OnDisConnect, self.OnProtocol, self.DoProtocol, is_encrypt=False)
        self.lsConnect.connect(address)        

    def DoProtocol(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()

    def OnProtocol(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
    
        if cmd_id in zoneProtocol:
            # 协议ID对应的如果是ProtoBuffer，则进行解析；如果对应的是str，说明该协议只有头
            if isinstance(zoneProtocol[cmd_id], GeneratedProtocolMessageType):
                protobuf = zoneProtocol[cmd_id]()
                try:
                    protobuf.ParseFromString(buffer)
                except Exception, e:
                    logging.debug("command id = %d, buffer len=%d, trackback = %s" % (cmdId, len(buffer), traceback.format_exc()))
                    return
            else:
                protobuf = buffer
                 
            if cmd_id in self.respondZ2CHandler:
                self.respondZ2CHandler[cmd_id](protobuf)

    def OnConnect(self):
        asyncresult_manager.fire(self, "ZoneServerConnected", True)
        gevent.spawn(self.PingServer)
            
    def PingServer(self):
        while self.lsConnect and self.lsConnect.connected:
            self.lsConnect.send_protocol(ZONE_PROTOCOL_PING_REQ)
            gevent.sleep(9)
    
    def OnDisConnect(self):
        request_success.fire(request_type='get', name="OnDisConnect", response_time=0, response_length=0) 
        self.server.state = STATE_ZO_DISCONET
        logging.debug("zone server disconnect")
        
    def Uninit(self):
        if self.lsConnect:
            self.lsConnect.close()
            self.lsConnect = None
            
    def Register(self):
        request = RegisterServiceToZone()
        request.service_type=4
        request.group_id = self.groupid
        request.service_id = self.server_id 
        request.listen_ip = self.address[0]
        request.listen_port = self.address[1]
        request.outer_ip = self.address[0]
        request.outer_port= self.address[1]
        self.lsConnect.send_protocol(ZONE_PROTOCOL_REGISTER_SERVICE_REQ, request)

    def On_RegisterServiceToZoneRsp(self, respond):
        logging.debug("On_RegisterServiceToZoneRsp respond = %s" % respond) 
        if respond.result:     
            asyncresult_manager.fire(self, "ZoneServerRegister", True)
            self.server.state = STATE_ZO_LOGINING
        else:
            asyncresult_manager.fire(self, "ZoneServerRegister", False)

    def Match_Battle_JoinMatchRequest(self, members):
        request = Match_JoinMatchRequest()
        for i in range(members):
            players = Match_Player()
            players.family_id =  self.familyid
            players.fight_power = random.randint(30000, 100000)  
            players.member = FAMILY_MEMBER_TYPE_MAIN
            series_faction = random.randint(1, 5)            
            players.series = series_faction #五行
            players.server_group_id = self.groupid
            players.gameserver_id = self.server_id
            players.gender = GENDER_TYPE_MALE
            players.level = random.randint(23, 50)   
            request.players.extend([players])
            if self.familyid  > self.startfamilyid + FAMILY_BATCH - 1:
                request_success.fire(request_type='get', name="[Battle AccountEmpty]", response_time=0, response_length=0) 
                gevent.sleep(999999)
            else:
                self.familyId_start_time.setdefault(self.familyid, time.time())
                self.familyid += 1
            request_success.fire(request_type='get', name="BattleMatch_People", response_time=0, response_length=0) 
        self.lsConnect.send_protocol(ZONE_PROTOCOL_BATTLEFIELD_MATCH_JOIN_REQUEST, request)
        if self.is_cancel():
            familyid = random.choice(request.players).family_id
            self.Battle_CancelMatchRequest(familyid)
        
    def _MatchTime(self, l, k):
        if k in l:
            return time.time() - self.familyId_start_time[l[i]]
        else:
            return 0

    def On_Match_MatchStateNotifyEx(self, respond):
        '''
            FAIL   = 0                 匹配异常
            START  = 1                 开始匹配
            CANCEL = 2                 取消匹配
            FINISH = 3                 匹配成功
        '''
        logging.debug("On_Match_MatchStateNotifyEx respond = %s" % respond)
        list = respond.family_id._values
        if self.is_cancel():
            familyid = random.choice(list)
            self.Battle_CancelMatchRequest(familyid)
        if respond.state == 0:
            for i in range(len(list)):
                request_success.fire(request_type='get', name="Match_MatchState_FAIL", response_time = self._MatchTime(list, i), response_length=0) 
        elif respond.state == 1:
            for i in range(len(list)):
                request_success.fire(request_type='get', name="Match_MatchState_START", response_time = self._MatchTime(list, i), response_length=0) 
        elif respond.state == 2:
            for i in range(len(list)):
                request_success.fire(request_type='get', name="Match_MatchState_QUIE", response_time = self._MatchTime(list, i), response_length=0) 
        elif respond.state == 3:
            for i in range(len(list)):
                request_success.fire(request_type='get', name="Match_MatchState_FINISH", response_time = self._MatchTime(list, i), response_length=0) 
        
    def Battle_CancelMatchRequest(self, family_id):
        request = Match_CancelMatchRequest()
        request.family_id = family_id 
        self.lsConnect.send_protocol(ZONE_PROTOCOL_BATTLEFIELD_MATCH_CANCEL_REQUEST, request)

    def LiveGameJoinReq(self, members):
        request = ScriptPack()
        request.cmd = ZONE_PROTOCOL_GAME_SERVER_SEND_SCRIPT
        request.fromServerID = self.server_id
        request.fromGroupID = self.groupid
        playerList = []
        for i in range(members):
            playerList.append({
                    "familyID":self.familyid,
                    "groupID":self.groupid,
                    "playCount":random.randint(0, 20),
                })
            if self.familyid  > self.startfamilyid + FAMILY_BATCH - 1:
                request_success.fire(request_type='get', name="[AccountEmpty]", response_time=0, response_length=0) 
                gevent.sleep(999999)
            else:
                self.familyId_start_time.setdefault(self.familyid, time.time())
                self.familyid += 1
        teamid = self.familyid
        requestlist = ["LiveGame:MatchReq", self.server_id, teamid, playerList]
        by = bytearray(4096)
        lens = SaveValueToBuff(requestlist, by, idx=[0])
        request.len = sizeof(ScriptPack) + lens
        self.lsConnect.send_protocol_direct(request.serialize()+str(by[0:lens]))
                                     
    def ChaosFight(self):
        request = ScriptPack()
        match_value = [0, 5, 10, 15, 20, 25, 30]
        request.cmd = ZONE_PROTOCOL_GAME_SERVER_SEND_SCRIPT
        request.fromServerID = self.server_id
        request.fromGroupID = self.groupid
        requestlist = ["ChaosFight:OnGSCallFunc_ZS", "Match_FromGSJoinReq_ZS", self.familyid, self.groupid, random.randint(40, 50), random.randint(50000, 500000), random.sample(match_value, 1)[0]]
        by = bytearray(4096)
        lens = SaveValueToBuff(requestlist, by, idx=[0])
        request.len = sizeof(ScriptPack) + lens
        request_success.fire(request_type='get', name="ChaosFight_People", response_time=0, response_length=0) 
        if self.familyid > self.startfamilyid + FAMILY_BATCH -1:
            request_success.fire(request_type='get', name="ChaosFight_AccountEmpty", response_time=0, response_length=0) 
            gevent.sleep(9999999)
        else:
            self.familyId_start_time.setdefault(self.familyid, time.time())
            self.familyid += 1
        self.lsConnect.send_protocol_direct(request.serialize()+str(by[0:lens]))

    def On_RecvGSScript(self, buf):
        respond =  LoadValueFromBuff(None, buf[8:], len(buf)-8, [0])
        if 'ChaosFight:Match_FromZSJoinRsp_GS' in respond:
            request_success.fire(request_type='get', name="ChaosFight_Join", response_time=time.time() - self.familyId_start_time[int(respond[1])], response_length=0) 
        elif "ChaosFight:OnZSMissionCreateComplete_GS" in respond:
            for i in range(len(respond[1])):
                request_success.fire(request_type='get', name="ChaosFight_Finish", response_time=time.time() - self.familyId_start_time[int(respond[1][i])], response_length=0)
        elif "LiveGame:MatchRsp" in respond:
            for i in range(len(respond[len(respond)-1])):
                request_success.fire(request_type='get', name="EatChicken_Join", response_time=time.time() - self.familyId_start_time[respond[len(respond)-1][i][0]['familyID']], response_length=0) 
        elif "LiveGame:NotifyEnterMission" in respond:
            for i in range(len(respond[len(respond)-1])):
                if self.familyId_start_time.has_key(respond[len(respond)-1][i][0]["nFamilyId"]):
                    request_success.fire(request_type='get', name="EatChicken_Finish", response_time=time.time() - self.familyId_start_time[respond[len(respond)-1][i][0]["nFamilyId"]], response_length=0) 
                    del self.familyId_start_time[respond[len(respond)-1][i][0]["nFamilyId"]]
        pass
        
class ScriptPack(NetPack):
    
    _fields_ = [("fromServerID", c_uint32),
                ("fromGroupID", c_uint32),]
#                 ("scriptBuff", c_char_p),]
     
def LoadValueFromBuff(result, buf, buf_size, idx, recursion=True):
    while idx[0] < buf_size:
        if buf[idx[0]] == 'N':
            result.append(None)
            idx[0] += 1
        elif buf[idx[0]] == 'T':
            result.append(True)
            idx[0] += 1
        elif buf[idx[0]] == 'F':
            result.append(False)
            idx[0] += 1
        elif buf[idx[0]] == 'b':
            result.append(Struct('b').unpack(buf[idx[0]+1:idx[0]+2])[0])
            idx[0] += 2
        elif buf[idx[0]] == 'w':
            result.append(Struct('H').unpack(buf[idx[0]+1:idx[0]+3])[0])
            idx[0] += 3
        elif buf[idx[0]] == 'd':
            result.append(Struct('I').unpack(buf[idx[0]+1:idx[0]+5])[0])
            idx[0] += 5
        elif buf[idx[0]] == 'n':
            result.append(Struct('n').unpack(buf[idx[0]+1:idx[0]+9])[0])
            idx[0] += 9
        elif buf[idx[0]] == 's':
            lens = Struct('H').unpack(buf[idx[0]+1:idx[0]+3])[0]
            result.append(buf[idx[0]+3:idx[0]+3+lens])
            idx[0] += 3+lens
        elif buf[idx[0]] == '{':
            idx[0] += 1
            table = _LoadTableFromBuff(buf, buf_size, idx)
            if result is None:
                result = table
            else:
                result.append(table)
            return result
        else:
            c = buf[idx[0]]
            if c >= '0' and c <= '9':
                result.append(ord(c) - ord('0'))
            else:
                print "[ERROR]LoadValueFromBuff, char=%d" % ord(c)
            idx[0] += 1
        if not recursion:
            break

def _LoadTableFromBuff(buf, buf_size, idx):
    result = []
    keyvalues = {}
    split = False
    while idx[0] < buf_size:
        if buf[idx[0]] == ';':
            split = True
            idx[0] += 1
        elif buf[idx[0]] == '}':
            idx[0] += 1
            break        
        if split:
            item = []
            # read key
            LoadValueFromBuff(item, buf, buf_size, idx, recursion=False)
            # read value
            LoadValueFromBuff(item, buf, buf_size, idx, recursion=False)
            keyvalues[item[0]] = item[1]
        else:
            LoadValueFromBuff(result, buf, buf_size, idx)

    if split:        
        result.append(keyvalues)
    return result

def SaveValueToBuff(value, buf, idx):
    if isinstance(value, str):
        buf[idx[0]] = 's'
        buf[idx[0]+1:idx[0]+3] = pack('H', len(value))
        buf[idx[0]+3:idx[0]+3+len(value)] = value
        idx[0] += 3 + len(value)
    elif isinstance(value, int):
        if value >= 0 and value <= 9:
            buf[idx[0]] = ord('0') + value
            idx[0] += 1
        elif value >= 0 and value <= 0xff:
            buf[idx[0]] = 'b'
            buf[idx[0]+1] =  value
            idx[0] += 2
        elif value >= 0 and value <= 0xffff:
            buf[idx[0]] = 'w'
            buf[idx[0]+1:idx[0]+3] =  pack('H', value)
            idx[0] += 3
        else:
            buf[idx[0]] = 'd'
            buf[idx[0]+1:idx[0]+5] =  pack('I', value)
            idx[0] += 5
    elif isinstance(value, float):
        buf[idx[0]] = 'n'
        buf[idx[0]+1:idx[0]+9] =  pack('d', value)
        idx[0] += 9
    elif isinstance(value, list):
        if list:
            buf[idx[0]]='{'
            idx[0] += 1
            for v in value:
                SaveValueToBuff(v, buf, idx)
            buf[idx[0]]='}'
            idx[0] += 1
        else:
            buf[idx[0]]=';'
    elif isinstance(value, dict):
            buf[idx[0]]='{'
            idx[0] += 1
            buf[idx[0]]=';'
            idx[0] += 1
            for k,v in value.items():
                SaveValueToBuff(k, buf, idx)
                SaveValueToBuff(v, buf, idx)
            buf[idx[0]]='}'
            idx[0] += 1
        
        
    return idx[0]   
        
        
        
        
