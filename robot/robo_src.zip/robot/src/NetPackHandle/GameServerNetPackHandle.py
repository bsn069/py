#encoding=utf-8
'''
Created on 2015-5-27

@author: Administrator
'''
import io
import traceback
import re
from Config.RoleFigures import *
from google.protobuf.reflection import GeneratedProtocolMessageType
from Cmd2protocol import *
from net.NetProtocol import *
from net.NetConnector import *
from net.Common.ComDefine_pb2 import *
from net.ProtoBuffer.ComProtocol_pb2 import *
from net.ProtoBuffer.DBProxyProtocol_pb2 import *
from ProtoBuffer.ComProtocol_pb2 import Auction64BitId as MyAuction64BitId
from Config.Kin import *
from Family import *
from Modules.ModuleManager import *
import math
import random
import logging
import time
import threading
import json
import gevent
from _struct import Struct
from Tools.Switch import switch
from Config.CaseDefine import *
from locust.asyncevent import asyncresult_manager
from locust.events import *
from Tools.Rand import Rand
from Config.RunConfig import *
from Tools.GenerateChinese import generate_chinese
from ModuleState.NotifyState import NotifyState
from TestCase.Files.Team import Team, TeamBaseInfo
from TestCase.Script.TestCase_TeamBase import TeamCreateType, TeamMemberType
from TestCase.Files.Shop import Shop, SHOPID_KIN
from TestCase.Files.FamilyBase import *
from TestCase.Files.Battle import Battle
from ProtoBuffer.ComProtocol_pb2 import ChatTextBlock as MyChatTextBlock 

TIMEOUT = 300


class GameServerNetPackHandle(object):
    global moduleManager

    def __init__(self, address, family):
        self.gsConnect = None
        self.gsAddress = address
        self.isLoginGame = False # 标识是否在游戏内，用于换GS的情况
        self.isReady = False
        
        # AQR相关
        self.s2cRecvSeq = 0
        self.s2cRecvLength = 0
        self.s2cRspAckSeq = 0
        self.s2cLastRspTime = 0

        self.familyId = None
        self.family = family
        self.mainName = self.family.mainName
        self.coupleName = self.family.coupleName
        self.userId = self.family.userId
        self.token = self.family.token
        self.channelId = self.family.channelId

        # 排位, 装备
        self.isGetWeapon = False
        self.isGetClothEquip = False
        self.isGetHeadEquip = False

        self.isPutOnCloth = False
        self.isPutOnHead = False

        self.clothItemId = None
        self.weaponItemId = None

        # 穴位
        self.isSetUseCloth = False
        self.isSetUseHead = False

        # 背包
        self.bagList = []
        self.bloodItemId = -1

        # 角色装备栏
        self.characterBagList = []

        # 当前场景
        self.currentSence = 0
        self.respondS2CHandler = {}
        self.requestC2SHandler = {}
        self.RegeditHandle()

        self.sceneTemplateId = 0
        self.sceneInstanceId = 0

        # 换线
        self.switchLineId = 0
        self.gsChanged = False
        self.isRecordGsChanged = False
        # 排行榜
        self.rankListType = 0

        # 龙门荒漠队伍列表
        self.bossTeamDict = {}
        self.bossTeamIdDict = {}
        self.bossTeamApplyIdList = []
        self.bossTeamInfoDict = {}
        self.bossBoolMove = True
        self.bossDict = {}
        self.fightBossId = 0
        self.fightBossPosX = 0
        self.fightBossPosY = 0
        self.bossLine = False
        self.moveTag = True
        self.gameServerId = 0

        # 联赛
        self.sence = 0
        self.canSkill = True
        self.skillList = []
        self.attackList = []

        # 护法
        self.visitGuardianId = -1

        # 好友同步请求次数
        self.friendSyncTimes = 0

        # 技能
        self.skillCdList = []
        self.skillid = 0
        # 主线任务
        self.maintaskId = 0

        # NPC人物
        self.sceneNPCDict = {}

        # 拍卖行
        self.tradeHouseTradePrice = 0  # 记录上架时系统推荐的价格
        self.tradeHouseMyTradeId = []  # 记录自己上架商品系统分配的tradeid，用于下架和重新上架
        self.tradeHousePutOnItem = []  # 记录拍卖行上的商品信息，用于购买
        self.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_TRADEHISTORY  # 设置查询自己出售商品后的状态

        # 奇遇记录当前的state
        self.nowState = None
        
        #首次进入场景
        self.isFirstEnterScene = True
        
        #角色类型
        '''
            1 : 男，
            2 : 女，
            3 : 孩子
        '''
        self.memberType = FAMILY_MEMBER_TYPE_MAIN
#        self.hasMemberChange = False
        self.memberType2Bag = {
                               FAMILY_MEMBER_TYPE_MAIN : 'self.family.bag.member1Bag',
                               FAMILY_MEMBER_TYPE_COUPLE : 'self.family.bag.member2Bag',
                               FAMILY_MEMBER_TYPE_KID : 'self.family.bag.member3Bag',
                               }

        #瞬移
        self.gmArrivalStateIsNeedChange = False#是否需要改变gm到达后的状态
        self.autoMoveDstPost = None
        
        self.serverId=0
    def RegeditHandle(self):
        for (protocolId, name) in S2CProtocol.items():
            func = getattr(self, "On_" + str(name).split(".")[-1].rstrip("'>"))
            self.respondS2CHandler[protocolId] = func

    # GameServer Correlation function
    def DoGsProtocol(self, *args, **kwds):
        return NetPack(*args, **kwds).GetBuff()

    def OnGsProtocol(self, header, buffer=None):
        cmdId = header if isinstance(header, int) else header.cmd
        
        if cmdId in [
                      GS_TO_CLI_SKILL_HIT, # FlatBuffer，暂时用不着
                      ]:
            return
        
        if cmdId in S2CProtocol:
            # 协议ID对应的如果是ProtoBuffer，则进行解析；如果对应的是str，说明该协议只有头
            if isinstance(S2CProtocol[cmdId], GeneratedProtocolMessageType):
                protobuf = S2CProtocol[cmdId]()
                try:
                    protobuf.ParseFromString(buffer)
                except Exception, e:
                    logging.debug("command id = %d, buffer len=%d, trackback = %s" % (cmdId, len(buffer), traceback.format_exc()))
                    return
            else:
                protobuf = buffer
                 
            if cmdId in self.respondS2CHandler:
                self.respondS2CHandler[cmdId](protobuf)
        else:
#             logging.debug('cmdId error : %s' % cmdId)
            moduleManager.OnProtocol(cmdId, buffer)

    def On_RecvARQPack(self, buffer):
        ARQPack = Struct("II")
        (realCmdId, seq) = ARQPack.unpack(buffer[0:8])
        if seq < self.s2cRecvSeq:
#             logging.error("NetARQAgent:OnRecvServerARQPack error %d, %d" % (seq, self.s2cRecvSeq))
            return
        
        unixSec = self.family.serverTime.UnixSec()
        if self.s2cRecvSeq == self.s2cRspAckSeq:
            self.s2cLastRspTime = unixSec
        self.s2cRecvSeq = seq
        self.s2cRecvLength += len(buffer) - 8
        if self.s2cRspAckSeq == self.s2cRecvSeq:
            return
        
        if unixSec > self.s2cLastRspTime + 15 \
            or self.s2cRecvLength >= 1024 * 5 \
            or self.s2cRecvSeq - self.s2cRspAckSeq >= 20:
            if self.SendAckPackToServer(self.s2cRecvSeq):
                self.s2cRspAckSeq = self.s2cRecvSeq
                self.s2cRecvLength = 0
                self.s2cLastRspTime = unixSec
                
        if realCmdId in self.respondS2CHandler:
            self.OnGsProtocol(realCmdId, buffer=buffer[8:])
            
    def SendAckPackToServer(self, serverSeq):
        request = NetAckPack()
        request.ackSeq = serverSeq
        return self.SendProtocol(CLI_TO_GS_RSP_ACK, request)
        
    def ClientLoginGameRequest(self):
        request = AccountLoginGame()
        request.token = self.family.token
        request.channelId = self.family.channelId
        request.userId = self.family.userId
        request.groupId = self.family.groupId
        request.userName = 'null'
        request.deviceID = '%s58:44:98:a0:3a:f8' % self.family.imei
        request.mobileModel = 'MI NOTE LTE'
#         request.appVersion = '1.0'
        request.imei = '%s' % self.family.imei
        request.mac = '58:44:98:a0:3a:f8'
        request.firmwareVersion = '4.4.4'
        request.idfa = 'AdvertisingID'
        request.screenX = 1920
        request.screenY = 1080
        request.platformType = 4
        request.netMode = 4
        if Config.is_illegaltest():
            request.platform = Rand.bound_uint32(0, 4)
            request.netMode = Rand.bound_uint32(0, 4)
            request.screenX = Rand.bound_uint32(0, 1920)
            request.screenY = Rand.bound_uint32(0, 1080)
        self.SendProtocol(CLI_TO_GS_LOGIN_GAME, request)
        # print "send ClientLoginGameRequest %s" % self.family.userName
        asyncresult_manager.await(self, "ClientLoginGameRequest", TIMEOUT)

    def On_ClientLoginGameResponse(self, respond):
        logging.debug('ClientLoginGameResponse_Respond : %s ' % respond)#
        if respond.loginResult == 0:
            asyncresult_manager.fire(self, "ClientLoginGameRequest", True)
            self.family.characterCur.tick = respond.serverTick
            self.serverId = respond.serverId
            self.family.serverTime.UpdateServerTick(respond.serverTick, respond.unixMSec)
            self.isLoginGame = True
        else:
            asyncresult_manager.fire(self, "ClientLoginGameRequest", False,
                                     error="result == %d" % respond.loginResult)

    def ClientFamilyListRequest(self):
        request = ClientFamilyListRequest()
        self.SendProtocol(CLI_TO_GS_FAMILIY_LIST, request)
        asyncresult_manager.await(self, "ClientFamilyListRequest", TIMEOUT)

    def On_ClientFamilyListResponse(self, respond):
        asyncresult_manager.fire(self, "ClientFamilyListRequest", True)
        if len(respond.familyDataList._values) == 0:
            # self.ClientAskRoleNameRequest()    #现在跳过请求名字服务器
            if self.family.caseId == CaseManager.DATACHECKER or (self.family.caseId == CaseManager.TRADEHOUSE_DATA and RUN_TYPE == CASE_TYPE.PLAY_WITH_LOOP_ROLE):
                self.family.behavior = Behavior.END
                asyncresult_manager.fire(self.family, "All_GameServer", False, error="CaseId:%d can not find role" % self.family.caseId)
                return
            self.ClientCreateFamilyRequest()  # 使用自己生成的名称
        elif RUN_TYPE == CASE_TYPE.PLAY_WITH_CREATE_MULTI_ROLE and self.family.GetState() == STATE_GS_RETIRE :
            self.family.mainName=u"男%s" % generate_chinese(5)
            self.family.coupleName = u"女%s" % generate_chinese(5)
            self.ClientCreateFamilyRequest()  # 使用自己生成的名称
            
        else:
            self.family.familyListRetire.clear()
            self.family.familyListUnretire.clear()
            for familyData in respond.familyDataList._values:
                family_base_info = FamilyBase()
                family_base_info.familyId = familyData.familyId
                family_base_info.mainName = familyData.mainName
                family_base_info.coupleName = familyData.coupleName
                family_base_info.retire = familyData.retire
                if family_base_info.retire:
                    self.family.familyListRetire[family_base_info.familyId] = family_base_info
                else:
                    self.family.familyListUnretire[family_base_info.familyId] = family_base_info
            self._check_and_entergame()

    def _check_and_entergame(self):
        if self.family.GetState() == STATE_GS_RETIRE:
            if len(self.family.familyListUnretire) < 3:
                self.ClientFamilyListRequest()
            else:
                self.Do_Retire(random.choice(self.family.familyListUnretire.keys()))
        elif self.family.GetState() == STATE_GS_UNRETIRE:
            assert len(self.family.familyListRetire) > 0
            self.Do_Unretire(random.choice(self.family.familyListRetire.keys()))
        else:
            assert len(self.family.familyListUnretire) > 0
            for (family_id, familyData) in self.family.familyListUnretire.items():
                self.familyId = familyData.familyId
                self.mainName = familyData.mainName
                self.coupleName = familyData.coupleName
                self.family.familyId = self.familyId
                self.family.mainName = self.mainName
                self.family.coupleName = self.coupleName
                self.EnterGame(self.family.familyId)
                break

    def ClientAskRoleNameRequest(self):
        request = ClientAskRoleNameRequest()
        request.count = 30
        request.male = True
        request.female = True
        if Config.is_illegaltest():
            request.count = Rand.bound_uint32(0, 1024)
        self.SendProtocol(CLI_TO_GS_ASK_ROLE_NAME, request)
        asyncresult_manager.await(self, "ClientAskRoleNameRequest", TIMEOUT)

    def On_ClientAskRoleNameResponse(self, respond):
        #         print 'On_ClientAskRoleNameResponse %s' % respond
        if respond.result == 0:
            asyncresult_manager.fire(self, "ClientAskRoleNameRequest", True)
            #             self.coupleName = respond.coupleName._values[0]
            #             self.mainName = respond.mainName._values[0]
            self.ClientCreateFamilyRequest()
            return
        else:
            asyncresult_manager.fire(self, "ClientAskRoleNameRequest", False,
                                     error="result == %d" % respond.result)
            asyncresult_manager.fire(self.family, "All_GameServer", False)

    def ClientCreateFamilyRequest(self):
        request = ClientCreateFamilyRequest()
        request.group_id = self.family.serverGroupId
        appeartype =self.family.Getsexmember()
        self.family.characterCur.Adult = appeartype
        # TODO 性别永远为男性,为女性时候其他地方要修改
        request.sex = self.family.main_sex
        if request.sex == MALE:
            request.name = self.family.mainName
            request.portrait = 0
            request.faction = self.family.characterMan.faction
            request.appeartype = appeartype
            request.hair_id = 1
        else:
            request.name = self.family.mainName
            request.portrait = 0
            request.faction = self.family.characterMan.faction
            request.appeartype = appeartype
            request.hair_id = 1
        self.SendProtocol(CLI_TO_GS_CREATE_FAMILY, request)
        logging.debug(request)
        asyncresult_manager.await(self, "ClientCreateFamilyRequest", TIMEOUT)

    def On_ClientCreateFamilyResponse(self, respond):
        if respond.result == 0:
            asyncresult_manager.fire(self, "ClientCreateFamilyRequest", True)
            # self.familyId = respond.newFamilyData.familyId
            # request.Set("SetInfo", familyId=self.familyId)
            self.family.familyId = respond.newFamilyData.familyId
            self.family.mainSex = respond.newFamilyData.mainSex
            self.family.mainName = respond.newFamilyData.mainName
            self.family.coupleName = respond.newFamilyData.coupleName
            self.family.kidName = respond.newFamilyData.kidName
            self.family.kidName = respond.newFamilyData.kidName
            self.family.isNewRole = True

            family_base_info = FamilyBase()
            family_base_info.familyId = respond.newFamilyData.familyId
            family_base_info.mainName = respond.newFamilyData.mainName
            family_base_info.coupleName = respond.newFamilyData.coupleName
            family_base_info.retire = respond.newFamilyData.retire
            self.family.familyListUnretire[family_base_info.familyId] = family_base_info

            self._check_and_entergame()
        else:
            logging.debug('ClientCreateFamilyResponse result = %d' % respond.result)  #
#             asyncresult_manager.fire(self, "ClientCreateFamilyRequest", False,
#                                      error="result == %d, name = %s" % (respond.result, self.mainName))
            if respond.result == 5:
                asyncresult_manager.fire(self, "ClientCreateFamilyRequest", True)
                self.family.mainName = u"男%s" % generate_chinese(5)
                self.ClientCreateFamilyRequest()
            else:
                asyncresult_manager.fire(self, "ClientCreateFamilyRequest", False,
                                         error="result == %d" % respond.result)
                self.family.behavior = Behavior.END
                asyncresult_manager.fire(self.family, "All_GameServer", False)

    # 同步游戏状态，现在只剩下两个状态了
    def On_NotifyClientState(self, respond):
        logging.debug("On_NotifyClientState respond = %s" % respond)
        if respond.gameState == GAME_STATE_LOAD_ROLE_END:
            # print "GAME_STATE_LOAD_ROLE_END" + self.family.userName
            if not self.gsChanged:
                if RUN_TYPE == CASE_TYPE.PLAY_WITH_CREATE_MULTI_ROLE:
                    self.family.SetState(STATE_GS_RETIRE)
                self.ClientFamilyListRequest()
        elif respond.gameState == GAME_STATE_PLAYERING:            
            if self.family.GetState() == STATE_GS_WAIT_NOVICE_MISSION_START:
                self.family.SetState(STATE_GS_NOVICE_MISSION_STARTING)
                asyncresult_manager.fire(self, "EnterGame", True)
                asyncresult_manager.fire(self.family, "All_GameServer", True)
            elif not self.gsChanged:
                if self.family.isNewRole and RUN_TYPE is not CASE_TYPE.LOGIN_ONLY:
                    self.Action()
                    #重复登录后会先让角色回到临安城，而不是直接执行案例
                    self.family.SetState(STATE_GS_PLAYING)
                
                if self.family.caseId in [CaseManager.TRADEHOUSE_DATA]:#拍卖行数据校对的服务器异常测试添加状态重置机制
                    gevent.spawn(self.family.ResetState)
                elif self.family.caseId in [CaseManager.SKILLTEST]:
                    gevent.spawn(self.family.CheckState)
                
                asyncresult_manager.fire(self, "EnterGame", True)
                # gevent.sleep(0)
                asyncresult_manager.fire(self.family, "All_GameServer", True)
            else:
                if self.isRecordGsChanged:
                    self.family.SetState(STATE_GS_1_PLAYING)
                self.gsChanged = False
        else:
            pass

    # 进入游戏
    def EnterGame(self, familyId):
        # gevent.sleep(3)
        self.familyId = familyId
        request = EnterGame()
        request.familyId = familyId
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()

        if self.gsConnect:
            self.SendProtocol(CLI_TO_GS_ENTER_GAME, request)
            asyncresult_manager.await(self, "EnterGame", 30)
        else:
            logging.debug("GS connect is none, username id = %s", self.family.userName)
            asyncresult_manager.fire(self.family, "All_GameServer", False)

    # 进入竞技场
    def EnterArena(self):
        self.CallScriptTransfer(2001, 81.11, 127.18)

    # 同步character状态
    def On_SyncCharacterState(self, respond):
#         logging.debug('同步Character : %s' % respond)
#         if (self.family.GetPlayerId() == respond.id):
        if respond.id in self.family.GetAllCharacterPlayerId():
            state = self.family.GetState()
            self.family.characterCur.Updata(respond)

        elif self.fightBossId != 0 and respond.id == self.fightBossId:  # 同步龙门Boss位置
            logging.debug('同步Character : %s' % respond)
            # self.SyncCharacter(respond.id)
            self.fightBossPosX = respond.info.posX
            self.fightBossPosY = respond.info.posY

#         elif self.family.GetPlayerId() != respond.id:  # 同步角色state
        elif respond.id not in self.family.GetAllCharacterPlayerId():  # 同步角色state
            id2familyid = self.family.otherCharacterManager.getSceneId2FamilyidDict()
            if respond.id in id2familyid.keys():
                self.family.otherCharacterManager.setSceneId2FamilyidState(respond.id, respond.state)
        if respond.id in self.family.grave.monsterDict.keys(): #同步家族周末关卡敌人信息
            logging.debug("同步_埋骨之窟关卡敌人信息")
            self.family.grave.monsterDict[respond.id]['pos'] = (respond.info.posX, respond.info.posY)
        # 怪物走动
        elif respond.id in self.family.graveDigger.diGongNpcInfo:#同步挖宝地宫的Npc位置
            logging.debug("同步_挖宝地宫的Npc位置 : %s" % respond.id)
            self.family.graveDigger.diGongNpcInfo[respond.id]["pos"] = (respond.info.posX, respond.info.posY)
        
        elif respond.id in self.family.xiaomijing.bossDict:#同步小秘境的Npc位置
            logging.debug("同步_小秘境的Npc位置 : %s" % respond.id)
            self.family.xiaomijing.bossDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)
        
        elif respond.id in self.family.crusadeaginst.bossDict:
            logging.debug("同步_流寇活动的Npc位置 : %s" % respond.id)
            self.family.crusadeaginst.bossDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)

        elif respond.id in self.family.kinMan.warEnemyDict:#同步家族争夺PVE的Npc位置
            logging.debug("同步_家族争夺PVE的Npc位置 : %s" % respond.id)
            self.family.kinMan.warEnemyDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)

        elif respond.id in self.family.kinMan.warGeneralsDict:#同步家族争夺PVP的大将位置
            logging.debug("同步_家族争夺PVP的大将位置 : %s" % respond.id)
            self.family.kinMan.warGeneralsDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)

        elif self.family.kinMan.defendBossMsg:#同步家族争夺PVP的秦始皇位置
            if respond.id == self.family.kinMan.defendBossMsg["id"]:
                logging.debug("同步_家族争夺家族盛宴的BOSS位置 : %s" % respond.id)
                self.family.kinMan.defendBossMsg["pos"] = (respond.info.posX, respond.info.posY, respond.info.posH)
            
        elif respond.id in self.family.damijing.npcDict:
            self.family.damijing.npcDict[respond.id] = (respond.info.posX, respond.info.posY)

        elif respond.id in self.family.boss_challenge.bossDict:#同步打塔的boss位置
            logging.debug("同步_打塔的boss位置 : %s" % respond.id)
            self.family.boss_challenge.bossDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)
            
        elif respond.id in self.family.skill.skillTargetDict:#同步指向性技能所需npc位置
            logging.debug("同步_指向性技能所需npc位置 : %s" % respond.id)
            self.family.skill.skillTargetDict[respond.id]["pos"] = (respond.info.posX, respond.info.posY)
        
        elif respond.id == self.family.wuyi.birdId and self.family.caseId == CaseManager.WUYI:
            self.family.wuyi.SetBirldPos(respond.info.posX, respond.info.posY, respond.info.posH)
            self.family.SetState(STATE_GS_WU_YI_START)

    def On_SyncUpdateTask(self, respond):
        logging.debug("On_SyncUpdateTask respond = %s" % respond)
        if self.family.caseId == CaseManager.MAINTASK:
            if respond.taskData.taskId == Task_Yizuifangxiu:
                for taskValue in respond.taskData.taskValue._values:
                    #  喝三杯酒
                    if taskValue.stepId == 10167 and taskValue.value == 1:
                            self.family.maintaskMan.ismeijiu = True
                            self.family.SetState(STATE_GS_MAIN_TASK_START)
                            
            elif respond.taskData.taskId == Task_Youxi:
                for taskValue in respond.taskData.taskValue._values:
                    #  游戏
                    if taskValue.stepId == 10043 and taskValue.value == 1:
                            self.family.SetState(STATE_GS_MAIN_TASK_START)

        elif self.family.caseId == CaseManager.MASTER and respond.taskData.taskId == 9001:#师徒任务-师父任务信息
            for taskValue in respond.taskData.taskValue._values:
                if taskValue.stepId == 9001 and taskValue.value == 0:#需要进入桃李园
                    break
                elif taskValue.stepId == 9002 and taskValue.value == 0:#需要完成师徒的第一个任务
                    self.family.master.task = "文圣孔子"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9003 and taskValue.value == 0:#需要完成师徒的第二个任务
                    self.family.master.task = "武圣关公"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9004 and taskValue.value == 0:#需要完成师徒的第三个任务
                    self.family.master.task = "敬师堂"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9004 and taskValue.value == 1:#师徒任务完成
                    self.family.SetState(STATE_GS_MASTER_TASK_FINISH)
                    break
                
        elif respond.taskData.taskId == 9005:#师徒任务-徒弟任务信息
            for taskValue in respond.taskData.taskValue._values:
                if taskValue.stepId == 9005 and taskValue.value == 0:#需要进入桃李园
                    break
                elif taskValue.stepId == 9006 and taskValue.value == 0:#需要完成师徒的第一个任务
                    self.family.master.task = "文圣孔子"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9007 and taskValue.value == 0:#需要完成师徒的第二个任务
                    self.family.master.task = "武圣关公"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9008 and taskValue.value == 0:#需要完成师徒的第三个任务
                    self.family.master.task = "敬师堂"
                    self.family.SetState(STATE_GS_MASTER_DO_TASK)
                    break
                elif taskValue.stepId == 9008 and taskValue.value == 1:#师徒任务完成
                    self.family.SetState(STATE_GS_MASTER_TASK_FINISH)
                    break
                
                    

    def On_SyncSceneCharacterInfo(self, respond):
        logging.debug('CharacterInfo : %s' % respond)
        SyncInfoList = list(respond.syncInfo)
        random.shuffle(SyncInfoList)#乱序
        for characterSyncInfo in SyncInfoList:
            # logging.debug('characterSyncInfo : %s' % characterSyncInfo)
            # local player = me:GetActivePlayer(); player:Sync(); GM强制同步周边player信息
#             if self.family.GetPlayerId() == characterSyncInfo.id:
            if characterSyncInfo.id in self.family.GetAllCharacterPlayerId():
                self.family.GetCurCharacter().SyncSceneCharacterInfo(characterSyncInfo)
                if self.family.state == STATE_GS_MOVE_AUTO_MOVING:
                    if characterSyncInfo.state == CHAR_STATE_IDLE and self._distance(self.autoMoveDstPost[0], self.autoMoveDstPost[1], characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY) < 3:
                        self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                    else:
                        self.PlayerAutoPath(*self.autoMoveDstPost)
                        return
            else:
                if (characterSyncInfo.type == 2):
                    self.family.otherCharacterManager.syncCharacterInfo(characterSyncInfo)
                char_name = characterSyncInfo.name.encode("utf8")
                self.sceneNPCDict[char_name] = characterSyncInfo.id  # 添加到NPC字典
                if (characterSyncInfo.scene_template_id in [SceneLongmen, SceneFenghua, SceneBeach,SceneLiShanYiJi]) and characterSyncInfo.templateId in self.family.randomBoss.BossIdList:
                    self.bossDict[characterSyncInfo.id] = characterSyncInfo
                    logging.debug("龙门荒漠or枫华谷or观晴滩 or骊山遗迹characterName = %s" % char_name)

                if self.family.caseId == CaseManager.GRAVEDIGGER:
                    if char_name == "幽暗的入口":
                        logging.debug("地宫入口id = {0}".format(characterSyncInfo.id))
                        self.family.graveDigger.digongId = characterSyncInfo.id
                    elif char_name == "地宫篝火":
                        logging.debug("发现地宫篝火，跑去烤火")
                        self.canSkill = False
                        self.family.graveDigger.hasFindBonfire = True
                        self.family.graveDigger.bonfirePox = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        self.family.SetState(STATE_GS_GRAVEDIGGER_DIGONG_JUDGE)
                    elif char_name in ["寻宝者", "无常鬼", "摸金校尉", "搬山道人", "<首领>江洋大盗", "<首领>尸鬼王"]:
                        self.family.graveDigger.SetDiGongNpcInfo(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                elif self.family.caseId == CaseManager.VALENTINE:
                    if char_name == "月下老儿":
                        self.family.valentine.yuexialaoer = characterSyncInfo.id                        
                        return
                elif self.family.caseId == CaseManager.MAINTASK:
                    if char_name == "美酒":
                        self.family.maintaskMan.meijiuId = None
                        self.family.maintaskMan.meijiuId = characterSyncInfo.id
                        self.family.maintaskMan.meijiuIdX = characterSyncInfo.stateParam.posX
                        self.family.maintaskMan.meijiuIdY = characterSyncInfo.stateParam.posY
                        return   
                    elif char_name == "风筝":
                        self.family.maintaskMan.fengzhengId = None
                        self.family.maintaskMan.fengzhengId = characterSyncInfo.id
                        self.family.maintaskMan.fengzhengX = characterSyncInfo.stateParam.posX
                        self.family.maintaskMan.fengzhengY = characterSyncInfo.stateParam.posY
                        return
                    elif char_name == "粮草":
                        self.family.maintaskMan.liangcaoId = None
                        self.family.maintaskMan.liangcaoId = characterSyncInfo.id
                        self.family.maintaskMan.liangcaoX = characterSyncInfo.stateParam.posX
                        self.family.maintaskMan.liangcaoY = characterSyncInfo.stateParam.posY
                        return
                    elif char_name == "鹰槽":
                        if  characterSyncInfo.id not in self.family.maintaskMan.yingcaoId:
                            self.family.maintaskMan.yingcaoId.append(characterSyncInfo.id)
                        return
                        
                elif self.family.caseId == CaseManager.INSTANCE:
                    if char_name == "明心":
                        self.family.instance.npcId = None
                        self.family.instance.npcId = characterSyncInfo.id         
                elif self.family.caseId == CaseManager.WUYI:
                    if char_name == "飞奔的阿黄":
                        self.family.wuyi.SetBirldId(characterSyncInfo.id)
                        self.family.wuyi.SetBirldPos(characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.stateParam.posH)
                        self.family.SetState(STATE_GS_WU_YI_START)
                        return
                elif self.family.caseId == CaseManager.GRAVE:
                    #M埋骨之窟
                    if char_name == "夜光草":
                        self.family.grave.SetGrassInfo(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    elif char_name in ["千琼奴仆", "千琼圣女", "千琼护法"]:
                        self.family.grave.SetMonsterInfo(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    elif char_name[:9] == "机关【":
                        logging.debug("On_SyncSceneCharacterInfo = %s" % char_name)
                        self.family.grave.SetPostInfo(char_name, characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
#                    elif characterSyncInfo.scene_template_id == SceneKinWeek and characterSyncInfo.type == CHARACTER_TYPE_PLAYER:
#                        logging.debug("埋骨之窟关卡成员信息~~ On_SyncSceneCharacterInfo = %s" % char_name)
#                        self.family.kinMan.SetMemberInfo(characterSyncInfo.familyId)
                    elif char_name == "<首领>制尸者":
                        self.family.grave.SetBossInfo(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)

                elif self.family.caseId == CaseManager.JIAZU:
                    #家族守护
                    if char_name == "<首领>天竺僧":#boss为远程攻击，现瞬移过去放技能
                        self.GM_MoveToPosition(False, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    elif char_name == "大胃王" and characterSyncInfo.scene_template_id == SceneKinLand:
                        self.family.kinMan.defendBossMsg = {
                                                                        "id" : characterSyncInfo.id,
                                                                        "pos" : (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.stateParam.posH)
                                                                        }
                    #家族争夺-皇陵外宫
                    elif characterSyncInfo.scene_template_id == SceneHuangLingWaiGong:
                        '''
                        KIN_WAR_NPC 存储了家族皇陵中所有的怪物所对应的模板ID
                        '''
                        if characterSyncInfo.templateId in KIN_WAR_NPC:
                            self.family.kinMan.SetWarEnemyDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        elif char_name == "长明灯":
                            self.family.kinMan.warLampDict["id"] = characterSyncInfo.id
                            self.family.kinMan.warLampDict["pos"] = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        elif char_name == "战鼓":
                            self.family.kinMan.SetWarDrumDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        elif char_name == "宝箱":
                            self.family.kinMan.warBoxDict["id"] = characterSyncInfo.id
                            self.family.kinMan.warBoxDict["pos"] = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                            self.family.SetState(STATE_GS_KIN_WAR_OPEN_RANK_UI)
                        else:
                            logging.debug("char_name = %s" % char_name)
                            
                    elif characterSyncInfo.scene_template_id == SceneHuangLingNeiDian:
                        if char_name in ["蒙恬", "章邯", "王翦", "白起", "蒙毅", "秦始皇"]:
                            self.family.kinMan.SetWarGeneralsDict(characterSyncInfo.id, char_name, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        else:
                            logging.debug("char_name = %s" % char_name)
                            
                #小秘境
                elif characterSyncInfo.scene_template_id in [SceneXiaoMiJing6, SceneXiaoMiJing7]:
                    if char_name == "宝箱":
                        self.family.xiaomijing.boxMsg = {
                                                                    "id" : characterSyncInfo.id,
                                                                    "pos" : (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                                                                    }
                    elif characterSyncInfo.type == 1 and characterSyncInfo.camp == 2 and characterSyncInfo.fightState == 1:
                        self.family.xiaomijing.SetBossDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.name)
                    elif any(ext in char_name for ext in ["开门", "休门", "生门", "伤门", "杜门", "景门", "死门", "惊门"]):
                        self.family.xiaomijing.hasSwitch = True
                        self.family.xiaomijing.SetSwitchDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    elif characterSyncInfo.type == CHARACTER_TYPE_PLAYER:
                        logging.debug("小秘境成员信息~~ On_SyncSceneCharacterInfo = %s" % char_name)
                        self.family.xiaomijing.SetTeammateIdList(characterSyncInfo.familyId)
                    else:
                        logging.debug("char_name = %s" % char_name)
                        
                elif self.family.caseId == CaseManager.DAMIJING:
                    if char_name == '太史丹':
                        self.family.damijing.taishidanId = characterSyncInfo.id
                    elif char_name == '衡虚境·宝藏':
                        self.family.damijing.baoXiang = {}
                        self.family.damijing.baoXiang[characterSyncInfo.id] = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    elif self.family.damijing.refreshNPC and characterSyncInfo.type == 1:
                        self.family.damijing.npcDict[characterSyncInfo.id] = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    
                elif self.family.caseId == CaseManager.BOSSCHALLENGE and characterSyncInfo.scene_template_id == SceneBossChallenge:
                    if char_name in ["<首领>冷月使", "<首领>贪官万大户", "<首领>铁浮屠", "<首领>完颜阿鲁补", "<首领>带剑异者", "<首领>连珠箭客", "<首领>巨灵战熊", 
                                                 "<首领>铁浮屠【狱】", "<首领>完颜烈", "<首领>药王谷灵豹", "<首领>无想师太", "<首领>殷童", "<首领>完颜襄", "<首领>张善德", 
                                                 "<首领>虎王", "<首领>唐芸", "<首领>独孤剑", "<首领>杨瑛", "<首领>吕四爷", "<首领>鱼三", "<首领>唐晓", "<首领>兀撒", 
                                                 "<首领>战虎", "<首领>叶芷琳", "<首领>龙五公子", "<首领>何人我", "<首领>媚杀夫人", "<首领>古松", "<首领>赏兴都", 
                                                 "<首领>拜日月教大善姆", "<首领>完颜烈【狂】", "<首领>贺惊山", "<隐士>万通", "<隐士>胡霸天", "<隐士>鱼六", "<隐士>纳兰潜凛"]:
                        self.family.boss_challenge.SetBossDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                        if self.family.GetState() == STATE_GS_BOSSCHALLENGE_TARGET_WAIT:
                            self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                    else:
                        logging.debug("char_name = %s" % char_name)
                elif self.family.caseId == CaseManager.BATTLE and characterSyncInfo.scene_template_id == SceneBattle:
                    if char_name == Battle.BAOXIANG_NAME:
                        self.family.battle.baoxiangPos = (characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                
                #劫镖
                if char_name.endswith("队的镖车") and self.family.escort.jieBiaoIsArrived == True and self.family.GetState() == STATE_GS_ESCORT_JIEBIAO_WAIT:
                    self.family.SetState(STATE_GS_ESCORT_JIEBIAO_JUDGE)
                    npcId = characterSyncInfo.id
                    if npcId == self.family.escort.jieBiaoLastNpcId:
                        logging.debug("已劫过这个镖车了")
                        self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)
                        continue
                    else:
                        self.family.escort.jieBiaoLastNpcId = npcId
                    logging.debug("Add New NpcId=%s" % npcId)
                    def StateJudge(npcId, posX, posY):#防止出现如果服务器无响应会无限等待的情况
                        logging.debug("瞬移，劫镖")
                        self.CallScriptGmDoCommand("me:GetActivePlayer():MoveToPosition({X}, {Y})".format(X=posX, Y=posY))
                        self.AskNpc_obj(npcId)
                        if self.family.GetState() == STATE_GS_ESCORT_JIEBIAO_JUDGE:
                            logging.debug("服务器没有返回对应协议，继续等待镖车")
                            self.GM_MoveToPosition(False, *(self.family.escort.GetJieBiaoPos()))#重置劫镖位置
                            self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)
                    gevent.spawn(StateJudge, npcId, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    
                #衡道书Boss
                if self.family.caseId == CaseManager.DUNGEON and char_name in ["<首领>金蛇香主", "<首领>黑面郎君", "<首领>殷童", "<首领>南宫誉", "<首领>马逵", "<首领>大善母", "<首领>岳霆", "<首领>岳震", "<首领>岳霖"]:
                    self.family.dungeon.SetBossIdList(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.stateParam.posH)
                
                #指向性技能释放目标
                if char_name == "测试用刺客" : 
                    if characterSyncInfo.scene_template_id in [SceneLongmen, SceneLiShanYiJi, SceneBattle]:
                        self.family.skill.SetSkillTargetDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    else:
                        self.family.gameServerNetPackHandle.GM_GetNpcKill(characterSyncInfo.id)
                if self.family.caseId == CaseManager.VALENTINE:
                    if "的烟花" in char_name and self.family.mainName in char_name:
                        self.family.valentine.fire = characterSyncInfo.id  
                        self.family.fireX = characterSyncInfo.stateParam.posX
                        self.family.fireY = characterSyncInfo.stateParam.posY
                        self.family.fireZ = characterSyncInfo.stateParam.posH
                if self.family.caseId == CaseManager.INSTANCE:
                    if char_name in ["金矿"]:
                        self.family.instance.setgoldDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.stateParam.posH)
                    elif char_name in ["何掌柜", "胡大户", "魏员外", "钱七爷"]:
                        self.family.instance.setbusinessman(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY, characterSyncInfo.stateParam.posH)    
                if self.family.caseId == CaseManager.CRUSADEAGINST and characterSyncInfo.scene_template_id in [SceneLongmen, SceneLuWeiDang, ScenekKunLun, SceneBeach, SceneYaoWangGu, ScencHeiShuiCaoYuan]:
                    if char_name in ['<流寇>倭寇精英']:
                        self.family.crusadeaginst.SetBossDict(characterSyncInfo.id, characterSyncInfo.stateParam.posX, characterSyncInfo.stateParam.posY)
                    
    def On_PlayerLeaveScene(self, respond):
        if self.sceneTemplateId in [SceneKinDaily, SceneXoyo1, SceneXoyo2, SceneXoyo3, SceneXoyo4, SceneXoyo5]:
            self.canSkill = False
            logging.debug("On_PlayerLeaveScene, canSkill = %s" % self.canSkill)

    def On_SyncSceneDropInfo(self, respond):
        SyncInfoList = list(respond.syncInfo)
        for SyncSceneDropInfo in SyncInfoList:
            if self.family.caseId == CaseManager.EATCHICKEN and SyncSceneDropInfo.sceneTempId == SenceXueYuSha:
                self.family.eatchicken.SetEquip(SyncSceneDropInfo.id, SyncSceneDropInfo.posx, SyncSceneDropInfo.posy, SyncSceneDropInfo.posz) 
                break
                
    def On_CurrentFamily(self, respond):
        # self.SyncMaxFocusViewer()
        '''
            VALUE_COIN_NULL         = 0;
            VALUE_COIN_SILVER       = 1;        // 银两
            VALUE_COIN_GOLD         = 2;        // 元宝
            VALUE_COIN_BIND_GOLD    = 3;        // 绑定元宝
            VALUE_COIN_XIAYI        = 4;        // 侠义值
            VALUE_COIN_REPUTATION   = 5;        // 联赛声望
            VALUE_COIN_BATTLE_HONOR = 6;        // 战场功勋值
            VALUE_COIN_LUN_JIAN_PRESTIGE = 7;   // 论剑威望值
            VALUE_COIN_MASTER_COIN = 8;         // 师徒货币
            VALUE_COIN_YINGYONGBAO = 9;         // 应用宝充值代币
            VALUE_COIN_TIANLANG     = 10;       // 天狼套碎片
        '''
        self.family.kinMan.id = respond.kinId
        self.family.valueCoin = {}
        for value in respond.valueCoin._values:
            self.family.valueCoin[value.coinType] = value.coinValue

    # 设置同屏人数
#     def SyncMaxFocusViewer(self):
#         request = SyncMaxFocusViewer()
#         request.count = 20
#         if Config.is_illegaltest():
#             request.count = Rand.bound_uint32(0, 0xFF)
#         self.SendProtocol(CLI_TO_GS_SHOW_PLAYER_COUNT, request)

    def Action(self):
        logging.debug('action!!!!')
        # 开启所有功能模块，开启之后UI才会有显示被屏蔽的功能
        self.OpenModule()
        # 通关新手本
        self.CallScriptGmDoCommand("me:SetDataInt(103,200,1)")
        self.CallScriptGmDoCommand("me:SetDataInt(106,300,1000)")
        # 接受第一个任务
        self.Do_AcceptTask(taskid=10001)
        # 装备系统的开启
        self.LevelUp_Character()  # 升级角色
        #开启第一个护法
        self.OpenFirstGardian()
        # self.Chararcter_EquipmentSystem()    #装备系统相关
        self.Chararcter_PlayerCaseEX()
        
#         gm获取解锁表情物品
        for scrollId in ActionScroll:
            self.Add_ActionItem(scrollId)
#            gevent.sleep(0)
    def OpenFirstGardian(self):   
        if self.family.caseId not in [CaseManager.GUARDIAN]:
            #开启第一个护法
            self.CallScriptGmDoCommand("KGuardian.UnlockGuardian(%d, 17);KGuardian.AddGuardianVisitTimes(%d, 17, 700);" % (self.family.familyId, self.family.familyId))
            self.RecruitGuardian(17)   
            
    def Add_ActionItem(self, id):
        self.CallScriptAddStackItem(5, 4, 206, id, 1, False, 0)

    def Chararcter_PlayerCaseEX(self):
#         #添加装备到背包
#         self.Add_HeadEquipment()
        # GM命令
        if self.family.isAddGold:
            self.Add_Gold()  # 加元宝
            logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"coin" : {3 : 10000000}}))
        if self.family.isAddSliver:
            self.Add_Sliver()  # 加银币
            logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"coin" : {1 : 10000000}}))
        self.Add_JingLi()  # 加精力
        self.Add_CaiLiao()  # 加强化材料

    def Chararcter_EquipmentSystem(self):
        # 添加装备到背包
        self.Add_ClothEquipment()
        self.Add_HeadEquipment()

        # GM命令
        self.Add_Gold()  # 加元宝
        self.Add_JingLi()  # 加精力
        self.Add_Sliver()  # 加银币
        self.Add_CaiLiao()  # 加强化材料

        # 秘籍
        self.Add_MiJi()  # 主秘籍

        # 经脉
        self.OpenAcuPoint()  # 开穴
        self.ZazenReq()  # 获取真气

        # #外观
        self.Buy_AvaterClothes()  # 购买衣服
        self.Buy_GuaJian()  # 购买挂件

    def OpenModule(self):
        self.CallScriptGmDoCommand("me:OpenAllModuleByGM();")

    def OpenModuleById(self, nModuleId):
        request = NotifyClientOpenModule()
        request.moduleId = nModuleId
        self.SendProtocol(CLI_TO_GS_OPEN_MODULE_RESULT, request)
    
    def On_SyncActiveMember(self, respond):
        logging.debug("On_SyncActiveMember respond : %s" % respond)
        self.memberType = respond.activeMember
    
    def On_CurrentPlayer(self, respond):
        logging.debug("On_CurrentPlayer %s" % respond)

        if respond.familyMemberType == FAMILY_MEMBER_TYPE_MAIN:
            self.family.characterMan.playerId = respond.playerId
            self.family.characterMan.belongFamilyId = respond.belongFamilyId
            self.family.characterMan.familyMemberType = respond.familyMemberType
            self.family.characterMan.name = respond.name
            self.family.characterMan.faction = respond.faction
            self.family.characterMan.series = respond.series
            self.family.characterMan.level = respond.level
            self.family.characterMan.sex = respond.sex
        
        elif respond.familyMemberType == FAMILY_MEMBER_TYPE_COUPLE:
            self.family.characterWoman.playerId = respond.playerId
            self.family.characterWoman.belongFamilyId = respond.belongFamilyId
            self.family.characterWoman.familyMemberType = respond.familyMemberType
            self.family.characterWoman.name = respond.name
            self.family.characterWoman.faction = respond.faction
            self.family.characterWoman.series = respond.series
            self.family.characterWoman.level = respond.level
            self.family.characterWoman.sex = respond.sex
            
        elif respond.familyMemberType == FAMILY_MEMBER_TYPE_KID:
            self.family.characterChild.playerId = respond.playerId
            self.family.characterChild.belongFamilyId = respond.belongFamilyId
            self.family.characterChild.familyMemberType = respond.familyMemberType
            self.family.characterChild.name = respond.name
            self.family.characterChild.faction = respond.faction
            self.family.characterChild.series = respond.series
            self.family.characterChild.level = respond.level
            self.family.characterChild.sex = respond.sex


    def SetCurrentCharacter(self, memberType):
        self.memberType = memberType
        if self.memberType == FAMILY_MEMBER_TYPE_MAIN:
            self.family.characterCur = self.family.characterMan
        elif self.memberType == FAMILY_MEMBER_TYPE_COUPLE:
            self.family.characterCur = self.family.characterWoman
        elif self.memberType == FAMILY_MEMBER_TYPE_KID:
            self.family.characterCur = self.family.characterChild
    
    def On_PlayerEnterScene(self, respond):
        logging.debug("[FamilyId : %s]enter scene %s" % (self.family.familyId, respond))
        self.family.characterCur.posX = respond.posX
        self.family.characterCur.posY = respond.posY
        self.family.characterCur.posH = respond.posH
        self.sceneTemplateId = respond.scene_template_id
        self.sceneInstanceId = respond.scene_instance_id
        
#        if self.hasMemberChange:#切换角色
#            self.hasMemberChange = False
#            self.SetCurrentCharacter(respond.memberType)
#            self.skillCdList = []
#            if self.family.GetCurCharacter().attackList:
#                self.attackList = self.family.GetCurCharacter().attackList
#                self.skillList = self.family.GetCurCharacter().skillList
#            elif self.family.skill.isFinalMember:
#                self.family.skill.isFinalMember = False
#                # 多次切换角色的时候，在最后一次切换后更新门派对应技能
#                logging.debug("多次切换角色的时候，在最后一次切换后更新门派对应技能")
#                self.SetOriginSkill()
            
        if self.isFirstEnterScene:
            self.isFirstEnterScene = False
            if self.family.isNewRole:
                #TODO:如果是使用随机技能等改变了初始的技能，再循环角色就有可能出现装备技能卡住的情况
                self.SetOriginSkill()
            #使用循环账号的逻辑时，重复登录后会先让角色回到临安城
            else:
                #更新当前角色技能列表
                self.SetCurrentCharacter(self.memberType)
                self.attackList = self.family.characterCur.attackList
                self.skillList = self.family.characterCur.skillList
                logging.debug("技能列表更新为：%s" % self.skillList)
                if respond.scene_template_id != SceneLinan:
                    logging.debug("当前场景id=%s, 5s后传入临安城" % respond.scene_template_id)
                    self.Transfer2Map(SceneLinan)
                    return
            
        # 判断换线是否成功
        if self.family.GetState() == STATE_GS_LINE_SWITCH_WAIT:
            logging.debug("换线之后获取一下线路信息，比对是否换线成功")
            self.Get_LineInfo()
            return
        
        if self.family.GetState() == STATE_GS_GUARDIAN_TRANSFER and respond.scene_template_id == self.family.guardian.targetSceneId:
            self.family.SetState(STATE_GS_GUARDIAN_START_MISSION)
            return

        
        if self.family.GetState() == STATE_GS_WAIT_ENTER_SCENE:
            self.family.SetState(STATE_GS_ENTER_SCENE_FINISHED)
            
        for case in switch(respond.scene_template_id):
            if case(SceneLinan):
                # print "%s Enter Chengzheng" % self.mainName
                # self.LeagueMatch_MatchTeammaterRequest()

                self.sceneTemplateId = SceneLinan
                self.currentSence = SceneLinan
                if not self.family.isLandingMember:
                    self.family.SetState(STATE_GS_PLAYING)  # 重置的状态
                else:
                    self.family.isLandingMember = False
                self.sence = STATE_GS_CHENGZHEN
                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)  #客户端加载完之后确认进入主城
                break

            # 武林联赛
            elif case(SceneArena3, SceneArena4, SceneArena5, SceneArena6):
                logging.debug("name: %s Enter JingjiChang, familyId: %s, characterId:%s \n" % (
                    self.mainName, str(self.familyId), str(self.family.characterCur.playerId)))
                self.family.SetState(STATE_GS_LEAGUEMATCH_START_FIGHT)
                break

            elif case(SceneLongmen, SceneLuWeiDang, ScenekKunLun, SceneBeach, SceneYaoWangGu, ScencHeiShuiCaoYuan) and self.family.caseId == CaseManager.CRUSADEAGINST:
                if self.family.state == STATE_GS_CRUSADEAHAINST_MAPLE_WAIT:
                    self.family.SetState(STATE_GS_CRUSADEAHAINST_MAPLE)
                    break

            
            elif case(SenceYouBiShenLin, SenceHenXuJingShenMu, SenceJianGeZhiShang1, SenceHenXuJingXuanBin, SenceHenXuJingJiaoZhuo, SenceCuiYan, SenceJianGeZhiShang2, SenceHanWuYiJi):
                if self.family.caseId == CaseManager.CROSSBATTLE:
                    self.MarkTestCase("TestCase_CROSSBATTLE_EnterFightSence")
                    break
                
            elif case(SenceMoXiangJu):
                if self.family.state == STATE_GS_ENTER_WEEK_GAME_WAIT:
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_MOXIANGJU)
                    break
            
            elif case(SenceHuangQuanJian):
                self.MarkTestCase("TestCase_Bight_EnterSence")
                self.family.SetState(STATE_GS_BIGFIGHT_ENTER_SENCE)
                break
            
            # 漠北草原
            elif case(SceneMoBeiCaoYuan):
                if self.family.state == STATE_GS_BATTLE_ENTER:
                    self.family.SetState(STATE_GS_BATTLE_MOBEI)
                    break
                elif self.family.state == STATE_GS_BIGFIGHT_ENTER:
                    self.family.SetState(STATE_GS_BIGFIGHT_MOBEI)
                    break
                elif self.family.state == STATE_GS_EAT_CHICKEN_WAIT:
                    self.family.SetState(STATE_GS_EAT_CHICKEN_MOBEI)
                    break
            elif case(SenceXueYuSha):
                self.MarkTestCase("TestCase_EatChicken_EnterSence")
                break
            elif case(SceneZhuluJinTan):
                self.family.SetState(STATE_GS_GOLD_DEER_ACTIVITY)
                self.MarkTestCase("TestCase_CampWar_EnterSence")
                break
            #试剑台
            elif case(SenceShiJianTai):
                if self.family.state == STATE_GS_LEAGUEMATCH_WAIT_ENTER_READY_SCENE:
                    self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT)
                    # 检查报名状态
                    self.Cli_LeagueMatch_CheckJoinRequest()
                elif self.family.state == STATE_GS_LEAGUEMATCH_WAIT_BACK_READY_SCENE:
                    self.family.SetState(STATE_GS_LEAGUEMATCH_BACK_READY_SCENE)    
                                
            elif case(SceneBattle):
                if self.family.caseId == CaseManager.SKILLTEST and self.family.GetState() == STATE_GS_SKILLTEST_ENTER_WAIT:
                    self.family.SetState(STATE_GS_SKILLTEST_SET_CAMP)
                else:
                    #匹配成功
                    asyncresult_manager.fire(self, "TestCase_Battle_MatchFinish", True)
                    self.family.SetState(STATE_GS_BATTLE_MATCHED)
                break
            
            elif case(SceneXoyo):
                self.family.SetState(STATE_GS_XOYO_ENTER)
                break
            
            # 进入逍遥谷的地图检查
            elif case(SceneXoyo1, SceneXoyo2, SceneXoyo3, SceneXoyo4, SceneXoyo5):
                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)
                self.MarkTestCase("TestCase_Xoyo_EnterMap")
                self.family.SetState(STATE_GS_IN_XOYOGAME_MAP)
                break
            
            # 小秘境
            elif case(SceneXiaoMiJing6, SceneXiaoMiJing7):
                self.MarkTestCase("TestCase_XiaoMiJing_EnterMap")   
                break

            elif case(SceneKinDaily):  # 家族副本
                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)
                self.MarkTestCase("TestCase_Kin_DailyInstanceStart")
                self.family.SetState(STATE_GS_ENTER_KIN_DAILY)
                break
            
            elif case(SceneKinLand): #家族领地
                if self.family.GetState() == STATE_GS_KIN_LAND:#家族盛宴
                    self.MarkTestCase("TestCase_Kin_FeastGameStart")
                    self.family.SetState(STATE_GS_KIN_FEAST)
                break
            
            elif case(SceneDiGong):#进入地宫
                self.family.graveDigger.isEnterDiGongFirstFloor = True
                self.family.SetState(STATE_GS_GRAVEDIGGER_ENTER_DIGONG)
                break
            
            #跨服约战场景
            elif case(SenceKuaFuBattle):
                if self.family.GetState() == STATE_GS_CROSSBATTLE_ENTER_WAIT:
                    self.family.SetState(STATE_GS_CROSSBATTLE_ENTER)
                break

                
            elif case(SceneShuiYunJing):#水云境
                if self.family.caseId == CaseManager.XIAOMIJING:
                    if self.family.xiaomijing.hasEnterShuiYunJing:
                        self.family.SetState(STATE_GS_END)
                    else:
                        self.family.SetState(STATE_GS_MOVE_GO)
                elif self.family.caseId == CaseManager.DAMIJING:
                    if self.family.damijing.hasEnterShuiYunJing:
                        self.family.SetState(STATE_GS_END)
                    else:
                        self.family.damijing.hasEnterShuiYunJing = True
                        self.family.SetState(STATE_GS_DAMIJING_ENTRY_READY_SCENE)
                break
            
            elif case(SceneHuangLingWaiGong):#皇陵外宫
#                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)  #客户端加载完之后确认进入场景
                self.MarkTestCase("TestCase_Kin_EnterWaiGong")
                break
            
            elif case(SceneHuangLingNeiDian):#皇陵内殿
                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)  #客户端加载完之后确认进入场景
#                gevent.sleep(15)#等待进入时的buff消失
                self.AddBuffBlock()#增加强力格挡
                self.AddBuffHeavyDamage()#增加一击必杀
                self.family.kinMan.isdajiang = True
                self.family.SetState(STATE_GS_KIN_WAR_KILL_GENERALS)
                self.family.kinMan.target = KinWarKillGenerals
                self.MarkTestCase("TestCase_Kin_EnterNeiDian")
                break
            
            elif case(1861, 1862, 1863, 1864, 1865): # 大秘境
                self.family.SetState(STATE_GS_DAMIJING_ENTER_SCENE)
                self.SendProtocol(CLI_TO_GS_PLAYER_ENTER_SCENE)  #客户端加载完之后确认进入场景
                break
            
            elif case(SceneBossChallenge):#江湖风云录
                self.MarkTestCase("TestCase_BossChallenge_EnterMap")
                break
            
            elif case(SenceEngChouHuanJing):
                self.family.SetState(STATE_GS_KILLER_IN_MISS)
                
    def On_SyncFamilyDataSet(self, respond):
        '''
                message SyncFamilyDataSet {
            message IntValue {
                required uint32  index  = 1;
                required int32   value  = 2;
            }
        
            message IntGroup {
                required uint32   group  = 1;
                repeated IntValue intValue  = 2;             // value不为1时存放在这
                repeated uint32   indexOfBoolValueTrue = 3;  // value为1的存放这里，只存index
            }
        
            repeated IntegerValue integerValue = 1;  // 旧同步方式，已废弃（流量优化，移到了intGroup）
            repeated BufferValue  bufferValue  = 2;
            repeate
        '''
        for intGroup in respond.intGroup:
            if intGroup.group == 123 and intGroup.indexOfBoolValueTrue:
                logging.debug("同步数据1 = {0}".format(intGroup.group))
                logging.debug("同步数据2 = {0}".format(intGroup.indexOfBoolValueTrue._values))#同步以激活称号
                self.family.family_designtion_list=intGroup.indexOfBoolValueTrue._values
        pass

    def On_SyncDataCommon(self, respond):
        if respond.dataList[0].type == 2:
            # 称号系统
            if self.family.GetState() == STATE_GS_SET_JH_DESIGNATION_WAIT:
                self.family.SetState(STATE_GS_GET_DESIGNATION)
            if self.family.GetState() == STATE_GS_SET_GX_DESIGNATION_WAIT:
                self.family.SetState(STATE_GS_SET_JH_DESIGNATION)
            if self.family.GetState() == STATE_GS_SET_XG_DESIGNATION_WAIT:
                self.family.SetState(STATE_GS_SET_GX_DESIGNATION)
            if self.family.GetState() == STATE_GS_UNSET_DESIGNATION_WAIT:
                self.family.SetState(STATE_GS_UNSET_DESIGNATION_RESULT)
            # 必做任务+奖励补领
            if self.family.GetState() == STATE_GS_GET_DAILY_MUST_DO_AWARD_AWAIT:
                self.family.SetState(STATE_GS_GET_DAILY_MUST_DO_AWARD_RESULT)
            if self.family.GetState() == STATE_GS_APPLY_BUY_ACTIVITY_REDO_WAIT:
                self.family.SetState(STATE_GS_APPLY_BUY_ACTIVITY_REDO_RESULT)
            # 领取7日豪礼
            if self.family.GetState() == STATE_GS_GET_LOGIN7_REWARD_AWAIT:
                self.family.SetState(STATE_GS_GET_LOGIN7_REWARD_RESULT)
                
        if respond.id == self.family.characterCur.playerId:
            # 血量
            if respond.dataList[0].type == 6:
                if respond.dataList[0].data[0].int32Value1 == 0:
                    if self.sceneTemplateId == SceneKinDaily:  # 家族副本死亡，复活继续释放技能
                        self.KinDailyRevival(random.randint(1, 2))
                        self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
#                     elif self.sceneTemplateId in [SceneLongmen, SceneFenghua, SceneYaoWangGu, SceneBeach]:
#                         self.Add_Gold()
#                         self.BossRevival(1)  # 原地复活
#                         self.DefaultRevival(1)
                    elif self.sceneTemplateId in [SceneXoyo1, SceneXoyo2, SceneXoyo3, SceneXoyo4, SceneXoyo5]:
                        self.canSkill = False  # 禁止技能
                    elif self.sceneTemplateId == SceneKinWeek:
                        self.CallScript("PlayerCmd", "KinWeekRevival", 2)#家族周末关卡死亡，原地复活
                        self.AddBuffInvincible()#增加无敌
            #天忍技能资源点
            elif respond.dataList[0].type == 83:
                if respond.dataList[0].data[0].uint32Value1 == 4:
                    logging.debug("天忍月技能点=%d" % respond.dataList[0].data[0].uint32Value2)
                    self.family.skill.tianrenMoonSkillPoint = respond.dataList[0].data[0].uint32Value2
                elif respond.dataList[0].data[0].uint32Value1 == 6:
                    logging.debug("天忍日技能点=%d" % respond.dataList[0].data[0].uint32Value2)
                    self.family.skill.tianrenSunSkillPoint = respond.dataList[0].data[0].uint32Value2
            #峨眉技能资源点
            elif respond.dataList[0].type == 84:
                if respond.dataList[0].data[0].uint32Value1 == 8:
                    logging.debug("峨眉技能点琴意=%d" % respond.dataList[0].data[0].uint32Value2)
                    self.family.skill.emeiSkillPointQinyi = respond.dataList[0].data[0].uint32Value2
                elif respond.dataList[0].data[0].uint32Value1 == 14:
                    logging.debug("峨眉技能点莲花=%d" % respond.dataList[0].data[0].uint32Value2)
                    self.family.skill.emeiSkillPointLianhua = respond.dataList[0].data[0].uint32Value2
        if respond.id == self.familyId:
            for datainfo in respond.dataList:
                # 金币
                if datainfo.type == 12:
                    for data in datainfo.data:
                        self.family.valueCoin[data.int64Value1] = data.int64Value2
                    self.family.notifyState.set_state(NotifyState.STATE_GS_SYNC_MONEY)
                # 创建家族时候分配的家族id(创建、加入、解散、退出家族)
                elif datainfo.type == 7:
                    for data in datainfo.data:
                        self.family.kinMan.id = data.uint32Value1
                elif datainfo.type == 8:
                    for data in datainfo.data:
                        self.family.kinMan.name = data.strValue1
                #悬赏与奇遇
                elif datainfo.type == 2:
                    xoyoCancel1 = xoyoCancel2 = 0
                    for data in datainfo.data:
                        if data.int32Value1 == 39387337 and data.int32Value2 != 0:
                            logging.debug("同步奇遇数据 = {0}".format(data.int32Value2))
                            self.nowState = self.family.GetState()
                            self.family.SetState(STATE_GS_FORTUITOUS_MEETING)
                        elif data.int32Value1 == 39387149 and data.int32Value2 == 0:
                            xoyoCancel1 = 1
                        elif data.int32Value1 == 13107253 and data.int32Value2 == 0:
                            xoyoCancel2 = 1
                    if xoyoCancel1 == xoyoCancel2 == 1 and self.family.GetState() == STATE_GS_XOYO_CANCLE:#逍遥谷取消匹配后的逻辑
                        if (not self.family.team_manager.myteam.IsInTeam()) or self.family.team_manager.myteam.IsLeader(self.family.familyId):
                            logging.debug("逍遥谷取消匹配后单人或队长的逻辑")
                            self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                        else:
                            logging.debug("逍遥谷取消匹配后队员的逻辑")
                            if random.randint(0, 1) == 0:
                                logging.debug("逍遥谷队员选择离开队伍")
                                self.family.SetState(STATE_GC_TEAM_BEGIN)

    def On_CharacterSyncInfo(self, respond):
#         if (self.family.GetPlayerId() != respond.id):
        if respond.id in self.family.GetAllCharacterPlayerId():
            self.family.otherCharacterManager.syncCharacterInfo(respond)

    def On_CharacterLeaveScene(self, respond):
        self.family.otherCharacterManager.playerLeaveScene(respond)
        
        for name in self.sceneNPCDict.keys():
            if respond.id == self.sceneNPCDict[name]:
                del self.sceneNPCDict[name]
                break
            flag = False
            for char_id in respond.id._values:
                if char_id == self.sceneNPCDict[name]:
                    del self.sceneNPCDict[name]
                    flag = True
                    break
            if flag:
                break
            
        postDict = dict((self.family.grave.postDict[name]["id"], name) for name in self.family.grave.postDict.keys())
        if respond.id._values[0] in self.family.grave.grassIdDict.keys():#移除家族周末关卡被采摘的夜光草
            del self.family.grave.grassIdDict[respond.id._values[0]]

        elif respond.id._values[0] in self.family.grave.monsterDict.keys():#移除家族周末关卡被杀的敌人
            logging.debug("移除_埋骨之窟关卡被杀的敌人 : %s" % respond.id._values[0])
            del self.family.grave.monsterDict[respond.id._values[0]]
        
        elif respond.id._values[0] in postDict.keys():#移除被解开的机关柱子
            logging.debug("移除_被解开的机关柱子 : %s" % respond.id._values[0])
            del self.family.grave.postDict[postDict[respond.id._values[0]]]
            
        elif respond.id._values[0] in self.family.grave.memberIdList:#移除家族周末关卡离开的成员
            logging.debug("移除_埋骨之窟关卡离开的成员 : %s" % respond.id._values[0])
            self.family.grave.memberIdList.remove(respond.id._values[0])
                        
        elif respond.id._values[0] in self.family.grave.bossDict.keys():#移除家族周末关卡被杀的制尸者Boss
            logging.debug("移除_埋骨之窟关卡被杀的制尸者Boss : %s" % respond.id._values[0])
            del self.family.grave.bossDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.dungeon.bossIdList:#移除衡道书被杀的Boss
            logging.debug("移除_衡道书被杀的Boss : %s" % respond.id._values[0])
            del self.family.dungeon.bossIdList[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.graveDigger.diGongNpcInfo.keys():#移除挖宝地宫被杀的Npc
            logging.debug("移除_挖宝地宫被杀的Npc : %s" % respond.id._values[0])
            del self.family.graveDigger.diGongNpcInfo[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.xiaomijing.bossDict:#移除小秘境被杀的Npc
            logging.debug("移除_小秘境被杀的Npc : %s" % respond.id._values[0])
            del self.family.xiaomijing.bossDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.kinMan.warEnemyDict:#移除家族争夺PVE被杀的Npc
            logging.debug("移除_家族争夺PVE被杀的Npc : %s" % respond.id._values[0])
            del self.family.kinMan.warEnemyDict[respond.id._values[0]]

        elif respond.id._values[0] in self.family.kinMan.warGeneralsDict:#移除家族争夺PVP被杀的大将
            logging.debug("移除_家族争夺PVP被杀的大将 : %s" % respond.id._values[0])
            del self.family.kinMan.warGeneralsDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.crusadeaginst.bossDict:#移除流寇活动被杀的NPC
            logging.debug("移除流寇活动被杀的NPC : %s" % respond.id._values[0])
            self.MarkTestCase("TestCase_Crusagains_BOSS")
            del self.family.crusadeaginst.bossDict[respond.id._values[0]]
            
#        elif self.family.kinMan.warQinShiHuang and respond.id._values[0] == self.family.kinMan.warQinShiHuang["id"]:#移除家族争夺PVP被杀的秦始皇
#            logging.debug("移除_家族争夺PVP被杀的秦始皇 : %s" % respond.id._values[0])
#            self.family.kinMan.warQinShiHuang = {}

        elif respond.id._values[0] in self.family.kinMan.warDrumDict:#移除家族争夺消失的战鼓
            logging.debug("移除_家族争夺消失的战鼓 : %s" % respond.id._values[0])
            del self.family.kinMan.warDrumDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.damijing.npcDict:
            del self.family.damijing.npcDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.instance.goldDict:
            del self.family.instance.goldDict[respond.id._values[0]]
            
        elif respond.id._values[0] in self.family.boss_challenge.bossDict:#移除打塔被杀的boss
            logging.debug("移除_打塔被杀的boss : %s" % respond.id._values[0])
            del self.family.boss_challenge.bossDict[respond.id._values[0]]

        elif respond.id._values[0] in self.family.skill.skillTargetDict:#移除消失的指向性技能所需的npc
            logging.debug("移除_消失的指向性技能所需的npc : %s" % respond.id._values[0])
            del self.family.skill.skillTargetDict[respond.id._values[0]]

    # 升级角色等级
    def LevelUp_Character(self, level=None):
        if not level:
            if self.family.caseId == CaseManager.MASTER:#师徒案例需要徒弟等级至少低于师父3级；案例里再把师父升为满级
                level = MaxLevel
            elif self.family.caseId in [CaseManager.MOVE, CaseManager.SQUAREDANCE]:#随机移动、野外Boss案例等有不同等级战力需求
                level = 18
            elif self.family.caseId in [CaseManager.BOSS, CaseManager.MAPLE]:#进图最低等级
                level = 30
            elif self.family.caseId == CaseManager.BEACH:#进图最低等级
                level = 45
            elif self.family.caseId == CaseManager.FRIEND: # 战场最低等级要求
                level = 30
            elif self.family.caseId == CaseManager.TRADEHOUSE:#拍卖行现在超过60级的话会变成3个摊位，先设定为60级
                level = 50
            else:
                level = MaxLevel
        self.CallScriptGmDoCommand("local player = me:GetActivePlayer(); player:AddLevel(%d - player:GetLevel());" % level)

            
    # 元宝
    def Add_Gold(self):
        self.CallScriptGmDoCommand("me:AddBindGold(10000000, 1);")

    # 银子
    def Add_Sliver(self):
        self.CallScriptGmDoCommand("me:AddSilver(10000000, 1);")

    # 精力
    def Add_JingLi(self):
        self.CallScriptGmDoCommand("KMeridian.AddEnergy(%d,10000000, 0)" % self.familyId)

    # 材料
    def Add_CaiLiao(self):
        for addtype in range(1, 9, 1):
            self.CallScriptAddStackItem(5, 1, addtype, 1, 1000, False, 0)

    # 秘籍
    def Add_MiJi(self):
        for p in [1, 2, 3]:
            self.CallScriptAddStackItem(3, 1, p, 1, 1, False, 0)

    # GM 获取衣服装备
    def Add_ClothEquipment(self):
        self.CallScriptAddStackItem(1, 2, self.family.GetCurCharacter().faction, 5, 1, False, 0)
        self.isGetClothEquip = True

    # GM 获取头盔
    def Add_HeadEquipment(self):
        self.CallScriptAddStackItem(1, 4, self.family.GetCurCharacter().faction, 5, 1, False, 0)
        self.isGetHeadEquip = True

    # GM 获取武器
    def Add_Weapon(self):
        self.CallScriptAddStackItem(1, 1, self.family.GetCurCharacter().faction, 5, 1, False, 0)
        self.isGetWeapon = True

    # 时装背包,新增
    def On_BuyAvatarResult(self, respond):
        logging.debug('On_BuyAvatarResult: %s' % respond)
        if respond.result == 0:
            if respond.avatar.key:
                AppearanceDict = self.family.appearance.AppearanceDict
                for part in AppearanceDict.keys():
                    if AppearanceDict[part] and AppearanceDict[part]["avatarId"] == respond.avatar.avatarId:
                        AppearanceDict[part]["key"] = respond.avatar.key
                self.PutOn_AvatarGuise(respond.avatar.key, memberType=self.memberType)
            elif respond.ride.key:
                AppearanceDict = self.family.appearance.AppearanceDict
                if AppearanceDict[Appearance_Mounts] and AppearanceDict[Appearance_Mounts]["avatarId"] == respond.avatar.avatarId:
                    AppearanceDict[Appearance_Mounts]["key"] = respond.avatar.key
                self.PutOn_Horses(respond.ride.key, memberType=self.memberType)
                self.GetOnRide(respond.ride.key, memberType=self.memberType)

    def On_PutOnAvatarResult(self, respond):
        logging.debug('On_PutOnAvatarResult: %s' % respond)
        if not respond.result == 0:
            return
        AppearanceDict = self.family.appearance.AppearanceDict
        for part in AppearanceDict.keys():
            if AppearanceDict[part].has_key("key"):
                key = AppearanceDict[part]["key"] 
                if key == respond.key:
                    if part == Appearance_Mounts:
                        if self.family.caseId not in [CaseManager.MOVE,
                                                      CaseManager.BOSS,
                                                      CaseManager.MAPLE,
                                                      CaseManager.BEACH,
                                                      CaseManager.SQUAREDANCE,
                                                      CaseManager.SKILLTEST,
                                                      CaseManager.APPEARANCE]:#不卸下坐骑的案例
                            self.TakeOff_Horses(key, memberType=self.memberType)
                    else:
                        if self.family.caseId not in [CaseManager.MOVE, 
                                                      CaseManager.BOSS,
                                                      CaseManager.MAPLE,
                                                      CaseManager.BEACH,
                                                      CaseManager.SQUAREDANCE,
                                                      CaseManager.GODDESS,
                                                      CaseManager.SKILLTEST,
                                                      CaseManager.APPEARANCE]:#不脱掉时装的案例
                            self.TakeOff_AvatarGuise(key, memberType=self.memberType)

    def On_TakeOffAvatarResult(self, respond):
        logging.debug("On_TakeOffAvatarResult: %s" % respond)

    # 购买外观接口
    def Buy_AvaterGuise(self, avatarId, memberType=1, buyIndex=2, chooseAttrIndex=0, colorPlanIndex=0):
        if memberType == FAMILY_MEMBER_TYPE_MAIN:
            faction = self.family.characterMan.faction
        elif memberType == FAMILY_MEMBER_TYPE_COUPLE:
            faction = self.family.characterWoman.faction
        elif memberType == FAMILY_MEMBER_TYPE_KID:
            faction = self.family.characterChild.faction
            
        if avatarId in QiBingList:
            avatarId += (faction - 1) * 200
            self.family.appearance.AppearanceDict[Appearance_QiBing]["avatarId"] = avatarId
        elif avatarId in FashionList:
            avatarId = self.GetFashionOrHairAvatarId(avatarId, memberType)
            self.family.appearance.AppearanceDict[Appearance_Fashion]["avatarId"] = avatarId
        elif avatarId in HairList:
            avatarId = self.GetFashionOrHairAvatarId(avatarId, memberType)
            self.family.appearance.AppearanceDict[Appearance_Hair]["avatarId"] = avatarId
        elif avatarId in PendantList:
            self.family.appearance.AppearanceDict[Appearance_Pendant]["avatarId"] = avatarId
        elif avatarId in HeaddressList:
            self.family.appearance.AppearanceDict[Appearance_Headdress]["avatarId"] = avatarId
        elif avatarId in BeltList:
            if avatarId in SpecialBeltList:
                avatarId += (faction - 1) * 5
            self.family.appearance.AppearanceDict[Appearance_Belt]["avatarId"] = avatarId
            
        request = BuyAvatarRequest()
        request.avatarId = avatarId
        request.memberType = memberType
        request.buyIndex = buyIndex
        request.chooseAttrIndex = chooseAttrIndex
        if colorPlanIndex:
            request.colorPlanIndex = colorPlanIndex
        if Config.is_illegaltest():
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
            request.buyIndex = Rand.bound_uint32(0, 9)
        logging.debug("购买外观 request=%s" % (request))
        self.SendProtocol(CLI_TO_GS_BUY_AVATAR, request)
    
    #获取时装与发型在不同成员和性别下真实的avatarId
    def GetFashionOrHairAvatarId(self, avatarId, memberType):
        if self.family.characterCur.Adult > FEMALE:
            if self.family.characterCur.Adult == 3:
                avatarId += 300
            else:
                avatarId += 200
        elif self.family.characterCur.sex == 2:
            avatarId += 100
        return avatarId
    
    # 穿外观接口
    def PutOn_AvatarGuise(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = PutOnAvatarRequest()
        request.key = key
        request.memberType = memberType
        if Config.is_illegaltest():
            request.key = Rand.bound_int32(0)
            request.rideCount = Rand.bound_int32(0)
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
        self.SendProtocol(CLI_TO_GS_PUT_ON_AVATAR, request)

    # 卸外观接口
    def TakeOff_AvatarGuise(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = TakeOffAvatarRequest()
        request.key = key
        request.memberType = memberType
        if Config.is_illegaltest():
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
            request.key = Rand.bound_int32(0)
        self.SendProtocol(CLI_TO_GS_TAKE_OFF_AVATAR, request)

    # 购买马
    def Buy_AvaterHorse(self, avatarId=None, memberType=FAMILY_MEMBER_TYPE_MAIN, buyIndex=2, chooseAttrIndex=0):
        '''
        avatarId:
        1:踏雪
        2:乌骓
        3:墨狮（元宝无法购买）
        4:玄鹿
        5:倔驴
        6:福禄猫
        8:渠黄
        9:疾风
        10:绯雪蹋云
        11:暖暖
        13:疾风·丹心
        14:绯雪蹋云·烟波
        '''
        #获取墨狮碎片
        self.CallScriptAddStackItem(5,3,301,1, 1000, False, 0)
        gevent.sleep(1)
        request = BuyAvatarRequest()
        if not avatarId:
#             avatarId = random.choice([2, 4, 6, 8, 9])
            avatarId = random.choice([id for id in range(2, 15) if id not in [7, 12]])
        self.family.appearance.AppearanceDict[Appearance_Mounts]["avatarId"] = avatarId
        
        request.avatarId = avatarId
        request.memberType = memberType
        request.buyIndex = buyIndex
        request.chooseAttrIndex = chooseAttrIndex
        if Config.is_illegaltest():
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
            request.buyIndex = Rand.bound_uint32(0, 9)
        logging.debug("购买马：request=%s" % request)
        self.SendProtocol(CLI_TO_GS_BUY_RIDE, request)

    # 装备马:
    def PutOn_Horses(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = PutOnAvatarRequest()
        request.key = key
        request.memberType = memberType
        if Config.is_illegaltest():
            request.key = Rand.bound_int32(0)
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
            request.rideCount = Rand.bound_int32(0)
        self.SendProtocol(CLI_TO_GS_PUT_ON_RIDE, request)

    # 卸下马
    def TakeOff_Horses(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = TakeOffAvatarRequest()
        request.key = key
        request.memberType = memberType
        if Config.is_illegaltest():
            request.key = Rand.bound_int32(0)
            request.memberType = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
        self.SendProtocol(CLI_TO_GS_TAKE_OFF_RIDE, request)
    
    #上马
    def GetOnRide(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = PutOnAvatarRequest()
        request.key = key
        request.memberType = memberType
        self.SendProtocol(CLI_TO_GS_GET_ON_RIDE, request)
    
    #下马
    def TakeOffRide(self, key, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = TakeOffAvatarRequest()
        request.key = key
        request.memberType = memberType
        self.SendProtocol(CLI_TO_GS_GET_OFF_RIDE, request)
    
    # 升级武器
    def LevelUp_Weapon(self):
        index = 0
        for item in self.characterBagList:
            if item.itemData.itemIndex.d == 1:
                request = ApplyDevelopEquip()
                request.slotPos.memberType = FAMILY_MEMBER_TYPE_MAIN
                request.slotPos.roomType = 0
                request.slotPos.slotPosition = 0
                request.itemId = item.itemData.itemId
                request.developTimes = 3
                self.SendProtocol(CLI_TO_GS_DEV_EQUIP, request)
                return True
            index += 1
        return False
    
    #强化印鉴
    def StrengthenYinJian(self,itemId):
        request = ApplyDevelopEquip()
        request.slotPos.memberType = 1
        request.slotPos.roomType = 0
        request.slotPos.slotPosition = 9
        request.itemId = itemId 
        request.developTimes = 2
        self.SendProtocol(CLI_TO_GS_DEV_EQUIP, request)
    
    def On_SyncEquipDevelopResult(self, reponse):
        if self.family.GetState() == STATE_GS_MAIN_TASK_WAIT:
            if reponse.result and reponse.familyId == self.family.familyId:
                self.family.SetState(STATE_GS_MAIN_TASK_START)
    
    # 印鉴-玄玉—开孔
    def ApplyOpenSignetHole(self):
        for i in range(9):
            self.CallScript("ItemCmd", "ApplyOpenSignetHole", 2.0)
            gevent.sleep(1)
    
    def ApplyEnchantSignet(self, slotPosition, itemid):
         request = ApplyEnchantSignet()
         request.member = 1
         request.stuffPos.memberType = 0
         request.stuffPos.roomType = 0
         request.stuffPos.slotPosition = slotPosition
         request.stuff_id = itemid
         request.holeIdx = random.randint(0, 2)
         self.SendProtocol(CLI_TO_GS_ENCHANT, request)
    
    def On_SyncEnchantResult(self, respond):
        logging.debug("On_SyncEnchantResult respond = %s" % respond)
        if respond.result == True:
            self.MarkTestCase("TestCase_Equip_EnchantSignet")

        


    # 镶嵌宝石
    def ApplyEnchaseStone(self, equipId, slotPosition, stoneSlotPosition, holeIndex):
        request = ApplyEnchaseStone()
        request.equipPos.memberType = FAMILY_MEMBER_TYPE_MAIN
        request.equipPos.roomType = 0
        request.equipPos.slotPosition = slotPosition
        request.equipId = equipId
        request.stonePos.memberType = 0
        request.stonePos.roomType = 0
        request.stonePos.slotPosition = stoneSlotPosition
        request.holeIndex = holeIndex
        logging.debug("ApplyEnchaseStone request=%s" % request)
        self.SendProtocol(CLI_TO_GS_ENCHASE_STONE, request)

    # 镶嵌宝石结果
    def On_SyncEnchaseStoneResult(self, respond):
        logging.debug("On_SyncEnchaseStoneResult respond = %s" % respond)
        if respond.result == True:
            self.family.bag.SetStoneEnchaseData(respond)
            self.MarkTestCase("TestCase_Equip_EnchaseStone")
        else:
            self.MarkTestCase("TestCase_Equip_EnchaseStone", isSuccess=False, exception="result=%s" % respond.result)
    
    #剥离宝石
    def ApplyPeelStone(self, equipId, slotPosition, holeIndex):
        request = ApplyPeelStone()
        request.equipPos.memberType = FAMILY_MEMBER_TYPE_MAIN
        request.equipPos.roomType = 0
        request.equipPos.slotPosition = slotPosition
        request.equipId = equipId
        request.holeIndex = holeIndex
        self.SendProtocol(CLI_TO_GS_PEEL_STONE, request)
    
    def On_SyncPeelStoneResult(self, respond):
        logging.debug("On_SyncPeelStoneResult respond = %s" % respond)
        
    # 开经脉
    def OpenAcuPoint(self, member=1, type=0, acupoint=11):
        request = OpenAcuPoint()
        request.member = member
        request.type = type
        request.acupoint = acupoint
        if Config.is_illegaltest():
            request.member = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
            request.type = Rand.bound_uint32()
            request.acupoint = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_OPEN_ACUPOINT, request)

    # 开经脉的结果
    def On_SyncOpenAcuPointResult(self, respond):
        pass

    # --- 秘籍 ---

    # 从背包找秘籍穿上
    def PutOn_MiJi(self,index=0,count=1,memberType=FAMILY_MEMBER_TYPE_MAIN):
        bookIdList = []
        for gdpl in self.family.bag.bookBag:
            g, d, p, l = map(int, gdpl.split("_"))
            if g == emItemGBook and d == 1:
                for itemId in self.family.bag.bookBag[gdpl][True]:
                    bookIdList.append(itemId)
        if bookIdList:
            for bookId in enumerate(bookIdList[:count]):
                self.ApplyEquipBook(bookId[1], self.memberType,index)
                index+=1
        else:
            logging.error("没有找到背包中的秘籍")
    
    #从身上找秘籍脱下
    def TakeOff_MiJi(self):
        bagDict = eval(self.memberType2Bag[self.memberType])["Book"]
        for gdpl in bagDict:
            for bookId in bagDict[gdpl][True]:
                self.ApplyUnEquipBook(bookId)
    
    #装备秘籍
    def ApplyEquipBook(self, itemId, memberType, slotPosition):
        request = ApplyEquipBook()
        request.itemId = itemId
        request.slotPos.memberType = memberType
        request.slotPos.roomType = emMemberRoomBook
        request.slotPos.slotPosition = slotPosition
        self.SendProtocol(CLI_TO_GS_EQUIP_BOOK, request)
    
    def On_SyncEquipBookResult(self, respond):
        logging.debug("On_SyncEquipBookResult respond=%s" % respond)
        if respond.result == True:
            self.family.bag.UseBookSync(respond)
            self.MarkTestCase("TestCase_Equip_EquipBook")
        else:
            self.MarkTestCase("TestCase_Equip_EquipBook", isSuccess=False, exception="result=%s" % respond.result) 
            
    #卸下秘籍
    def ApplyUnEquipBook(self, itemId):
        request = ApplyUnEquipBook()
        request.itemId = itemId
        self.SendProtocol(CLI_TO_GS_UNEQUIP_BOOK, request)
        
    def On_SyncUnEquipBookResult(self, respond):
        logging.debug("On_SyncUnEquipBookResult respond=%s" % respond)
        if respond.result == True:
            self.family.bag.UseBookSync(respond, isUnEquip=True)
            self.MarkTestCase("TestCase_Equip_UnEquipBook")
        else:
            self.MarkTestCase("TestCase_Equip_UnEquipBook", isSuccess=False, exception="result=%s" % respond.result) 
    
    #升级秘籍
    def ApplyAddBookExp(self, bookItemId, itemCount, part):
        request = ApplyAddBookExp()
        request.bookItemId = bookItemId
        request.itemCount = itemCount
        request.part = part
        self.SendProtocol(CLI_TO_GS_BOOK_ADD_EXP, request)
    
    def On_SyncAddBookExp(self, respond):
        logging.debug("On_SyncAddBookExp respond=%s" % respond)
        if respond.result == True:
            self.family.bag.SetBookExpData(respond)
            self.MarkTestCase("TestCase_Equip_AddBookExp")
        else:
            self.MarkTestCase("TestCase_Equip_AddBookExp", isSuccess=False, exception="result=%s" % respond.result) 
    
    #出售物品
    def ApplySellItem(self, itemId, count, slotPosition, roomType=emPublicRoomBag):
        request = ApplySellItem()
        sell = ApplySellItem.SellUnit()
        sell.itemId = itemId
        sell.count = count
        sell.itemPos.memberType = 0
        sell.itemPos.roomType = roomType
        sell.itemPos.slotPosition = slotPosition
        request.sell.extend([sell])
        logging.debug("ApplySellItem request = %s" % request)
        self.SendProtocol(CLI_TO_GS_SELL_ITEM, request)
    
    def On_SyncItemSellResult(self, respond):
        logging.debug("On_SyncItemSellResult respond=%s" % respond)
    
    #回购物品
    def ApplyBuyRecycleItem(self, itemId, count):
        logging.debug("ApplyBuyRecycleItem itemId=%s, count=%s" % (itemId, count))
        self.CallScript("ItemCmd", "ApplyBuyRecycleItem", {"type" : "NUMBER", "value" : None}, itemId, count)
    
    # 查找背包里面的衣服装备上
    def PutOn_ClothEquipment(self):
        index = 0
        for item in self.bagList:
            if not item.itemData.itemIndex.g == 1:
                index += 1
                continue

            if item.itemData.itemIndex.d == 2:
                self.PutOn_BagEuqipment(index, item.itemData.itemId)
                break
            index += 1

    # 装备武器
    def PutOn_Weapon(self):
        index = 0
        for item in self.bagList:
            if not item.itemData.itemIndex.g == 1:
                index += 1
                continue

            if item.itemData.itemIndex.d == 1:
                self.PutOn_BagEuqipment(index, item.itemData.itemId)
                break
            index += 1

    def PutOn_Cloth(self):
        index = 0
        for item in self.bagList:
            if not item.itemData.itemIndex.g == 1:
                index += 1
                continue

            if item.itemData.itemIndex.d == 2:
                self.PutOn_BagEuqipment(index, item.itemData.itemId)
                break
            index += 1

    # 通过穿戴背包里的装备
    def PutOn_BagEuqipment(self, nItemIndex, nItemId, memberType=FAMILY_MEMBER_TYPE_MAIN):
        request = UseItem()
#         request.slotPos.memberType = 0
#         request.slotPos.roomType = 0
#         request.slotPos.slotPosition = nItemIndex
        request.itemId = nItemId
        request.member = memberType
        request.useCount = 1
        logging.debug("PutOn_BagEuqipment request = %s" % request)
        self.SendProtocol(CLI_TO_GS_USE_ITEM, request)
    
    # 使用动作宝典卷轴添加动作
    def PutOn_Action(self, nItemId):
        request = UseItem()
        request.itemId = nItemId
        request.member = 1
        request.useCount = 1
        self.SendProtocol(CLI_TO_GS_USE_ITEM, request)

    # -- 新增--
    # 背包逻辑
    def On_SyncAddItem(self, respond):
        # 记录item及其个数,可以用作交易，买卖等的验证
        logging.debug("On_SyncAddItem respond=%s" % respond)
        if respond.familyId == self.familyId:
            if str(respond).find("itemPos") != -1:
                itemPos = respond.itemPos
            else:
                itemPos = None
            self.family.bag.SetBagItem(respond.itemData, itemPos, respond.isRecycle)
            #自动鉴定添加的装备（拍卖行案例除外）
            if self.family.caseId not in [CaseManager.TRADEHOUSE, CaseManager.TRADEHOUSE_DATA, CaseManager.DATACHECKER] and respond.itemData.itemIndex.g == 5 and \
                respond.itemData.itemIndex.d == 11:
                self.Do_UseItem(respond.itemData.itemId)
            #情人节活动-烟花
            elif respond.itemData.itemIndex.g == 5 and \
                respond.itemData.itemIndex.d == 4 and \
                respond.itemData.itemIndex.p == 300 and \
                respond.itemData.itemIndex.l in [2, 5]:
                self.family.valentine.yanhua = respond.itemData.itemId     
#                self.family.SetState(STATE_GS_VALENTINE_FIREWORKS)
                return
            #情人节活动-火柴
            elif respond.itemData.itemIndex.g == 5 and \
                respond.itemData.itemIndex.d == 4 and \
                respond.itemData.itemIndex.p == 300 and \
                respond.itemData.itemIndex.l == 3:
                self.family.SetState(STATE_GS_VALENTINE_FIRE_WAIT)
                
            #女神节活动-炫光
            elif respond.itemData.itemIndex.g == 5 and \
                respond.itemData.itemIndex.d == 4 and \
                respond.itemData.itemIndex.p == 126 and \
                respond.itemData.itemIndex.l == 6:
                self.Do_UseItem(respond.itemData.itemId, self.memberType)
                self.FamilyTitle_SetActive(effectTitleId=409)#装备炫光
            #春节活动--获取红包道具ID
            elif respond.itemData.itemIndex.g == 5 and \
                respond.itemData.itemIndex.d == 3 and \
                respond.itemData.itemIndex.p in [91, 92] and \
                respond.itemData.itemIndex.l in [1, 2]:
                self.family.newyear.SetRedPacket(respond.itemData.itemId)
            #主线任务-获取衣服     
            elif self.family.caseId == CaseManager.MAINTASK and \
                 respond.itemData.itemIndex.g == 5 and \
                 respond.itemData.itemIndex.d == 22 and \
                 respond.itemData.itemIndex.p > 100 and \
                 respond.itemData.itemIndex.l == 1:
                self.family.maintaskMan.isequip = True   
            # WARNING 这样判断ItemType会有问题，但是没发现更好的办法，所以先这样用
            # '\n' 开头的Item为扩展物品，因为我们只要取baseitem count所以，这里随便指定一个item类型
            # 这样会造成扩展Item的扩展字段解析不了，但是我们只取BaseItem的count字段
            if respond.itemData.itemSerializeInfo.startswith("\n"):
                item = EquipDbData()
                item.ParseFromString(respond.itemData.itemSerializeInfo)
                self.family.items[respond.itemData.itemId] = item.baseData.count
            else:
                item = ItemSerializeInfoBase()
                item.ParseFromString(respond.itemData.itemSerializeInfo)
                self.family.items[respond.itemData.itemId] = item.count

        if not respond.itemPos:
            self.characterBagList.append(respond)
            self.characterBagList = self.Sort_ComonBag(self.characterBagList)
            return

        # 背包栏
        if respond.itemPos.memberType == FAMILY_MEMBER_TYPE_NULL:
            self.bagList.insert(respond.itemPos.slotPosition, respond)
            self.bagList = self.Sort_ComonBag(self.bagList)
        # 角色装备栏
        elif respond.itemPos.memberType == FAMILY_MEMBER_TYPE_MAIN:
            self.characterBagList.insert(respond.itemPos.slotPosition, respond)
            self.characterBagList = self.Sort_ComonBag(self.characterBagList)

        ItemIndex = respond.itemData.itemIndex
        # 孔明灯
        if (respond.familyId == self.familyId) and ItemIndex.g == 5 and ItemIndex.d == 1 and ItemIndex.p in [30,
                                                                                                             31] and ItemIndex.l == 1:
            self.family.SetState(STATE_GS_SKYLANTERN_GET_LANTERN_SUCCEED)
            
#         使用动作宝典卷轴
        if respond.familyId == self.familyId and  ItemIndex.g == 5 and ItemIndex.d == 4 and ItemIndex.p == 206 and ItemIndex.l in ActionScroll:
            self.PutOn_Action(respond.itemData.itemId)

        # 令牌
        tokenId_list = [1, 2, 3]
        if respond.familyId == self.familyId and  ItemIndex.g == 5 and ItemIndex.d == 1 and ItemIndex.p == 36 and ItemIndex.l in tokenId_list:
            self.SetUpFire(respond.itemData.itemId)

    def On_SyncUseItemResult(self, respond):
        logging.debug('SyncUseItemResult respond = %s' % respond)
        self.On_SyncUseItemResultEx(respond)  # 新增的背包逻辑，暂不使用
        if respond.result == True:
            self.family.bag.UseItemSync(respond)#同步使用的物品
        return

    def On_SyncUseItemResultEx(self, respond):
        if respond.result == True:
            if respond.itemPos.roomType == 0:  # 背包， 装备的结果
                item = self.bagList.pop(respond.itemPos.slotPosition)
                result, index = self.Exchange_bag2Character(item)
                if result:
                    equipment = self.characterBagList.pop(index)
                    self.bagList.insert(respond.itemPos.slotPosition, equipment)

                self.characterBagList.insert(index, item)
                self.characterBagList = self.Sort_ComonBag(self.characterBagList)
                self.bagList = self.Sort_ComonBag(self.bagList)

#     def On_SyncAllAvatars(self, respond):
    def On_FamilyAvatarData(self, respond):
        self.family.appearance.SetAllAvatarsData(respond.avatars)

    # -- 自定义通用排序 --
    def Sort_ComonBag(self, unsortList):
        sortedList = sorted(unsortList, cmp=self.Sort_BagByG)
        return sortedList

    # 装备GDPL
    def Sort_BagByG(self, itemA, itemB):
        if itemA.itemData.itemIndex.g > itemB.itemData.itemIndex.g:
            return 1

        if itemA.itemData.itemIndex.g < itemB.itemData.itemIndex.g:
            return -1

        if itemA.itemData.itemIndex.g == itemB.itemData.itemIndex.g:
            return self.Sort_BagByD(itemA, itemB)

    def Sort_BagByD(self, itemA, itemB):
        if itemA.itemData.itemIndex.d > itemB.itemData.itemIndex.d:
            return 1

        if itemA.itemData.itemIndex.d < itemB.itemData.itemIndex.d:
            return -1

        if itemA.itemData.itemIndex.d == itemB.itemData.itemIndex.d:
            return self.Sort_BagByP(itemA, itemB)

    def Sort_BagByP(self, itemA, itemB):
        if itemA.itemData.itemIndex.p > itemB.itemData.itemIndex.p:
            return 1

        if itemA.itemData.itemIndex.p < itemB.itemData.itemIndex.p:
            return -1

        if itemA.itemData.itemIndex.p == itemB.itemData.itemIndex.p:
            return self.Sort_BagByL(itemA, itemB)

    def Sort_BagByL(self, itemA, itemB):
        if itemA.itemData.itemIndex.l > itemB.itemData.itemIndex.l:
            return 1

        if itemA.itemData.itemIndex.l < itemB.itemData.itemIndex.l:
            return -1

        if itemA.itemData.itemIndex.l == itemB.itemData.itemIndex.l:
            return 0

    # 交换角色装备位置
    def Exchange_bag2Character(self, equipment):
        index = 0
        for item_equipment in self.characterBagList:
            if item_equipment.itemData.itemIndex.d == equipment.itemData.itemIndex.d:
                return True, index

            index += 1

        index = equipment.itemData.itemIndex.d
        return False, index

    # 道具数目变化， 强化材料
    def On_SyncItemCountChange(self, respond):
        if respond.familyId == self.family.familyId:
            self.family.items[respond.itemId] += respond.change

            self.family.bag.UpdateItemCount(respond.itemId, respond.change)
            
    #删除物品
    def On_SyncDelItem(self, respond):
        if respond.familyId == self.family.familyId:
            self.family.bag.DelBagItem(respond.itemId)
        
        if self.family.GetState() == STATE_GS_ASK_LELENPC:
            self.family.SetState(STATE_GS_SET_UP_FIRE)
        # 物品用完被删除了
        if respond.familyId == self.family.familyId \
                and self.family.items.has_key(respond.itemId):
            del self.family.items[respond.itemId]

    # ----排行榜----

    # 获取排名
    def ApplyRankingRank(self, rank_type, key=None):
        if not self.familyId:
            return
        request = ApplyRankingRank()
        request.rankListType = rank_type
        #         request.key = (self.familyId << 32) + 1
        if key is None:
            if rank_type == RANK_LIST_TYPE_KIN_ACTIVE:
                request.key = self.family.kinMan.id
            else:
                request.key = self.familyId
        else:
            request.key = key

        if Config.is_illegaltest():
            request.key = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_APPLY_RANKING_RANK, request)
        # asyncresult_manager.spawnAwait( self, "ApplyRankingRank", TIMEOUT)

    def On_RankingRankResult(self, respond):
        # asyncresult_manager.fire( self, "ApplyRankingRank", True)
        logging.debug('获取排名响应')
        logging.debug("On_RankingRankResult respond=%s" % respond)
        self.MarkTestCase("TestCase_Rank_RankResult")
        pass

    # 获取前100名的排名
    def ApplyRankingList(self, rank_type, key=None, beginIndex=0, maxCount=100):
        request = ApplyRankingList()
        request.rankListType = rank_type
        request.beginIndex = beginIndex
        request.maxCount = maxCount
        # request.key = (self.familyId << 32) + 1
        if key is None:
            if rank_type == RANK_LIST_TYPE_KIN_ACTIVE:
                request.key = self.family.kinMan.id
            else:
                request.key = self.familyId
        else:
            request.key = key
        if Config.is_illegaltest():
            request.beginIndex = Rand.bound_uint32()
            request.maxCount = Rand.bound_uint32()
            request.key = Rand.bound_uint32(0, request.key + 1)
        self.SendProtocol(CLI_TO_GS_APPLY_RANKING_LIST, request)
        # asyncresult_manager.spawnAwait( self, "ApplyRankingList", TIMEOUT)

    def On_RankingListResult(self, respond):
        # asyncresult_manager.fire( self, "ApplyRankingList", True)
        logging.debug('获取前100名的排名响应')
        logging.debug("On_RankingListResult respond=%s" % respond)
        self.MarkTestCase("TestCase_Rank_ListResult")
        pass
    
    def ChatRequestByMsg(self, msg, channel=emChatChannelWorld, isredpacket=False):
        gevent.spawn(self._ChatRequestByMsg(msg, channel, isredpacket=False))
        
    def _ChatRequestByMsg(self, msg, channel=emChatChannelWorld, isredpacket=False):
        """
            C->S: CMD_ID=365, total_length=18, Time=1505879873.12
            ChatRequest channel: 1
            msgBlocks {
              msg: "hly"
              linkType: NORMAL
            }
            emChatChannelWorld      = 1;
            emChatChannelKin        = 2;
            emChatChannelTeam       = 3;
            emChatChannelScene      = 4;
            emChatChannelInvite     = 5;    // 邀请 招募 队员
            emChatChannelFaction    = 6;    // 门派
            emChatChannelShitu      = 7;    // 师徒
            emChatChannelNotify     = 8;    // 提示
            emChatChannelCustom     = 9;    // 自定义频道
            emChatChannelPrivate    = 10;   // 私聊频道
            emChatChannelFriend     = 11;   // 好友频道
            emChatChannelCount      = 12;
        """
        if not msg:
            return
        if channel == 0:
            self.MarkTestCase("emChatChannelBroadcast_%d" % self.family.caseId)
            logging.error("emChatChannelBroadcast_%d" % self.family.caseId)
            return
        request = ChatRequest()
        request.channel = channel
        if channel >emChatChannelCount:
            request.subChannel = channel
            request.channel = emChatChannelPrivate
        msgBlocks = MyChatTextBlock()
        msgBlocks.msg = msg
        if self.family.caseId in [CaseManager.DUNGEON, CaseManager.CROSSBATTLE, CaseManager.CROSSFRIEND]:#跨服行为需要发消息到对方的GC上
            if not self.family.team_manager.myteam.leadergroupid == self.family.serverGroupId:
                self.family.KUAFU = True
                request.recverGroupID = self.family.team_manager.myteam.leadergroupid
        if self.family.caseId in [CaseManager.REDPACKET, CaseManager.ACTIVITY_NEWYEAR] and isredpacket:                                                  #红包行为需要推送一条消息到频道上
            msgBlocks.linkType = GAIN_PACKET
            msgBlocks.redPacketLink.packetId = self.family.redpacket.redpacket
            msgBlocks.redPacketLink.currency = 1
            msgBlocks.redPacketLink.linkStatus = 1
        else:    
            msgBlocks.linkType = NORMAL
        request.msgBlocks.extend([msgBlocks])
        self.SendProtocol(CLI_TO_GS_CHAT, request)

    # 聊天错误返回
    def On_SyncChatResult(self, respond):
        logging.debug('ChatResult Error: %s' % respond.result)
        pass

        # 同步聊天消息

    def On_SyncChatMsg(self, respond):
        """
            S->C: CMD_ID=370, total_length=64, Time=1505879873.28
            SyncChatMsg sender {
              familyId: 103881
              name: "\351\227\253\346\205\250\350\277\233"
              headId: 1051
              title: 1
              kinId: 0
              faction: 1
              level: 50
              fightPower: 58853
            }
            channel: 1
            msgBlocks {
              msg: "hly"
              linkType: NORMAL
            }
            time: 1505879594
            voiceId: 0
            groupid: 7
            voiceTime: 0
            teamLinkID: 0                
        """
        # 自己发的消息不需要处理
        if (respond.sender.familyId == self.familyId and self.family.caseId != CaseManager.REDPACKET) or len(respond.msgBlocks._values) == 0:
            return
        
        for values in respond.msgBlocks._values:
            msg = values.msg.encode('utf8')
            logging.debug("Msg : %s ; channel = %s" % (msg, respond.channel))
        
            # 现有队伍类型
            match = re.match(r'\[26B2F3,<[^>]*>[^<|>]*,team,(\d+),(\d+)\].*', msg)
            if match:
                team_id = int(match.group(1))
                teamType = int(match.group(2))
                MemberCount = int(match.group())
                self.family.team_manager.recruitList[teamType] = TeamBaseInfo(
                    team_id, teamType,
                    respond.sender.familyId, respond.groupid
                )
                return
            # 自定义队伍类型
            match = re.match(r'\[26B2F3,<.*><(\d+)>,team,(\d+),(\d+)\].*', msg)
            if match:
                teamType = int(match.group(1))
                team_id = int(match.group(2))
                self.family.team_manager.recruitList[teamType] = TeamBaseInfo(
                    team_id, teamType,
                    respond.sender.familyId, respond.groupid
                )
                return
            #师徒招募
            match = re.match(r'\[26B2F3,.*<.*>,school,(\d+),(\d+)\].*', msg)
            if match:
                school_type = int(match.group(1))
                school_id = int(match.group(2))
                self.family.master.SetSchoolMsgIdList(school_type, school_id)
                if school_type == 0 and self.family.GetState() == STATE_GS_MASTER_MSG_WAIT:
                    self.family.SetState(STATE_GS_MASTER_SEND_REQ_TO_MASTER)
                return
            
#            #新的组队招募
#            if str(respond).find("ctrl") != -1:
#                match = re.match(r'(\d+\.\d+)\|\|(\d+)\|TEAM#(\d+)#(\d+)', respond.ctrl)
#                if match:
#                    team_member_count = 5
#                    team_id = int(match.group(3))
#                    team_type = int(match.group(4))
#                    
#                    msgMatch = re.match(r'\[26B2F3,\<[^\(]+\(\d+\/(\d+)\)\>\<(\d+)\>', msg)
#                    if msgMatch:
#                        team_member_count = int(msgMatch.group(1))
#                        team_type = int(msgMatch.group(2))
#                    else:
#                        msgMatch = re.match(r'\[26B2F3,\<[^\(]+\(\d+\/(\d+)\)\>', msg)
#                        if msgMatch:
#                            team_member_count = int(msgMatch.group(1))
#                            
#                    self.family.team_manager.recruitList[team_type] = TeamBaseInfo(
#                        team_id, team_type,
#                        respond.sender.familyId,
#                        respond.groupid,
#                        team_member_count
#                    )
#                    return
            if 'RemoveBuffer' in msg and self.family.caseId == CaseManager.JIAZU:
                self.RemoveBuffBlock()
            elif "KinWarBegin" in msg and self.family.GetState() == STATE_GS_KINWAR_WAIT_MSG:   
                self.family.SetState(STATE_GS_KINWAR_MSG)
                return
            elif "CampWar:BeginFight" in msg and self.family.caseId == CaseManager.INSTANCE:   
                self.family.instance.isfight = True
                self.family.SetState(STATE_GS_GOLD_DEER_FIGHT)
                return
            if "KinList" in msg:
                result = re.match(r'KinList:(\d+)', msg)
                if result:
                    self.Do_ApplyJoinKin(int(result.group(1)))
                    self.family.SetState(STATE_GS_PLAYING)
                    return
            if self.family.caseId == CaseManager.REALTIMEVOICE:
                result = re.match(r'RealTimeVoice:(\d+)', msg)
                if result:
                    self.family.chatroom.newRoomId = int(result.group(1))
                    return
#                 Realtime_match1 = re.match(r'RealTimeVoiceQuit:(\d+)', msg)
#                 if Realtime_match1:
#                     if self.family.chatroom.KinRoomId == int(Realtime_match1.group(1)):
#                         self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_MEMBER_QUIT) 
#                     return
            
            if values.linkType == GAIN_PACKET:
                RedPacketid = respond.msgBlocks._values[0].redPacketLink.packetId
                self.RedPacket(RedPacketid)
                return
            if self.family.caseId == CaseManager.VALENTINE:
                if"ValentinesDay" in msg and self.family.GetState() == STATE_GS_VALENTINE_WAIT_MSG:
                    match = re.match(r'ValentinesDay:(\d+)', msg)
                    if match:
                        man_six = int(match.group(1))
                        if man_six+self.family.main_sex == 1:
                            self.family.valentine.familyid = respond.sender.familyId
                            self.family.SetState(STATE_GS_VALENTINE_MSG)
                        return
                elif "ValentinesDayFire" in msg and self.family.GetState() == STATE_GS_VALENTINE_FIRE_WAIT:
                    result = re.match(r'ValentinesDayFire:(\d+):(\d+):(\d+)', msg)
                    if result:
                        self.GM_MoveToPosition(False, int(result.group(1)), int(result.group(2)), int(result.group(3)))
                        self.family.SetState(STATE_GS_VALENTINE_FIRE_BEGIN)
                        return
                elif 'ValentinesDay|Ready' in msg and self.family.GetState() == STATE_GC_TEAM_CREATE_FINISHED:
                    self.family.valentine.familyid = respond.sender.familyId
                    self.TeamInviteReq(respond.sender.familyId)
                    self.family.SetState(STATE_GS_VALENTINE_START)
                    return
                
            if self.family.caseId == CaseManager.CROSSFRIEND:
                if 'CrossReadyOK'  in msg:
                    self.family.crossfriend.familyid = respond.sender.familyId
                    self.family.SetState(STATE_GS_CROSSFRIENG_FIND)
                    return
                elif 'CrossAddOK' in msg:
                    self.family.SetState(STATE_GS_CROSSFRIENG_END)
                    return
            
            if msg == "本队长已到达目标位置" and respond.channel == emChatChannelTeam:
                self.family.gameServerNetPackHandle.TransferToTeammate(respond.sender.familyId)#传送至队长位置
                return
            
            if self.family.caseId in [CaseManager.KILLER]:
                if "Kill:" in msg:
                    self.family.killer.SetRewardPeople(respond.sender.familyId, values.msg[len("Kill:"):len(msg)])
            
            if self.family.GetState() == STATE_GS_OFFLINE_REPLY_WAIT and respond.channel == emChatChannelScene and msg == "OfflineChat_附近":#离线聊天
                self.family.offlinechat.targetId = respond.sender.familyId
                self.family.SetState(STATE_GS_OFFLINE_REPLY)
                return
            
            #限时竞拍
            if self.family.caseId in [CaseManager.DUNGEON, CaseManager.JIAZU]:
                if '竞拍已结束' in msg:
                    self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
                    return
                elif '竞拍开始了，参与本次活动的家族成员可前往拍卖行进行竞拍' in msg:
                    self.AuctionConcernReq()
                match = re.match(r'LimitedAcution_buy:(\d+)', msg)
                if match:
                    self.family.limitedacution.sellneed = int(match.group(1))
                    self.family.SetState(STATE_GS_LIMITED_AUCTION_INFOREP)  
                    return  
            # 家族招募
            if self.family.caseId in [CaseManager.JIAZU, CaseManager.SKILLTEST] and self.family.kinMan.id == 0:
                if self.family.GetState() == STATE_GS_KIN_APPLY_JOIN_WAIT:
                    #普通类型
                    match = re.match(r'Robot:Kin:(\d+):(\W+):(\d+)', msg)
                    if match:
                        kin_id = int(match.group(1))
                        kin_name = match.group(2)
                        gameType = int(match.group(3))
                        #仅申请未申请过的家族
                        if kin_id not in self.family.kinMan.hasAppliedKinIdList:
                            self.family.kinMan.SetInviteMsgDict(kin_id, kin_name, gameType)
                            self.family.SetState(STATE_GS_KIN_APPLY_JOIN)
                        return
                    #分发类型
                    match = re.match(r'Robot:Kin:(\d+):(\d+):(\W+):(\d+)', msg)
                    if match:
                        dist_kin_id = int(match.group(1))
                        kin_id = int(match.group(2))
                        kin_name = match.group(3)
                        gameType = int(match.group(4))
                        #仅申请和自己分发的家族id一样且未申请过的家族
                        if dist_kin_id == self.family.kinMan.distKinId and kin_id not in self.family.kinMan.hasAppliedKinIdList:
                            self.family.kinMan.SetInviteMsgDict(kin_id, kin_name, gameType)
                            self.family.SetState(STATE_GS_KIN_APPLY_JOIN)
                        return
            if "GroveRoomId" in msg:
                grove_math = re.match(r'GroveRoomId:(\d+)', msg)
                if grove_math:
                    roomid = int(grove_math.group(1))
                    if roomid == self.family.grave.GetWeekRoomId() and respond.sender.familyId not in self.family.grave.memberIdList:
                        self.family.grave.SetMemberInfo(respond.sender.familyId)
                                
            msg = respond.msgBlocks._values[0].msg.encode('utf8')
            if msg == '家园互动啦':
                self.family.homeland.AddOtherFamilyId(respond.sender.familyId)
            elif msg == '抱一抱':
                Id2Family = self.family.otherCharacterManager.getSceneId2FamilyidDict()
                familyid2id = dict([(value['familyid'], key) for key, value in Id2Family.items()])
                if (respond.sender.familyId in familyid2id.keys()) and (
                    self.family.GetState() == STATE_GS_DOUBLEACTION_STAY):
                    playid = familyid2id[respond.sender.familyId]
                    self.family.doubleAction.SetHugPlayid(playid)
                    self.family.SetState(STATE_GS_DOUBLEACTION_HUG)
    
            elif msg == '放我下来':
                Id2Family = self.family.otherCharacterManager.getSceneId2FamilyidDict()
                familyid2id = dict([(value['familyid'], key) for key, value in Id2Family.items()])
                playerid = self.family.doubleAction.GetHugPlayid()
                if respond.sender.familyId in familyid2id and familyid2id[respond.sender.familyId] == playerid \
                        and self.family.GetState() == STATE_GS_DOUBLEACTION_HUG_WAIT:
                    self.family.SetState(STATE_GS_DOUBLEACTION_STOPHUG)
            
            elif msg[:24] == "下一个机关柱子为" and msg[24:] != self.family.grave.postTarget:
                self.family.grave.postTarget = msg[24:]
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST)
                    
            elif msg == '切磋一下不':
                if self.family.GetState() == STATE_GS_PK_WAIT:
                    self.family.playerFight.SetMatchPlayid(respond.sender.familyId)
                    self.family.SetState(STATE_GS_PK_ASKPK)
                    
            elif msg == '已移动至师徒任务地点':
                MyMasterId = self.family.master.myMasterId
                MyApprenticeId = self.family.master.myApprenticeId
                if (MyMasterId and respond.sender.familyId == MyMasterId) or (MyApprenticeId and respond.sender.familyId == MyApprenticeId):
                    self.family.master.hasOthersArrival = True
                    if self.family.master.hasArrival:
                        self.family.SetState(STATE_GS_MASTER_DO_TASK)
            elif msg == '已移动至师徒传功地点' and self.family.GetState() == STATE_GS_MASTER_TRAINING_CHAT:
                MyMasterId = self.family.master.myMasterId
                MyApprenticeId = self.family.master.myApprenticeId
                if (MyMasterId and respond.sender.familyId == MyMasterId) or (MyApprenticeId and respond.sender.familyId == MyApprenticeId):
                    self.family.master.hasOthersArrival = True
                    if self.family.master.hasArrival:
                        self.family.SetState(STATE_GS_MASTER_DO_TRAINING_TASK)
            elif msg == '徒弟完成拜师任务':
                MyMasterId = self.family.master.myMasterId
                MyApprenticeId = self.family.master.myApprenticeId
                if (MyMasterId and respond.sender.familyId == MyMasterId) or (MyApprenticeId and respond.sender.familyId == MyApprenticeId):
                    self.family.SetState(STATE_GS_APPRENTICE_TASK_FINISH)                    
            
            #女神节活动
            elif self.family.GetState() == STATE_GS_GODDESS_ACCEPT_WAIT and msg == "送你桃花宝匣好吗":
                self.family.SetState(STATE_GS_GODDESS_TEAM_INVITE_STAY)
                self.TeamMakeWithOtherPlayer(respond.sender.familyId)
                def resetState():
                    if self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_STAY:
                        self.family.SetState(STATE_GS_GODDESS_ACCEPT_WAIT)
                gevent.spawn(resetState)
                return
            #家族争夺
            elif self.family.GetState() == STATE_GS_KIN_WAR_OPEN_WAIT and msg == "骊山一角忽然坍塌，漏出一条幽深的地道，竟是传说中沉寂地底千年的秦始皇陵，各大家族若欲寻宝请速速前往！":
                self.MarkTestCase("TestCase_Kin_MoveToEntrance")
                self.family.SetState(STATE_GS_MOVE_GO)
                return
            
            if self.family.caseId == CaseManager.JIAZU:
                ''' [卩埠笃牍淑]家族的[余谦济]神功盖世，成功击败了<蒙毅>！ '''
                match = re.match(r'\[\W+\]家族的\[\W+\]神功盖世，成功击败了<(\W+)>！', msg)
                if match:
                    self.family.kinMan.UpdateWarGeneralNameList(match.group(1))
                    return
                    
            #分发组队
            if self.family.GetState() == STATE_GS_SKILLTEST_TEAM_INVITE_WAIT:
                match = re.match(r'TeamApplyWait:(\d+)', msg)
                if match:
                    if int(match.group(1)) == self.family.team_manager.myteam.accountId:
                            logging.debug("TeamInviteReq")
                            self.TeamInviteReq(beInvitedFamilyId=respond.sender.familyId)
                    return
                
            # 队长收到队员发来的入队申请 
            if self.family.GetState() == STATE_GC_TEAM_RECRUIT:
                match = re.match(r'TeamApply\|(\d+)\|(\d+)\|(\d+)', msg)
                if match:
                    if int(match.group(1)) == self.family.team_manager.myteam.accountId:
                        if int(match.group(3)) == self.family.groupId: 
                            self.TeamInviteReq(beInvitedFamilyId=respond.sender.familyId)
                        else:
                            self.family.KUAFU = True
                            self.PbCheckJoinTeamInGc_DiffGroupId(int(match.group(3)), respond.sender.familyId)
                    return
            
            # 队员收到队长发来的CheckIn或者队伍Ready的信息
            if self.family.GetState() == STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN:
                if msg == "TeamBeginCheckIn":
                    self.ChatRequestByMsg(msg="TeamCheckIn|%d" % self.family.familyId,
                                      channel=self.family.team_manager.myteam.leaderFamilyId)
                # 所有队员准备完毕，收到队长发送的Ready消息，回复队长,并设置当前为准备完毕
                elif msg == "TeamReadyReq":
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
                    self.ChatRequestByMsg(msg="TeamReadyOK",
                                      channel=self.family.team_manager.myteam.leaderFamilyId)
#                    self.MarkTestCase("TestCase_Battle_TeamOK_Member")
            
            # 队长收到CheckIn报数
            if self.family.GetState() is STATE_GC_TEAM_RECRUIT_CHECKIN:
                match = re.match(r'TeamCheckIn\|(\d+)', msg)
                if match:
                    member_family_id = int(match.group(1))
                    if  member_family_id in self.family.team_manager.myteam.memberList \
                    and member_family_id not in self.family.team_manager.myteam.memberCheckList:
                        self.family.team_manager.myteam.memberCheckList.append(member_family_id)
                        if self.family.GetState() == STATE_GC_TEAM_RECRUIT_CHECKIN and len(self.family.team_manager.myteam.memberCheckList) + 1 == self.family.team_manager.myteam.MemberCount():
                            self.family.team_manager.myteam.memberCheckList = []
                            self.family.SetState(STATE_GC_TEAM_RECRUIT_CHECKIN_DONE)
                return
            
            if self.family.GetState() == STATE_GC_TEAM_RECRUIT_CHECKIN_DONE:
                if msg == "TeamReadyOK" and self.family.team_manager.myteam.IsLeader(self.family.familyId):
                    if  respond.sender.familyId in self.family.team_manager.myteam.memberList \
                    and respond.sender.familyId not in self.family.team_manager.myteam.memberCheckList:
                        self.family.team_manager.myteam.memberCheckList.append(respond.sender.familyId)
                        if len(self.family.team_manager.myteam.memberCheckList) + 1 == self.family.team_manager.myteam.MemberCount():
                            self.family.team_manager.myteam.memberCheckList = []
                            self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)                
                return
        
    #接收离线聊天消息
    def SyncOfflineMsgReq(self):
        request = SyncOfflineMsgReq()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SYNC_OFFLINE_MSG_REQ, request)
    
    def On_SyncOfflineMsgRsp(self, respond):
        logging.debug("On_SyncOfflineMsgRsp respond = %s" % respond)
        for msg in respond.msgList:
            if msg.channel == self.family.familyId and msg.msg.encode('utf8')[:26] == "OfflineChat_私聊[心动]":
                self.MarkTestCase("TestCase_OfflineChat_GetOfflineMsg")
        self.family.SetState(STATE_GS_OFFLINE_RELOGIN)
        
    def On_SyncCharacterShouting(self, respond):
        chat = respond.chat.encode("utf8")
        # 请求切磋者
        if self.family.GetState() == STATE_GS_ASKPK_WAIT:
            # 重新进入等待切磋他人
            if respond.chat == u"对方没有接受您的切磋邀请！":
                self.family.SetState(STATE_GS_PK_WAIT)
#                 gevent.sleep(20)
            elif respond.chat == u"对方拒绝了您的切磋邀请!":
                self.family.SetState(STATE_GS_PK_WAIT)
#                 gevent.sleep(30)
            elif respond.chat == u"你们双方距离太远，无法开始切磋！":
                self.family.SetState(STATE_GS_PK_WAIT)
#                 gevent.sleep(30)
            elif respond.chat == u"您发起切磋太频繁，请稍后再试!":
                self.family.SetState(STATE_GS_PK_WAIT)
#                 gevent.sleep(10)
#             else:
#                 print respond.chat
                
        # 被请求切磋者
        elif self.family.GetState() == STATE_GS_PK_AFTER_ANSWERPK:
            if respond.chat == u"你们双方距离太远，无法开始切磋！":
                self.family.SetState(STATE_GS_PK_TALK)
#             else:
#                 print respond.chat
                
#                 gevent.sleep(30)
            
        elif self.family.GetState() == STATE_GS_XIAOMIJING_WAIT and ("点击宝箱领取奖励！" in chat or "宝箱已掉落在队伍附近，请点击领取奖励！" in chat):
            if self.family.xiaomijing.boxMsg:
                self.family.SetState(STATE_GS_XIAOMIJING_OPEN_BOX)
        
    # 获取真气
    def ZazenReq(self):
        request = ZazenReq()
        request.type = 0
        request.free = True
        if Config.is_illegaltest():
            request.type = Rand.bound_uint32(ZAZEN_TYPE_FREE, ZAZEN_TYPE_COUNT)
        self.SendProtocol(CLI_TO_GS_ZAZEN_REQ, request)

    # 获取真气的结果
    def On_SyncMeridian(self, respond):
        self.family.energy = respond.meridian.energy
        self.family.bag.SetMerdianSyncData(respond.meridian.meridian)

    # 客户端先发起心跳
    def PingServer(self):
        while self.isReady and self.gsConnect and self.gsConnect.connected:
            request = PingServer()
            request.clientTick = int(time.time())
            # request.clientTick = self.family.serverTime.GetTick()
            try: # 切换GS的时候可能会有问题
                self.SendProtocol(CLI_TO_GS_PING, request)
            except:
                pass
            gevent.sleep(8)

    def On_ReplyPingClient(self, respond):
        self.family.serverTime.UpdateServerTick(respond.serverTick, respond.unixMSec)
        pass
    
    def RedPacket(self, packetIds):
        self.family.redpacket.recvPackIds[packetIds] = True
        self.QueryRedPacketReq(packetIds)

    def QueryRedPacketReq(self, packetIds):
        request = QueryRedPacketReq()
        request.packetIds.extend([packetIds])
        request.dataVersions.extend([0])
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_QUERY_RED_PACKET, request)
        
    def On_SyncRedPacketRsp(self, respond):
        logging.debug("On_SyncRedPacketRsp respond=%s" % respond)
        if self.family.redpacket.recvPackIds.has_key(respond.dbInfos._values[0].packetId):
            if respond.dbInfos._values[0].currentMoney != 0:            
                self.CallScript("PlayerCmd", "GainRedPacket", str(respond.dbInfos._values[0].packetId))
            del self.family.redpacket.recvPackIds[respond.dbInfos._values[0].packetId]        

    def QueryRedPacketHistoryReq(self):
        request = QueryRedPacketHistoryReq()
        request.dataVersion = 0
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_QUERY_RED_PACKET_HISTORY, request)
    
    def On_SyncRedPacketHistoryRsp(self, respond):
        logging.debug("On_SyncRedPacketHistoryRsp respond=%s" % respond)
        if self.family.GetState() == STATE_GS_REDPACK_HISTORY_WAIT:
            self.family.SetState(STATE_GS_REDPACK_HISTORY_FINISHED)
        
    # 离开游戏
    def LeaveGame(self):
        if self.isLoginGame:
            self.isLoginGame = False
            if self.gsConnect and  self.gsConnect.connected and self.isReady:
                request = LeaveGame()
                self.SendProtocol(CLI_TO_GS_LEAVE_GAME, request)
            else:
                asyncresult_manager.fire(self.family, "LeaveGame", True)
        self.isReady = False

    # 离开游戏的结果
    def On_NotifyLogoutGame(self, respond):
        self.isLoginGame = False
        self.isReady = False
        logging.debug("On_NotifyLogoutGame respond=%s; username=%s; familyId = %s" %(respond, self.family.userName, self.family.familyId))
        if respond.flag == LOGOUT_FLAG_SWITCH_SERVER:  # 跨服
            self.gsChanged = True
            self.GSUninit()
            self.gsAddress = (
            str(respond.switch_server_param.game_server_ip), respond.switch_server_param.game_server_port)
            self.family.encryptKey = respond.switch_server_param.encryptKey
            self.sceneTemplateId = respond.switch_server_param.scene_template_id
            self.ConnectGameServer()
            self.MarkTestCase("KUAFU")
            logging.debug('跨服')
        else:
            asyncresult_manager.fire(self.family, "LeaveGame", True)

    # --- 移动 ---
    def _distance(self, x1, y1, x2, y2):
        return math.hypot((x1 - x2), (y1 - y2))

    # 自动寻路31
        
    def PlayerAutoPath(self, dstX, dstY, dstZ = 0):
        self.family.SetState(STATE_GS_MOVE_AUTO_MOVING)
        while self.family.characterCur.posX is None:
            self.ForceSyncPlayer()
            gevent.sleep(5)
        request = PlayerAutoPath()
        request.tick = self.family.serverTime.GetTick()
        request.srcPosX = self.family.characterCur.posX
        request.srcPosY = self.family.characterCur.posH
        request.srcPosZ = self.family.characterCur.posY
        request.dstPosX = dstX
        request.dstPosY = dstZ
        request.dstPosZ = dstY
        self.autoMoveDstPost = (dstX, dstY, dstZ)
        if self._distance(request.srcPosX, request.srcPosZ, request.dstPosX, request.dstPosZ) < 3:
            self.family.SetState(STATE_GS_MOVE_ARRIVAL)
            return
        if Config.is_illegaltest():
            request.dstPosY = Rand.bound_int32()
            request.dstPosY = Rand.bound_int32()
        self.SendProtocol(CLI_TO_GS_AUTO_PATH, request)
        # 大概计算一个需要移动到目标点的时间,默认移动速度是4m/s，8s后开始跑，跑动速度为9m/s
        speed = self.family.characterCur.speed if self.family.characterCur.speed else 4.0
        distance = math.sqrt(math.pow(request.srcPosX - request.dstPosX, 2)+math.pow(request.srcPosZ - request.dstPosZ,2))
        waitTime = distance / speed if distance / speed < 8 else (distance - 8 * speed) / 9 + 8
        gevent.spawn_later(waitTime, self.ForceSyncPlayer)

    def ForceSyncPlayer(self):
        if self.isLoginGame:
            self.CallScriptGmDoCommand("local player = me:GetActivePlayer(); player:Sync();")


    def Do_PlayerMoveTo(self, posX, posY):
        speed = self.family.characterCur.GetCharacterSpeed()
        distance = self._distance(self.family.characterCur.posX, self.family.characterCur.posY, posX, posY)
        t = distance / speed
        self.Do_PlayerMove(posX, posY)
        timer = threading.Timer(t, self.Do_PlayerStop)
        timer.start()
        self.family.characterCur.posX = posX
        self.family.characterCur.posY = posY

    # 开始移动
    def Do_PlayerMove(self, posX, posY):
        CurrentPosX = self.family.characterCur.posX
        CurrentPosY = self.family.characterCur.posY
        DifferenceX = math.fabs(CurrentPosX - posX)
        DifferenceY = math.fabs(CurrentPosY - posY)

        if DifferenceX == 0:
            if CurrentPosY - posY < 0:
                dir = 0
            else:
                dir = 180
        elif DifferenceY == 0:
            if CurrentPosX - posX < 0:
                dir = 90
            else:
                dir = 270
        else:
            if posX > CurrentPosX:
                if posY > CurrentPosY:
                    dir = math.atan(DifferenceX / DifferenceY) / math.pi * 180
                else:
                    dir = math.atan(DifferenceY / DifferenceX) / math.pi * 180 + 90
            else:
                if posY < CurrentPosY:
                    dir = math.atan(DifferenceX / DifferenceY) / math.pi * 180 + 180
                else:
                    dir = math.atan(DifferenceY / DifferenceX) / math.pi * 180 + 270

        request = MovePack()
        request.tick = self.family.serverTime.GetTick()
        request.dir = dir
        request.posX = posX
        request.posY = 0
        request.posZ = posY
        logging.debug("MovePack request = %s" % request)
        if Config.is_illegaltest():
            request.dstPosY = Rand.bound_int32()
            request.dstPosY = Rand.bound_int32()
        self.SendProtocol(CLI_TO_GS_PLAYER_MOVE, request)
        # self.family.SetState(STATE_GS_MOVE_HALT)

    def Do_PlayerTurn(self, posX, posY, dir=10):
        request = MovePack()
        request.tick = self.family.serverTime.GetTick()
        request.dir = dir
        request.posX = posX
        request.posY = 0
        request.posZ = posY
        self.SendProtocol(CLI_TO_GS_PLAYER_TURN, request)

    # 停止移动
    def Do_PlayerStop(self):
        if self.gsConnect:
            request = MovePack()
            request.tick = self.family.serverTime.GetTick()
            request.dir = 0
            request.posX = self.family.characterCur.posX
            request.posY = self.family.characterCur.posH
            request.posZ = self.family.characterCur.posY
            self.SendProtocol(CLI_TO_GS_PLAYER_STOP, request)
            self.family.SetState(STATE_GS_MOVE_ARRIVAL)

    def PickUpDropInfo(self, id):
        ID = []
        ID.append(id)
        request = PickUpDropInfo()
        request.id.extend(ID)
        self.SendProtocol(CLI_TO_GS_PICK_DROP_OBJECT, request)

    # --- 主线 ---
    # 请求完成对话NPC任务
#     def Do_ApplyTalkToNpc(self, npcId, taskId):
#         request = ApplyTalkToNpc()
#         request.taskId = taskId
#         request.npcId = npcId
#         self.SendProtocol(CLI_TO_GS_APPLY_TALKTO_NPC, request)
    
    def Do_ApplySetTaskValue(self, condType, condExtId, taskValue, withTeammate):
        request=ApplySetTaskValue ()
        request.condType=condType
        request.condExtId=condExtId
        request.taskValue=taskValue
        request.withTeammate=withTeammate
        self.gsConnect.send_protocol(CLI_TO_GS_SET_TASK_VALUE, request)
        
    def Do_ApplySetTaskStepValue(self, taskId, stepId, extid, value):
        request=ApplySetTaskStepValue()
        request.taskId=taskId
        request.stepId=stepId
        request.extId= extid
        request.value= value
        self.gsConnect.send_protocol(CLI_TO_GS_SET_TASK_STEP_VALUE, request)
    
#     def Do_ApplyAddTaskValue(self, task_cond_type, task_value, cond_ext_id):
#         request = ApplyAddTaskValue()
#         request.taskCondType = task_cond_type
#         request.taskValue = task_value
#         request.condExtId = cond_ext_id
#         self.SendProtocol(CLI_TO_GS_ADD_TASK_VALUE, request)
    
    def Do_AcceptTask(self, taskid = 0):
        TASKID = []
        TASKID.append(taskid)
        request = ApplyAcceptTask()
        request.taskId.extend(TASKID)
        if Config.is_illegaltest():
            request.taskId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_ACCEPT_TASK, request)

    def On_SyncTaskAward(self, respond):
        self.family.maintaskMan.Update(respond)
        if self.family.GetState() == STATE_GS_MAIN_TASK_WAIT:
            self.family.SetState(STATE_GS_MAIN_TASK_SYNC)

    # 请求完成任务
    def Do_ApplyFinishMainTask(self, TASKID = None):
        request = ApplyFinishTask()
        request.taskId.extend(TASKID)
        if Config.is_illegaltest():
            request.taskId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_FINISH_TASK, request)
        self.maintaskId += 1

    def On_SyncRemoveTask(self, respond):
        if self.family.state == STATE_GS_MAIN_TASK_WAIT:
            self.family.SetState(STATE_GS_MAIN_TASK_FINISHED)

    # 同步日常任务列表
    def On_SyncFamilyTaskList(self, respond):
        pass

    # --- 家族 ---    
    # 家族列表
    def Do_GetKinList(self):
        request = GetKinList()
        self.SendProtocol(CLI_TO_GS_KIN_LIST, request)

    def On_SyncKinListResult(self, respond):
        self.family.kinMan.UpdateKinList(respond.kinList)
        self.family.SetState(STATE_GS_KIN_LIST_RESULT)

    # 创建家族
    def Do_CreateKin(self, name, iconId=random.randint(3, 8)):
        request = CreateKin()
        request.kinName = name
        request.iconId = iconId
        if Config.is_illegaltest():
            request.kinName = generate_chinese(Rand.bound_uint32(3, 6))
            request.iconId = Rand.bound_uint32(0, 6)
        self.SendProtocol(CLI_TO_GS_CREATE_KIN, request)
        logging.debug("Do_CreateKin")

    def On_SyncCreateKinResult(self, respond):
        logging.debug("On_SyncCreateKinResult %s" % respond)
        if respond.result == respond.SUCCESS:
            self.ChatRequestByMsg(u'Chat_家族[得意]创建', emChatChannelWorld)
            self.MarkTestCase("TestCase_Kin_CreateKin")
            self.family.SetState(STATE_GS_KIN_UPGRADE)
#            gevent.sleep(5)
            self.ChatRoomEnterRoom(self.family.kinMan.id, ChatRoom_Kin)#族长加入家族频道
        else:
            logging.warning("On_SyncCreateKinResult ErrorCode = %s" % str(respond.result))
            self.MarkTestCase("TestCase_Kin_CreateKin", isSuccess=False, exception="respond.result=%s" % respond.result)
            self.family.behavior = Behavior.END


    # 申请加入家族
    def Do_ApplyJoinKin(self, kinId):
        request = ApplyJoinKin()
        request.kinId = kinId
        if Config.is_illegaltest():
            request.kinId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_APPLY_JOIN_KIN, request)

    def On_SyncJoinKinResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
            #仅申请成功，不一定会被批准
            if respond.kinId not in self.family.kinMan.hasAppliedKinIdList:
                self.family.kinMan.hasAppliedKinIdList.append(respond.kinId)
        else:
            if respond.result not in [KIN_HAS_APPLIED, KIN_APPLYER_FULL]:
                logging.warning("On_SyncJoinKinResult ErrorCode = %s" % str(respond.result))
            self.family.SetState(STATE_GS_KIN_APPLY_JOIN)

    # 退出家族
    def Do_ApplyQuitKin(self):
        request = ApplyQuitKin()
        self.SendProtocol(CLI_TO_GS_QUIT_KIN, request)

    def On_SyncQuitKinResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
#             logging.debug('暂停查看')
            # gevent.sleep(10)
#             self.family.kinMan.id = 0
#             self.family.behavior = Behavior.END#家族退出后各种状态没有重置，现直接退出游戏
            self.family.SetState(STATE_GS_KIN_LEAVE_FINISH)
        else:
            logging.warning("On_SyncQuitKinResult ErrorCode = %s" % str(respond.result))

    # 解散家族
    def Do_ApplyDismissKin(self):
        request = ApplyDismissKin()
        request.type = 1
        if Config.is_illegaltest():
            request.type = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_DISMISS_KIN, request)

    def On_SyncDismissKinResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
#             gevent.sleep(10)
#             self.family.behavior = Behavior.END#家族退出后各种状态没有重置，现直接退出游戏
            self.family.SetState(STATE_GS_KIN_LEAVE_FINISH)
        else:
            logging.warning("On_SyncDismissKinResult ErrorCode = %s" % str(respond.result))

    # 查找家族
    def Do_ApplyLookUpKin(self, name):
        request = ApplyLookUpKin()
        request.type = request.NAME
        request.kinName = name
        if Config.is_illegaltest():
            request.type = random.choice([request.ID, request.NAME])
            request.kinName = generate_chinese(Rand.bound_uint32(1, 6))
        self.SendProtocol(CLI_TO_GS_LOOKUP_KIN, request)

    def On_SyncKinLookupResult(self, respond):
        logging.debug("On_SyncKinLookupResult respond = %s" % respond)
        # 不管搜索的家族是否存在，都会返回'SUCCEED'
        
        if respond.result == ErrorCode.Value('SUCCEED'):
            self.family.SetState(STATE_GS_KIN_APPLY_JOIN_WAIT)
        else:
            logging.debug("On_SyncKinLookupResult ErrorCode = %s" % str(respond.result))
            
    def On_SyncKinBaseData(self,respond):
        logging.debug("On_SyncKinBaseData respond = %s" % respond)
        
    # 踢人
    def Do_ApplyKinKick(self, kickId):
        request = ApplyKinKick()
        request.kickId = kickId
        if Config.is_illegaltest():
            request.kickId = 0
        self.SendProtocol(CLI_TO_GS_KIN_KICK, request)

    def On_SyncKinKickResult(self, respond):
        self.family.SetState(STATE_GS_KIN_DISMISS)

    # 家族审批
    def Do_ApplyKinApprove(self, beApproveId, is_pass):
        request = ApplyKinApprove()
        request.beApproveId = beApproveId
        setattr(request, "pass", is_pass)
        self.SendProtocol(CLI_TO_GS_KIN_APPROVE, request)

    # 招募设定
    def Do_KinApplySetting(self, openApply=True, needApprove=False, joinNeedLevel=1, applyNotice=""):
        request = KinApplySetting()
        request.openApply = openApply
        request.needApprove = needApprove
        request.joinNeedLevel = joinNeedLevel
        request.applyNotice = applyNotice
        if Config.is_illegaltest():
            request.joinNeedLevel = Rand.bound_uint32()
            request.applyNotice = Rand.rand_string(random.choice([0, 4096]))
        self.SendProtocol(CLI_TO_GS_KIN_APPLY_SETTING, request)

    def On_SyncKinSettingResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
            self.family.SetState(STATE_GS_KIN_SET_NOTICE)
        else:
            logging.debug("On_SyncKinSettingResult ErrorCode = %s" % str(respond.result))

    # 设置官职
    def Do_ApplyKinSetPost(self, postFamilyId, post):
        """
        Common.ComDefine_pb2.KIN_POST_COMMON => 3 成员
        Common.ComDefine_pb2.KIN_POST_VICE_LEADER => 2 副族长
        Common.ComDefine_pb2.KIN_JOIN_TIME_NOT_ENOUGH => 1 族长
        """
        request = ApplyKinSetPost()
        request.postFamilyId = postFamilyId
        request.post = post
        if Config.is_illegaltest():
            request.post = Rand.bound_uint32(KIN_POST_INVALID, KIN_POST_MAX)
            request.postFamilyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_KIN_SET_POST, request)

    def On_SyncKinSetPostResult(self, respond):
#         print respond
        if respond.result == ErrorCode.Value('SUCCEED'):
            if self.family.GetState() == STATE_GS_KIN_POST_VICE_LEADER_WAIT:
                self.family.SetState(STATE_GS_KIN_POST_COMMON)  # 撤职
            else:
#                gevent.sleep(5)
                self.family.SetState(STATE_GS_KIN_DISMISS)  # 解散
        else:
            self.family.SetState(STATE_GS_KIN_DISMISS)  # 解散
            logging.debug("On_SyncKinSetPostResult ErrorCode = %s" % str(respond.result))

    # 设置公告
    def Do_KinSetNotice(self, notice=u"公告内容未设置"):
        request = KinSetNotice()
        request.notice = notice
        if Config.is_illegaltest():
            request.notice = generate_chinese(random.choice[0, 8192])
        self.SendProtocol(CLI_TO_GS_KIN_SET_NOTICE, request)

    def On_SyncKinSetNoticeResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
            self.family.SetState(STATE_GS_KIN_RECRUIT)
        else:
            logging.debug("On_SyncKinSetNoticeResult ErrorCode = %s" % str(respond.result))

    # 申请人员变更
    def On_SyncKinApplyerChange(self, respond):
        if respond.type == respond.Add:
            #将申请加入家族的人加到列表
            if str(respond).find("applyer") != -1:
                self.family.kinMan.SetApplyerList(respond.applyer.familyId)

    # 成员变更
    def On_SyncKinMemberChange(self, respond):
        '''
            Add = 1;
            Mod = 2;
            Del = 3;
        '''
        logging.debug('SyncKinMemberChange : %s, %s' % (respond, respond.type))
        if respond.type == respond.Del:
            if respond.familyId == self.familyId and self.family.kinMan.kinKick:  # 被踢的时候退出
                self.family.SetState(STATE_GS_KIN_LEAVE_FINISH)
                return
            logging.debug('SyncKinMemberChange : %s, %s' % (respond, respond.type))
            self.family.kinMan.DelKinMember(respond.familyId)
            if self.family.kinMan.GetLeader():#族长
                self.family.SetState(STATE_GS_KIN_POST_VICE_LEADER)#这里改为升级副族长状态
        else:
            if self.family.kinMan.GetLeader() and respond.type == respond.Add:#邀请新加入的族员进入家族频道
                self.ChatRoomInviteMember(self.family.chatroom.roomId, [respond.familyId])
            self.family.kinMan.SetKinMember(respond.familyId, respond.member)

    # 同步家族信息
    def On_SyncKinData(self, respond):
        logging.debug("On_SyncKinData respond=%s" % respond)
        
        self.family.kinMan.id = respond.kinData.basedata.id
        self.family.kinMan.name = respond.kinData.basedata.name
        for member in respond.kinData.memberdata.members:
            self.family.kinMan.SetKinMember(member.familyId, member)
            if member.familyId == self.familyId:
                if member.post == KinLeader:
                    self.family.kinMan.SetLeader(True)
                else:
                    self.family.kinMan.SetLeader(False)
                    
        if self.family.GetState() in [STATE_GS_KIN_WAIT_APPROVE, STATE_GS_KIN_APPLY_JOIN_WAIT, STATE_GS_KIN_APPLY_JOIN]:
            self.family.kinMan.UpdateKinGameType()#成功加入后将GameType更新到kin_man
            self.ChatRequestByMsg(u'Chat_家族[礼物]新人加入', emChatChannelKin)
            self.MarkTestCase("TestCase_Kin_JoinKin")
            self.family.SetState(STATE_GS_KIN_SIGN)  # 签到
    
    #家族许愿
    def Do_KinBuyPray(self, count=20):
        for i in range(count):
            self.CallScript("PlayerCmd", "BuyPray", i+1)
            gevent.sleep(1)
    
    # 家族签到
    def Do_KinSign(self, typeid=random.randint(0, 2), msg='KinSign Success'):
        '''
        KIN_SIGN_LOW = 0
        KIN_SIGN_MIDDLE = 1
        KIN_SIGN_HIGH = 2
        '''
        request = KinSign()
        request.type = typeid
        request.msg = msg
        if Config.is_illegaltest():
            # KIN_SIGN_MESSAGE_LENGTH = 64
            request.msg = generate_chinese(Rand.bound_uint32(0, 65))
        self.SendProtocol(CLI_TO_GS_KIN_SIGN, request)

    def On_SyncKinSignResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
            # 家族商店购买
            self.family.SetState(STATE_GS_KIN_SHOP)
        else:
            logging.debug("On_SyncKinSignResult ErrorCode = %s" % str(respond.result))

    # 家族技能使用
    def Do_KinSkillUse(self, skillId=1):
        request = KinSkillUse()
        request.skillId = skillId
        if Config.is_illegaltest():
            request.skill_id = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_KIN_SKILL_USE, request)

    def On_SyncKinSkillUseResult(self, respond):
        logging.debug('SyncKinSkillUse_ ： %s' % respond)
        if respond.result == ErrorCode.Value('SUCCEED'):
            logging.debug('On_SyncKinSkillUseResult Success')
            if self.family.kinMan.GetLeader():
                self.family.SetState(STATE_GS_KIN_SKILL_UPGRADE)  # 升级家族技能
            else:
                self.family.SetState(STATE_GS_KIN_ADD_FIREND)
        else:
            logging.debug("On_SyncKinSkillUseResult ErrorCode = %s" % str(respond.result))
            self.family.SetState(STATE_GS_KIN_ADD_FIREND)
    
    #家族升级
    def Do_KinUpgrade(self):
        request = KinUpgrade()
        self.SendProtocol(CLI_TO_GS_KIN_UPGRADE, request)

    # 家族技能升级
    def Do_KinSkillUpgrade(self, skill_id=1, attr=13):
        respond = KinSkillUpgrade()
        respond.skillId = skill_id
        respond.attr = attr
        if Config.is_illegaltest():
            respond.skillId = Rand.rand_uint32()
            respond.attr = Rand.rand_uint32()
        self.SendProtocol(CLI_TO_GS_KIN_SKILL_UPGRADE, respond)

    def On_SyncKinSkillUpgradeResult(self, respond):
        if respond.result == ErrorCode.Value('SUCCEED'):
            self.family.SetState(STATE_GS_KIN_ADD_FIREND)
        else:
            self.MarkTestCase("TestCase_Kin_SyncKinSkillUpgradeResult", isSuccess=False, exception="ErrorCode = %s" % str(respond.result))
            self.family.SetState(STATE_GS_KIN_ADD_FIREND)

    # 818家族商店刷新
    def Do_KinShopApply(self):
        self.SendProtocol(CLI_TO_GS_KIN_SHOP_APPLY)

    def Do_ApplyGoodsList(self, shopid=1, cursequence=1):
        request = ApplyShopGoodsList()
        request.shopId = shopid
        request.curSequence = cursequence
        self.SendProtocol(CLI_TO_GS_APPLY_GOODS_LIST, request)

    def On_SyncShopGoodsList(self, respond):
        self.family.shops[respond.shopId] = Shop(respond)
        self.family.notifyState.set_state(NotifyState.STATE_GS_SYNC_SHOP_GOODS_LIST)

        if self.family.GetState() == STATE_GS_KIN_WAIT and respond.shopId in SHOPID_KIN:
            self.family.shopid_kin = respond.shopId
            self.family.SetState(STATE_GS_KIN_SHOP_BUY)

    # 家族商店购买
    def Do_KinShopBuy(self, good_index=-1, buy_count=1, goods_sequence=-1):
        request = ApplyBuyShopItem()
        if (good_index == -1 or goods_sequence == -1):
            assert self.family.shops[self.family.shopid_kin]

        request.shopId = self.family.shopid_kin
        if good_index == -1:
            request.goodIndex = self.family.shops.GetRandomGoodIndex()
        else:
            request.goodIndex = good_index
        request.buyCount = buy_count
        if goods_sequence == -1:
            request.goodsSequence = self.family.goods_sequence
        else:
            request.goodsSequence = goods_sequence
        self.SendProtocol(CLI_TO_GS_BUY_SHOP_ITEM, request)

    # 进入家族关卡
    def EnterKinDailyGame(self):
        self.CallScript("PlayerCmd", "EnterKinDailyGame", 1)

    # 家族关卡玩家死亡复活: 1->元宝复活 2->出生点复活
    def KinDailyRevival(self, param_type=2):
        self.CallScript("PlayerCmd", "KinDailyRevival", param_type)
 
    # 进入家族周末关卡
    def EnterKinWeekGame(self):
        self.CallScript('GraveCmd', 'ApplyJoinGraveGame')
    
    #进入家族领地
    def EnterKinLand(self):
        self.CallScript("PlayerCmd", "EnterKinLand")
    
    #周末关卡信息
    def On_SyncKinWeekGameInfo(self, respond):
        logging.debug('On_SyncKinWeekGameInfo %s' % respond)
        self.family.kinMan.UpdateWeekRoomPlayerCount(respond.roomPlayerCount)
    
    #家族领地信息
    def On_SyncKinLandInfo(self, respond):
        '''
            KIN_LAND_COMMON = 0;
            KIN_LAND_FEAST = 1;
            KIN_LAND_DEFEND = 2;
        '''
        logging.debug("On_SyncKinLandInfo respond = %s" % respond)
        self.family.kinMan.SetKinGameIsOpen(respond.type)
    
    #家族盛宴上交食材
    def KinFeastCommitFood(self, g, d, p, l):
        self.CallScript("PlayerCmd", "CommitFood", g, d, p, l)
    
    #家族盛宴享用食物
    def KinFeastGetDish(self):
        self.CallScript("PlayerCmd", "GetDish")
    
    #家族盛宴饮酒
    def KinFeastAskDrink(self, DrinkType):
        '''
            1 : 普通米酒
            2 : 陈年杜康
        '''
        self.CallScript("PlayerCmd", "AskDrink", DrinkType)
    
    #---家族争夺---
    #打开族员报名面板
    def KinWarOpenSignUpUI(self):
        self.CallScript("KinWarCmd", "OpenSignUpUI")

    #关闭族员报名面板
    def KinWarOnCloseSignUpUI(self):
        self.CallScript("KinWarCmd", "OnCloseSignUpUI")
        
    #调整族员是否参加PVP
    def KinWarApplyChangePvpType(self, familyId, type):
        '''
            0 : PVE
            1 : PVP
        '''
        self.CallScript("KinWarCmd", "ApplyChangePvpType", familyId, type)
    
    #报名参加冲锋
    def KinWarApplyAttendPvp(self):
        self.CallScript("KinWarCmd", "ApplyAttendPvp")
    
    #添加排行榜数据
    def AddKinWarRankMonthScore(self, score):
        self.CallScriptGcGmDoCommand("Kin.AddKinWarRankMonthScore(%d, %d);" % (self.family.kinMan.id, score), self.family.familyId)
    
    #打开计分面板
    def KinWarOpenRankUI(self, rankType):
        self.CallScript("KinWarCmd", "OpenRankUI", rankType)
    
    #开启家族战
    def StartKinWar(self):
        self.CallScriptGmDoCommand("ZoneServerExcute({\'KinWar:ExecuteScheduleStep_ZS\', 1, true})")
    
    #开始报名
    def KinWarStartSignUp(self):
        self.CallScriptGmDoCommand("KinWar:TestEnterPve()")
    
    #结束家族战报名
    def CloseKinWarSignUp(self):
        self.CallScriptGmDoCommand("ZoneServerExcute({\'KinWar:ExecuteScheduleStep_ZS\', 2})")
    
    #家族PVP时间截止
    def KinWarPVPEnd(self):
        self.CallScriptGmDoCommand("ZoneServerExcute({\'KinWar:ExecuteScheduleStep_ZS\', 5})")
    
    #修改家族参与人数为1人
    def KinWarChangeNumber(self):
        self.CallScriptGmDoCommand("ZoneServerExcute({\'GM:DoCommand\', \'KinWar.MIN_SIGNUP_ONLINE_COUNT = 1\'})")
    
    #关闭家族战
    def CloseKinWar(self):
        self.CallScriptGmDoCommand("ZoneServerExcute({\'KinWar:ExecuteScheduleStep_ZS\', 6})")
    
    # 创建队伍(单人)
    def TeamCreateReq(self, team_type=TEAM_TYPE_FREE, member=FAMILY_MEMBER_TYPE_MAIN):
        request = TeamCreateReq()
        request.teamType = team_type
        self.SendProtocol(CLI_TO_GS_TEAM_CREATE, request)

    def TeamListQuery(self, team_type=TEAM_TYPE_FREE):
        request = TeamListQuery()
        request.teamType = team_type
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_QUERY_TEAM_LIST, request)

    def On_TeamListResult(self, respond):
#        for team in respond.teamList:
#            if not team.isFull and team.isLeader:
#                self.family.team_manager.recruitList[team.teamType] = TeamBaseInfo(
#                    team.teamId, team.teamType,
#                    team.familyId, 0
#                )
#                break
        self.family.SetState(STATE_GC_TEAM_START)

    # 自动组队，完成招募或加入队伍
    def _auto_team(self):
        if self.family.team_manager.myteam.IsInTeam():
            member_count = self.family.team_manager.myteam.MemberCount()
            mumber_limit = self.family.team_manager.myteam.GetTeamLimit()
            logging.debug("team member = %d/%d" % (member_count, mumber_limit))
            if self.family.team_manager.myteam.IsLeader(self.family.familyId):
                if self.family.GetState() in [STATE_GC_TEAM_CREATE_WAIT, STATE_GC_TEAM_RECRUIT,
                                          STATE_GS_MAIN_TASK_CREATE_TEAM_WAIT,
                                          STATE_GS_GRAVEDIGGER_CREATE_TEAM_WAIT]:
                    if member_count < mumber_limit:
                        # 队员不够，继续招募
                        self.family.SetState(STATE_GC_TEAM_RECRUIT)
                    elif self.family.team_manager.myteam.teamCreateType == TeamCreateType.FIXED:
                        self.family.SetState(STATE_GC_TEAM_RECRUIT_CHECKIN)
                    elif self.family.team_manager.myteam.teamCreateType == TeamCreateType.RANDOM:
                        self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)
            elif self.family.GetState() == STATE_GC_TEAM_APPLY:
                if self.family.team_manager.myteam.teamCreateType == TeamCreateType.FIXED:
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_CHECKIN)
                elif self.family.team_manager.myteam.teamCreateType == TeamCreateType.RANDOM:
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_WAIT_OTHERS)
            
            if self.family.GetState() == STATE_GC_TEAM_RECRUIT_WAIT_OTHERS:
                if member_count >= mumber_limit:
                    self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)

    # 组队信息同步
    def On_TeamInfoSync(self, respond):
        # 无论有没有加入队伍，登陆后都会同步一下队伍信息给客户端
        logging.debug("familyId = %d, On_TeamInfoSync respond = %s" % (self.family.familyId, respond))
        state = self.family.GetState()
        self.family.team_manager.myteam.Update(respond)
        
        if self.family.GetState() == STATE_GS_SKILLTEST_TEAM_INVITE_WAIT and self.family.team_manager.myteam.MemberCount() == 5:
            self.family.SetState(STATE_GS_SKILLTEST_TRANSFER_MAP)
            return
        for member in respond.memberList:
            if member.familyId == self.family.familyId:
                self.family.characterCur.posX = member.posX
                self.family.characterCur.posY = member.posY
                if self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_STAY and self.family.team_manager.myteam.MemberCount() > 1:
                    self.family.SetState(STATE_GS_GODDESS_MOVE)#移动至礼物兑换NPC
                elif self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_WAIT_STAY and self.family.team_manager.myteam.MemberCount() > 1:
                    self.TransferToTeammate(self.family.team_manager.myteam.leaderFamilyId)#传送至队长位置
#                    gevent.sleep(2)
                    self.family.SetState(STATE_GS_GODDESS_MOVE)#移动至礼物兑换NPC
            if member.familyId == self.family.master.myApprenticeId and respond.leaderFamilyId == self.familyId:#徒弟加入了队伍
                if self.family.GetState() == STATE_GS_MASTER_TEAM_INVITE_STAY:
                    self.family.SetState(STATE_GS_MASTER_ENTER_TAOLIYUAN)
                return
            if member.familyId == self.familyId and respond.leaderFamilyId == self.family.master.myMasterId:#加入了师父的队伍
                if self.family.GetState() == STATE_GS_MASTER_TEAM_INVITE_WAIT_STAY:
                    self.family.SetState(STATE_GS_MASTER_ENTER_TAOLIYUAN_WAIT)
                return
        
        if respond.teamid == 0:
            if state == STATE_GC_TEAM_QUIT:
                self.family.SetState(STATE_GC_TEAM_QUIT_FINISHED)
            elif state == STATE_GC_TEAM_QUIT_FOR_CREATE:
                self.family.SetState(STATE_GC_TEAM_BEGIN)
        elif self.family.team_manager.myteam.isBegin:
            self.gameServerId = respond.memberList._values[0].gameServerId
            if state == STATE_GC_TEAM_CREATE_WAIT:
                self.family.SetState(STATE_GC_TEAM_CREATE_FINISHED)
            else:
                myteam = self.family.team_manager.myteam
                if not myteam.IsLeader() and myteam.id in self.family.team_manager.applyList:
                    myteam.SetTeamLimit(self.family.team_manager.applyList[myteam.id])
                    self.family.team_manager.applyList = {}
                self._auto_team()

    def On_TeamMemberInfoSync(self, respond):
#         logging.debug("On_TeamMemberInfoSync respond = %s" % respond)
        self.family.team_manager.myteam.SyncTeamMember(respond)
        if self.family.state == STATE_GS_START_FIGHT_WAIT:
            if self.family.familyId in self.family.team_manager.myteam.memberList\
                    and self.family.team_manager.myteam.memberList[self.family.familyId].fightState:
                self.family.SetState(STATE_GS_START_FIGHT_BEGIN)
        elif self.family.state == STATE_GS_MASTER_ENTER_TAOLIYUAN_WAIT:
            if respond.member.familyId == self.family.master.myMasterId and respond.member.sceneTemplateId == SceneTaoLiYuan:
                self.family.master.myMasterMember = respond.member
                self.family.SetState(STATE_GS_MASTER_TRANSFER_TO_SERVER)

    def On_TeamStateSync(self, response):
        if response.familyId == self.family.familyId and self.family.team_manager.myteam.IsInTeam():
            self._auto_team()
    
    def On_TeamTips(self, respond):
        logging.debug("On_TeamTips respond = %s" % respond)
    
    # 申请加入队伍
    def TeamApplyReq(self, team_type=TEAM_TYPE_FREE):
        if self.family.team_manager.recruitList.has_key(team_type):
            team = self.family.team_manager.recruitList[team_type]
            self.family.team_manager.applyList[team.id] = team.memberCount
            request = TeamApplyReq()
            request.teamId = self.family.team_manager.recruitList[team_type].id
            self.SendProtocol(CLI_TO_GS_TEAM_APPLY, request)

#     # 取消申请加入队伍
#     def TeamCancelApplyReq(self):
#         request = TeamCancelApplyReq()
#         self.SendProtocol(852, request)


    # 批准入队申请
    def TeamApproveApplyReq(self, apply_family_id, is_join_team=True):
        request = TeamApplyReply()
        request.applyFamilyId = apply_family_id
        request.isJoinTeam = is_join_team
        request.autoReply = True
        self.SendProtocol(CLI_TO_GS_TEAM_APPLY_REPLY, request)

    # 有人申请入队响应
    def On_TeamApplyListSync(self, respond):
        cur_count = self.family.team_manager.myteam.MemberCount()
        mumber_limit = self.family.team_manager.myteam.GetTeamLimit()
        for apply in respond.applyList:
            if cur_count >= mumber_limit:
                break
            self.TeamApproveApplyReq(apply.familyId)
            cur_count += 1

    # 直接加入队伍
#     def TeamJoinReq(self):
#         request = TeamJoinReq()
#         self.SendProtocol(854, request)

    # 退出队伍
    def TeamLeaveReq(self):
        request = TeamLeaveReq()
        self.SendProtocol(CLI_TO_GS_TEAM_LEAVE, request)

    # 踢出队伍
    def TeamKickOutReq(self, targetFamilyId):
        request = TeamKickOutReq()
        request.targetFamilyId = targetFamilyId
        self.SendProtocol(CLI_TO_GS_TEAM_KICK_OUT, request)

    # 队伍邀请
    def TeamInviteReq(self, beInvitedFamilyId=0):
        request = TeamInviteReq()
        request.teamType = self.family.team_manager.myteam.type
        request.beInvitedFamilyId = beInvitedFamilyId
        request.beInvitedFamilyGroupId = self.family.groupId
        self.SendProtocol(CLI_TO_GS_TEAM_INVITE, request)
    # 跨服队伍邀请
    def TeamInviteReq_KuaFu(self, beInvitedFamilyId=0, beInvitedFamilyGroupId = 0):
        request = TeamInviteReq()
        request.teamType = self.family.team_manager.myteam.type
        request.beInvitedFamilyId = beInvitedFamilyId
        request.beInvitedFamilyGroupId = beInvitedFamilyGroupId
        self.SendProtocol(CLI_TO_GS_TEAM_INVITE, request)
        
    #队长不同服同线邀请队员
    def PbCheckJoinTeamInGc_DiffGroupId(self, groupId, checkFamilyId):
        request= PbCheckJoinTeamInGc()
        request.fromFamilyGroupId = self.family.groupId
        request.fromFamilyGsId = self.serverId
        request.checkFamilyId = checkFamilyId
        request.checkTeamType = True
        request.teamId = self.family.team_manager.myteam.id
        request.data.beInviteFamilyGroupId = groupId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GC_TEAM_CHECK_JOIN_TEAM_IN_GC, request)
        
    def PbCheckJoinTeamInGc(self, teamId, teamType, groupId, inviteFamilyId = None):
        request= PbCheckJoinTeamInGc()
        request.fromFamilyGroupId = groupId
        request.fromFamilyGsId = self.serverId
        request.checkFamilyId = self.family.familyId
        request.checkTeamType = True
        request.teamType = teamType 
        request.teamId = teamId
        if inviteFamilyId:
            request.data.inviteFamilyId = inviteFamilyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GC_TEAM_CHECK_JOIN_TEAM_IN_GC, request)  
        
    def PbCheckJoinTeamInGs(self, information):
        request = PbCheckJoinTeamInGs()
        request.fromFamilyGroupId = information.fromFamilyGroupId
        request.fromFamilyGsId = information.fromFamilyGsId
        if information.data.beInviteFamilyGroupId == 0:
            request.checkFamilyGroupId = information.fromFamilyGroupId
        else:
            request.checkFamilyGroupId = information.data.beInviteFamilyGroupId
        request.checkFamilyId = information.checkFamilyId
        request.teamType = self.family.team_manager.myteam.type
        request.teamId = information.teamId
        self.Teaminforset(request.data.leader, information.data.leader)
        request.data.beInviteFamilyGroupId = information.data.beInviteFamilyGroupId
        request.data.inviteFamilyId = information.data.inviteFamilyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GC_TEAM_CHECK_JOIN_TEAM_IN_GS, request)  
        
    def On_PbCheckJoinTeamInGs(self, respond):
        logging.debug('On_PbCheckJoinTeamInGs %s' % respond)
        self.family.KuaFuGroupId = self.family.serverGroupId
        if respond.result == True:
            if respond.data.leader.familyId == self.family.familyId:
                self.TeamInviteReq_KuaFu(respond.checkFamilyId, respond.checkFamilyGroupId)  
            else:
                self.family.team_manager.myteam.leaderinf = respond.data.leader
                self.TeamInviteReply(respond.data.leader.familyId)
                      
    def On_PbCheckJoinTeamInGc(self,respond):
        logging.debug('On_PbCheckJoinTeamInGc %s' % respond)
        self.family.team_manager.myteam.leaderinf = respond.data.leader
        
        if  self.family.KUAFU:
            if respond.data.leader.familyId == self.family.familyId:
                self.family.KuaFuGroupId = respond.data.beInviteFamilyGroupId
            self.PbCheckJoinTeamInGs(respond)

        #如果是单加的话
        if self.family.team_manager.myteam.leaderFamilyId == respond.data.leader.familyId \
        and self.family.GetState() == STATE_GC_TEAM_APPLY \
        and not self.family.team_manager.myteam.IsInTeam():
            self.TeamInviteReply(respond.data.leader.familyId)
            return
        
        self.family.team_manager.myteam.inviteId = respond.data.leader.familyId
        if self.family.master.myMasterId == respond.data.leader.familyId and self.family.GetState() == STATE_GS_MASTER_TEAM_INVITE_WAIT:
            self.family.SetState(STATE_GS_MASTER_TEAM_INVITE_WAIT_STAY)
            self.TeamInviteReply(respond.data.leader.familyId)
            return
        
        elif self.family.caseId == CaseManager.GODDESS and self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_WAIT:
            self.family.SetState(STATE_GS_GODDESS_TEAM_INVITE_WAIT_STAY)
            self.TeamInviteReply(respond.data.leader.familyId)
            def resetState():
                if self.family.GetState() == STATE_GS_GODDESS_TEAM_INVITE_WAIT_STAY:
                    self.family.SetState(STATE_GS_GODDESS_TEAM_INVITE_WAIT)
            gevent.spawn(resetState)
            return
        elif self.family.caseId == CaseManager.VALENTINE:
            self.TeamInviteReply(respond.data.leader.familyId)
            self.family.SetState(STATE_GS_VALENTINE_START)            
            return
        
        elif self.family.caseId == CaseManager.SKILLTEST and self.family.GetState() == STATE_GS_SKILLTEST_TEAM_APPLY_WAIT:
            self.TeamInviteReply(respond.data.leader.familyId)
            self.family.SetState(STATE_GS_SKILLTEST_TRANSFER_MAP)            
            return
        
        if not self.family.team_manager.myteam.IsInTeam() and self.family.caseId is CaseManager.FISHING:
            self.TeamInviteReply(self.family.team_manager.myteam.inviteId)
    # 队伍邀请响应
    def On_TeamInviteListSync(self, respond):
        logging.debug('Team_Invite %s' % respond)
        if respond.familyId != self.family.familyId:
            return
        for invite_family in respond.inviteList._values:
#            self.inviteFamilyId = invite_family.familyId
#            if respond.inviteList._values
            if invite_family.groupId == self.family.serverGroupId:
                self.PbCheckJoinTeamInGc(invite_family.teamId, invite_family.teamType, invite_family.groupId)
            else:
                self.family.KUAFU = True
                self.family.KuaFuGroupId = invite_family.groupId
                self.PbCheckJoinTeamInGc(invite_family.teamId, invite_family.teamType, invite_family.groupId, inviteFamilyId=invite_family.familyId)
                self.family.KuaFuGroupId = self.family.serverGroupId
                
    def TeamInviteJoinActivity(self, beInvitedFamilyId, teamTitle):
        request = TeamInviteJoinActivity()
        request.beInvitedFamilyId = beInvitedFamilyId
        request.teamTitle = teamTitle
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_INVITE_JOIN_ACTIVITY, request)

    def On_TeamInviteJoinActivity(self, respond):
        logging.debug("On_TeamInviteJoinActivity respond = %s" % respond)
        # 茶室,收到邀请，直接传送
        if self.family.team_manager.myteam.typeEx == TEAM_TYPE_TEA:
            self.CallScript("PlayerCmd", "TransferToTeaRoom", respond.invitedFamilyId)
        else:
            request = TeamInviteJoinActivityReply()
            request.beInvitedFamilyId = self.family.familyId
            request.isJoin = True
            self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_INVITE_JOIN_ACTIVITY_REPLY, request)
            self.family.gameServerNetPackHandle.CallScript("PlayerCmd", "SetInActivityUI", 1)#设置为联赛界面，通知队长进入了联赛界面

    def TeamInviteJoinYabiao(self, beInvitedFamilyId, teamTitle):
        request = TeamInviteJoinActivity()
        request.beInvitedFamilyId = beInvitedFamilyId
        request.teamTitle = teamTitle
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_INVITE_JOIN_YABIAO, request)

#    def On_TeamInviteJoinYabiao(self, respond):
#        logging.debug("On_TeamInviteJoinYabiao respond=%s" % respond)
#        request = TeamInviteJoinYabiaoReply()
#        request.invitedFamilyId = respond.invitedFamilyId
#        request.beInvitedFamilyId = respond.beInvitedFamilyId
#        request.isJoin = True
#        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_INVITE_JOIN_YABIAO_REPLY, request)

    def TeamMemberCallCheck(self):
        request = TeamMemberCallCheck()
        request.checkList.extend([member.familyId for key, member in self.family.team_manager.myteam.memberList.items() if member.familyId != self.family.familyId])
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_MEMBER_CALL_CHECK, request)
        
    def On_TeamMemberCallCheckResult(self, respond):
        logging.debug("On_TeamMemberCallCheckResult respond=%s" % respond)
        
        request = TeamMemberCall()
        request.toFamilyId.extend(respond.passList)
        self.SendProtocol(CLI_TO_GS_TEAM_MEMBER_CALL, request)
        pass
    
    def On_TeamMemberCall(self, respond):
        self.CallScript("PlayerCmd", "TransferToTeammate", respond.fromFamilyId, 1.0)
#        self.family.gameServerNetPackHandle.Switch_SceneLine(self.family.team_manager.myteam.leaderinf.sceneInstanceId+1)#换线

            
    def TeamApplyMsg(self, account_team_id, leaderFamilyId, familyId, groupid):
        self.ChatRequestByMsg("TeamApply|%d|%d|%d" % (account_team_id, familyId, groupid),
                              channel=leaderFamilyId)
        
    def BossRevival(self, param_type):
        self.GetEnoughMoney(VALUE_COIN_GOLD, 100)
        self.CallScript("PlayerCmd", "BossRevival", param_type)
    
    def DefaultRevival(self, param_type):
        self.CallScript("GMCmd", "DoCommand", "me:AddSilver(500000, 1);")
        self.CallScript("PlayerCmd", "DefaultRevival", param_type)
    
    def GetEnoughMoney(self, coinType, needValue):
#         logging.debug("GetEnoughMoney valueCoin=%s, coinType=%s, needValue=%s" % (str(self.family.valueCoin), coinType, needValue))
        if coinType not in self.family.valueCoin or self.family.valueCoin[coinType] <= needValue:
            for idx in range(int(math.ceil(float(needValue)/MaxGMAddCoinValue))):
                logging.debug("GetEnoughMoney Add coin")
                self.GM_AddValueCoin(coinType, MaxGMAddCoinValue)
            gevent.sleep(2)
    
    # --- 好友 ---

    # 同步好友数据
    def Do_ApplyRelationData(self):
        request = ApplyRelationDataReq()
        request.dataVersion = 0
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_APPLY_RELATION_DATA, request)

    def On_SyncRelationData(self, respond):
        logging.debug('On_SyncRelationData %s' % respond)
#         if respond.result == RelationApplyResult.Value('SUCCESS'):
#             self.family.friendMan.UpdateSyncData(respond)
#             self.family.SetState(STATE_GS_FRIEND_REMOVE)
#         if respond.result == RelationApplyResult.Value('PENDING'):
#             self.friendSyncTimes += 1
#             if self.friendSyncTimes >= 3:
#                 self.family.behavior = Behavior.END
#             else:
#                 self.family.SetState(STATE_GS_FRIEND_SYNC_DATA)
        self.family.friendMan.UpdateSyncData(respond)
        #信息同步后，跳转到搜索玩家
        if self.family.GetState() == STATE_GS_FRIEND_WAIT_SEARCH:
            if self.family.isNewRole or self.family.friendMan.hasCleanFriends:
                self.family.SetState(STATE_GS_FRIEND_SEARCH)
            else:
                self.family.SetState(STATE_GS_FRIEND_CLEAN_FRIENDS)
        
#         for studentId in respond.relationInfo.schoolData.oldStudentList:#不知道为什么收不到这条，暂时通过出师邮件结束案例
#             if studentId == self.family.master.myApprenticeId and self.family.GetState() == STATE_GS_MASTER_WAIT_APPRENTICE_LEAVE:
#                 logging.debug("徒弟%s已成功出师" % studentId)
#                 self.family.SetState(STATE_GS_END)
    def Do_SearchFamilyGlobalReq(self, familyId):
        request = SearchFamilyGlobalReq()
        request.familyId = familyId
        request.type = 0
        self.SendProtocol(CLI_TO_GS_SEARCH_FAMILY_GLOBAL, request)
    
    def On_GlobalSearchFamilyRsp(self,respond):
        logging.debug("On_GlobalSearchFamilyRsp: %s" % respond)
        if respond.result == emSearchSucc:
            self.family.crossfriend.askfriendgroupid = respond.groupId
            self.family.SetState(STATE_GS_CROSSFRIENG_JOIN)
  
    # 搜索玩家
    def Do_SearchFamilyReq(self, name, type=0):
        logging.debug("要搜索的玩家名为：")
        logging.debug(name)
        request = SearchFamilyReq()
        request.name = name
        request.type = type
        if Config.is_illegaltest():
            request.type = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SEARCH_FAMILY, request)

    def On_SearchFamilyRsp(self, respond):
        logging.debug("On_SearchFamilyRsp: %s" % respond)
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.family.SetState(STATE_GS_FRIEND_RECOMMAND)

    # 添加好友
    def Do_ApplyAddFriend(self, familyId, groupid = None):
        request = ApplyAddFriend()
        request.familyId = familyId
        if self.family.caseId == CaseManager.CROSSFRIEND:
            request.groupId = self.family.serverGroupId
            self.family.KuaFuGroupId = groupid
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_ADD_FRIEND, request)
        self.family.KuaFuGroupId = self.family.serverGroupId
        
    def On_AddFriendRsp(self, respond):
        logging.debug("添加好友rsp")
        if respond.result == RelationApplyResult.Value('SUCCESS'):
            if self.family.caseId == CaseManager.CROSSFRIEND:
                self.family.crossfriend.beaskfriendgroupid = respond.targetGroupId
                self.family.crossfriend.familyid = respond.applyerFamilyId              
                self.family.SetState(STATE_GS_CROSSFRIENG_REPLY)
            pass
        # 被请求添加好友会推送该协议，故增加判断
        if self.family.GetState() == STATE_GS_FRIEND_WAIT_ADD:
#             self.family.SetState(STATE_GS_FRIEND_APPLY)
            self.family.SetState(STATE_GS_FRIEND_ADD)#循环请求添加好友
        
        
    # 同意添加好友
    def Do_AgreeAddFriend(self, familyId, groupId=None):
        request = AgreeAddFriend()
        request.familyId = familyId
        if self.family.caseId == CaseManager.CROSSFRIEND:
            if self.family.serverGroupId != groupId:
                request.groupId =  groupId
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_AGREE_ADD_FRIEND, request)

    def On_AgreeAddFriendRsp(self, respond):
        if respond.result == RelationApplyResult.Value('SUCCESS'):
            self.MarkTestCase("TestCase_Friend_AddFriendCount")
#         self.family.SetState(STATE_GS_FRIEND_SYNC_DATA)
        if self.family.caseId == CaseManager.FRIEND:
            self.family.SetState(STATE_GS_FRIEND_APPLY)#循环处理好友请求
        if self.family.caseId == CaseManager.CROSSFRIEND:
            self.family.SetState(STATE_GS_CROSSFRIENG_END)#循环处理好友请求


    # 拒绝添加好友
    def Do_RefuseAddFriend(self, familyId):
        request = RefuseAddFriend()
        request.familyId = familyId
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_REFUSE_ADD_FRIEND, request)

    def On_RefuseAddFriendRsp(self, respond):
        if respond.result == RelationApplyResult.Value('SUCCESS'):
            pass
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.family.SetState(STATE_GS_FRIEND_APPLY)#循环处理好友请求
        elif self.family.GetState() == STATE_GS_BLACK_LIST_WAIT:
            self.family.SetState(STATE_GS_BLACK_LIST)


    # 删除好友
    def Do_RemoveFriend(self, familyId):
        request = RemoveFriend()
        request.familyId = familyId
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_REMOVE_FRIEND, request)

    def On_RemoveFriendRsp(self, respond):
        if respond.result == RelationApplyResult.Value('SUCCESS'):
            pass
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.family.SetState(STATE_GS_FRIEND_SEND_GIFT)

    # 获取推荐好友
    def Do_RecommandFriendReq(self):
        request = RecommandFriendReq()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_RECOMMAND_FRIEND, request)

    def On_RecommandFamilyRsp(self, respond):
        self.family.friendMan.UpdateRecommand(respond)
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.family.SetState(STATE_GS_FRIEND_ADD)
    
    # 好友送礼
    def SendGiftReq(self, receiverId, desc, shopId, goodId, buyCount, priceIndex):
        request = SendGiftReq()
        request.senderId = self.familyId
        request.receiverId = receiverId
        request.giftInfo.desc = desc
        shopItem = request.giftInfo.shopItemList.add()
        shopItem.shopId = shopId
        shopItem.goodId = goodId
        shopItem.buyCount = buyCount
        shopItem.priceIndex = priceIndex
        self.SendProtocol(CLI_TO_GS_GIFT_SEND, request)
    
    #收到礼物
    def On_SyncGiftListRsp(self, respond):
        logging.debug("On_SyncGiftListRsp respond = %s" % respond)
        self.SyncOneGiftReq()
    
    #同步接收到的礼物信息
    def SyncOneGiftReq(self):
        request = SyncOneGiftReq()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_GIFT_SYNC_ONE, request)
    
    def On_SyncOneGiftRsp(self, respond):
        logging.debug("On_SyncOneGiftRsp respond = %s" % respond)
        if respond.giftBag and respond.giftBag.giftId:
            self.GetOneGiftReq(respond.giftBag.giftId)#接收礼物
            self.ThanksForGift(respond.giftBag.sendFamilyId)#答谢礼物
            for item in respond.giftBag.giftInfo.shopItemList:
                if item.goodId == Friend_XinXinXiangYin and self.family.caseId == CaseManager.FRIEND:#确保亲密度足够再添加密友（收到第二个礼物）
                    logging.debug("答谢完成后，请求添加密友")
                    self.ApplyAddCloseFriend(respond.giftBag.sendFamilyId)#请求添加密友
                elif item.goodId == Friend_TaoHuaBaoXia and self.family.caseId == CaseManager.GODDESS:
                    self.MarkTestCase("TestCase_Goddess_GetGift")
                    self.family.SetState(STATE_GS_GODDESS_BUY_BOX)
    
    #接收礼物  
    def GetOneGiftReq(self, giftId):
        request = GetOneGiftReq()
        request.giftId = giftId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_GIFT_GET_REQ, request)
    
    def On_GetOneGiftRsp(self, respond):
        logging.debug("On_GetOneGiftRsp respond = %s" % respond)
    
    #答谢礼物
    def ThanksForGift(self, receiverId):
        request = ThanksForGift()
        request.familyId = self.familyId
        request.receiverId = receiverId
        request.desc = u"3Q你的礼物"
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_GIFT_THANKS, request)
    
    
    # ---黑名单---
    def AddBlackList(self, familyId):
        request = AddBlackList()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_RELATION_ADD_BLACKLIST, request)
    
    def On_RemoveBlackListRsp(self, respond):
        self.family.SetState(STATE_GS_REMOVE_BLACK_LIST)

    # ---密友---
    def ApplyAddCloseFriend(self, familyId):
        request = ApplyAddCloseFriend()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_ADD_CLOSEFRIEND, request)
    
    def On_AddCloseFriendRsp(self, respond):
        logging.debug("On_AddCloseFriendRsp respond = %s" % respond)
        if respond.applyFamilyId != self.familyId:
            logging.debug("familyId = %s 请求添加我为密友" % respond.applyFamilyId)
            if random.randint(0, 1) == 0:
                logging.debug("同意添加%s为密友" % respond.applyFamilyId)
                self.AgreeAddCloseFriend(respond.applyFamilyId)
            else:
                logging.debug("拒绝添加%s为密友" % respond.applyFamilyId)
                self.RefuseAddCloseFriend(respond.applyFamilyId)
                
    #同意添加为密友
    def AgreeAddCloseFriend(self, familyId):
        request = AgreeAddCloseFriend()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_AGREE_ADD_CLOSEFRIEND, request)
    
    def On_AgreeAddCloseFriendRsp(self, respond):
        '''
            SUCCESS     = 0;                // 请求成功
            PENDING      = 1;                // 数据加载中
            EXIST        = 2;
            MAX_FRIEND_SELF = 3;
            MAX_FRIEND_TARGET = 4;
            FAILED      = 5;                // 失败
            MAX_CLOSEFRIEND_SELF = 6;        // 自己密友达到上限
            MAX_CLOSEFRIEND_TARGET = 7;        // 对方密友达到上限
            NOT_FRIEND = 8;                    // 不是好友
            IS_CLOSEFRIEND = 9;                // 已经是密友
            COHESION_NOT_ENOUGH = 10;        // 亲密度不够
            TARGET_OFFLINE = 11;            // 目标不在线
        '''
        logging.debug("On_AgreeAddCloseFriendRsp respond = %s" % respond)
        if respond.result == 0:
            logging.debug("解除密友关系")
            self.RemoveCloseFriend(respond.applyFamilyId)#解除密友关系
        
    #拒绝添加为密友
    def RefuseAddCloseFriend(self, familyId):
        request = RefuseAddCloseFriend()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_REFUSE_ADD_CLOSEFRIEND, request)
    
    #解除密友关系
    def RemoveCloseFriend(self, familyId):
        request = RemoveCloseFriend()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_REMOVE_CLOSEFRIEND, request)
    
    def On_RemoveCloseFriendRsp(self, respond):
        logging.debug("On_RemoveCloseFriendRsp respond = %s" % respond)
    
    # ---仇人---
    def ApplyRevengeeInfo(self):
        request = ApplyRevengeeInfo()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_APPLY_REVENGEE_INFO, request)
    
    def On_SyncRevengeeInfo(self, respond):
        logging.debug("仇人列表：%s" % respond)
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.family.SetState(STATE_GS_BLACK_LIST)
            
    # -- 跨服约战 --
    def Do_NVNCreateRoomReq(self):
        request = NVNCreateRoomReq()
        request.nRoomType = 1  
        request.nMissionTimeout = 300
        request.szRoomName = generate_chinese(3)
        if self.family.crossbattle.type == True:
            request.bWatchRoom = True
            request.nCampCount = 3
            request.nTeamMemberLimit = 3
        self.SendProtocol(CLI_TO_GS_NVN_CREATE_ROOM_REQ, request)
        
    def On_NVNResult(self, respond):
        '''
        NVN.RESULT_SUCCESS             = 0;        -- 成功
        NVN.RESULT_FAIL             = 1;        -- 失败
        NVN.RESULT_ROOM_FULL         = 2;        -- 房间满
        NVN.RESULT_ROOM_REJOIN         = 3;        -- 重复加入
        NVN.RESULT_ROOM_NOTEXITS    = 4;        -- 房间不存在
        NVN.RESULT_INVALID_SCENE    = 5;        -- 不在准备场
        NVN.RESULT_WRONG_PASSWORD    = 6;        -- 密码不正确
        NVN.RESULT_TEAM_CHANGE        = 7;        -- 队伍信息改变
        '''
        if respond.nResult == 0:
            if self.family.GetState() == STATE_GS_CROSSBATTLE_CREATROOM:
                self.MarkTestCase("TestCase_CrossBattle_BuildRoom")                
            elif self.family.GetState() == STATE_GS_CROSSBATTLE_JOIN:
                self.MarkTestCase("TestCase_CrossBattle_JoinRoom")
            self.family.SetState(STATE_GS_CROSSBATTLE_WAIT) 
            return
        else:
            if self.family.GetState() == STATE_GS_CROSSBATTLE_CREATROOM:
                if self.family.team_manager.myteam.IsLeader():
                    self.family.SetState(STATE_GS_CROSSBATTLE_CREATROOM)              
            elif self.family.GetState() == STATE_GS_CROSSBATTLE_JOIN:
                if self.family.team_manager.myteam.IsLeader():
                    self.family.SetState(STATE_GS_CROSSBATTLE_FINDROOM) 
                 
    def Do_RoomListReq(self):
        self.SendProtocol(CLI_TO_GS_NVN_ROOMLIST_REQ, None)

    def On_NVNRoomList(self, respond):
        if len(respond.roomList._values) < 1:
            self.family.SetState(STATE_GS_CROSSBATTLE_CREATROOM)
        else:
            index = random.randint(0, len(respond.roomList._values)-1)
            self.family.crossbattle.CrossroomID = respond.roomList._values[index].nId    
            if respond.roomList._values[index].bWatchRoom == True:
                self.family.crossbattle.type = True
            self.family.SetState(STATE_GS_CROSSBATTLE_JOIN)
    
    def Do_NVNJoinRoomReq(self):
        request = NVNJoinRoomReq()
        if self.family.crossbattle.type == True:
            request.szTeamName = generate_chinese(3)
        request.nRoomId = self.family.crossbattle.CrossroomID
        self.SendProtocol(CLI_TO_GS_NVN_JOIN_ROOM_REQ, request)

    
    # -- 联赛 --
    def SetLeagueScore(self, score):
        self.CallScriptGmDoCommand("me:SetLeagueScore(%d);" % score)
        
    def SetLeagueStage(self, stage):
        self.CallScriptGmDoCommand("me:SetLeagueStage(%d);" % stage)
        
    # 检查报名条件550
    def Cli_LeagueMatch_CheckJoinRequest(self, familyid=None, member=None):
        request = Cli_LeagueMatch_CheckJoinRequest()
        if familyid:
            request.familyId = familyid
        else:
            request.familyId = self.family.familyId
        if member:
            request.member = member
        else:
            request.member = FAMILY_MEMBER_TYPE_MAIN
        self.SendProtocol(CLI_TO_GS_LEAGUE_MATCH_CHECK_JOIN_REQUEST, request)

    def On_LeagueMatch_CheckJoinResponse(self, respond):
        if respond.result == 0:
            self.family.SetState(STATE_GS_LEAGUEMATCH_CHECKOVER)
        else:
            logging.debug('LeagueMatch_CheckJoin Error: %s' % respond.result)
            self.family.behavior = Behavior.END

    # 报名551
    def Cli_LeagueMatch_JoinRequest(self, familyid=None, member=None):
        request = Cli_LeagueMatch_JoinRequest()
        if self.family.team_manager.myteam.IsInTeam():  # 组队匹配
            logging.debug("发送组队匹配")
            for member in self.family.team_manager.myteam.memberList.values():
                player = request.players.add()
                player.familyId = member.familyId
                player.member = member.member
                player.gameServerId = member.gameServerId
            self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_LEAGUE_MATCH_JOIN_REQUEST, request)
        else:  # 单人匹配
            logging.debug("发送单人匹配")
            player = request.players.add()
            player.familyId = self.family.familyId
            player.member = FAMILY_MEMBER_TYPE_MAIN
            player.gameServerId = 0
            self.SendProtocol(CLI_TO_GS_LEAGUE_MATCH_JOIN_REQUEST, request)

    # 报名应答551
    def On_LeagueMatch_JoinResponse(self, respond):
#         #         logging.debug("%s Match result:%s, familyId:%s " % (self.mainName, respond, str(self.familyId)))
#         self.ClientForbitTeamOperator()
#         do nothing
        self.MarkTestCase("On_LeagueMatch_JoinResponse")
        pass

    # 禁止客户端队伍操作
    def ClientForbitTeamOperator(self):
        self.CallScript('PlayerCmd', 'ClientForbitTeamOperator', 1.0)
    
    #切换队伍匹配状态
    def TeamMatchingStateChange(self, bool):
        request = TeamMatchingStateChange()
        request.isMatching = bool
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_TEAM_MATCHING_STATE_CHANGE, request)
    
    # 取消匹配队友552
    def Cli_LeagueMatch_CancelRequest(self):
        request = Cli_LeagueMatch_CancelRequest()
        self.SendProtocol(CLI_TO_GS_LEAGUE_MATCH_CANCEL_REQUEST, request)
        
        self.CallScript('PlayerCmd', 'ClientForbitTeamOperator', 0.0)

    # 取消匹配队友结果552
    def On_LeagueMatch_CancelResponse(self, respond):
        '''
            SUCCESS = 0; 
            FAIL    = 1;
        '''
        #         logging.debug('CancelMatchTeammaterResponse : %s' % respond)
        pass

    # 联赛回城553####################################
    def Cli_LeagueMatch_BackTownRequest(self):
        request = Cli_LeagueMatch_BackTownRequest()
        self.SendProtocol(CLI_TO_GS_LEAGUE_MATCH_BACK_TOWN_REQUEST, request)

    ######### GS2S
    # 联赛，当前匹配状态553
    def On_LeagueMatch_MatchStateNotify(self, respond):
        '''
        FAIL                  = 0;
        CANCEL                = 1; // 自己取消匹配
        TEAMMATER_CANCEL      = 2; // 队友取消匹配
        BEGIN_MATCH_TEAMMATER = 3; // 即将开始匹配队友
        MATCHED_TEAMMATER     = 4; // 匹配队友成功，开始匹配对手
        MATCHED_COMPETITOR    = 5; // 匹配对手成功，即将开始进入战斗
        '''
        #         logging.debug("Match Complete: %s, name is: %s, familyId is:%s \n" % (respond, self.mainName, str(self.familyId)))
        logging.debug('LM_MatchStateNotify_state : %s' % respond.state)
        if respond.state == LeagueMatch_MatchStateNotify.FAIL and self.family.state == STATE_GS_LEAGUEMATCH_JOIN_WAIT:
            self.family.behavior = Behavior.END
        elif respond.state in [LeagueMatch_MatchStateNotify.CANCEL, LeagueMatch_MatchStateNotify.TEAMMATER_CANCEL]:
            self.family.SetState(STATE_GC_TEAM_RECRUIT_FINISHED)#重新匹配
        elif respond.state in [LeagueMatch_MatchStateNotify.BEGIN_MATCH_TEAMMATER, LeagueMatch_MatchStateNotify.MATCHED_TEAMMATER]:
            self.family.SetState(STATE_GS_LEAGUEMATCH_MATCHING)
        elif respond.state == LeagueMatch_MatchStateNotify.MATCHED_COMPETITOR:
            self.family.SetState(STATE_GS_LEAGUEMATCH_MATCHED_COMPETITOR)
            self.MarkTestCase("On_LeagueMatch_Matched")

    # ---战场---

    # 战场报名555
    def Cli_BattleFieldMatch_JoinRequest(self):
        request = Cli_BattleFieldMatch_JoinRequest()
        if self.family.team_manager.myteam.IsInTeam():  # 组队匹配
            for member in self.family.team_manager.myteam.memberList.values():
                player = request.players.add()
                player.familyId = member.familyId
                player.member = member.member
                player.gameServerId = member.gameServerId
        else:  # 单人匹配
            player = request.players.add()
            player.familyId = self.family.familyId
            player.member = FAMILY_MEMBER_TYPE_MAIN
            player.gameServerId = 0
        self.SendProtocol(CLI_TO_GS_BATTLEFILED_MATCH_JOIN_REQUEST, request)
        self.MarkTestCase("Cli_BattleFieldMatch_JoinRequest")

    # 报名结果560
    def On_BattleFieldMatch_JoinResponse(self, respond):
        #         logging.debug( 'BattleFieldMatch_JoinResponse : %s' % respond.result)    
        if respond.result != BATTLE_MATCH_SUCCESS:
            logging.debug('BattleFieldMatch_JoinResponse Error : %s' % respond.result)
            self.MarkTestCase("BattleFieldMatch_JoinResponse_Error", isSuccess=False, exception=respond.result)

    # 战场，取消报名555
    def Cli_BattleFieldMatch_CancelRequest(self):
        request = Cli_BattleFieldMatch_CancelRequest()
        self.SendProtocol(CLI_TO_GS_BATTLEFIELD_MATCH_CANCEL_REQUEST, request)

    # 战场取消报名响应561
    def On_BattleFieldMatch_CancelResponse(self, respond):
        #         logging.debug( 'BattleFieldMatch_CancelResponse : %s' % respond)
        pass

    # 战场，当前匹配状态562
    def On_BattleFieldMatch_MatchStateNotify(self, respond):
        '''
        FAIL                       = 0; // 匹配异常
        START                   = 1; // 开始匹配
        CANCEL                = 2; // 取消匹配
        FINISH                   = 3; // 匹配成功
        '''
        
        def GeventTask():
            rep = asyncresult_manager.wait(self, "TestCase_Battle_MatchFinish", 60*25)
            if not rep:
                self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Battle_MatchTimeout", isSuccess=False, exception="userName=%s, familyId=%s"%(self.family.userName, self.family.familyId))
                self.family.SetState(STATE_GS_END)
                
        logging.debug('BattlefieldMatch_MatchStateNotify : %s.%s' % (respond, self.familyId))
        if respond.state == 0:
            asyncresult_manager.fire(self, "TestCase_Battle_MatchFinish", False, error="MatchState=FAIL")
            self.family.SetState(STATE_GS_END)
        elif respond.state == 1:
            self.ClientForbitTeamOperator()
            self.family.battle.beginMatchTime = time.time()
            self.MarkTestCase("TestCase_Battle_MatchStartCount")
            self.family.SetState(STATE_GS_BATTLE_WAIT)
            gevent.spawn(GeventTask)
        elif respond.state == 2:
            self.MarkTestCase("TestCase_Battle_MatchCancleCount")
#             asyncresult_manager.fire(self, "TestCase_Battle_MatchFinish", True)
        if respond.state == 3:
            result = time.time() - self.family.battle.beginMatchTime
            for i in range(Battle.MATCH_COUNT):
                if i * Battle.MATCH_TIME < result <= (i+1) * Battle.MATCH_TIME:
                    self.MarkTestCase("TestCase_Battle_MatchFinishCount_%d" % (i+1))
                    break
            self.MarkTestCase("TestCase_Battle_MatchFinishCount")
    

    # 战场，当前战场信息通知563
    def On_BattleFieldMatch_FightInfo(self, respond):
        '''
        MISSION_START = 0;      // 开启
        MISSION_OVER = 1;       // 结束
        MISSION_LEAVE = 2;      // 离开
        MISSION_ERROR = 3;      // 错误
        '''
        logging.debug('BattlefieldMatch_FightInfo : %s' % respond)
        logging.debug('%s, type : %s' % (respond.state, type(respond.state)))
#         if respond.state in [1, 2]:
#             self.canSkill = False
#             self.family.SetState(STATE_GS_BATTLE_SHOP)  # 宋金商店
#         elif respond.state == 3:
#             self.family.SetState(STATE_GS_END)
        if respond.state == 3:
            self.family.SetState(STATE_GS_END)

    #战场，比赛结果564
#     def On_BattleFieldMatch_FightResult(self, respond):
#         logging.debug('BattlefieldMatch_FightResult : %s' %(respond.result))
#         gevent.sleep(3)
#         self.canSkill = False # 禁止技能
#         self.family.SetState(STATE_GS_BATTLE_SHOP) # 宋金商店

    # --- 副本 ---

    # 开始单人副本战斗
    def Do_StartSingleMission(self, scene_id):
        request = StartSingleMission()
        request.scene_template_id = scene_id
        if Config.is_illegaltest():
            request.scene_template_id = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_START_SINGLE_MISSION, request)

    def On_AnsStartSingleMission(self, respond):
        logging.debug("On_AnsStartSingleMission respond = %s" % respond)
        if respond.scene_template_id == 1000: # 新手本
            self.family.SetState(STATE_GS_WAIT_NOVICE_MISSION_START)
        if respond.ansCode in [1, 2] and self.family.GetState() == STATE_GS_WAIT_SINGLE_MISSION:
            self.family.SetState(STATE_GS_END_SINGLE_MISSION)

    def On_AnsEndSingleMission(self, respond):
        self.family.SetState(STATE_GS_END_SINGLE_MISSION)

    # 结束单人副本战斗
    def Do_EndSingleMission(self, SingleMission_id, missionTime=0):
        request = EndSingleMission()
        request.scene_template_id = SingleMission_id
        request.strLog = "0;0"
        if missionTime != 0:
            request.missionTime = missionTime
        if Config.is_illegaltest():
            request.scene_template_id = Rand.bound_uint32()
            request.missionTime = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_END_SINGLE_MISSION, request)

    # 进入龙门荒漠
    def EnterGantryDesert(self):
        self.CallScriptTransfer(2014, 72.47, 75.92)

    # 进入枫华山谷
    def EnterMapleValley(self):
        self.CallScriptTransfer(2015, 28.7, 74.8)

#     #装备升星
#     def _apply_develop_equip(self, slot_position, item_id, develop_times, memberType=FAMILY_MEMBER_TYPE_MAIN):
#         request = ApplyDevelopEquip()
#         request.slotPos.memberType = memberType
#         request.slotPos.roomType = 0
#         request.slotPos.slotPosition = slot_position
#         request.itemId = item_id
#         request.developTimes = develop_times
#         self.SendProtocol(CLI_TO_GS_DEV_EQUIP, request)
        
    # 让机器人变得更强（机器人穿全部装备）
    def BecomeStronger(self, memberType=FAMILY_MEMBER_TYPE_MAIN):
        self.RandomEquip(MaxLevel, memberType, isRandom=False)

    # 获取高级装备(帽子已在初始时获取)
    def GM_AllEquipments(self, p, l=5):
        for d in range(1, 8):
            self.CallScriptAddStackItem(1, d, p, l, 1, False, 0)
    
    #获取未鉴定装备
    def AddAllUnIdedEquipments(self, score, quality, faction=None):
        if not faction:
            faction = self.family.characterCur.faction
        for part in EquipmentsPart:
            g, d, p, l = self.family.bag.GetUnIdedEquipmentsId(score, quality, faction, part)
            self.CallScriptAddStackItem(g, d, p, l, 1, False, 0)
    
    #获取印鉴
    def AddSignet(self, equipP):
        self.CallScriptAddStackItem(1, 10, equipP, 1, 1, False, 0)
        
    #随机装备和升星，以达到不同战力的需求
    def RandomEquip(self, level, memberType=FAMILY_MEMBER_TYPE_MAIN, isRandom=True):
        self.LevelUp_Character(level)
        
        if memberType == FAMILY_MEMBER_TYPE_MAIN:
            faction = self.family.characterMan.faction
        elif memberType == FAMILY_MEMBER_TYPE_COUPLE:
            faction = self.family.characterWoman.faction
        elif memberType == FAMILY_MEMBER_TYPE_KID:
            faction = self.family.characterChild.faction
        else:
            logging.error("RandomEquip memberType %s error" % memberType)
            return
                    
        if isRandom:
            #随机选择装备与装备个数
            EquipRandomList = sorted(random.sample(EquipmentsPart, random.randint(0, len(EquipmentsPart)))) + [SIGNET]
#             EquipRandomList = EquipmentsPart[:4]
            if level < 29:
                score = 1
            elif level < 39:
                score = 2
            elif level < 49:
                score = 3
            elif level < 55:
                score = 4                    
            else:
                score = random.choice([4, 5])
            quality = random.randint(1, 5)
        else:
            EquipRandomList = EquipmentsPart + [SIGNET]
            score = 4
            quality = 5
            
        self.Add_Sliver()
        self.AddAllUnIdedEquipments(score, quality, faction)
        self.AddSignet(random.choice(SIGNETLIST))
        gevent.sleep(5)  # 等背包的数据刷新
        
        logging.debug("RandomEquip level = %s, memberType = %s, faction = %s" % (level, memberType, faction))
        logging.debug("RandomEquip score = %s, quality = %s, EquipRandomList = %s" % (score, quality, EquipRandomList))
        #鉴定未鉴定装备
        for Equip_d in EquipRandomList:
            for gdpl in self.family.bag.consumeBag:
                g, d, p, l = map(int, gdpl.split("_"))
                if g == 5 and d == Equip_d + 20 and p == faction:
                    try:
                        itemId = random.choice(self.family.bag.consumeBag[gdpl][False].keys())
                        slotPosition = self.family.bag.consumeBag[gdpl][False][itemId]["slotPosition"]
                    except Exception, e:
                        logging.error("RandomEquip error = %s" % e)
                        break
                    self.PutOn_BagEuqipment(slotPosition, itemId, memberType=memberType)
                    gevent.sleep(1)
        #装备已鉴定装备
        for Equip_d in EquipRandomList:
            for gdpl in self.family.bag.consumeBag:
                g, d, p, l = map(int, gdpl.split("_"))
                if ((g == 1 and d == SIGNET) or g == 7) and d == Equip_d and p == faction:
                    try:
                        itemId = random.choice(self.family.bag.consumeBag[gdpl][True].keys())
                        slotPosition = self.family.bag.consumeBag[gdpl][True][itemId]["slotPosition"]
                    except Exception, e:
                        logging.error("RandomEquip error = %s" % e)
                        break
                    logging.debug("gdpl = %s, itemId = %s, slotPosition = %s" % (gdpl, itemId, slotPosition))
                    self.PutOn_BagEuqipment(slotPosition, itemId, memberType=memberType)
                    gevent.sleep(1)
                    break
        
    #穿随机时装
    def RandomAvatar(self, memberType=FAMILY_MEMBER_TYPE_MAIN):
        #获取挂件碎片（用于兑换挂件）
        for (g, d, p, l) in AllPendantPieces:
            self.CallScriptAddStackItem(g, d, p, l, 1000, False, 0)
        #获取月影石（用于兑换挂件）
        self.CallScriptAddStackItem(5, 1, 8, 1, 50000, False, 0)
        gevent.sleep(3)
        # 购买时装-衣服
        self.Buy_AvaterGuise(random.choice(FashionList), memberType=memberType, buyIndex=2, colorPlanIndex=random.randint(0, 2))
        # 购买时装-发型
        self.Buy_AvaterGuise(random.choice(HairList), memberType=memberType, buyIndex=2)
        # 购买时装-腰饰
        self.Buy_AvaterGuise(random.choice(BeltList), memberType=memberType, buyIndex=2)
        # 购买时装-奇兵
        self.Buy_AvaterGuise(random.choice([QiBing1, QiBing2, QiBing3]), memberType=memberType, buyIndex=2)
        # 购买脸饰
        self.Buy_AvaterGuise(random.choice(HeaddressList), memberType=memberType, buyIndex=2)
        # 购买背饰
        self.Buy_AvaterGuise(random.choice(PendantList), memberType=memberType, buyIndex=2)
        #购买坐骑
        self.Buy_AvaterHorse(memberType=memberType, buyIndex=2)
        
    #循环穿卸秘籍
    def LoopWearMiJi(self):
        while self.gsConnect and self.gsConnect.connected:
            gevent.sleep(5)
            logging.debug("装备秘籍")
            self.PutOn_MiJi()
            gevent.sleep(5)
            logging.debug("卸下秘籍")
            self.TakeOff_MiJi()
    
    #循环喊话
    def LoopChat(self):
        lastTime = time.time()
        while True:
            now = time.time()
            if now > lastTime + 120:
                break
            if self.isReady and self.gsConnect and self.gsConnect.connected:
                lastTime = now
                self.ChatRequestByMsg(msg=generate_chinese(random.randint(3, 8)), channel=random.choice([emChatChannelWorld, emChatChannelScene]))
            gevent.sleep(random.randint(5, 30))
    
    # ---技能---
    def SkillCanBeReleased(self, designatedSkillList=[]):
        def NoSkillJudge():
            if self.family.skill.needCommonAttack:
                self.Do_CastSkill(None, random.choice(self.family.gameServerNetPackHandle.attackList))
            else:
                self.UpdateSkillCd()#更新技能cd
                self.ResetSkillState()
                
        if not self.canSkill or \
        (self.family.characterCur.state != CHAR_STATE_IDLE \
        and self.family.characterCur.state != CHAR_STATE_RUN \
        and self.family.characterCur.state != CHAR_STATE_JUMP \
        and self.family.characterCur.state != CHAR_STATE_SKILL_JUMP):
            self.ResetSkillState()
            return

        self.family.skill.isLastSkill = False
        logging.debug("self.skillList = %s, designatedSkillList = %s" % (self.skillList, designatedSkillList))
        if self.skillList:
            if designatedSkillList:#只放指定技能
                skillList = []
                for sid in designatedSkillList:
                    if sid in self.skillList:
                        skillList.append(sid)
                    elif sid in SKILL_COST:
                        for cid in SKILL_COST[sid]:
                            if cid in self.skillList:
                                skillList.append(cid)
                if not skillList:
                    NoSkillJudge()
                    return
            else:
                skillList = self.skillList
#             logging.debug("skillList = %s" % skillList)
            choose_id = random.choice(skillList)
#             logging.debug("origin choose_id = %s" % choose_id)
            if choose_id in self.skillList:
                remove_id = choose_id
            else:
                logging.error("choose_id=%s, self.skillList=%s, designatedSkillList=%s" % (choose_id, self.skillList, designatedSkillList))
                raise
#             logging.debug("remove_id = %s" % remove_id)
            if remove_id in SKILL_STORAGE:#充能技能可以释放多次
                SKILL_STORAGE[remove_id]["now"] -= 1
                if SKILL_STORAGE[remove_id]["now"] < 1:
                    self.skillList.remove(remove_id)
                    SKILL_STORAGE[remove_id]["now"] = 0
            else:
                self.skillList.remove(remove_id)
            if choose_id in SKILL_COST:#需要消耗资源的技能
                choose_id =  self.ChooseCostSkillId(choose_id)
            elif choose_id in self.family.skill.costSkillKeyDict:#需要消耗资源的技能
                choose_id =  self.ChooseCostSkillId(self.family.skill.costSkillKeyDict[choose_id])
            logging.debug('choose_id : %s' % choose_id)
            if choose_id in SKILL_NEED_TARGET and  self.family.caseId == CaseManager.SKILLTEST and self.sceneTemplateId not in [SceneLinan]:
                while not self.family.skill.skillTargetDict:
                    sceneId = self.sceneTemplateId
                    line = self.sceneInstanceId
                    self.AddHostileNpc(sceneId, line, self.family.characterCur.GetCharacterposX(), self.family.characterCur.GetCharacterposH(), self.family.characterCur.GetCharacterposY())
                    return
                target_id = random.choice(self.family.skill.skillTargetDict.keys())
                target_posX, target_posY, = self.family.skill.skillTargetDict[target_id]["pos"]
                self.GM_MoveToPosition(False, target_posX,target_posY)
                self.Do_CastSkill(None, choose_id, target_id=target_id, target_posX=target_posX, target_posY=target_posY, target_srcid=target_id)
            else:
                self.Do_CastSkill(None, choose_id)
        else:
            NoSkillJudge()
    
    #选择需要消耗资源的技能
    def ChooseCostSkillId(self, skillId):
        costSkillDict = SKILL_COST[skillId]
        logging.debug("ChooseCostSkillId skillId=%s, costSkillDict=%s" % (skillId, str(costSkillDict)))
        faction = self.family.GetCurCharacter().faction
        if faction == EMEI:
            choose_id = random.choice(costSkillDict.keys())
            self.family.skill.costSkillKeyDict[choose_id] = skillId
            def GetSkillNeedPoint(now_skill_point, choice_skill_point):
                logging.debug("now_skill_point = %d" % now_skill_point)
                if now_skill_point < choice_skill_point:
                    return choice_skill_point - now_skill_point
                else:
                    return 0 
            choice_skill_point_list = costSkillDict[choose_id]
            choice_skill_point_type = choice_skill_point_list[0]
            choice_skill_point = choice_skill_point_list[1]
            logging.debug("choice_skill_point_type = %d, choice_skill_point = %d" % (choice_skill_point_type, choice_skill_point))
            if choice_skill_point_type == SKILL_POINT_QINYI:
                points = GetSkillNeedPoint(self.family.skill.emeiSkillPointQinyi, choice_skill_point)
                if points:
                    self.AddEmeiSkillPointQinyi(points)
            elif choice_skill_point_type == SKILL_POINT_LIANHUA:
                points = GetSkillNeedPoint(self.family.skill.emeiSkillPointLianhua, choice_skill_point)
                if points:
                    self.AddEmeiSkillPointLianhua(points)
#                gevent.sleep(1)
        elif faction == TIANREN:
            choose_id = random.choice(costSkillDict.keys())
            self.family.skill.costSkillKeyDict[choose_id] = skillId
            now_sun_skill_point = self.family.skill.tianrenSunSkillPoint
            now_moon_skill_point = self.family.skill.tianrenMoonSkillPoint
            choice_skill_point = costSkillDict[choose_id]
            logging.debug("now_sun_skill_point = %d, now_moon_skill_point = %d, choice_skill_point = %d" % (now_sun_skill_point, now_moon_skill_point, choice_skill_point))
            if now_sun_skill_point < choice_skill_point:
                self.AddTianrenSunSkillPoint(choice_skill_point - now_sun_skill_point)
#                gevent.sleep(1)
            elif now_moon_skill_point < choice_skill_point:
                self.AddTianrenMoonSkillPoint(choice_skill_point - now_moon_skill_point)
#                gevent.sleep(1)
        else:
            logging.error("Do_CastSkill can not find faction %s" % faction)
            raise
        return choose_id
    
    # 释放技能
    def Do_CastSkill(self, data=None, skill_id=1, original_skill_id=0, target_id=None, target_posX=0, target_posY=0, target_srcid=None):
        self.family.skill.isLastSkill = False
        if skill_id in SKILL_COMBO and SKILL_COMBO[skill_id] == COMBO_REPEAT and not self.family.skill.hasReleaseRepeatSkill:
            self.family.skill.originSkillOfRepeatSkill = self.family.skill.lastSkillId
        request = CastSkill()
        request.tick = 0
        request.skill_id = self.family.skill.lastSkillId = skill_id
        request.skill_level = 1
        request.dir = self.family.characterCur.GetCharacterDir()
        request.posX = self.family.characterCur.GetCharacterposX()
        request.posY = self.family.characterCur.GetCharacterposY()
        if target_id == None:
            target_id = self.family.characterCur.GetCharacterId()
        request.target_id = target_id
        if not target_posX or not target_posY:
            target_posX = self.family.characterCur.GetCharacterposX()
            target_posY = self.family.characterCur.GetCharacterposY()
        request.target_posX = target_posX
        request.target_posY = target_posY
        request.original_skill_id = original_skill_id
        if target_srcid == None:
            target_srcid = 0
        request.target_srcid = target_srcid
        # request.target_id = data.id
        # request.target_posX = data.info.posX
        # request.target_posY = data.info.posY
        if Config.is_illegaltest():
            request.skill_id = Rand.bound_uint32()
            request.skill_level = Rand.bound_uint32()
#         logging.debug("Do_CastSkill request=%s" % request)
        request.member = 1
        self.SendProtocol(CLI_TO_GS_CAST_SKILL, request)
        
    def On_SyncSkillResult(self, respond):  # 37
        logging.debug('On_SyncSkillResult_37 : %s' % respond)
        skillId = respond.skill_id
        self.skillid = respond.skill_id
        # 技能状态
        if skillId != self.family.skill.replaceSkill and skillId not in self.attackList:
            skill_time = time.time()
            if respond.skill_cd == 0:
                if skillId not in self.skillList:
                    self.skillList.append(skillId)
            elif skillId not in self.skillCdList or skillId in SKILL_STORAGE:
                if skillId in SKILL_CHANGE_CD:
                    skill_cd = SKILL_CHANGE_CD[skillId]
                else:
                    skill_cd = respond.skill_cd
                self.skillCdList.append({"id" : skillId, "cd" : skill_cd / 1000, "time" : skill_time})
        #更新技能cd
        self.UpdateSkillCd()
        if respond.skill_result == srcSuccess:
            if skillId in SKILL_COMBO:#连招技能
                def resetState():
                    if self.family.skill.isWaitingSkillCombo:
                        self.family.skill.isWaitingSkillCombo = False
                        logging.debug("二段技能在死亡时是收不到协议的，恢复技能释放")
                        self.ResetSkillState()
                if SKILL_COMBO[skillId] == COMBO_DOUBLE:
                    logging.debug("%s技能是二段技能" % skillId)
                    self.family.skill.isWaitingSkillCombo = True
                    self.family.skill.lastSkillId = skillId
                    gevent.spawn(resetState)
                    return
                elif SKILL_COMBO[skillId] == COMBO_MOVE:
                    logging.debug("%s技能攻击中移动" % skillId)
                    nowX = self.family.characterCur.posX
                    nowY = self.family.characterCur.posY
                    logging.debug("nowX=%s, nowY=%s" % (nowX, nowY))
                    self.Do_PlayerMove(nowX+3*random.uniform(-1, 1), nowY+3*random.uniform(-1, 1))
#                    gevent.sleep(2)
                    self.Do_PlayerStop()
                elif SKILL_COMBO[skillId] == COMBO_CHARGE:
                    sec = random.uniform(0.1, SKILL_CHARGE_SEC[skillId])
                    logging.debug("%s技能蓄力攻击, sec=%s" % (skillId, sec))
#                    gevent.sleep(sec)
                    self.CastChargeSkill(sec)
                elif SKILL_COMBO[skillId] == COMBO_TURN:
                    logging.debug("%s技能攻击中转向" % skillId)
                    for dir in range(0, 360, 15):
                        self.Do_PlayerTurn(self.family.characterCur.posX, self.family.characterCur.posY, dir)
#                        gevent.sleep(0.2)
                elif SKILL_COMBO[skillId] == COMBO_REPEAT:
                    if not self.family.skill.hasReleaseRepeatSkill:
                        self.family.skill.hasReleaseRepeatSkill = True
                        logging.debug("%s技能重复释放一次" % skillId)
#                        gevent.sleep(respond.skill_cd/1000.0)
                        self.Do_CastSkill(None, skillId, original_skill_id=self.family.skill.originSkillOfRepeatSkill)
                        return
                    else:
                        logging.debug("%s技能完成重复释放" % skillId)
                elif SKILL_COMBO[skillId] == COMBO_KID:
                    logging.debug("%s释放子技能" % skillId)
                    choose_id = SKILL_KID[skillId]
                    if choose_id in SKILL_NEED_TARGET and self.family.caseId == CaseManager.SKILLTEST and self.sceneTemplateId not in [SceneLinan]:
                        while not self.family.skill.skillTargetDict:
                            sceneId = self.sceneTemplateId
                            line = self.sceneInstanceId
                            self.AddHostileNpc(sceneId, line, self.family.characterCur.GetCharacterposX(), self.family.characterCur.GetCharacterposH(), self.family.characterCur.GetCharacterposY())
                            return
                        target_id = random.choice(self.family.skill.skillTargetDict.keys())
                        target_posX, target_posY, = self.family.skill.skillTargetDict[target_id]["pos"]
                        self.GM_MoveToPosition(False, target_posX,target_posY)
                        self.Do_CastSkill(None, choose_id, target_id=target_id, target_posX=target_posX, target_posY=target_posY, target_srcid=target_id)
                    else:
                        self.Do_CastSkill(None, choose_id)
        elif respond.skill_result == srcNotEnoughEnergy:
            faction = self.family.GetCurCharacter().faction
            if faction == EMEI:
                logging.debug("死亡会导致峨眉资源清零")
                self.AddEmeiSkillPointQinyi(5)
                self.AddEmeiSkillPointLianhua(15)
            elif faction == TIANREN:
                logging.debug("补充天忍技能资源点")
                self.AddTianrenSunSkillPoint(100)
                self.AddTianrenMoonSkillPoint(100)
        self.family.skill.isLastSkill = True
        if respond.skill_result != srcSuccess:
            self.ResetSkillState()
    
    #同步技能cdindex剩余时间（TODO:不知道cdidnex是啥，暂不做处理）
    def On_SkillCDInfoList(self, respond):
        logging.debug("On_SkillCDInfoList respond=%s" % respond)
        
    def ResetSkillState(self):
        logging.debug("ResetSkillState:%s" % self.canSkill)
#        if self.canSkill:
        if self.canSkill and not SKILL_KID.has_key(self.skillid):
            self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
    
    #更新技能cd
    def UpdateSkillCd(self):
        for skill in self.skillCdList[:]:
            if (time.time() - skill["time"]) > skill["cd"]:
                skill_id = skill["id"]
                if skill not in self.skillList:
                    self.skillList.append(skill_id)
                elif skill_id in SKILL_STORAGE and SKILL_STORAGE[skill_id]["origin"] > SKILL_STORAGE[skill_id]["now"]:
                    SKILL_STORAGE[skill_id]["now"] += 1
                self.skillCdList.remove(skill)
        logging.debug("self.skillCdList = %s" % str(self.skillCdList))
    
    #出现二段技能
    def On_ReplaceSkill(self, respond):
        logging.debug("On_ReplaceSkill respond=%s" % respond)
        if respond.replaceSkillID:
#            self.family.skill.isWaitingSkillCombo = False
            self.family.skill.replaceSkill = respond.replaceSkillID._values[0]
            logging.debug("释放二段技能%s, 一段技能是%s" % (self.family.skill.replaceSkill, self.family.skill.lastSkillId))
            if self.family.caseId == CaseManager.SKILLTEST and self.family.skill.replaceSkill in SKILL_NEED_TARGET :
                while not self.family.skill.skillTargetDict:
                    sceneId = self.sceneTemplateId
                    line = self.sceneInstanceId
                    self.AddHostileNpc(sceneId, line, self.family.characterCur.GetCharacterposX(), self.family.characterCur.GetCharacterposH(), self.family.characterCur.GetCharacterposY())
                    return
                target_id = random.choice(self.family.skill.skillTargetDict.keys())
                target_posX, target_posY, = self.family.skill.skillTargetDict[target_id]["pos"]
                self.GM_MoveToPosition(False, target_posX,target_posY)
                self.Do_CastSkill(None, self.family.skill.replaceSkill, original_skill_id=self.family.skill.lastSkillId,target_id=target_id, target_posX=target_posX, target_posY=target_posY, target_srcid=target_id)    
            else:
                self.Do_CastSkill(None, self.family.skill.replaceSkill, original_skill_id=self.family.skill.lastSkillId)

    #释放蓄力技能
    def CastChargeSkill(self, sec):
        request = CastChargeSkill()
        request.chargeSec = sec
        self.SendProtocol(CLI_TO_GS_CAST_CHARGE_SKILL, request)
    
    def On_SyncCastSkill(self, respond):  # 32
#         logging.debug('On_SyncCastSkill_32 : %s' % respond)
        # print respond
        pass

    def On_SyncSkillState(self, respond):  # 36
        '''     
            scsInvalid = 0,
            scsNotCast = 1,
            scsWaitCast = 2,
            scsPrepare = 3,
            scsRecover = 4,
            scsMoveRecover = 5,
            scsChannel = 6,
            scsTotal = 7
        '''
        logging.debug('On_SyncSkillState_36 : %s ,isLastSkill = %s, characterCurId=%s' % (respond, self.family.skill.isLastSkill, self.family.characterCur.playerId))
        if self.family.skill.isLastSkill \
        and respond.id == self.family.characterCur.playerId \
        and respond.skill_state == 1:
            self.ResetSkillState()
            
    def On_SyncPlayerSkillData(self, respond):
        logging.debug("On_SyncPlayerSkillData respond=%s" % respond)
        character = self.family.GetCharacterByPlayerId(respond.id) 
        if character:
            skillList = []
            for skillId in respond.skillButtonSkillId:
                skillList.append(skillId)
            character.attackList = FACTION_SKILL[character.faction][0]  # 普攻
            character.skillList = skillList  # 技能
            logging.debug("characterId=%s, skillButtonSkillList=%s" % (respond.id, skillList))
    
    def On_SkillHit(self, respond):  # 33
#         logging.debug('On_SkillHit_33 : %s' % respond)
        pass

    def On_SkillMissileLaunch(self, respond):  # 39
#         logging.debug('On_SkillMissileLaunch_39 : %s' % respond)
        pass

    # ========================================
    # VIP领取奖励
    def ApplyGetVipAward(self):
        request = ApplyGetVipAward()
        request.vipLevel = 1
        self.SendProtocol(CLI_TO_GS_GET_VIP_AWARD, request)

    # 创建充值订单-模拟充值
    def ClientCreatePayOrderReq(self):
        request = ClientCreatePayOrderReq()
        request.productId = 1
        request.productCount = 1
        request.totalAmount = 100
        request.payAmount = 1
        request.gainGold = 100
        request.extraGold = 100
        self.SendProtocol(CLI_TO_GS_CREATE_PAY_ORDER, request)

    # ========================================
    # 领取福利-升级大礼
    def GetLevelGift(self, level=20):  # 482
        request = ApplyAchieveAward()
        request.achieveId = level
        self.SendProtocol(CLI_TO_GS_APPLY_LEVEL_GIFT, request)

    # 福利-每日签到


    # 进入品茶室
    def ApplyEnterTeaRoom(self):
        request = ApplyEnterTeaRoom()
        self.SendProtocol(CLI_TO_GS_APPLY_ENTER_TEA_ROOM, request)

    # 进入品茶室响应
    def On_SyncEnterTeaRoomRes(self, respond):  # 650
        logging.debug('%s' % respond)
        self.family.SetState(STATE_GS_WELFARE_ENTER_TEAROOM)  # 已进入
        pass

    # 离开品茶室响应
    def On_SyncLeavingTeaRoom(self, respond):  # 651
        logging.debug('%s' % respond)
        pass

    # 获得品茶室奖励
    def On_SyncTasteTeaAward(self, respond):  # 653
        logging.debug('%s' % respond)
        if respond.awardGrade > 0:
            self.family.SetState(STATE_GS_WELFARE_GOOD_TEA)
        pass

    # 同步闲聊说的话
    def On_SyncTeaRoomTalkingContent(self, respond):  #
        logging.debug('%s' % respond)
        pass

    # 同步玩家在茶室的状态
    def On_SyncTasteTeaState(self, respond):  # 652
        logging.debug('%s' % respond)
        pass

    # 领取稀有茶品
    def ApplyGrabTeaRoomAward(self):
        request = ApplyGrabTeaRoomAward()
        self.SendProtocol(CLI_TO_GS_GRAB_TEA_ROOM_AWARD, request)

    # 领取稀有茶品通知
    def On_SyncGrabTeaInfo(self, respond):
        logging.debug('On_SyncGrabTeaInfo %s' % respond)
        self.family.SetState(STATE_GS_WELFARE_WAIT)
        pass

    def CreatePayOrder(self, productId='com.wali.jianxiashijie3D.648rmb'):
        request = ClientCreatePayOrderReq()
        request.productId = productId
        self.SendProtocol(CLI_TO_GS_CREATE_PAY_ORDER, request)

    def On_CreatePayOrderMsg(self, respond):
        if respond.result == SUCCESS:
            self.family.SetState(STATE_GS_PLAYING)

    # 获得摇钱树奖励
    def GetMoneyTreeAward(self):
        request = ApplyGetMoneyTreeAward()
        self.SendProtocol(CLI_TO_GS_APPLY_GET_MONEY_TREE_AWARD, request)

    def On_SyncMoneyTreeAward(self, respond):
#         logging.debug('SyncMoneyTreeAward')
        self.family.SetState(STATE_GS_PLAYING)
        pass

    # 同步摇钱树数据
    def On_SyncMoneyTreeData(self, respond):
#         logging.debug('%s' % respond)
        pass

    def On_SyncRemoveTeaAward(self, respond):
#         logging.debug('%s' % respond)
        pass

    def AskNpc(self, npc_name):
        if npc_name in self.sceneNPCDict:
            request = AskNpc()
            request.npcId = self.sceneNPCDict[npc_name]
            self.SendProtocol(CLI_TO_GS_ASK_NPC, request)
        else:
            logging.debug("NPC名称未找到 name = %s; sceneNPCDict = %s" % (npc_name, str(self.sceneNPCDict)))

    def AskNpc_obj(self, npc_id):
        request = AskNpc()
        request.npcId = npc_id
        self.SendProtocol(CLI_TO_GS_ASK_NPC, request)
        
    def GetNpcID(self, npc_name, is_fuzzy=False):
        if npc_name in self.sceneNPCDict:
            return self.sceneNPCDict[npc_name]
        if is_fuzzy:
            for key in self.sceneNPCDict.keys():
                if npc_name in key:
                    return self.sceneNPCDict[key]
        return None
    
    def On_DialogInfo(self, respond):
#         logging.debug("On_DialogInfo respond=%s" % respond)
        self.family.dialog.Update(respond)
        for i in range(len(respond.optionList._values)):
            content0 = respond.optionList._values[i].optionText.encode("utf8")
            if '贺察' in self.sceneNPCDict and respond.dialogCtrl.npcId == self.sceneNPCDict['贺察']:
                self.family.SetState(STATE_GS_WELFARE_TEAROOM_NPC)
            elif '马三' in self.sceneNPCDict and respond.dialogCtrl.npcId == self.sceneNPCDict['马三'] & self.family.GetState() == STATE_GS_ASSIST_WAIT:
                self.family.SetState(STATE_GS_ASSIST_ENTERMISSION)
            elif self.family.GetState() == STATE_GS_GRAVEDIGGER_WAIT and "这是一个幽深的入口" in content0:
                logging.debug("进入地宫入口")
                for item in respond.optionList:
                    if item.optionText.encode("utf8") == "进入地宫":
                        self.AnswerDialog(respond.dialogType, respond.dialogId, respond.dialogCtrl.npcId, item.optionText, item.optionIndex)
                        break
            
            if self.family.caseId == CaseManager.GODDESS and content0 == "388块莺华玉就可以在希子这里兑换女神节特殊称号以及音乐炫光礼盒了哦！":
                self.AnswerDialog(respond.dialogType, respond.dialogId, respond.dialogCtrl.npcId, respond.menuList[0].btnName, 0)
                self.family.SetState(STATE_GS_GODDESS_BUY_FASHION)
            
            if self.family.caseId == CaseManager.BATTLE:
                if '午铭' in self.sceneNPCDict and respond.dialogCtrl.npcId == self.sceneNPCDict['午铭']:
                    for item in respond.optionList:
                        if item.optionText.encode("utf8") == "襄北演武":
                            self.family.SetState(STATE_GS_BATTLE_ENTER)
    #                        self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", item.optionIndex)
                            break
                elif self.family.characterCur.state == CHAR_STATE_DEATH and respond.dialogType == 'deathtip':
                    self.canSkill = False
                    self.family.SetState(STATE_GS_BATTLE_WAIT_ALIVE)
                    for item in respond.optionList:
                        # "回重生点#false#4"
                        result = re.match("回重生点#(\w+)#(\d+)", item.optionText.encode("utf8"))
                        if result:
    #                        if result.group(1).lower() == 'false':
    #                            gevent.sleep(int(result.group(2)))
                            self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", item.optionIndex)
                            break
            elif self.family.caseId == CaseManager.JIAZU and respond.dialogType == "deathtip":
                logging.debug("家族案例复活")
                for item in respond.optionList:
                    if "复活" in item.optionText.encode("utf8"):
                        self.MarkTestCase("TestCase_Kin_Revival")
                        self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", item.optionIndex)
                        break
            elif self.family.caseId == CaseManager.DAMIJING:
                if len(respond.contentList._values) >0:
                    if '队伍可进入衡虚境' in respond.contentList._values[0].encode("utf8"):
                        self.AnswerDialog("poppanel", respond.sequenceId, 0, "", 2)  
                if respond.dialogType == "deathtip":
                    for item in respond.optionList:
                        result = re.match("复活\((\d+)/(\d+)\)#(\w+)#(\d+)", item.optionText.encode("utf8"))
                        if result:
                            count = int(result.group(1))
                            maxCount = int(result.group(2))
                            canClick = True if result.group(3).lower() == 'true' else False
                            waitTime = int(result.group(4))
                            if count < maxCount:
            #                        if not canClick and waitTime > 0:
            #                            gevent.sleep(waitTime)
                                self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", item.optionIndex)
                            break
            elif self.family.caseId == CaseManager.VALENTINE:
                if content0 in ["带有缘人来参加", "烟花·真爱永随" , "烟花·多彩流光" ]:
                    self.AnswerDialog(respond.dialogType, respond.sequenceId, self.family.valentine.yuexialaoer, "", 1)
                    return
                elif "领取" in content0:
                    self.AnswerDialog(respond.dialogType, respond.sequenceId, self.family.valentine.yuexialaoer, "", 2)
                    return
            elif self.family.caseId == CaseManager.ACTIVITY_NEWYEAR:
                if content0 in ["发送"]:
                    self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", 2)
                    self.family.SetState(STATE_GS_ACTIVITY_NEWYEAR_PICKED)
                    return
            elif self.family.caseId == CaseManager.SKILLTEST and respond.dialogType == "poppanel":
                self.AnswerDialog(respond.dialogType, respond.dialogId, respond.dialogCtrl.npcId, "", 1)
                return
            
            elif self.family.caseId == CaseManager.INSTANCE:
                if respond.dialogType ==  "deathtip":
                    self.AnswerDialog(respond.dialogType, respond.sequenceId, 0, "", 2) 
                    self.family.SetState(STATE_GS_GOLD_DEER_FIGHT)
                    self.family.instance.isfight = True 
     
        
    #应答NPC    
    def AnswerDialog(self, dialogType, dialogId, npcId, btnName, selIndex):
        request = AnswerDialog()
        request.type = dialogType
        request.dialogId = dialogId
        request.npcId = npcId
        request.btnName = btnName
        request.selIndex = selIndex
        self.SendProtocol(CLI_TO_GS_ANSWER_NPC, request)
        
    # ========================================

    # 请求场景的当前线的信息（编号，负载）309
    def Get_LineInfo(self):
        self.SendProtocol(CLI_TO_GS_GET_SCENE_LINE_INFO)

    # 请求场景当前线信息响应324
    def On_SceneLineInfo(self, respond):
        logging.debug('SceneLineInfo_respond : %s' % respond)
        self.family.lineInfo.lineInfo = respond
        self.line_id = respond.line_id
        #判断是否已执行过换线
        if self.family.GetState() == STATE_GS_LINE_SWITCH_WAIT:
            if respond.line_id == self.switchLineId:#判断是否换线成功
                logging.debug("换线成功了！")
                self.Switch_SceneLineSuccess(self.switchLineId)
            else:
                logging.debug("line_id : %s != switchLineId : %s ; 继续换线" % (respond.line_id, self.switchLineId))
                self.Switch_SceneLine(self.switchLineId)
        else:
            self.family.SetState(STATE_GS_LINE_LIST)

    # 请求场景的所有分线列表310
    def Get_LineList(self):
        self.SendProtocol(CLI_TO_GS_GET_SCENE_LINE_LIST)

    # 请求场景所有分线列表响应325
    def On_SceneLineListResult(self, respond):
        logging.debug('SceneLineListResult_respond : %s' % respond)
        self.family.lineInfo.lineList = respond
        if self.family.state == STATE_GS_LINE_LIST_WAIT:
            # 啥也不干只是单纯获取线路信息，放在案例里面去判断
            pass
        elif self.family.state == STATE_GS_RANDOMMOVE_LINELIST:
            for line in respond.lines:
                if line.player_count < line.max_player_count:
                    self.switchLineId = line.line_id
                    break
            if not self.switchLineId:
                logging.debug("未找到合适线路，直接执行后面流程")
                self.family.SetState(STATE_GS_MOVE_GO)
                return
            elif self.switchLineId == self.line_id:
                logging.debug("所选线路跟目前线路相同，直接执行后面流程")
                self.family.SetState(STATE_GS_MOVE_GO)
                return
        else:
            # 存储线路
            if self.bossLine:
                BossLineList = [line.line_id for line in respond.lines if line.hasboss and (line.player_count < line.max_player_count)]
                if BossLineList and self.line_id not in BossLineList:
                    self.switchLineId = random.choice(BossLineList)
                else:
                    self.family.SetState(STATE_GC_BOSS_TEAM_LIST)  # Boss组队
                return
            else:
                other_lines =  [line.line_id for line in respond.lines if (line.player_count < line.max_player_count) and (line.line_id!=self.line_id)]
                if other_lines:
                    self.switchLineId = random.choice(other_lines)
                else:
                    self.MarkTestCase("TestCase_ChangeLine_NoLineSwitch")
#                    gevent.sleep(5)
                    self.family.SetState(STATE_GS_PLAYING)
                    return
                
        logging.debug("switchLineId : %s > 0" % self.switchLineId)
        self.family.SetState(STATE_GS_LINE_SWITCH)
            

    # 切换线路
    def Switch_SceneLine(self, line_numb):
        if Config.is_illegaltest():
            line_numb = Rand.bound_uint32()
        self.CallScript("PlayerCmd", "SwitchSceneLine", line_numb)

    # 换线成功
    def Switch_SceneLineSuccess(self, linenumb):
        logging.debug('Switch_SceneLine %d Success' % linenumb)
        self.family.SetState(STATE_GS_LINE_SWITCH_SUCCESS)
    
    #切线失败，目标线人数已满
    def On_SwitchSceneLineError(self, respond):
        logging.debug("切线失败，目标线人数已满；再去请求一次线路列表")
        self.family.SetState(STATE_GS_LINE_LIST)
    
    # 护法招募214
    def RecruitGuardian(self, guardianid):
        request = ApplyRecruitGuardian()
        request.guardianId = guardianid
        if Config.is_illegaltest():
            request.guardianId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_RECRUIT_GUARDINA, request)

    def On_SyncGuardianRecruitRes(self, respond):
        if self.family.caseId in [CaseManager.GUARDIAN]:
            if respond.result:
                self.family.SetState(STATE_GS_GUARDIAN_ACTIVE)
            else:
                logging.debug('GuardianRecruit Error : %s' % respond)
            pass

    # 护法上阵208
    def ActiveGuardian(self, guardianid, bActive):
        request = ApplyActiveGuardian()
        request.bActive = bActive
        request.slotIndex = 0  # 护法槽
        request.guardianId = guardianid
        if Config.is_illegaltest():
            request.guardianId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_ACTIVE_GUARDIAN, request)

    def On_ActiveGuardianResult(self, respond):
        logging.debug('ActiveGuardian %s' % respond)
        if respond.result:
            if respond.bActive:
                self.family.SetState(STATE_GS_GUARDIAN_SECOND_TRANSFER)
            else:
                self.family.SetState(STATE_GS_GUARDIAN_END)
        else:
            logging.debug('ActiveGuardian Error : %s' % respond)
            self.family.SetState(STATE_GS_GUARDIAN_END)
    # 护法添加经验
    def ApplyGuardianUseExpItem(self,GuardianID):
        self.CallScript("GuardianCmd", "ApplyUseExpItem", GuardianID, 1.0)
    
    # 护法洗髓丹
    def ApplyGuardianResetAptitude(self,GuardianID):
        self.CallScript("GuardianCmd", "ApplyResetAptitude", GuardianID)
        
    # 护法应用当前洗髓值    
    def ApplySelectLastAptitude(self,GuardianID):
        self.CallScript("GuardianCmd", "ApplySelectLastAptitude", GuardianID, 1.0)
    # 拜访护法209
    def VisitGuardian(self, guardianid):
        self.visitGuardianId = guardianid
        request = ApplyVisitGuardian()
        request.guardianId = guardianid
        request.free_visit = True
        # if Config.is_illegaltest():
        #     request.guardianId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_VISIT_GUARDIAN, request)
    
    # 拜访护法响应
    def On_VisitGuardianResult(self, respond):
        if self.family.caseId in [CaseManager.GUARDIAN]:
            logging.debug('VisitGuardianResult_id = %s, result = %s,free_visit_times = %s' % (
            respond.guardianId, respond.result, respond.free_visit_times))
            if respond.guardianId == self.visitGuardianId:
                self.MarkTestCase("TestCase_Guardian_VisitGuardian")
                self.family.SetState(STATE_GS_GUARDIAN_INACTIVE)
    #             return
            else:
                self.family.SetState(STATE_GS_GUARDIAN_TRANSFER)
            
    def On_SyncGuardianAddExp(self, respond):
        pass

    def On_SyncGuardianUnLock(self, respond):
        pass

    def On_SyncGuardianSlotOpen(self, respond):
        pass
    
    def On_FamilyGuardianDbData(self,respond):
        logging.debug("On_BuyShopItemResult respond=%s" % respond)
        self.guardiansecondlist=[]
        for i in range(len(respond.totalVisitTimes._values)):
            self.guardiansecondlist.append(respond.totalVisitTimes._values[i])
        logging.debug("FamilyGuardianDbData respond=%s" % respond)
    # 购买物品205（默认购买银币商店药品）
    def ApplyBuyShopItem(self, shopId=1, goodIndex=0, buyCount=1, goodsSequence=-1):
        request = ApplyBuyShopItem()
        request.shopId = shopId
        request.goodIndex = goodIndex
        request.buyCount = buyCount
        if goodsSequence >= 0:
            request.goodsSequence = goodsSequence
        if Config.is_illegaltest():
            request.shopId = Rand.bound_uint32()
            request.goodIndex = Rand.bound_uint32()
            request.buyCount = Rand.bound_uint32()
        logging.debug("ApplyBuyShopItem request=%s" % request)
        self.SendProtocol(CLI_TO_GS_BUY_SHOP_ITEM, request)

    # 购买商品响应
    def On_BuyShopItemResult(self, respond):
        logging.debug("On_BuyShopItemResult respond=%s" % respond)
        if self.family.GetState() in [STATE_GS_KIN_WAIT, STATE_GS_SHOP_WAIT_RESULT]:
            self.family.SetState(STATE_GS_SHOP_RESULT)
        if self.family.GetState() == STATE_GS_SHOP_ONLINE_BUY_VIP_WAIT:  # 在线商城购买VIP结果
            self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_VIP_RESULT)
        if self.family.GetState() == STATE_GS_SHOP_ONLINE_BUY_GOLD_SHOP_WAIT:  # 在线商城购买鎏金宝阁结果
            self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_GOLD_SHOP_RESULT)
        if self.family.GetState() == STATE_GS_SHOP_ONLINE_BUY_SILVER_SHOP_WAIT:  # 在线商城购买VIP专享商品结果
            self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_SILVER_SHOP_RESULT)
        self.family.notifyState.set_state(NotifyState.STATE_GS_SHOP_RESULT)

    def SetGoldNumber(self, productId="jxsj2.yuanbao.rmb648"):  # GM内部模拟充值（1-5）10000元宝
        '''
            data/sheet/pay/cnyproduct.txt
        '''
        self.CallScriptGmDoCommand("me:GMSimulateRecharge(\"%s\", 0);" % productId)
    
    #通知充值成功
    def On_NotifyPaySuccess(self, respond):
        logging.debug("充值成功")
        if self.family.GetState() == STATE_GS_SHOP_ONLINE_GOLD_CHARGE_WAIT:
#            gevent.sleep(1)
            self.family.SetState(STATE_GS_SHOP_ONLINE_GOLD_CHARGE_RESULT)  # GM内部模拟充值结果
        elif self.family.GetState() == STATE_GS_SHOP_ONLINE_BUY_GIFT_PACKAGE_WAIT:
#            gevent.sleep(1)
            self.family.SetState(STATE_GS_SHOP_ONLINE_BUY_GIFT_PACKAGE_RESULT)  # GM内部模拟购买超值礼包
    
    def ApplyBuyOnlineShopItem(self, shopId=1, goodIndex=1, buyCount=1):
        request = ApplyBuyShopItem()
        request.shopId = shopId
        request.goodIndex = goodIndex
        request.buyCount = buyCount
        if Config.is_illegaltest():
            request.shopId = Rand.bound_uint32()
            request.goodIndex = Rand.bound_uint32()
            request.buyCount = Rand.bound_uint32()
        logging.debug("ApplyBuyOnlineShopItem request=%s" % request)
        self.SendProtocol(CLI_TO_GS_BUY_SHOP_ITEM, request)
    
    #清除在线商城购买次数
    def CleanShopOnlineBuyLimit(self):
        for i in [1, 2]:
            self.CallScriptGmDoCommand("me:SetDataInt(107, %d, 1);" % i)
    
    def GM_GetDesignation(self, id):        # GM开启称号，id就是称号对应的id，最后一个数字改为0就是关闭
        self.CallScriptGmDoCommand("me:SetDataInt(123, %d, 1);" % id)

    def FamilyTitle_SetActive(self, titleID1=0, titleID2=0, effectTitleId=0):   # 装备称号，titleID1（江湖/个性前缀），titleID2（个性后缀），effectTitleId（炫光）
        request = FamilyTitle_SetActive()
        request.familyId = 0
        request.titleId1 = titleID1
        request.titleId2 = titleID2
        request.effectTitleId = effectTitleId
        logging.debug('装备称号发送: %s' % request)
        self.MarkTestCase("TestCase_Designation_SetActive")
        self.SendProtocol(CLI_TO_GS_FAMILYTITLE_SETACTIVE, request)


#     def On_SyncAllRedoData(self, respond):
#         if self.family.caseId in [CaseManager.TRADEHOUSE, CaseManager.TRADEHOUSE_DATA, CaseManager.DATACHECKER]:#拍卖行不执行奖励补领
#             return
#         logging.debug("On_SyncAllRedoData respond = %s"% respond)
#         if respond.redoActivityData.redoData:
#             for data in respond.redoActivityData.redoData:
#                 if data.activityId >= 0 and data.maxCanBuyCommTimes > 0:
#                     self.ApplyBuyActivityRedo(data.activityId)
#                     break
    
    #奖励补领
    def ApplyBuyActivityRedo(self, id):
        self.CallScript('PlayerCmd', 'GainRedoAward', id,1.0)

    def GM_GetToken(self, token):
        self.CallScriptGmDoCommand("KItem.AddStackItem(%d,5,1,35,%d,1,0,false,0)" % (self.familyId, token))

    # def Cli_Activity_Join(self):    # 参加国庆节日活动
    #     self.CallScript("PlayerCmd", "ActivityOnClick", 4.0)

    def SetUpFire(self, nItemId):     # 放烟花
        logging.debug('放烟花')
        request = UseItem()
        request.itemId = nItemId
        request.member = 1
        request.useCount = 1
        self.SendProtocol(CLI_TO_GS_USE_ITEM, request)

    def GetLogin7Reward(self):      # 领取7日好礼
        request = GetLogin7RewardApply()
        request.dayIndex = 1
        self.SendProtocol(CLI_TO_GS_GET_LOGIN7_REWARD_NEW,request)

    # GM完成主线任务，如果taskid=999，这个函数会非常耗
    def GM_FinishMainTaskToId(self, taskId=999):  
        self.CallScriptGmDoCommand("me:FinishMainTaskToId(%d);" % taskId)
 
    def On_SyncNewAchieveComplete(self, respond):
        for i in respond.achieveId._values:
            self.ApplyAchieveAward(i)

    # 领取成就的等级奖励
    def ApplyAchieveAward(self, achieveId=1):
        respond = ApplyAchieveAward()
        respond.achieveId = achieveId
        if Config.is_illegaltest():
            respond.achieveId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_APPLY_ACHIEVE_AWARD, respond)
    
    def ChangePKMode(self, pk_mode_type):
        self.CallScript("PlayerCmd", "ChangePKMode", pk_mode_type)


    def LeaveSingleMission(self, cur_member=1):
        request = LeaveSingleMission()
        request.curMember = cur_member
        # if Config.is_illegaltest():
        #     request.curMember = Rand.bound_uint32(FAMILY_MEMBER_TYPE_NULL, FAMILY_MEMBER_TYPE_MAX)
        self.SendProtocol(CLI_TO_GS_LEAVE_SINGLE_MISSION, request)
        
    # ---逍遥谷---
    # 进行匹配
    def Do_AttandXoyoGame(self, Type=1):
        '''
        Type 1 : 简单
                  2 : 普通
                  3 : 困难
        '''
        self.CallScript("PlayerCmd", "AttandXoyoGame", Type)
    
    #取消逍遥谷匹配
    def CancelXoyoGame(self):
        self.CallScript("PlayerCmd", "CancelXoyoGame")
    
    # ---小秘境---
    #进入小秘境副本邀请
    def ApplySecretRealmGame(self):
        index = random.randint(1, 2)
        self.CallScript("JiuZhouCmd", "ApplyJiuZhouGame", 1.0)
    
    #应答进入小秘境副本
    def ReplayOpenSecretRealmGame(self, index=1.0):
        self.CallScript("SecretRealmCmd", "ReplayOpenSecretRealmGame", index)
    
    def InviteMemberJoinActivityResult(self, result=0):
        if self.family.caseId == CaseManager.GRAVEDIGGER:
            self.CallGcScript("PlayerCmd", "InviteMemberJoinActivityResult", result)
        else:
            self.CallScript("PlayerCmd", "InviteMemberJoinActivityResult", self.familyId, result)
            
    # 远程调用客户端脚步响应
    def On_ClientScript(self, respond):
        logging.debug("On_ClientScript %s " % respond.script.encode('utf8'))
        # 队长开启探宝,跳出探宝界面
        script = respond.script.encode("utf8")
        # 公共组队活动应答
        if 'Team:LeaderInviteJoinActivity' in script:
            if self.family.team_manager.myteam.leadergroupid == self.family.serverGroupId or self.family.KUAFU == False:
                self.CallGcScript("PlayerCmd", "JoinActivityVote", 1)
            else:
                self.family.KuaFuGroupId = self.family.team_manager.myteam.leadergroupid
                self.CallGcScript("PlayerCmd", "JoinActivityVote", 1)
                self.family.KuaFuGroupId = self.family.serverGroupId
            return
        
        if "Team:InviteMemberJoinActivityFromGs" in script:
            self.family.team_manager.myteam.join_active_rsp = False
            self.family.team_manager.myteam.memberCheckList = []
            result = re.match('{\"Team:InviteMemberJoinActivityFromGs\",(\d+),}', script)
            if result:
                wait_time = int(result.group(1))
                self.CallGcScript("PlayerCmd", "LeaderInviteJoinActivity", wait_time, 0)
            return
        if "Team:InviteMemberJoinActivityFromGc" in script:
            self.family.team_manager.myteam.join_active_rsp = False
            self.family.team_manager.myteam.memberCheckList = []
            result = re.match('{\"Team:InviteMemberJoinActivityFromGc\",(\d+),}', script)
            if result:
                wait_time = int(result.group(1))
                self.CallGcScript("PlayerCmd", "LeaderInviteJoinActivity", wait_time, 0)
            return
        if 'Team:ReceiveLeaderInviteJoinActivity' in script:
            if self.family.team_manager.myteam.leadergroupid == self.family.serverGroupId or self.family.KUAFU == False:
                self.CallGcScript("PlayerCmd", "JoinActivityVote", 1)
            else:
                self.family.KuaFuGroupId = self.family.team_manager.myteam.leadergroupid
                self.CallGcScript("PlayerCmd", "JoinActivityVote", 1)
                self.family.KuaFuGroupId = self.family.serverGroupId
            return
        result = re.match('{\"Team:RecieveMemberVote\",(\d+),(\d+),}', script)
        if result:
            id = int(result.group(1))
            choice = int(result.group(2))
            member_checklist = self.family.team_manager.myteam.memberCheckList
            if id not in member_checklist:
                if choice == 1:
                    member_checklist.append(id)
                    if len(member_checklist) + 1 == self.family.team_manager.myteam.MemberCount():
                        self.InviteMemberJoinActivityResult(1)
                else:
                    self.InviteMemberJoinActivityResult(0)
            return
                     
        if "Item:OnSignetHoleLevelResult" in script:
            self.MarkTestCase("TestCase_Equip_OpenSignetHole")      
            return       
             
        #换线
        if script == "{\"me:PopTips\",\"您当前正在此线\",}" and self.family.caseId == CaseManager.CHANGELINE:
            logging.debug("当前已在所选线路，再去获取一次分线列表")
            self.family.SetState(STATE_GS_LINE_LIST)
            return
        
        if script == "{\"Activity:GoPosTalkToNpc\",2001,203.1,149.7,15005,}":
            logging.debug('参加节日活动成功')
            return
        
        # 领取孔明灯道具
        if 'GetLanternReplyUi' in script:
            self.family.SetState(STATE_GS_SKYLANTERN_GET_LANTERN)
            return

        # 放孔明灯
        if 'PutLanternReplyUi' in script:
            self.family.SetState(STATE_GS_SKYLANTERN_PUT_LANTERN)
            return

        if '一盏两盏孔明灯，放飞希望，共享友谊，愿你有更美的江湖' in script:
            self.family.SetState(STATE_GS_SKYLANTERN_PUT_LANTERN_SUCCEED)
            return
        
        #女神节活动
        if "系统返还了50%绑定元宝" in script:
            self.MarkTestCase("TestCase_Goddess_ReturnGold")
            return
            
        #游历护法
        if "Event.tbGuardRefresh:OnSyncCurrRefreshData" in script:
            self.family.guardian.guardianDict = json.loads('{"%s}' % script[script.find(",{[")+2:script.find(",},}")+2].replace("[", "").replace("]", "").replace(",}", "}").replace("=", ":").replace("{", "[").replace("}", "]").replace("],", '],"').replace(":", '":'))
            logging.debug("游历护法dict = %s" % self.family.guardian.guardianDict)
            return
            
        if script == "{\"Boss:OpenDeathUi\",}":
            self.BossRevival(1)  # 原地复活
            return
        elif script == "{\"Player:OpenDeathUi\",}":
            self.DefaultRevival(1) # 原地复活
            return
        if self.family.caseId == CaseManager.VALENTINE:
            if "领取到了一个烟花" in script:
                self.family.SetState(STATE_GS_VALENTINE_FIREWORKS)
                return
            elif "领取到了一个火柴" in script:
                self.family.SetState(STATE_GS_VALENTINE_FIRE_WAIT)
                return
            elif "烟花摆放成功" in script:
                self.family.SetState(STATE_GS_VALENTINE_FIRE)
                return
            elif "燃放成功" in script:
                self.family.SetState(STATE_GS_VALENTINE_END)
                return
        if self.family.caseId == CaseManager.EATCHICKEN:
            if "LiveGame:OnStartMatch" in script:
                self.MarkTestCase("TestCast_EatChicken_SignUp_Succsee")
                return
            elif "LiveGame:OnStartFly" in script:
                self.CallScript("LogCmd", "LogQinggongStage", 0)
                return 
            elif "KScene.ChangeBoundingCircleScale" in script:
                '''
                "{\"KScene.ChangeBoundingCircleScale\",\"Duquan\",{712.96120134424,27.650783538818,911.27590089469,10,},10,10,28,1,}"
                '''
                result = re.search('KScene.ChangeBoundingCircleScale.*{(\d+)\.\d+,(\d+)\.\d+,(\d+)\.\d+', script)
                if result:
                    self.family.eatchicken.SetMovePos(int(result.group(1)), int(result.group(2)), int(result.group(3)))
                    self.family.SetState(STATE_GS_EAT_CHICKEN_SKILL)
                    return
            elif "Scene.EnableBoundingCircleEffect" in script:
                '''
                "{\"KScene.EnableBoundingCircleEffect\",\"Duquan\",{1024,21.2,1024,},1600,1200,1,}"
                '''
                a = script.split(',{')[1].split(',}')[0].split(',')
                self.family.eatchicken.SetMovePos(int(float(a[0])), int(float(a[1])), int(float(a[2])))
                self.family.SetState(STATE_GS_EAT_CHICKEN_SKILL)
                return
            elif "LiveGame:OnDeath" in script:
                self.CallScript("PlayerCmd", "LiveGameApplyLeave")
                self.MarkTestCase("TestCast_EatChicken_OnDeath")
                self.family.eatchicken.isdeath = True
                self.family.SetState(STATE_GS_EAT_CHICKEN_END)
                return 
            
            elif "LiveGame:OnLeaveMission" in script:
                self.family.SetState(STATE_GS_EAT_CHICKEN_END)
                return
            
        if self.family.caseId == CaseManager.BIGFIGHT:
            if "ChaosFight:Match_OnJoinSuccess" in script:
                self.family.SetState(STATE_GS_BIGFIGHT_SIGNUP_SUCCESS)
                return
            
            elif "ChaosFight:GSMissionEnd" in script:
                self.family.SetState(STATE_GS_BIGFIGHT_END)  
                return
            elif "被 [d32a2a]" and "[-] 击败了" in script:
                self.family.SetState(STATE_GS_BIGFIGHT_DEATH)
                return
        if self.family.caseId == CaseManager.CROSSBATTLE:
            if "NVN:OnStartFight" in script:
                self.family.SetState(STATE_GS_CROSSBATTLE_FIGHT)
                return
            elif "NVN:OnSyncResult" in script:
                self.family.SetState(STATE_GS_CROSSBATTLE_END)
                return
            elif "进入了约战房间" in script:
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                return
            elif "5秒后将进入战场" in script:
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                return
            elif "不在准备场" in script:
                self.family.SetState(STATE_GS_CROSSBATTLE_WAIT)
                return 
            
        if self.family.caseId == CaseManager.FISHING:
            if script == "{\"Fishing:AcceptFishingTaskSucc\",}":
                logging.debug('SyncAcceptFishTaskRes: %s' % script)
                self.family.SetState(STATE_GS_FISHING_ACCEPT_TASK)
                return
            
            elif "Fishing:OnBuyFishBaitSucc" in script :
                self.family.SetState(STATE_GS_FISHING_BAIT)
                return
            elif "Fishing:SyncFishPoolData" in script:
                logging.debug("On_SyncNewFishInHooking")
                logging.debug(script)
                self.MarkTestCase("TestCase_Fishing_NewFishInHooking")
                del self.family.fish_list[:]
                ss = "{\\\"Fishing:SyncFishPoolData\\\",{(.*)},}"
                a = re.match(ss,script)
                if a is not None and 1 == len(a.groups()):
                    b=list(a.groups())
                    c=b[0].split(",")
                    for i in range( len(c)-1):
                        self.family.fish_list.append(int(c[i]))
                self.family.SetState(STAGE_GS_FISHING_IN_HOOKING)
                return
            elif "Fishing:OnFinishFishingTask" in script:
                self.MarkTestCase("TestCase_Finish_Fishing")
                # 交任务结算的奖励才改变状态，分享获得的奖励不改变状态
                if self.family.GetState() == STATE_GS_FISHING_AWARD_WAIT:
                    self.family.SetState(STATE_GS_FISHING_AWARD)
                return    
            elif script == "{\"me:PopTips\",\"您当前没钓到这种鱼\",}":
                self.family.SetState(STATE_GS_FISHING_BEGIN)
                return
            elif "Fishing:GetOneFishBySelf" in script: 
                self.MarkTestCase("TestCase_Fishing_GetOneFish")
                Fishing_Treatment = {
                                        1 : 1,       #分享
                                        0 : 1,        #不分享
                                    }
                self.Treatmen = Rand.weighted_choice(Fishing_Treatment)#根据权重分享鱼
                if self.Treatmen ==1 and self.family.team_manager.myteam.IsInTeam():
                    self.family.SetState(STATE_GS_FISHING_SHARE)
                else:
                    self.family.SetState(STATE_GS_FISHING_BEGIN)
                return
        if self.family.caseId == CaseManager.GRAVEDIGGER:
            if script == "{\"SeekTreasure:OpenPutInClueUI\",\"[5,1,9,3,5,1,9,4,5,1,9,5]\",}":
                logging.debug("OpenPutInClueUi")
                self.family.SetState(STATE_GS_GRAVEDIGGER_PUTINCLUEITEM)
                return
            # 弹出藏宝图信息
            script_format = script.replace("\\", "").split(":")
            if len(script_format) > 1:
                if script_format[1].startswith("OpenTreasureMapUI"):
                    if not len(script_format) == 11:
                        return
                    self.family.graveDigger.mapid = int(re.findall(r'(\w*[0-9]+)\w*', script_format[2])[0])
                    A = [int(re.findall(r'(\w*[0-9]+)\w*', script_format[5])[0]),
                         int(re.findall(r'(\w*[0-9]+)\w*', script_format[6])[0])]
                    B = [int(re.findall(r'(\w*[0-9]+)\w*', script_format[7])[0]),
                         int(re.findall(r'(\w*[0-9]+)\w*', script_format[8])[0])]
                    C = [int(re.findall(r'(\w*[0-9]+)\w*', script_format[9])[0]),
                         int(re.findall(r'(\w*[0-9]+)\w*', script_format[10])[0])]
                    self.family.graveDigger.UpdateSite(A, B, C)
                    logging.debug("mapid = {0}, siteList = {1}".format(self.family.graveDigger.mapid, self.family.graveDigger.siteList))
                    self.family.SetState(STATE_GS_GRAVEDIGGER_TRANSFER2MAP)
                    return
            
            #收到探宝邀请
            if "SeekTreasure:AskAttendSeekTreasure" in script:
                logging.debug("队员同意探宝")
                dataList = script.split(",")
                self.OnAgreeAttendSeekTreasure(int(dataList[2]), int(dataList[3]))
                return
    
            # 挖到了地宫
            if '发现了地宫' in script:
                self.family.graveDigger.HavaDigger(WaDaoDiGong)
                return
    
            if "地宫二层" in script and not self.family.graveDigger.isEnterDiGongSecondFloor:
                self.family.graveDigger.isEnterDiGongSecondFloor = True
                return
            
        if self.family.caseId == CaseManager.ESCORT:    
            # 准备开始押镖
            if script.startswith("{\"Escort:OnStartEscort\""):
                logging.debug("准备开始押镖")
                self.MarkTestCase("TestCase_Escort_StartEscort")
                self.family.SetState(STATE_GS_ESCORT_START_NOW)
                return
            
            #劫镖-镖车信息
            if "Escort:OpenRobUI" in script:
                npcId = int(script.split(",")[-2])
                logging.debug("劫镖，npcId：%s" % npcId)
                self.MarkTestCase("TestCase_Escort_Rob")
                self.EscortRob(npcId)
                return
            
            #镖车为粮草镖或被劫过了或正被劫镖或镖车进入了安全区
            if script in ["{\"Escort:OnRob\",1,}", "{\"Escort:OnRob\",2,}"]  or "当前镖车正在劫镖中" in script or "镖车已经进入安全区" in script:
                logging.debug("此镖车为粮草镖或被劫过了或正被劫镖或镖车进入了安全区")
                if self.family.GetState() == STATE_GS_ESCORT_JIEBIAO_JUDGE:
                    self.GM_MoveToPosition(False, *(self.family.escort.GetJieBiaoPos()))#重置劫镖位置
                    self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)#再次等待劫镖
                return
    
            # 进入到战斗的地图
            if script == "{\"Escort:OnEscortStatesChange\",3,}":
                logging.debug("进入到战斗地图")
                self.MarkTestCase("TestCase_Escort_EscortEnterMap")
                return
    
            # 离开战斗的地图
            if script == "{\"Escort:OnEscortStatesChange\",1,}" and self.family.escort.gameType == Escort_Yabiao:
                logging.debug("离开战斗的地图")
                self.canSkill = False
                self.family.SetState(STATE_GS_ESCORT_ING)
                return
            
            if "\"Escort:OnMissionEvent\",\"OnWait\"" in script and self.family.escort.gameType == Escort_Jiebiao:
                logging.debug("劫镖者等待进入到战斗地图")
                self.MarkTestCase("TestCase_Escort_RobEnterMap")
                self.family.SetState(STATE_GS_ESCORT_JIEBIAO_START_WAIT)
                return
                
            if "\"Escort:OnMissionEvent\",\"OnReady\"" in script:
                if self.family.escort.gameType == Escort_Jiebiao:
                    logging.debug("劫镖者准备战斗")
                elif self.family.escort.gameType == Escort_Yabiao:
                    logging.debug("押镖者准备战斗")
                self.family.SetState(STATE_GS_ESCORT_IN_COMBAT)
                return
                
            if "\"Escort:OnMissionEvent\",\"OnFinish\"" in script and self.family.escort.gameType == Escort_Jiebiao:
                self.canSkill = False
                self.family.escort.jieBiaoCount += 1
                if self.family.escort.jieBiaoMemberType == Escort_JiebiaoSingle:
                    if self.family.escort.jieBiaoCount > 5:
                        logging.debug("完成五次单人劫镖，退出")
                        self.family.SetState(STATE_GS_ESCORT_FINISH)
                    else:
                        logging.debug("完成%s次单人劫镖，继续等镖车" % self.family.escort.jieBiaoCount)
#                        gevent.sleep(10)
                        self.GM_MoveToPosition(False, *(self.family.escort.GetJieBiaoPos()))#重置劫镖位置
#                        gevent.sleep(2)
                        self.family.SetState(STATE_GS_ESCORT_JIEBIAO_WAIT)
                elif self.family.escort.jieBiaoMemberType == Escort_JiebiaoTeam:
                    logging.debug("完成一次组队劫镖，退出")
                    self.family.SetState(STATE_GS_ESCORT_FINISH)
                return
            
            # 运镖结束
            if script.startswith("{\"Escort:OnFinishEscort\""):
                logging.debug("运镖结束")
                self.family.SetState(STATE_GS_ESCORT_FINISH)
                return
        
        if self.family.caseId == CaseManager.KILLER:
            # 领取悬赏令成功
            if "Wanted:PublishTaskSucess" in script:
                self.MarkTestCase("TestCase_Killer_PublishTaskSucess")
                self.family.SetState(STATE_GS_KILLER_CHANGE)
                return
            
            elif "Wanted:GetWantedListResult" in script:
                wanted = script[(len("Wanted:GetWantedListResult")+9):len(script)] 
                self.family.killer.killlist = wanted.split("{")  
            
            elif "Wanted:AcessOneTaskSucess" in script:
                self.MarkTestCase("TestCase_Killer_AcessOneTaskSucess")
                self.CallScript("PlayerCmd", "StartFindTarget")
                
            elif "Wanted:StartFindTargetSuc" in script:
                self.MarkTestCase("TestCase_Killer_StartFindTargetSuc")
                self.family.SetState(STATE_GS_KILLER_WAIT)
            
            elif "Wanted:StartPKAnim" in script:
                self.family.SetState(STATE_GS_KILLER_IN_MISS)
            
            elif "Wanted:ShowEventResult" in script:
                self.family.SetState(STATE_GS_KILLER_FINISH)

            
            # 进入到了悬赏副本
            if script.startswith("{\"Wanted:UpdateMisInfo\""):
                if "离开比赛场" in script:
                    self.canSkill = False
                    self.family.SetState(STATE_GS_KILLER_FINISH)
                else:
                    self.family.SetState(STATE_GS_KILLER_IN_MISS)
                return

        if self.family.caseId == CaseManager.XOYO:
            #逍遥谷匹配中
            if 'XoyoGame:OpenAttandUI' in script:
                logging.debug("逍遥谷匹配中")
                self.family.SetState(STATE_GS_XOYO_MATCHING)
                return
            
            #逍遥谷任务更新
            if "XoyoGame:UpdateLeftPanel" in script:
                if self.family.GetState() == STATE_GS_IN_XOYOGAME_MAP:
                    logging.debug("逍遥谷任务开始")
                    self.family.SetState(STATE_GS_START_FIGHT_BEGIN)
            
            if "RedDot:UpdateRedDotWithCond"in script or "KUI.DispatchEvent"in script:
                self.canSkill = False#禁止技能
                self.family.SetState(STATE_GS_FAMILY_ADD_AWARD_INFO)
                return
        if self.family.caseId == CaseManager.GRAVE:
            if 'me:PopTips' in script and "保护状态结束" in script:
                self.MarkTestCase("TestCase_Grave_Eliminate_Protection_Status")
            # 家族周末关卡
            if 'me:PopTips' in script and "所有机关复位，请从机关【壹】重新开始！" in script:
                self.family.grave.postTarget = ""
                self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST)
                return
            
            if 'Grave:SyncGameInfo' in script:
                self.family.grave.target = script.split('"')[7]
                if self.family.grave.target == KinTargetWait:
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_RUN_WAIT)
    
                if self.family.GetState() in [STATE_GS_ENTER_WEEK_GAME_RUN_WAIT, STATE_GS_ENTER_WEEK_GAME] and self.family.grave.target in [KinTargetStart, KinTargetOne]:
                    self.AddBuffInvincible()#增加无敌
                    self.AddBuffBlock()
                    self.MarkTestCase("TestCase_Grave_WeekInstanceStart")
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_FLOWER)
                    
                if self.family.grave.target == KinTargetOne:
                    self.family.grave.countList = script.split('"')[4][3:-4].split(",")
                    
                elif self.family.grave.target == KinTargetTwo:
                    self.family.grave.countList = script.split('"')[4][3:-4].split(",")
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_KILL)
                        
                if self.family.grave.countList == ["7", "7", "7"]:#准备打开机关柱子
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ENTER)
                        
                elif self.family.grave.target == KinTargetThree and self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST_WAIT:
                    self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_ENTER)
                
                elif self.family.grave.target == KinTargetEnd:
                    self.family.grave.countList = script.split('"')[4][3:-4].split(",")
                    if self.family.GetState() == STATE_GS_ENTER_WEEK_GAME_ROOM_POST_MSG_WAIT:
                        self.family.SetState(STATE_GS_ENTER_WEEK_GAME_ROOM_POST_BOSS)
                        return            
                        
        if self.family.caseId == CaseManager.JIAZU:
            #打完boss盛宴开始响应
            if "KUI.IconChat" in script:
                if "请移步盛宴厅" in script:
                    self.family.kinMan.cooking = True
                    self.family.SetState(STATE_GS_KIN_FEAST_ENTER_DINNING_ROOM)
                    return
                elif "大胃王" in script:
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                #盛宴休闲动作
                elif "食神" in script and "请做出休闲动作" in script:
                    action = script[script.find("“")+3:script.find("”")]#获取休闲动作
                    FeastActionDict = self.family.kinMan.feastActionDict
                    if action in FeastActionDict.keys():
                        logging.debug("做出休闲动作：%s" % action)
                        self.CharacterGesturePlay(FeastActionDict[action])#休闲动作
                    else:
                        logging.debug("家族盛宴休闲动作未找到：%s" % action)
                    return
            #做好食物响应
            if "KinDefendFeast:DishInfo" in script and self.family.GetState() == STATE_GS_KIN_FEAST_WAIT_SHOW_FOOD:
                self.MarkTestCase("ShowEatFood")
                self.family.SetState(STATE_GS_KIN_FEAST_EAT_FOOD)
                return
            
            if "SCom.ShowTipMgrWancheng" in script:
                #盛宴结束
                if "盛宴" in script and "结束" in script:
                    logging.debug("完成盛宴")
                    self.family.SetState(STATE_GS_KIN_FEAST_END)
                    return
        
        if self.family.caseId == CaseManager.PLAYERFIGHT:
            #被请求切磋
            if 'AskStartPk' in script:
                if self.family.GetState() == STATE_GS_PK_TALK:
                    if random.randint(1, 10) == 1:
                        self.Reject_PK()
                    else:
                        self.family.SetState(STATE_GS_PK_AFTER_ANSWERPK)
                        self.Accept_PK()
                return
            
            if 'ReadyStartPK' in script:
                self.family.SetState(STATE_GS_PK_READYSTART)
                return
            
            if 'StartPK' in script:
                self.family.SetState(STATE_GS_PK_START)
                return
            
            if 'OnEndPK' in script:
                self.canSkill = False
                self.family.SetState(STATE_GS_PK_END)
                return
            
        if self.family.caseId == CaseManager.MASTER: 
            
            if "BaiShi_003_F2&M1" in script:
                self.family.SetState(STATE_GS_MASTER_TASK_FINISH)
                return
            #师徒传功
            elif "OnSyncTrainingState" in script:
                msgList = script.split(",")
                self.family.master.SetTrainingPlace(msgList[4])
                familyId = int(msgList[3])
                if familyId == self.family.master.myMasterId:#徒弟同意传功后响应
                    self.family.SetState(STATE_GS_MASTER_DO_TRAINING_TASK)
                elif familyId == self.family.master.myApprenticeId:#接收到徒弟同意传功后响应
                    self.family.SetState(STATE_GS_MASTER_DO_TRAINING_TASK)
                return
            elif "DelayShowBecomeFormalMaster" in script:
                self.family.SetState(STATE_GS_MASTER_TASK_FINISH)
                return
            elif "AskStartTraining" in script:
                msgList = script.split(",")
                familyId = int(msgList[2])
                if familyId == self.family.master.myMasterId and self.family.GetState() == STATE_GS_MASTER_START_TRAINING_WAIT:#收到师父传功邀请
                    self.ReplySchoolTrainingAsk(familyId)#应答传功邀请
                return
            
            elif "BeginTraining" in script:
                if self.family.master.myApprenticeId:#师父结束传功
                    self.family.SetState(STATE_GS_MASTER_TRAINING_FINISH)
                return
            
            elif "FinishTraining" in script:#传功结束
                self.family.SetState(STATE_GS_MASTER_TRAINING_END)
                return
            
        if self.family.caseId == CaseManager.BATTLE:
            # 战场
            # 战场开始
            if "{\"Battle:OnSyncCurMissionState\",3" in script:
                self.canSkill = True
                self.family.SetState(STATE_GS_START_FIGHT_BEGIN)
                return
            
            if self.family.battle.isHandleEvent and "{\"Battle:CallRuleFun\",2050,\"OnRandomEvent\"," in script:
                result = re.match("{\"Battle:CallRuleFun\",2050,\"OnRandomEvent\",{(\d+),(\d+),(\d+),},}", script)
                if result:
                    pos_index, id, state  = int(result.group(1)), int(result.group(2)), int(result.group(3))
                    if state == 2:
                        self.family.battle.eventPosIdx = pos_index
                        self.family.battle.eventId = id
                return
        
            #战场结束
            if "{\"Battle:OnSyncCurMissionState\",5," in script:
                self.canSkill = False # 禁止技能
                self.family.SetState(STATE_GS_BATTLE_SHOP) # 宋金商店
                return
        
        # 联赛
        if self.family.caseId == CaseManager.PVP:
            if self.family.state == STATE_GS_LEAGUEMATCH_MATCHED_COMPETITOR and "{\"LeagueMatch:OnSyncSceneState\""in script:
                self.MarkTestCase("LeagueMatch_FightStart")
                return
            
            if "{\"LeagueMatch:OnFightResult\"" in script:
                self.canSkill = False
                self.family.SetState(STATE_GS_LEAGUEMATCH_WAIT_BACK_READY_SCENE)
                self.Transfer(SenceShiJianTai)
                self.MarkTestCase("LeagueMatch_FightFinished")
                return
            
        if self.family.caseId == CaseManager.DUNGEON:
            #开启衡道书的应答
            if "Dungeon:AskOpenGame" in script:
                self.AnswerOpenDungeonGame()
                self.family.SetState(STATE_GS_HENG_WAIT)
                return
            elif "Dungeon:UpdateTagInfo" in script:
                if "[E49E39]当前目标[-]\\n[E49E39]同时击败[-]天忍双煞" in script or \
                      "[E49E39]当前目标[-]\\n击败殷童" in script or \
                      "[E49E39]当前目标[-]\\n击败南宫誉" in script or\
                      "[E49E39]当前目标[-]\\n击败大漠狂匪[E49E39]马逵[-]" in script or \
                      "[E49E39]当前目标[-]\\n击败拜日月教大善母" in script or \
                      "[E49E39]当前目标[-]\\n击败岳门三英" in script:
                    if self.family.GetState() == STATE_GS_MOVE_MOVING:
                        self.family.dungeon.StateForArrival = STATE_GS_HENG_SKILL
                    else:
                        self.family.SetState(STATE_GS_HENG_SKILL)
                    return

                if  "[E49E39]当前目标[-]\\n前往[E49E39]山顶集结点[-]" in script :
                    self.AddBuffInvincible()#无敌
                    self.family.dungeon.enterFightAreaCount == 4 
                    self.family.SetState(STATE_GS_MOVE_GO)
                    return
                
                elif "[E49E39]当前目标[-]\\n前往[E49E39]集结点[-]" in script or \
                    "[E49E39]当前目标[-]\\n前往[E49E39]拜日月教祭坛[-]" in script or \
                    "[E49E39]当前目标[-]\\n前往[E49E39]废弃之地[-]" in script:
                    self.AddBuffInvincible()#无敌
                    self.family.dungeon.enterFightAreaCount += 1
                    self.family.SetState(STATE_GS_MOVE_GO)
                    return

                elif "[E49E39]战斗胜利[-]\\n奖励已发并开启" in script:
                    self.family.SetState(STATE_GS_HENG_FINISH_WAIT)
                    return

            elif "RollAward:OnRollEquip" in script:
                dataList = script.split(",")
                if int(dataList[3]) == 1:
                    self.AnswerRollAward(int(dataList[2]), 2)
        
        #装备技能
        if self.family.GetState() == STATE_GS_SKILL_EQUIP_WAIT and "UISkillVM" in script:
            if "_OnEquipAllSkill" in script:
                skillList = map(int, script.split(",")[3:7])
                if skillList == self.family.skill.skillDict.values():
                    self.family.skill.finalSkillList = skillList
                    self.family.skill.skillDict = {}
                    gevent.spawn(self.EquipCharacterSkill())
        
        if self.family.caseId == CaseManager.XIAOMIJING:
            #小秘境副本邀请
            if script == "{\"SecretRealm:AskOpenGame\",1,}":
                self.ReplayOpenSecretRealmGame()#应答进入副本邀请
            elif self.sceneTemplateId in [SceneXiaoMiJing6, SceneXiaoMiJing7]:
                if "KUI.WantedWaitStartPKGame" in script:#关卡开始
                    self.AddBuffInvincible()#无敌
                    self.family.SetState(STATE_GS_XIAOMIJING_JUDGE)
                elif "奖励领取成功" in script:
                    self.MarkTestCase("TestCase_XiaoMiJing_OpenBox")
                    return
                if "演武台" in script:
                    self.family.xiaomijing.hasSwitch = True
                    self.family.SetState(STATE_GS_XIAOMIJING_JIGUAN)
                    return
                elif  "观岭台" in script or "毒仙泽" in script or "枯木壤" in script:
                    self.family.xiaomijing.bossDict = {}
                
                elif "破除成功" in script:
                    self.family.xiaomijing.hasSwitch = False
                    self.family.SetState(STATE_GS_MOVE_GO)

                
        #家族争夺
        if self.family.caseId == CaseManager.JIAZU and self.family.kinMan.gameType == KinWarGame:
            ''' {\"KinWar:ShowBattleMsg\",2335,\"家族成员【男帜胍鬓诀昨】已在冲锋场内阵亡！\",} '''
            match = re.match(r".*KinWar:ShowBattleMsg.*家族成员【(\W+)】已在冲锋场内阵亡！.*", script)
            if match and match.group(1).decode("utf-8") == self.family.mainName:
                logging.debug("在PVP阵亡了")
                self.MarkTestCase("TestCase_Kin_WarDead")
                self.family.kinMan.hasWarPvpDead = True
                self.family.SetState(STATE_GS_KIN_WAIT)
                return
            if "本场皇陵时间已结束，即将返回准备场。" in script:
                self.MarkTestCase("TestCase_Kin_WarTimeoutEnd")
                return
            #根据提示框内容改变状态
            for target in [KinWarWait, KinWarPveFight, KinWarLamp, KinWarEnterNeiDian, KinWarKillGenerals, KinWarEnd, KinWarCheer, KinWarCheerEnd]:
                if target in script and target != self.family.kinMan.target:
                    self.family.kinMan.target = target
                    if target == KinWarWait:
                        self.family.SetState(STATE_GS_KIN_WAR_ENTER_HUANGLING)
                        break
                    elif target == KinWarPveFight:
                        self.family.SetState(STATE_GS_KIN_WAR_START)
                        break
                    elif target == KinWarLamp:
                        self.MarkTestCase("TestCase_Kin_LampAppear")
                        self.canSkill = False
#                        gevent.sleep(5)
                        self.family.SetState(STATE_GS_KIN_WAR_LAMP)
                        break
                    elif target == KinWarEnterNeiDian:
                        self.MarkTestCase("TestCase_Kin_NeiDianOpen")
                        self.family.SetState(STATE_GS_MOVE_GO)
                        break
                    elif target == KinWarKillGenerals:
                        self.AddBuffBlock()#增加强力格挡
                        self.AddBuffHeavyDamage()#增加一击必杀
                        self.family.kinMan.isdajiang = True
                        self.family.SetState(STATE_GS_KIN_WAR_KILL_GENERALS)
                        break
                    elif target == KinWarEnd:
                        logging.debug("争夺活动结束")
                        self.family.SetState(STATE_GS_KIN_WAR_OPEN_RANK_UI)
                        break
                    elif not self.family.kinMan.hasWarPvpDead and target == KinWarCheer:
                        self.family.SetState(STATE_GS_KIN_CHEER_START)
                        break
                    elif target == KinWarCheerEnd:
                        self.family.SetState(STATE_GS_KIN_WAIT)
                        break
                
            ''' {"KUI.SetLeftPanelMsg","[e8d09c]助威人数[-] [ffffff]2[-] [3ef41a](已报名)[-]\n[e8d09c]冲锋人数[-] [ffffff]0/20[-]\n[ffa700]请在此烤火等待\n报名结束后活动将开始[-]",} '''
            match = re.match(r".*KUI.SetLeftPanelMsg.*\[.*\]助威人数\[.*\] \[.*\](\d+)\[.*\].*\[.*\]冲锋人数\[.*\] \[.*\](\d+)/(\d+)\[.*\].*", script)
            if match:
                self.family.kinMan.UpdateWarMemberCount(int(match.group(1)), int(match.group(2)), int(match.group(3)))
                return
            
            ''' {"KinWar:OpenSignUpUI",{{341271,0,"五毒珅百",70,5,100019223,0,1,},{341272,0,"余谦济",70,5,100019223,0,1,},},} 
                tbInfo[1] = self.nFamilyId;            -- 角色ID
                tbInfo[2] = self.nPvpType;           -- 是否为pvp类型
                tbInfo[3] = self.szName;               -- 角色名字
                tbInfo[4] = self.nLevel;                  -- 角色等级
                tbInfo[5] = self.nFaction;              -- 角色门派
                tbInfo[6] = self.nFightPower;       -- 战力
                tbInfo[7] = self.nApplyPvpFlag;   -- 是否申请了冲锋场权限
                tbInfo[8] = self.nIsInPveMission;  -- 是否在Mission中
            '''
            if "KinWar:OpenSignUpUI" in script or "KinWar:OnSyncSignUpFamilyInfo" in script:
                warCompile = re.compile(r"\{(\d+),(\d+),\W+,\d+,\d+,\d+(?:\.\d+)*,\d+,\d+,\}")
                match = warCompile.findall(script)
                if match:
                    logging.debug("OpenSignUpUI or OnSyncSignUpFamilyInfo match success")
                    self.family.kinMan.UpdateWarMemberDict(self.family.familyId, match)
                    return
            
            ''' {\"KinWar:OnChangeSignUpPvpType\",341272,0,} '''
            match = re.match(r"\{\"KinWar:OnChangeSignUpPvpType\",(\d+),(\d+),\}", script)
            if match:
                logging.debug("OnChangeSignUpPvpType match success")
                self.family.kinMan.UpdateWarMemberDict(self.family.familyId, [match.groups()])
                return
            
            ''' {\"KinWar:PlayMovie\",\"Seq_Taijie1\",100,{117,66,},} '''
            match = re.match(r"\{\"KinWar:PlayMovie\",\"Seq_(\w+)\",\d+,\{\d+,\d+,\},\}", script)
            if self.family.kinMan.warMemberType == KinWarAssaulter and match:
                sequenceName = match.group(1)
                if sequenceName in ["Taijie1", "Taijie2"]:#播放开启Pve2、Pve3区的动画
                    logging.debug("等待播放完开启Pve2、3区动画后移动")
                    self.canSkill = False
#                    gevent.sleep(15)
                    self.family.SetState(STATE_GS_MOVE_GO)
                    return
                elif sequenceName == "Saomupopo":#扫墓婆婆出场动画
                    logging.debug("等待播放完扫墓婆婆出场动画后移动")
                    self.canSkill = False
#                    gevent.sleep(10)
                    self.canSkill = True
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
                    return
            
            if "KinWar:ApplyOpenRankUI" in script:
                self.family.SetState(STATE_GS_KIN_WAR_OPEN_RANK_UI)
                return
        
            #系统强制安排为冲锋的情况
            if "您被更改为参与冲锋" in script:
                self.family.kinMan.warMemberType = KinWarAssaulter
                return
            
        if self.family.caseId == CaseManager.DAMIJING:
            if '"KUI.SetLeftPanelMsg"' in script:
                if '对话继续挑战' in script or '对话开始挑战' in script:
                    self.canSkill = False
                    self.family.damijing.refreshNPC = False
                    self.family.SetState(STATE_GS_DAMIJING_MOVETO_GUARD)
                elif '打开宝箱' in script:
                    self.canSkill = False
                    self.family.SetState(STATE_GS_DAMIJING_MOVETO_BAOXIANG)
                    self.MarkTestCase("TestCase_Damijing_OpenBox")
            elif '"KUI.SetLeftPanelTitle"' in script:
                if " 入侵 战斗阶段" in script:
                    self.canSkill = True
                    self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)                    
            elif '{\"DaMiJing:OnStartFight\"' in script:
                self.canSkill = True
                self.family.SetState(STATE_GS_SINGLE_MISSION_RELEASE_SKILLS)
            elif '{\"DaMiJing:SyncResult\"' in script:
                self.canSkill = False
                self.CallScript("PlayerCmd", "DaMiJingApplyLeave", self.family.damijing.missionId)
                self.MarkTestCase("TestCase_Damijing_Level_%d" % self.family.damijing.level)
                self.family.SetState(STATE_GS_END)
                return
            elif "AskEnterMission" in script:
                result = re.match('{\"DaMiJing:AskEnterMission\",(\d+),(\d+)', script)
                if result:
                    id = int(result.group(1))
                    familyId = int(result.group(2))
                    self.CallScript("PlayerCmd", "DaMiJingReplyEnterMission", 1, id, familyId)
            elif "AskFinish" in script:
                result = re.match('{\"DaMiJing:AskFinish\",(\d+),(\d+),(\d+)', script)
                if result:
                    missionId = int(result.group(1))
                    id = int(result.group(2))
                    familyId = int(result.group(3))
                    self.CallScript("PlayerCmd", "DaMiJingReplyFinish", missionId, id, familyId)
            elif "OnSyncGuiderData" in script:
                result = re.match(r'{\"DaMiJing:OnSyncGuiderData\",.*.nSeries\"]=(\d+).*nMissionId\"\]=(\d+)', script)
                if result:
                    self.canSkill = True
                    self.family.damijing.refreshNPC = True
                    self.family.damijing.missionId = int(result.group(2))
                    if self.family.damijing.level < 10 or random.randint(0, 10) < 3:
                        self.DaMiJingApplyFight(self.family.damijing.missionId, int(result.group(1)))
                    else:
                        self.DaMiJingApplyFinish(self.family.damijing.missionId, int(result.group(1)))
            elif "WantedWaitStartPKGame" in script:
                self.family.damijing.hasBeRob = True
                self.family.SetState(STATE_GS_DAMIJING_MOVETO_ROB_SKILLPOINT)
            elif "SCom.ShowTipMgrWancheng" in script and "挑战通过" in script:
                # {"SCom.ShowTipMgrWancheng",{"true","第三层","挑战通过","",2,},}
                self.family.damijing.level += 1
            elif "{\"DaMiJing:ShowRobWarningInfo\",}" == script:
                self.canSkill = False
            elif '{"SCom.ShowTipMgrWancheng",{[1]="false",[2]="入侵",[3]="",[4]="失败",[5]=2,},}' == script\
            or '{"SCom.ShowTipMgrWancheng",{"true","入侵","成功","",2,},}' == script\
            or '{"SCom.ShowTipMgrWancheng",{"true","防守","成功","",2,},}' == script\
            or '{"SCom.ShowTipMgrWancheng",{"true","防守","失败","",2,},}' == script:
                self.family.damijing.hasBeRob = False
                self.canSkill = False
                self.MarkTestCase("TestCase_Damijing_RobFinished")
            return                    
                
        #江湖风云录
        if self.family.caseId == CaseManager.BOSSCHALLENGE and self.sceneTemplateId == SceneBossChallenge:
            if "挑战开始" in script:
                if self.family.GetState() == STATE_GS_BOSSCHALLENGE_TARGET_WAIT:
                    self.AddBuffBlock()#强力格挡
#                    gevent.sleep(5)
                    self.family.SetState(STATE_GS_BOSSCHALLENGE_SKILL)
                else:
                    self.family.boss_challenge.needSkill = True
                return
            
            elif "已击败区域内所有敌人，请大侠前往下个区域！" in script:
                self.MarkTestCase("TestCase_BossChallenge_NextArea")
                self.family.boss_challenge.needSkill = False
                self.family.boss_challenge.needMove = True
                return
                
            elif "SCom.ShowTipMgrWancheng" in script:
                self.MarkTestCase("TestCase_BossChallenge_Finish")
                self.family.SetState(STATE_GS_END)
                return
            
        if self.family.caseId == CaseManager.EQUIP  :      
            if script == "{\"me:PopTips\",\"回购成功！\",}":
                self.MarkTestCase("TestCase_Equip_RecycleSuccess")
                return
        if self.family.caseId == CaseManager.INSTANCE:
            if "逐鹿金滩将在[ffa700]{0}秒[-]后开启，请双方玩家做好准备" in script:
                self.family.SetState(STATE_GS_GOLD_DEER_ACTIVITY)
                return
            elif "KUI.OpenWindow"  in script:
                result = re.match(r'{\"KUI.OpenWindow\",\"UIPaoshang\,(\d+)', script)
                if result:
                    if self.family.instance.isBusinessmanBuy:
                        self.CallScript("CampWarCmd", "ApplyBuyGoods", int(result.group(1)))
                    else:
                        self.CallScript("CampWarCmd", "ApplySellGoods", int(result.group(1)))
                if "UIZhuLuJinTan" in script:
                    self.CallScript("CampWarCmd", "ApplyEnterCampWar") #活动报名   
                    self.MarkTestCase("TestCase_CampWar_SignUp")  
            elif "率先完成金矿收集的一方将在资源官处获得一辆矿车" in script and self.family.instance.isfirst:
                self.family.instance.isfirst = False
                self.family.SetState(STATE_GS_GOLD_DEER_ACTIVITY)
                return
            elif "CampWar:SellGoods" in script:
                self.MarkTestCase("TestCase_CampWar_SellGoods")
                return
            elif "CampWar:BuyGoods" in script:
                self.family.instance.isBusinessmanBuy = False
                self.MarkTestCase("TestCase_CampWar_BuyGoods")
                self.family.SetState(STATE_GS_GOLD_DEER_SELL)
                return
            elif "10秒后将在资源官处获得一辆" in script and self.family.instance.isfight == False:
                self.family.instance.isfight = True
                self.MarkTestCase("TestCase_CampWar_Car")
                self.family.SetState(STATE_GS_GOLD_DEER_FIGHT)
                return
            elif "CampWar:ShowResult" in script or "开启下一场逐鹿金滩的准备阶段" in script:
                self.family.instance.isend = True       
                self.family.SetState(STATE_GS_GOLD_DEER_END)
                return
            
        if self.family.caseId == CaseManager.APPEARANCE:
            if script == "{\"me:PopTips\",\"染色失败，被染色物品已过期\",}" or \
                script == "{\"me:PopTips\",\"染色失败，染色数据异常，请联系客服处理\",}" or \
                script == "{\"me:PopTips\",\"染色失败，您的元宝不足\",}" or \
                script == "{\"me:PopTips\",\"染色失败，不能只染一个部位\",}" or \
                script == "{\"me:PopTips\",\"染色数值不正确，请重新染色\",}":
                self.MarkTestCase("TestCase_Appearance_ColoringItem", isSuccess=False, exception="errCode != 0")
                self.family.SetState(STATE_GS_END)
                return
            
        if self.family.caseId in[CaseManager.REDPACKET, CaseManager.ACTIVITY_NEWYEAR]:
            if "RedPacket:OnCreateRedPacketSuccess" in script:
                result = re.match('.*packetId\"]=\"(\d+)', script)
                if result:
                    self.family.redpacket.redpacket = int(result.group(1))
                    self.ChatRequestByMsg("RedPacket", self.family.redpacket.channel, isredpacket=True)
                    self.MarkTestCase("TestCase_RedPack_SendSuccess")
        if self.family.caseId in [CaseManager.WUYI]:
            if "阿黄又跑了起来" in  script\
            or "护送失败" in script:
                self.MarkTestCase("TestCase_WuYi_RunAgain")
                self.family.SetState(STATE_GS_MOVE_GO)
#            elif "SCom.ShowPosGuide" in script:
            elif "阿黄同意和你一起回到希子身边了" in script:
                self.family.SetState(STATE_GS_WU_YI_BACK)
            elif "阿黄！你回来了！谢谢大侠！" in script:
                self.family.SetState(STATE_GS_WU_YI_END)
            return
        
    def OnAgreeAttendSeekTreasure(self, id, familyId):
        self.CallScript("PlayerCmd", "OnAgreeAttendSeekTreasure", id, familyId)
    
    def CliGetFamilyLocationReq(self):
        request = CliGetFamilyLocationReq()
        request.familyId = self.family.familyId
        request.longitude = 0.0
        request.latitude = 0.0
        request.groupId = self.family.groupId
        request.userdata = "RECOMMEND"
        request.online = 1
        request.notDivideFlag = True
        request.maxPlayerNum = 20
        request.gender = 2
        self.SendProtocol(CLI_TO_GS_GET_FAMILY_LOCATION_REQ, request)
        
    def On_SvrGetFamilyLocationRsp(self, respond):
        logging.debug('On_SvrGetFamilyLocationRsp %s' % respond)
        if len(respond.infoLst._values) == 0:
            self.MarkTestCase("TestCase_Valentines_GetFamilyLocation", isSuccess=False, exception="list is None") 

    
    # 返回城镇
    def GoBackCity(self):
        self.CallScriptTransfer(2001, 81.11, 127.18)

    # 副本结算响应
    def On_FamilyAddAwardInfo(self, respond):
        #         logging.debug('FamilyAddAwardInfo : Game Over !')
        pass

    # ----Buff----
    #消除攻击力999倍
    def RemoveBuffHeavyDamage(self):
        self.CallScriptGmDoCommand("pl:RemoveBuffState(998,1);")
    
    #消除强力格挡
    def RemoveBuffBlock(self):
        self.CallScriptGmDoCommand("pl:RemoveBuffState(996,1);")
    
    # 增加攻击力999倍
    def AddBuffHeavyDamage(self):   
        self.CallScriptGmDoCommand("pl:AddBuffState(998,1);")

    # 无敌
    def AddBuffInvincible(self):
        self.CallScriptGmDoCommand("me:GetActivePlayer():AddBuffState(13,1);")
    
    #强力格挡
    def AddBuffBlock(self):
        self.CallScriptGmDoCommand("pl:AddBuffState(996,1);")
    
    # 增加攻击力10倍
    def AddBuffTenfoldDamage(self):
        self.CallScriptGmDoCommand("me:GetActivePlayer():AddBuffState(999, 4);")
    
    #加满血
    def AddFullHP(self):
        self.CallScriptGmDoCommand("pl:RestoreLifeAndMana()")

    # ----GM----
    
    #击杀指定id的NPC
    def GM_GetNpcKill(self, charId):
        self.CallScriptGmDoCommand("local p = KNpc.GetNpc(%s);p:KillBy(%s);" % (charId, self.family.characterCur.playerId))
        
    #瞬间移动
    def GM_MoveToPosition(self, isNeedChangeState, posX, posY, posZ=0):
        '''
        isNeedChangeState 是否需要在到达目标点时将状态设置为 STATE_GS_MOVE_ARRIVAL
        '''
        if isNeedChangeState:
            self.family.SetState(STATE_GS_MOVE_MOVING)
            self.gmArrivalStateIsNeedChange = True
        logging.debug("瞬间移动({X}, {Y})".format(X=posX, Y=posY))
        self.CallScriptGmDoCommand("me:GetActivePlayer():MoveToPosition({X}, {Y},{Z})".format(X=posX,Y=posZ, Z=posY))
        
    #GM进入场景
    def GM_EnterSceneAutoInstance(self, sceneId):
        self.CallScriptGmDoCommand("if KScene.CheckSceneMap({sceneId}) == 1 then me:EnterScene_AutoInstance({sceneId}, 0, 0) end".format(sceneId=sceneId))
    
    #GM开启家族盛宴
    def GM_OpenFeast(self):
        self.CallScript("GMCmd", "DoCommand", "GCExcute(me:GetGroupID(), { \"KinDefendFeast:OpenAll\",  true});")
    
    #GM开启家族守护
    def GM_OpenKinDefend(self):
        self.CallScript("GMCmd", "DoCommand", "GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[KinDefend.OpenAll_GC()]], \"familyid:%d\"})" % (self.family.familyId))
    
    # 增加侠义值、威望、功勋、声望等
    def GM_AddValueCoin(self, Type, count):
        '''
            VALUE_COIN_NULL = 0
            VALUE_COIN_SILVER = 1
            VALUE_COIN_GOLD = 2
            VALUE_COIN_BIND_GOLD = 3
            VALUE_COIN_XIAYI = 4
            VALUE_COIN_REPUTATION = 5
            VALUE_COIN_BATTLE_HONOR = 6
            VALUE_COIN_LUN_JIAN_PRESTIGE = 7
            VALUE_COIN_MASTER_COIN = 8
        '''
        self.CallScriptGmDoCommand("me:AddValueCoin({Type},{count},0);".format(Type=Type, count=count))
    
    # GM加家族资金
    def GM_AddKinBuildPoint(self, count=8000):
        logging.debug("GM加家族资金")
        self.CallScript("GMCmd", "DoCommand", "GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[Kin.GMAddBuildPoint(%d, %d)]], \"familyid:%d\"})" % (self.family.kinMan.id,count,self.family.familyId))
        
    #增加江湖阅历
    def GM_AddRepute(self, count=4000):
        self.CallScriptGmDoCommand("me:AddRepute(1,1,%d);" % count)
    
    #完成师道任务（成为师父）
    def GM_CompleteMasterTask(self):
        self.CallScriptGmDoCommand("me:CompleteMasterTask();")
    
    #清空背包
    def ClearItemRoom(self):
        for id in [0, 1, 2]:
            self.CallScriptGmDoCommand("KItem.ClearItemRoom(me:GetID(), 0, %s)" % id)
    
    #设置阵营
    def SetCamp(self, campTag):
        self.CallScriptGmDoCommand("KFamily.GetFamily(%s):GetActivePlayer():SetCamp(%s)" % (self.family.familyId, campTag))
    
    #添加战斗木桩
    def AddHostileNpc(self, sceneId, line, posX, posH, posY):
        self.CallScriptGmDoCommand("KNpc.AddNpc(1, 100, %d, %d, %d, %d, %d, SERIES_NONE);" % (sceneId, line, posX, posH, posY))

    #-----------
    # 角色进入新场景位置相关
    def On_SyncCharacterPosition(self, respond):  # 53
        logging.debug('SyncCharacterNewWorld : %s, [%s, %s], playId=%s' % (respond, self.sceneTemplateId, self.family.GetState(), self.family.GetPlayerId()))
        
        # 进入场景后部分地图会重置玩家坐标
#         if respond.id == self.family.GetPlayerId():
        if respond.id in self.family.GetAllCharacterPlayerId():
            self.family.characterCur.posX = respond.posX
            self.family.characterCur.posY = respond.posZ
            self.family.characterCur.posH = respond.posY
            
            if self.family.caseId == CaseManager.DUNGEON:
                if self.sceneTemplateId in [SenceMoXiangJu] and self.family.GetState() in [STATE_GS_HENG_ENTER_WAIT]:
                    self.family.SetState(STATE_GS_HENG_ENTER)
                elif self.sceneTemplateId in [SenceMoXiangJu] and self.family.GetState() in [STATE_GS_HENG_FINISH_WAIT]:
                    self.family.SetState(STATE_GS_PLAYING)
                    return

            # 判断进入的枫华谷的坐标在哪一边
            if self.sceneTemplateId in [SceneFenghua, SceneLongmen, SceneBeach, SceneLiShanYiJi]:
                if self.sceneTemplateId == SceneLiShanYiJi and self.family.caseId == CaseManager.JIAZU and self.family.GetState() == STATE_GS_KIN_WAR_ENTER_LISHANYIJI_WAIT:
#                    gevent.sleep(3)
                    self.family.SetState(STATE_GS_MOVE_GO)
                    return
                if self.family.GetState() in [STATE_GS_WAIT_SINGLE_MISSION,
                                                   STATE_GS_1_PLAYING]:
                    if not self.bossLine:
                        self.family.SetState(STATE_GS_BOSS_LINE_INFO)  # 换线
                         
                elif self.family.GetState() in [STATE_GS_RANDOMMOVE_MAPLE_ENTER_WAIT, STATE_GS_RANDOMMOVE_LONGMEN_ENTER_WAIT]:
                    self.family.SetState(STATE_GS_MOVE_GO)  # 野外地图-移动
                    return
                elif self.family.GetState() == STATE_GS_SKILLTEST_ENTER_WAIT:#技能测试
                    self.family.SetState(STATE_GS_SKILLTEST_SET_CAMP)
                    return
                elif self.family.GetState() in [STATE_GS_RANDOMMOVE_GATHER_MAPLE_ENTER_WAIT, STATE_GS_RANDOMMOVE_GATHER_LONGMEN_ENTER_WAIT]:
                    self.family.SetState(STATE_GS_RANDOMMOVE_LINEINFO) #切换线路以聚集人数
                    return
                
            if self.sceneTemplateId == SceneKinWeek:
                self.family.grave.SetWeekRoomId(respond.posX)
                       

            if self.gmArrivalStateIsNeedChange and self.family.GetState() in [STATE_GS_MOVE_GO, STATE_GS_MOVE_MOVING]:#如果采用GM瞬间移动，改变为到达的状态
                self.family.SetState(STATE_GS_MOVE_ARRIVAL)
                
            if self.family.GetState() in [STATE_GS_PK_CHANGMAP]:# pk 切换地图
                self.family.SetState(STATE_GS_PK_CHANGE_ARRIVAL)



    # 角色表情
    def CharacterGesturePlay(self, gesture):
        request = GesturePlay()
        request.familyId = self.familyId
        request.id = gesture
        request.ext = 0
        if Config.is_illegaltest():
            request.id = Rand.bound_uint32()
            request.ext = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_GESTURE_PLAY, request)

    # # 动作不会同步给自己
    # def On_SyncGesturePlay(self, respond):
    #     logging.debug('On_SyncGesturePlay %s' % respond)
    #     if respond.familyId == self.familyId:
    #         self.family.SetState(STATE_GS_WELFARE_GESTURE)

    # 停止表情动作
    def CharacterGestureStop(self):
        request = GestureStop()
        request.familyId = self.familyId
        self.SendProtocol(CLI_TO_GS_GESTURE_STOP, request)

    def On_SyncGestureStop(self, respond):
        logging.debug('On_SyncGestureStop %s' % respond)
        # if respond.familyId == self.familyId:
        #     self.family.SetState(STATE_GS_WELFARE_GESTURE)

    # 强制打开副本
    def UnlockMissionByForce(self, misId):
        self.CallScriptGmDoCommand("UnlockMissionByForce(%d,%d);" % (self.familyId, misId))

    # 论剑接口
    # 请求训练
    def Do_LunJianTrainReq(self):
        request = LunJianTrainReq()
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_TRAIN_REQ, request)

    # 训练完成
    def Do_LunJianTrainCompleteReq(self, name=generate_chinese(3), result=True, fight_power=1):
        request = LunJianTrainCompleteReq()
        request.name = name
        request.result = result
        request.fightPower = fight_power
        if Config.is_illegaltest():
            request.name = generate_chinese(Rand.bound_uint32(0, 6))
            request.fightPower = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_TRAIN_COMPLETE_REQ, request)

    def Do_LunJianFreshList(self):
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_FRESH_LIST_REQ)

    def On_LunJianRspChallengeList(self, respond):
        logging.debug("On_LunJianRspChallengeList respond = %s" % respond)
        self.family.lunjian_list = respond.familys._values
        if len(self.family.lunjian_list) > 0:
            self.family.SetState(STATE_GS_LUNJIAN_CHALLEGE)
        else:
            self.family.SetState(STAGE_GS_LUNJIAN_REFRESH_LIST)

    def Do_LunJianLunJianChallege(self):
        """
        C->S: CMD_ID=653, total_length=6
        LunJianChallegeReq
        index: 0

        C->S: CMD_ID=659, total_length=10
        LunJianSetMemberPosReq
        memberType: 2
        memberType: 1
        memberType: 3

        C->S: CMD_ID=654, total_length=6
        LunJianChallegeResult
        win: false

        C->S: CMD_ID=103, total_length=6
        LeaveSingleMission
        curMember: 1
        """
        listlen = len(self.family.lunjian_list)
        if listlen == 0:
            self.family.SetState(STAGE_GS_LUNJIAN_REFRESH_LIST)
            return

        request = LunJianChallegeReq()
        request.index = random.randint(0, listlen - 1)
        if Config.is_illegaltest():
            request.index = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_CHALLEGE_REQ, request)

        # 随机设置位置
#        pos = [1, 2, 3]
#        if Config.is_illegaltest():
#            pos = [0, 4, 5]
#        random.shuffle(pos)
 #       request = LunJianSetMemberPosReq()
#        request.memberType.extend(pos)
#        LunJianSetMemberPosReq()
#        self.SendProtocol(CLI_TO_GS_LUN_JIAN_SET_MEMBER_POS_REQ, request)

        
        # 开始挑战后，等7s才能发送挑战完成
        gevent.sleep(10)
        self.CallScriptGmDoCommand('KGameSwitch.SetOpenFunc(10, false)')
        request = LunJianChallegeResult()
        request.result = random.choice([0, 1])
        request.win = random.randint(0, 9999999)
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_CHALLEGE_RESULT, request)
        self.LeaveSingleMission()
        gevent.sleep(1)
        self.family.SetState(STATE_GS_LUNJIAN_RANK)

    def LunJianGetChallengeHistory(self):
        self.SendProtocol(CLI_TO_GS_LUN_JIAN_GET_CHALLENGE_HISTORY_REQ)

    def Do_Retire(self, family_id):
        request = ClientRetireReq()
        request.familyId = family_id
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_RETIRE, request)

    def Do_Unretire(self, family_id):
        request = ClientRetireReq()
        request.familyId = family_id
        if Config.is_illegaltest():
            request.familyId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_UNRETIRE, request)

    def On_ClientRetireRsp(self, respond):
        if respond.result:
            if respond.familyId in self.family.familyListUnretire.keys():
                self.family.familyListRetire[respond.familyId] = self.family.familyListUnretire[respond.familyId]
                del self.family.familyListUnretire[respond.familyId]
                self.family.SetState(STATE_GS_UNRETIRE)
            elif respond.familyId in self.family.familyListRetire.keys():
                self.family.familyListUnretire[respond.familyId] = self.family.familyListRetire[respond.familyId]
                del self.family.familyListRetire[respond.familyId]
                self.family.SetState(0)
            else:
                logging.error("Family retire except.")
            self._check_and_entergame()

    # 炼化协议
    def Do_ApplyAlchemy(self, alchemyId, bind):
        request = ApplyAlchemy()
        request.alchemyId = alchemyId
        request.num = 1
        request.isBind=bind
        request.useBagStaminaItem = False
        self.SendProtocol(CLI_TO_GS_ALEMCHY, request)
    
    def On_SyncAlchemyItem(self, respond):
        logging.debug("On_SyncAlchemyItem respond=%s" % respond)
        if respond.result == True:
            self.MarkTestCase("TestCase_Equip_Alchemy")
        else:
            self.MarkTestCase("TestCase_Equip_Alchemy", isSuccess=False, exception="result=%s" % respond.result) 
    
    #强化装备
    def ApplyEnhanceEquipGrid(self, equipD, member=""):
        if not member:
            member = self.memberType
        request = ApplyEnhanceEquipGrid()
        request.member = member
        request.equipD = equipD
        request.token = 0
        self.SendProtocol(CLI_TO_GS_ENHANCE_EQUIPGRID, request)
    
    def On_SyncEquipGridEnhanceResult(self, respond):
        emSuccess = 0;       #强化成功
        emFailed = 1;           #强化失败
        emException = 2;    #异常（并没有执行强化操作）
        logging.debug("On_SyncEquipGridEnhanceResult respond=%s" % respond)
        if respond.reuslt != emException:
            if respond.reuslt == emSuccess:
                self.family.bag.SetEquipGridEnhanceData(respond)
            self.MarkTestCase("TestCase_Equip_EnhanceEquipGrid")
        else:
            self.MarkTestCase("TestCase_Equip_EnhanceEquipGrid", isSuccess=False, exception="result=%s" % respond.result) 
    
    #同步装备格子强化信息
    def On_EquipGridEnhance(self, respond):
        memberType = respond.member
        for idx, data in enumerate(respond.slot_data):
            if data.enhance_times:
                if memberType not in self.family.bag.equipGridEnhance:
                    self.family.bag.equipGridEnhance[memberType] = {}
                self.family.bag.equipGridEnhance[memberType][idx+1] = data.enhance_times 
        
    # ---拍卖行---

    # 添加用来出售的商品
    def GM_GetTradeHouse_TradeItem(self, items, count=1):
        for (g, d, p, l) in items:
            gdpl = "_".join((str(x) for x in [g, d, p, l]))
            logging.info("[DataChecker][TradeItem]%s|%s|%s" % (self.family.familyId, self.family.userName, {gdpl : count}))
            logging.info("[DataChecker][TradeDetail]%s|%s|%s" % (self.family.familyId, self.family.userName, {"item" : {gdpl : count}}))
            self.CallScriptAddStackItem(g, d, p, l, count, False, 0)

    # 获得自己的出售列表
    def TradeHouse_GetMySaleList(self):
        request = TradeHouse_GetMySaleList()
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_GETSALELIST, request)

    def On_TradeHouse_GetMySaleList_Result(self, respond):
        logging.debug("On_TradeHouse_GetMySaleList_Result respond=%s" % respond)
        if respond.result == True:
            if respond.item:
                self.tradeHouseMyTradeId = []
                self.family.bag.mySaleItemDict = {}
                for i in respond.item:
                    self.tradeHouseMyTradeId.append(i.tradeId)
                    if i.indexId in self.family.bag.mySaleItemDict:
                        self.family.bag.mySaleItemDict[i.indexId] += i.count
                    else:
                        self.family.bag.mySaleItemDict[i.indexId] = i.count
            self.family.SetState(self.tradeHouseGetMySaleState)

    # 获得自己的历史交易记录
    def TradeHouse_GetTradeHistory(self):
        request = TradeHouse_GetTradeHistory()
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_GETTRADEHISTORY, request)

    def On_TradeHouse_GetTradeHistory_Result(self, respond):
        logging.debug('On_TradeHouse_GetTradeHistory_Result: %s' % respond)
        if respond.result == True:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
            self.tradeHouseGetMySaleState = STATE_GS_TRADEHOUSE_GETMYSALE_RESPONSE
        else:
#            gevent.sleep(2)
            self.TradeHouse_GetTradeHistory()

    # 请求出售商品的价格
    def TradeHouse_GetTradePrice(self, indexId):
        request = TradeHouse_GetTradePrice()
        request.indexId = indexId
        if Config.is_illegaltest():
            request.indexId = Rand.bound_uint32()
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_GETTRADEPRICE, request)

    def On_TradeHouse_GetTradePrice_Result(self, respond):
        if respond.result == True:
            self.tradeHouseTradePrice = respond.price
            logging.debug("拍卖行推荐价格：%s" % self.tradeHouseTradePrice)
            self.family.SetState(STATE_GS_TRADEHOUSE_PUTONSALE)

    # 商品上架
    def TradeHouse_PutOnSale(self, indexId, price=0):
        request = TradeHouse_PutOnSale()
        tradeBag = self.family.bag.GetTradeBag()
        if indexId not in tradeBag.keys():
            logging.error("TradeHouse_PutOnSale：%s not in %s" %(indexId, tradeBag.keys()))
            self.family.SetState(STATE_GS_TRADEHOUST_END)
            return
        request.itemId = random.choice(tradeBag[indexId])
        request.count = 1
        if price:
            request.price = price
        else:
            request.price = self.tradeHouseTradePrice
        if Config.is_illegaltest():
            for case in switch(random.randint(0, 2)):
                if case(0):
                    request.itemId = Rand.bound_uint32()
                    break
                if case(1):
                    request.count = Rand.bound_uint32(0, 6)
                    break
                if case(2):
                    request.price = Rand.bound_uint32()
                    break
        logging.debug("TradeHouse_PutOnSale request = %s" % request)
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_PUTON, request)

    def On_TradeHouse_PutOnSale_Result(self, respond):
        if respond.result == True:
            self.MarkTestCase("TestCase_TradeHouse_PutOnSale")
        else:
            self.MarkTestCase("TestCase_TradeHouse_PutOnSale", isSuccess=False, exception="result=%s"%respond.result)
#             logging.debug("On_TradeHouse_PutOnSale_Result respond.result = False")
        self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)

    # 商品下架
    def TradeHouse_PutOffShelves(self, tradeId=None):
        request = TradeHouse_PutOffShelves()
        if tradeId:
            request.tradeId = tradeId
        elif self.tradeHouseMyTradeId:
            request.tradeId = random.choice(self.tradeHouseMyTradeId)
        else:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
            self.tradeHouseGetMySaleState = STATE_GS_TRADEHOUST_REFRESH
            return
        if Config.is_illegaltest():
            request.tradeId = Rand.rand_string(8)
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_PUTOFF, request)

    def On_TradeHouse_PutOffShelves_Result(self, respond):
        logging.debug("On_TradeHouse_PutOffShelves_Result respond=%s" % respond)
        if respond.result == True:
            self.MarkTestCase("TestCase_TradeHouse_PutOffShelves")
            self.tradeHouseMyTradeId.remove(respond.tradeId)
            if not self.family.bag.needCleanSaleList:
                self.family.SetState(STATE_GS_TRADEHOUSE_GETMYSALE)
                self.tradeHouseGetMySaleState = STATE_GS_TRADEHOUST_REFRESH
        else:
            self.MarkTestCase("TestCase_TradeHouse_PutOffShelves", isSuccess=False, exception="result=%s"%respond.result)
            if not self.family.bag.needCleanSaleList:
                self.family.SetState(STATE_GS_TRADEHOUST_REFRESH)

    # 商品重新上架
    def TradeHouse_RePutOn(self):
        if self.tradeHouseMyTradeId:
            request = TradeHouse_RePutOn()
            request.tradeId = random.choice(self.tradeHouseMyTradeId)
            if Config.is_illegaltest():
                request.tradeId = Rand.rand_string(8)
            self.SendProtocol(CLI_TO_GS_TRADEHOUSE_REPUTON, request)
        else:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
  
    def On_TradeHouse_RePutOn_Result(self, respond):
        logging.debug('On_TradeHouse_RePutOn_Result: %s' % respond)
        # if respond.result == True:
        #     self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
        # 这里先不判断上架是否是否成功了，因为重新上架需要等待一段时间，所以这里一定会失败
#         self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
    
    #刷新出售列表
    def TradeHouse_Refresh(self):
        request = TradeHouse_Refresh()
        request.familyId = self.family.familyId
        request.groupId = 0
        request.refreshType = 1
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_REFRESH, request)
    
    def On_TradeHouse_Refresh_Result(self, respond):
        logging.debug("On_TradeHouse_Refresh_Result respond=%s" % respond)
        if respond.result == True:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
        else:
            self.MarkTestCase("TestCase_TradeHouse_Refresh", isSuccess=False, exception="result=%s"%respond.result)
            self.family.SetState(STATE_GS_TRADEHOUST_REFRESH)
    
    # 获得商品出售列表
    def TradeHouse_GetTradeList(self, indexId):
        request = TradeHouse_GetTradeList()
        request.indexId = indexId
        request.indexEnd = 15
        self.SendProtocol(CLI_TO_GS_TRADEHOUSE_GETTRADELIST, request)

    def On_TradeHouse_GetTradeList_Result(self, respond):
        if self.family.caseId not in [CaseManager.JIAZU,CaseManager.DUNGEON,CaseManager.Acution_Data]:
            if respond.result == True:
                if respond.item:
                    self.tradeHousePutOnItem = []
                    for i in respond.item:
                        self.tradeHousePutOnItem.append(i)
                    self.family.SetState(STATE_GS_TRADEHOUST_BUY)
                else:
                    self.family.SetState(STATE_GS_TRADEHOUST_REFRESH)
            else:
                self.MarkTestCase("TestCase_TradeHouse_GetTradeList", isSuccess=False, exception="result=%s; indexId=%s"%(respond.result, respond.indexId))
                self.family.SetState(STATE_GS_TRADEHOUST_REFRESH)

    # 商品购买
    def TradeHouse_BuyGoods(self):
        AllPutOn_TradeNumber = len(self.tradeHousePutOnItem)
        if AllPutOn_TradeNumber > 0:
            item = self.tradeHousePutOnItem[random.randint(0, AllPutOn_TradeNumber - 1)]
            if self.family.caseId == CaseManager.TRADEHOUSE_DATA and VALUE_COIN_SILVER in self.family.valueCoin and self.family.valueCoin[VALUE_COIN_SILVER] < item.price:
                logging.debug("TRADEHOUSE_DATA 没有足够金币购买商品")
                self.family.SetState(STATE_GS_TRADEHOUST_END)
                return
            self.GetEnoughMoney(VALUE_COIN_SILVER, item.price)#补充购买需消耗的货币
            request = TradeHouse_BuyGoods()
            request.indexId = item.indexId
            request.price = item.price
            request.count = 1
            if Config.is_illegaltest():
                for case in switch(random.randint(0, 1)):
                    if case(0):
                        request.count = Rand.bound_uint32()
                        break
                    if case(1):
                        request.indexId = Rand.rand_string(8)
                        break
            self.SendProtocol(CLI_TO_GS_TRADEHOUSE_BUYGOODS, request)
        else:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)

    def On_TradeHouse_BuyGoods_Result(self, respond):
        logging.debug("On_TradeHouse_BuyGoods_Result respond =%s" % respond)
        if respond.result == True:
            self.MarkTestCase("TestCase_TradeHouse_BuyGoods")
            self.family.SetState(STATE_GS_TRADEHOUST_JUDGE)
        else:
            self.family.SetState(STATE_GS_TRADEHOUSE_GETTRADELIST)
    
    def CleanTradeLimit(self):
        for i in [1, 3, 21, 23]:
            self.CallScript("GMCmd", "DoCommand", "me:SetDataInt(119,%s,0);" % i)
    
    def On_NewMailNotify(self, respond):
        '''
        attachmentState附件状态：
        MAIL_ATTACHMENT_STATE_NOTGET        = 0;            // 未领取
        MAIL_ATTACHMENT_STATE_GETTING    = 1;                // 获取中
        MAIL_ATTACHMENT_STATE_GETTED    = 2;                // 已经获取
        MAIL_ATTACHMENT_STATE_NONE    = 3;                    // 没有附件
        '''
        # 无状态，有新邮件就去读取
        logging.debug("**** New Mail.account = %s", self.family.userName)
        logging.debug(respond)
        getAttachmentMailList = []
        for mail in respond.mailInfoList:
            if not mail.readed:
                self.ReadedMailReq(mail.mailId)#读邮件

            if self.family.caseId not in [CaseManager.TRADEHOUSE_DATA, CaseManager.DATACHECKER] and mail.attachmentState == MAIL_ATTACHMENT_STATE_NOTGET:#把附件id加入收取列表
                getAttachmentMailList.append(mail.mailId)
            
            if "顺利出师" in mail.detail and self.family.GetState() == STATE_GS_MASTER_WAIT_APPRENTICE_LEAVE:
                self.family.SetState(STATE_GS_END)
               
            if "恭喜你在本次竞拍中成功竞得了" in mail.detail and self.family.caseId in [CaseManager.JIAZU,CaseManager.DUNGEON,CaseManager.Acution_Data]:
                if self.family.limitedacution.distinguish>0:
                    self.MarkTestCase("TestCase_World_Auction_Goodout")
                else: 
                    self.MarkTestCase("TestCase_Limited_Auction_Goodout")
        
        if getAttachmentMailList:
            self.GetMailAttachmentReq(getAttachmentMailList)#获取附件
    
    
    #限时竞拍
    def AuctionConcernReq(self):
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GC_AUCTION_BASEINFO_REQ,None)
        
    
    def On_AuctionBaseInfoRsp(self,respond):
        logging.debug("On_AuctionBaseInfoRsp respond = %s" % respond)
        if len(respond.shopList._values)>0:
            for i in range(len(respond.shopList._values)):
                hiId=respond.shopList._values[i].shopId.hiId
                lowId=respond.shopList._values[i].shopId.lowId
                dataVersion=respond.shopList._values[i].dataVersion
                if self.family.limitedacution.isFirstCalculation == False:
                    self.family.gameServerNetPackHandle.MarkTestCase("TestCase_Limited_Shopid")
                    self.family.limitedacution.totalshopinf[i]=[hiId,lowId,dataVersion]
            self.family.limitedacution.auctioninformationlist=[hiId,lowId,dataVersion]
            self.family.SetState(STATE_GS_LIMITED_AUCTION_CHANGE)
            return
        else:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
            return
    
    def AuctionShopDataReq(self,shopId,lowId,dataVersion):
        request = AuctionShopDataReq()
        request.shopId.hiId = shopId
        request.shopId.lowId = lowId
        request.goodsIndex = 0
        request.goodsCount = 10
        request.dataVersion = dataVersion
        request.sortType = 1
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GS_MEMBER_REVIVAL,request)

    def WorldlLimitedShopDataReq(self,goodsType,dataVersion=0):
        request = AuctionShopDataReq()
        request.shopId.hiId = 0
        request.shopId.lowId = 0
        request.goodsType = goodsType
        request.goodsIndex = 0
        request.goodsCount = 10
        request.dataVersion = dataVersion
        request.sortType = 1
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GS_MEMBER_REVIVAL,request)
        
    def On_AuctionShopDataRsp(self,respond):
        logging.debug("On_AuctionShopDataRsp respond = %s" % respond)
        if respond.goodsType == 0:
            self.family.limitedacution.auctionshopdatalist = []
            for i in range(len(respond.goodsIdList._values)):
                self.family.limitedacution.auctionshopdatalist.append(respond.goodsIdList._values[i].lowId)
            self.family.limitedacution.totalGoodsCount = respond.totalGoodsCount
        elif respond.goodsType >0:
            self.family.limitedacution.auctioninformationlist = []
            self.family.limitedacution.dataVersion=respond.dataVersion
            for i in range(len(respond.goodsIdList._values)):
                hiId=respond.goodsIdList._values[i].hiId
                lowId=respond.goodsIdList._values[i].lowId
                self.family.limitedacution.auctioninformationlist.append((hiId,lowId))
                self.family.SetState(STATE_GS_WORLD_LIMITED_SHOPDATA_WAIT)
                return
            self.family.SetState(STATE_GS_WORLD_LIMITED_DATAVERSION_WAIT)
            return
    #获取一件商品信息
    def WorldlLimitedGoodsDataReq(self, shopId, lowId, type, dataVersion):
        request = AuctionGoodsDataReq()
        request.shopId.hiId = 0
        request.shopId.lowId = 0
        request.type = type
        goodslist=MyAuction64BitId()
        goodslist.hiId=int(shopId)
        goodslist.lowId=lowId
        request.goodsIdList.extend([goodslist])
        request.dataVersion = dataVersion
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_AUCTION_GOODSDATA_REQ, request)
        
    #获取一件商品信息
    def AuctionGoodsDataReq(self, shopId, lowId, dataVersion, goodsnum=None):
        request = AuctionGoodsDataReq()
        request.shopId.hiId = shopId
        request.shopId.lowId = lowId
        if goodsnum is not None:
            goodslist=MyAuction64BitId()
            goodslist.hiId=int(shopId)
            goodslist.lowId=goodsnum
            request.goodsIdList.extend([goodslist])
        request.dataVersion = dataVersion
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_AUCTION_GOODSDATA_REQ, request)
        
    def On_AuctionGoodsDataRsp(self,respond):
        logging.debug("On_AuctionGoodsDataRsp respond = %s" % respond)
        if respond.result == AUCTION_BID_CANTBID:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
            return
        elif respond.result ==  AUCTION_SUCCESS :
            self.family.limitedacution.one_auctiondatainfolist=[]
            buyoutPrice = respond.goodsInfoList._values[0].buyoutPrice
            addPrice = respond.goodsInfoList._values[0].addPrice
            curPrice = respond.goodsInfoList._values[0].curPrice
            self.family.limitedacution.one_auctiondatainfolist=[buyoutPrice,addPrice,curPrice]
        elif respond.result ==  AUCTION_INVALID_DATAVER : 
            self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
            return
        self.family.SetState(STATE_GS_LIMITED_AUCTION_AUCTION)
    
    #竞拍商品
    def AuctionBidGoodsReq(self,shopId,lowId,goodsnum,isBuyout,buyoutPrice):
        request = AuctionBidGoodsReq()
        request.shopId.hiId = shopId
        request.shopId.lowId = lowId
        request.goodsId.hiId = shopId
        request.goodsId.lowId = goodsnum
        request.isBuyout = isBuyout
        request.valueCoin.coinType = 1
        request.valueCoin.coinValue = buyoutPrice
        request.dataVersion = 0
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GS_PICK_DROP_OBJECT,request)
    #获取一件商品信息
    def WorldlLimitedBidsGoodsReq(self,shopId,lowId,isBuyout,buyoutPrice):
        request = AuctionBidGoodsReq()
        request.shopId.hiId = 0
        request.shopId.lowId = 0
        request.goodsId.hiId = shopId
        request.goodsId.lowId = lowId
        request.isBuyout = isBuyout
        request.valueCoin.coinType = 1
        request.valueCoin.coinValue = buyoutPrice
        request.dataVersion = 0
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC,CLI_TO_GS_PICK_DROP_OBJECT,request)
        
    def On_AuctionBidGoodsRsp(self,respond):
        logging.debug("On_AuctionBidGoodsRsp respond = %s" % respond)
        if respond.result == AUCTION_SUCCESS:    
            self.family.SetState(STATE_GS_LIMITED_AUCTION_FINISH)
        elif respond.result == AUCTION_BID_MAX_ERROR:
            self.MarkTestCase("TestCase_Limited_BID_MAX_ERROR")
            self.family.SetState(STATE_GS_LIMITED_AUCTION_END)
        elif respond.result == AUCTION_FAILD:
            self.MarkTestCase("TestCase_Limited_Auction_Faild")
            self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
        else:
            self.family.SetState(STATE_GS_LIMITED_AUCTION_BEGIN)
            
    def On_SyncAuctionBidSuccess(self,respond):
        logging.debug("On_SyncAuctionBidSuccess respond = %s" % respond)
        if respond.shopId.hiId>0:
            self.MarkTestCase("TestCase_Limited_Auction_BidSuccess")
        else:
            self.MarkTestCase("TestCase_World_Auction_BidSuccess")
 
    def On_SyncAuctionSellout(self,respond):
        logging.debug("On_SyncAuctionSellout respond = %s" % respond)
        if respond.shopId.hiId>0:
            self.MarkTestCase("TestCase_Limited_Auction_Sellout")
        else:    
            self.MarkTestCase("TestCase_World_Auction_Sellout")

            
    #获取邮箱
    def ApplyMailBox(self):
        request = ApplyMailBox()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_APPLY_MAILBOX, request)
    
    def On_SyncMailBox(self, respond):
        logging.debug("On_SyncMailBox respond = %s" % respond)
        if respond.result == MAIL_RESULT_SUCCESS:
            if respond.mailBox:
                getAttachmentMailList = []
                self.family.bag.tradeMailCoinDict = {}
                self.family.bag.tradeMailItemDict = {}
                for mail in respond.mailBox.mailList:
                    logging.debug("mailId = %d" % mail.mailId)
                    mailDetail = MailDetailPb()
                    mailDetail.ParseFromString(mail.detail)
                    mailDetailContent = mailDetail.content.encode("utf8")
                    
                    if not mail.readed:
                        self.ReadedMailReq(mail.mailId)#读邮件
                        
                    if mail.attachmentState == MAIL_ATTACHMENT_STATE_NOTGET:#把附件id加入收取列表
                        if self.family.caseId not in [CaseManager.TRADEHOUSE_DATA, CaseManager.DATACHECKER]:
                            getAttachmentMailList.append(mail.mailId)
                        elif mailDetail.sender == u"交易行" and mailDetail.title == u"商会消息【交易成功】":
                            
                            match = re.match(r"你在商会成功出售了.*获得\[.*\]\d+银两.*", mailDetailContent)
                            if match:
                                for valueCoin in mailDetail.valueCoin:
                                    if valueCoin.coinType in self.family.bag.tradeMailCoinDict:
                                        self.family.bag.tradeMailCoinDict[valueCoin.coinType] += valueCoin.coinValue
                                    else: 
                                        self.family.bag.tradeMailCoinDict[valueCoin.coinType] = valueCoin.coinValue
                            if mailDetailContent == "这是你在商会落下的东西，还好被我捡到给你送来了。":
                                for valueCoin in mailDetail.valueCoin:
                                    if valueCoin.coinType in self.family.bag.tradeMailCoinDict:
                                        self.family.bag.tradeMailCoinDict[valueCoin.coinType] += valueCoin.coinValue
                                    else: 
                                        self.family.bag.tradeMailCoinDict[valueCoin.coinType] = valueCoin.coinValue
                                for attachments in mailDetail.attachments:
                                    gdpl = "_".join((str(x) for x in [attachments.itemTemplate.g, attachments.itemTemplate.d, attachments.itemTemplate.p, attachments.itemTemplate.l]))
                                    if gdpl in self.family.bag.tradeMailItemDict:
                                        self.family.bag.tradeMailItemDict[gdpl] += attachments.count
                                    else:  
                                        self.family.bag.tradeMailItemDict[gdpl] = attachments.count
                            
                    if "白秋琳" in mail.detail:
                        logging.debug("删除白秋琳的结为密友邮件")
                        # self.RemoveMailReq([mail.mailId])#删除邮件
                        
                if getAttachmentMailList:
                    self.GetMailAttachmentReq(getAttachmentMailList)#获取附件
        
        if self.family.GetState() == STATE_GS_FRIEND_WAIT:
            self.MarkTestCase("TestCase_Friend_RunCount")
            self.family.SetState(STATE_GS_FRIEND_SYNC_DATA)
#         elif self.family.GetState() == STATE_GS_DATACHECKER_WAIT:
#             self.family.SetState(STATE_GS_DATACHECKER_TRADE_DETAIL)
    
    #读邮件
    def ReadedMailReq(self, mailId):
        request = ReadedMailReq()
        request.mailId = mailId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_READED_MAIL, request)
    
    def On_ReadedMailRsp(self, respond):
        logging.debug("On_ReadedMailRsp respond = %s" % respond)
    
    #删除邮件
    def RemoveMailReq(self, mailIdList):
        request = RemoveMailReq()
        request.mailIdList.extend(mailIdList)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_REMOVE_MAIL, request)
    
    def On_RemoveMailRsp(self, respond):
        logging.debug("On_RemoveMailRsp respond = %s" % respond)
    
    #获取附件
    def GetMailAttachmentReq(self, mailIdList):
        request = GetMailAttachmentReq()
        request.mailIdList.extend(mailIdList)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_GET_MAIL_ATTACHMENT, request)
    
    def On_GetMailAttachmentRsp(self, respond):
        logging.debug("On_GetMailAttachmentRsp respond = %s" % respond)
        if respond.result == MAIL_RESULT_SUCCESS:
            self.MarkTestCase("GetMailAttachment")
        else:
            self.MarkTestCase("GetMailAttachment", isSuccess=False, exception="result=%s" % respond.result)
            if respond.result == MAIL_RESULT_FAILED_BAG_ROOM:
                self.ClearItemRoom()
#                gevent.sleep(5)
            
    #改名
    def ClientChangeRoleNameReq(self, name):
        request = ClientChangeRoleNameReq()
        request.member = FAMILY_MEMBER_TYPE_MAIN
        request.new_name = name
        self.SendProtocol(CLI_TO_GS_CHANGE_ROLE_NAME, request)
    
    def On_ChangeRoleNameRsp(self, respond):
        '''
        result_sucess             = 0;  //已经锁好名字, 可以进行改名
        result_gold_not_enough    = 1;  //非绑定金币不够
        result_level_illegal      = 2;  //等级不在合法范围内(<28)
        result_not_vip            = 3;  //非VIP玩家 , 不能够改名
        result_illegal            = 4;  //名字违规
        result_name_exists        = 5;  //锁定名字失败 , 名字或许已经被使用了
        result_verify_fail        = 6;  //NameServer失败.联系开发
        '''
        logging.debug("On_ChangeRoleNameRsp respond = %s" % respond)
        if self.family.GetState() == STATE_GS_SHOP_ONLINE_CHANGE_NAME_WAIT:
            self.family.SetState(STATE_GS_SHOP_ONLINE_CHANGE_NAME)
        if respond.result != 0:
            logging.debug("ChangeRoleNameRsp ERROR = %s" % respond.result)
            
    # ---师徒---
    #完成师徒任务响应
    def On_NotifyCompleteMasterTask(self, respond):
        if self.family.GetState() == STATE_GS_MASTER_COMPLETE_TASK_WAIT:
            self.family.SetState(STATE_GC_TEAM_CREATE)
    
    #修改师门信息
    def SetSchoolBaseInfoReq(self, schoolName=None, masterTitle=None):
        request = SetSchoolBaseInfoReq()
        if schoolName:
            request.schoolBaseInfo.schoolName = schoolName
        if masterTitle:
            request.schoolBaseInfo.masterTitle = masterTitle
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_SET_BASE_INFO_REQ, request)
    
    def On_SetSchoolBaseInfoResult(self, respond):
        logging.debug("On_SetSchoolBaseInfoResult respond = %s" % respond)
        if respond.result == SUCCESS:
            self.family.SetState(STATE_GS_MASTER_SEARCH)
        else:
            logging.debug("Error : On_SetSchoolBaseInfoResult result = %s" % respond.result)
            self.family.behavior = Behavior.END
    
    #设置搜索信息
    def SchoolSetSearchReq(self, beingStudent, enable, recruit):
        request = SchoolSetSearchReq()
        request.beingStudent = beingStudent
        request.enable = enable
        request.recruit = recruit
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_SET_SEARCH_REQ, request)
    
    def On_SchoolSetSearchRsp(self, respond):
        logging.debug("On_SchoolSetSearchRsp respond = %s" % respond)
        if respond.result == SUCCESS:
            self.family.SetState(STATE_GS_MASTER_RECOMMAND)
        else:
            logging.debug("Error : On_SchoolSetSearchRsp result = %s" % respond.result)
            self.family.behavior = Behavior.END
    
    #设置师门公告
    def SetSchoolAnnounceReq(self, msg):
        request = SetSchoolAnnounceReq()
        request.announce = msg
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_MODIFY_ANNOUNCE_REQ, request)
    
    def On_SetSchoolAnnounceResult(self, respond):
        logging.debug("On_SetSchoolAnnounceResult respond = %s" % respond)
        
    #获取徒弟推荐
    def RecommandStudentReq(self):
        request = RecommandStudentReq()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_RECOMMAND_STUDENT_REQ, request)
    
    def On_RecommandStudentRsp(self, respond):
        logging.debug("On_RecommandStudentRsp respond = %s" % respond)
        if respond.result == SUCCESS:
            self.family.SetState(STATE_GS_MASTER_SEND_MSG)
        else:
            logging.debug("Error : On_RecommandStudentRsp result = %s" % respond.result)
            self.family.behavior = Behavior.END
    
    #获取师父推荐
    def RecommandMasterReq(self):
        request = RecommandMasterReq()
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_RECOMMAND_MASTER_REQ, request)
    
    def On_RecommandMasterRsp(self, respond):
        logging.debug("On_RecommandMasterRsp respond = %s" % respond)
        if respond.result == SUCCESS:
            logging.debug("等待师父的招募消息")
            self.family.SetState(STATE_GS_MASTER_MSG_WAIT)
        else:
            logging.debug("Error : On_RecommandMasterRsp result = %s" % respond.result)
            self.family.behavior = Behavior.END
    
    #发出师徒请求
    def ApplySchoolReq(self, familyId, beingStudent):
        request = ApplySchoolReq()
        request.familyId = familyId
        request.beingStudent = beingStudent
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_APPLY_REQ, request)
    
    def On_ApplySchoolRsp(self, respond):
        logging.debug("On_ApplySchoolRsp respond = %s" % respond)
        if respond.beingStudent == True and respond.familyId == self.familyId:#徒弟发出请求的响应
            if respond.result != SUCCESS:
                self.family.master.RemoveMasterMsgIdList(respond.targetFamilyId)#删除请求失败的id
                self.family.SetState(STATE_GS_MASTER_SEND_REQ_TO_MASTER)
        elif respond.beingStudent == True and respond.targetFamilyId == self.familyId:#师父收到拜师申请
            if respond.result == SUCCESS and self.family.GetState() == STATE_GS_MASTER_SEND_MSG and not self.family.master.myApprenticeId:
                self.family.SetState(STATE_GS_MASTER_REPLY_APPLY)
                logging.debug("同意拜师申请")
                self.ReplySchoolApplyReq(respond.familyId, False, True)#同意拜师申请
            else:#其他的拜师申请需要拒绝
                self.ReplySchoolApplyReq(respond.familyId, False, False)#拒绝拜师申请
    
    #处理师徒申请
    def ReplySchoolApplyReq(self, familyId, beingStudent, isAgree):
        request = ReplySchoolApplyReq()
        request.familyId = familyId
        request.beingStudent = beingStudent
        request.isAgree = isAgree
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_REPLY_REQ, request)
        
    def On_ReplySchoolApplyRsp(self, respond):
        logging.debug("On_ReplySchoolApplyRsp respond = %s" % respond)
        if respond.beingStudent == False and respond.familyId == self.familyId and respond.isAgree == True:#已同意的徒弟拜师申请的响应
            if respond.result == SUCCESS:
                if self.family.GetState() == STATE_GS_MASTER_REPLY_APPLY:
                    self.family.master.myApprenticeId = respond.targetFamilyId
                    self.family.SetState(STATE_GS_MASTER_TEAM_INVITE)
            else:
                self.family.SetState(STATE_GS_MASTER_SEND_MSG)
        elif respond.beingStudent == True and respond.targetFamilyId == self.familyId and not self.family.master.myMasterId:#收到师父处理拜师申请的响应
            if respond.result == SUCCESS and respond.isAgree == True:
                self.family.master.myMasterId = respond.familyId
                logging.debug("徒弟等待师父邀请组队")
                self.family.SetState(STATE_GS_MASTER_TEAM_INVITE_WAIT)
            else:
                logging.debug("请求失败或被拒绝")
                self.family.master.RemoveMasterMsgIdList(respond.familyId)#删除请求失败的id
                self.family.SetState(STATE_GS_MASTER_SEND_REQ_TO_MASTER)#被拒绝后申请其他的师父
    
    #邀请他人进行组队
    def TeamMakeWithOtherPlayer(self, familyId, teamType=TEAM_TYPE_FREE):
        request = TeamMakeWithOtherPlayer()
        request.familyId = familyId
        request.teamType = teamType
        self.SendProtocol(CLI_TO_GS_TEAM_MAKE_WITH_OTHER_PLAYER, request)
        
    #队伍邀请答复
    def TeamInviteReply(self, inviteFamilyId, isJoinTeam=True):
        request = TeamInviteReply()
        if inviteFamilyId is -1:
            request.inviteFamilyId = self.family.familyId
        else:
            request.inviteFamilyId = inviteFamilyId
        request.isJoinTeam = isJoinTeam
        self.Teaminforset(request.leader, self.family.team_manager.myteam.leaderinf)                  
        self.SendProtocol(CLI_TO_GS_TEAM_INVITE_REPLY, request)
    
    def Teaminforset(self, request, infor):
        request.groupId = infor.groupId    
        request.gameServerId = infor.gameServerId   
        request.familyId = infor.familyId      
        request.member = infor.member                    
        request.kinId = infor.kinId                       
        request.faction = infor.faction                         
        request.name = infor.name                          
        request.portrait = infor.portrait           
        request.appearType = infor.appearType               
        request.fight=infor.fight                      
        request.level = infor.level                         
        request.hp = infor.hp                             
        request.maxhp = infor.maxhp                        
        request.sceneType = infor.sceneType                   
        request.sceneName = infor.sceneName                  
        request.sceneTemplateId = infor.sceneTemplateId               
        request.sceneInstanceId = infor.sceneInstanceId               
        request.lineId = infor.lineId                        
        request.posX = infor.posX                         
        request.posY = infor.posY      
        request.posH = infor.posH                
        request.fightState = infor.fightState                   
        request.isOnline = infor.isOnline                   
        request.isCanSignUp = infor.isCanSignUp   
        request.failSignUpCode = infor.failSignUpCode                  
        request.leagueScore = infor.leagueScore                 
        request.leagueStage = infor.leagueStage                
        request.equipSkill1 = infor.equipSkill1                 
        request.equipSkill2 = infor.equipSkill2                    
        request.equipSkill3 = infor.equipSkill3                   
        request.equipSkill4 = infor.equipSkill4                 
        request.isMengXin = infor.isMengXin  
        request.isHuiGui = infor.isHuiGui
        request.longtitude = infor.longtitude      
        request.latitude = infor.latitude  
        
    #传送至队长的线路和地图
    def TransferToServer(self, gameServerId, sceneTemplateId, sceneInstanceId):
        self.CallScript("PlayerCmd", "TransferToServer", gameServerId, sceneTemplateId, sceneInstanceId)
    
    #完成拜师的任务-通知队友
    def NofityTeammatePlaySequence(self, taskName):
        self.CallScript("TaskCmd", "ServerGuideStep", taskName, 47.0)

    #完成拜师的任务-设置任务条件
    def SetTaskStepValueWithCondType(self):
        self.CallScript("TaskCmd", "SetTaskStepValueWithCondType", 47, {"type" : "NUMBER", "value" : None}, 1)
    
    #开启师徒传功
    def ApplySchoolTrainingTask(self):
        self.CallScript("PlayerCmd", "ApplySchoolTrainingTask")

    #徒弟同意传功
    def ReplySchoolTrainingAsk(self,  familyId, isAgree=1):
        self.CallScript("PlayerCmd", "ReplySchoolTrainingAsk", familyId, isAgree)
    
    #开始师徒传功
    def BeginSchoolTraining(self):
        self.CallScript("PlayerCmd", "BeginSchoolTraining")
    
    #完成师徒传功
    def ApplyFinishSchoolTraining(self):
        self.CallScript("PlayerCmd", "ApplyFinishSchoolTraining")
    
    #断绝师徒关系
    def SchoolQuitReq(self, targetId, beingStudent=True):
        request = SchoolQuitReq()
        request.targetId = targetId
        request.beingStudent = beingStudent
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_QUIT_REQ, request)
    
    def On_SchoolQuitRsp(self, respond):
        logging.debug("On_SchoolQuitRsp respond = %s" % respond)
        if respond.result == SUCCESS and respond.srcId == self.familyId:#徒弟的响应
            if not self.family.master.hasLeave:
#                gevent.sleep(3)
                logging.debug("取消断绝师徒关系")
                self.SchoolCancelQuitReq(self.family.master.myMasterId)#取消断绝师徒关系
        elif respond.result == SUCCESS and respond.targetId == self.familyId:#师父的响应
            if self.family.master.hasLeave:
                logging.debug("同意断绝关系")
                self.SchoolQuitAgreeReq(respond.srcId)#同意断绝关系
            
    #取消断绝师徒关系
    def SchoolCancelQuitReq(self, targetId, beingStudent=True):
        request = SchoolCancelQuitReq()
        request.targetId = targetId
        request.beingStudent = beingStudent
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_CANCEL_QUIT_REQ, request)
    
    def On_SchoolCancelQuitRsp(self, respond):
        logging.debug("On_SchoolCancelQuitRsp respond = %s" % respond)
        if respond.result == SUCCESS and respond.srcId == self.familyId:
            self.family.master.hasLeave = True
            self.SchoolQuitReq(respond.targetId)#再次请求断绝关系
        elif respond.result == SUCCESS and respond.targetId == self.familyId:
            self.family.master.hasLeave = True
    
    #师父同意断绝关系
    def SchoolQuitAgreeReq(self, targetId, beingStudent=False):
        request = SchoolQuitAgreeReq()
        request.targetId = targetId
        request.beingStudent = beingStudent
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_QUIT_AGREE_REQ, request)
    
    def On_SchoolQuitAgreeRsp(self, respond):
        logging.debug("On_SchoolQuitAgreeRsp respond = %s" % respond)
        if respond.result == SUCCESS and respond.srcId == self.familyId:#师父的响应
            self.family.SetState(STATE_GS_END)
        elif respond.result == SUCCESS and respond.targetId == self.familyId:#徒弟的响应
            self.family.SetState(STATE_GS_END)
    
    #出师申请
    def GraduationReq(self, masterId):
        request = GraduationReq()
        request.masterId = masterId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_SCHOOL_GRADUATION_REQ, request)
        
    def On_GraduationRsp(self, respond):
        logging.debug("On_GraduationRsp respond = %s" % respond)
        if respond.result == SUCCESS:
            self.family.SetState(STATE_GS_END)
        else:
            logging.debug("On_GraduationRsp result not SUCCESS ! result = %s" % respond.result)
            self.family.SetState(STATE_GS_END)
    
    # --探宝 --
    # 添加探宝活动道具
    def Add_DiggerItem(self):
        for l in [3, 4, 5]:#添加三种探宝道具（夜明珠、司南针、龙纹佩）
            self.CallScriptAddStackItem(5, 1, 9, l, 10, False, 0)

    # 开启探宝
    def StartSeekTreasure(self):
        self.CallScript("PlayerCmd", "StartSeekTreasure")
        logging.debug("开启探宝")
    
    # 放入探宝材料
    def PutInTreasureClueItem(self):
        l = random.choice([3, 4, 5]) #随机使用探宝道具（夜明珠、司南针、龙纹佩）
        self.CallScript("PlayerCmd", "PutInTreasureClueItem", 5, 1, 9, l)

    # 跳转地图
    def Transfer2Map(self, mapid):
        self.CallScript("PlayerCmd", "Transfer", mapid)

    # 到达探宝地点后，点击探宝按钮
    def CollectAction(self):
        self.CallScript("PlayerCmd", "CollectAction", 2)

    # 钓鱼相关
    def BuyFishBait(self, num):
        self.CallScript("FishingCmd", "ApplyBuyFishBait",num)


        
    def ApplyAcceptFishingTask(self):
        self.CallScript("FishingCmd", "ApplyAcceptFishingTask")


    def StartFishing(self, type):
        pool_type = ["FishPoint1", "FishPoint3", "FishPoint4", "FishPoint5"]
        self.CallScript("FishingCmd", "ApplyStartFishing", pool_type[type-1])

    def ApplyGetOneFish(self, fish_type):
        self.CallScript("FishingCmd", "ApplyGetOneFishBySelf", fish_type)


    def ApplySendFishToOthers(self, fish_type):
        request = C2SCallScript()
        request.funName ="FishingCmd"
        param = C2SCallScript.Param()
        param.type = C2SCallScript.STRING
        param.str = "ApplySendFishToOthers"
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        param.number = fish_type
        request.paramList.extend([param])
        self.SendProtocol(CLI_TO_GS_CALL_SCRIPT, request)
        
    def BriberyMoney(self, Number, Quantity, channal, Statement, member=None):
        request = C2SCallScript()
        request.funName ="PlayerCmd"
        param = C2SCallScript.Param()
        param.type = C2SCallScript.STRING
        param.str = "SendGoldRedPacket"
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        param.number = Number
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        param.number = Quantity
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        param.number = channal
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.STRING
        param.str = Statement
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        if member:
            param.number = member
        request.paramList.extend([param])
        self.SendProtocol(CLI_TO_GS_CALL_SCRIPT, request)

    def ApplyOpenDungeonGame(self, Number):
        request = C2SCallScript()
        request.funName ="PlayerCmd"
        param = C2SCallScript.Param()
        param.type = C2SCallScript.STRING
        param.str = "ApplyOpenDungeonGame"
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        param.number = Number
        request.paramList.extend([param])
        param = C2SCallScript.Param()
        param.type = C2SCallScript.NUMBER
        request.paramList.extend([param])
        self.SendProtocol(CLI_TO_GS_CALL_SCRIPT, request)
 
    def PauseFishingTask(self):
        self.CallScript("FishingCmd", "ApplyStopFishing")


    def CalAllFish(self):
        self.CallScript("FishingCmd", "ApplyFinishFishingTask")

    # --押镖--

    # 添加保险劵
    def Add_EscortItme(self):
        self.CallScriptAddStackItem(5, 1, 26, 1, 1, False, 0)

    # 开始押镖
    def StartEscort(self, type):
        self.CallScript("EscortCmd", "StartEscort", type)

    def StartEScortNow(self):
        self.CallScript("EscortCmd", "StartNow")
    
    # 买保险
    def BuyInsurance(self):
        self.CallScript("EscortCmd", "BuyInsurance")
    
    #劫镖
    def EscortRob(self, npcId):
        logging.debug("EscortRob npcId = %s" % npcId)
        self.CallScript("EscortCmd", "Rob", self.family.familyId, npcId)
    
    #传送至队友处
    def TransferToTeammate(self, familyId):
        self.CallScript("PlayerCmd", "TransferToTeammate", familyId, 1)
        
    # --杀手--
    # 打开发布版获得悬赏令
    def PublishOneTask(self, famild):
        self.CallScript("PlayerCmd", "PublishOneTask", famild, 10000.0, 2.0, 1.0, u'我要上电视')

    def OpenJianghuWanted(self):
        request = self.CallScriptGetRequest("PlayerCmd", "OpenJianghuWanted", 4.0)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CALL_SCRIPT, request)

    def AcessOneTask(self, number):
        self.CallScript("PlayerCmd", "AcessOneTask", number)
        
    # 奇遇 1=收藏 2=赠送
    def FortuitousMeeting(self, type=1):
        self.CallScript("PlayerCmd", "GetRandomGift", type)
            
    # --- 助战 ---
    # 请求助战
    def SendApplyAssist(self):
        request = SendApplyAssist()
        request.check_apply_cd = False
        self.SendProtocol(CLI_TO_GS_APPLY_ASSIST, request)

    # 请求助战响应
    def On_AssistAnswerNotify(self, respond):
        logging.debug("On_AssistAnswerNotify respond = %s" % respond)
        if self.family.GetState() == STATE_GS_ASSIST_ASSISTREQUEST_WAIT:
            self.MarkTestCase("TestCase_Assist_AssistAnswerNotify")
            self.family.SetState(STATE_GS_ASSIST_ASSISTREQUEST_SUCCESS)

    # 收到助战请求
    def On_ReceiveAssistRequest(self, respond):
        self.MarkTestCase("TestCase_Assist_ReceiveAssistRequest")
        self.AnswerAssistRequest(respond.assitFamilyId)#应答助战

    # 应答助战请求
    def AnswerAssistRequest(self, familyId):
        request = AnswerAssistRequest()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_ANSWER_ASSIST_REQUEST, request)

    # 助战应答结果
    def On_AnswerAssistRequestRsp(self, respond):
        pass
    
    # --浴血争锋---
    def Do_ChaosFightCmd(self):
        self.CallScript("ChaosFightCmd", "JoinMatch")
        
    def Revival_BigFight(self):
        self.CallScript("ChaosFightCmd", "Revival", 1)
    
    # --空间送礼物--

    def GM_AddGift(self):
        self.CallScriptAddStackItem(5, 7, 10, 1, 3, False, 0)

    def SendOneGift(self, receiverId):
        request = SendGiftReq()
        request.senderId = self.family.familyId
        request.receiverId = receiverId
        request.giftInfo.desc = u'送礼么么哒'

        itemList = request.giftInfo.itemList.add()
        itemList.itemNum = 3
        itemList.itemIndex.g = 5
        itemList.itemIndex.d = 7
        itemList.itemIndex.p = 10
        itemList.itemIndex.l = 1

        shopItemList = request.giftInfo.shopItemList.add()
        shopItemList.shopId = 10
        shopItemList.goodId = 305
        shopItemList.buyCount = 1
        shopItemList.priceIndex = 0

        self.SendProtocol(CLI_TO_GS_GIFT_SEND, request)

    def On_SendGiftRsp(self, respond):
        if respond.result == 0:
            state = self.family.GetState()
            if state == STATE_MS_HOMELAND_WAIT:#空间送礼
                self.family.SetState(STATE_MS_HOMELAND_GET_MY_BOARD)
        else:
            logging.debug('On_SendOneGiftRsp fail %s' % respond)

    # ---染色---
    # 购买时装
    def BuyAvatarRequest(self, avatarId, memberType, buyIndex, AttrIndex):
        request = BuyAvatarRequest()
        request.avatarId = avatarId
        request.memberType = memberType
        request.buyIndex = buyIndex
        request.chooseAttrIndex = AttrIndex
        self.SendProtocol(CLI_TO_GS_BUY_AVATAR, request)

    # 随机颜色
    def RequestPlanAdd(self, request, place):
        plan = request.plan.add()
        plan.H = random.uniform(0, 1)
        plan.S = random.uniform(0, 1)
        plan.V = random.uniform(0, 1)
        plan.place = place

    # 染色
    def ApplyColoringItem(self, itemType, key):
        request = ApplyColoringItem()
        request.itemType = itemType
        request.key = key
        if itemType == ELEMENT_HAIR:
            self.RequestPlanAdd(request, ColoringHair)
            self.RequestPlanAdd(request, ColoringHairBand)
        else:
            self.RequestPlanAdd(request, ColoringCoat)
            self.RequestPlanAdd(request, ColoringPants)
        self.SendProtocol(CLI_TO_GS_APPLY_COLORING_ITEM, request)

    def On_SyncColoringItemRsp(self, respond):
        logging.debug('On_SyncColoringItemRsp : %s' % respond)
        if self.family.GetState() == STATE_GS_APPEARANCE_COLORING_HEAD_WAIT:
            self.MarkTestCase("TestCase_Appearance_ColoringHair")
            self.family.SetState(STATE_GS_APPEARANCE_COLORING_BODY)
        elif self.family.GetState() == STATE_GS_APPEARANCE_COLORING_BODY_WAIT:
            self.MarkTestCase("TestCase_Appearance_ColoringFashion")
            self.family.SetState(STATE_GS_APPEARANCE_COLORING_COUNT_CHECK)

    # 切换染色
    def ApplyUseColoringPlan(self, key, plan_idx):
        request = ApplyUseColoringPlan()
        request.key = key
        request.planIdx = plan_idx
        self.SendProtocol(CLI_TO_GS_APPLY_USE_COLORING_PLAN, request)

    def ApplyDelColoringPlan(self, key, plan_idx):
        request = ApplyDelColoringPlan()
        request.key = key
        request.planIdx = plan_idx
        self.SendProtocol(CLI_TO_GS_APPLY_DEL_COLORING_PLAN, request)

    def On_SyncUseColoringPlanRsp(self, respond):
        logging.debug('On_SyncUseColoringPlanRsp : %s' % respond)
        if respond.errCode == 0:
            self.MarkTestCase("TestCase_Appearance_UseColoringPlan")
        else:
            self.MarkTestCase("TestCase_Appearance_UseColoringPlan", isSuccess=False, exception="errCode=%s" % respond.errCode)
        self.family.SetState(STATE_GS_APPEARANCE_COLORING_APPLY_DEL_PLAN)

    def On_SyncDelColoringPlanRsp(self, respond):
        logging.debug('On_SyncDelColoringPlanRsp %s' % respond)
        if respond.code == 0:
            self.MarkTestCase("TestCase_Appearance_DelColoringPlan")
        else:
            self.MarkTestCase("TestCase_Appearance_DelColoringPlan", isSuccess=False, exception="code=%s" % respond.code)
        self.family.SetState(STATE_GS_APPEARANCE_FACE_BONE)

    # 染色信息同步
    def On_FamilyColoringData(self, respond):
        # print 'On_FamilyColoringData : %s' % respond
        pass
    
    def FaceEditDataAdd(self, request, opId, opValue, opType, edit_way, custom_param=None):
        edit_data = request.edit_data.add()
        edit_data.opId = opId
        edit_data.opValue = opValue
        edit_data.opType = opType
        edit_data.edit_way = edit_way
        if custom_param != None:
            edit_data.custom_param = custom_param
    
    #设置捏脸信息
    def ApplySetMemberFace(self, edit_data, hairId, bindFaceId, isBone=True, member=FAMILY_MEMBER_TYPE_NULL, hair_buy_index=None, hair_color_idnex=None):
        if not member:
            member = self.memberType
        request = ApplySetMemberFace()
        request.member = member
        request.hairId = hairId
        if hair_buy_index != None:
            request.hair_buy_index = hair_buy_index
        request.goldConsumeWay = emGoldConsumeNoneBindOnly
        request.bindFaceId = bindFaceId
        if isBone:
            opType = CustomFaceData.emFaceData_Bone
            for opId in edit_data:
                opValue = random.randint(edit_data[opId]["min"], edit_data[opId]["max"])
                if self.family.isNewRole:
                    if opValue == edit_data[opId]["default"]:
                        edit_way = init_value
                    else:
                        edit_way = new_add
                else:
                    edit_way = replace
                self.FaceEditDataAdd(request, opId, opValue, opType, edit_way)
        else:
            opType = CustomFaceData.emFaceData_Look
            for opId in edit_data:
                opValue = random.choice(edit_data[opId])
                if self.family.isNewRole:
                    edit_way = new_add
                else:
                    edit_way = replace
                self.FaceEditDataAdd(request, opId, opValue, opType, edit_way, custom_param=random.randint(1, 2))
        self.SendProtocol(CLI_TO_GS_SET_CUSTOM_FACE_DATA, request)
    
    def On_SyncSetCustomFaceResult(self, respond):
        logging.debug("On_SyncSetCustomFaceResult respond=%s" % respond)
        if self.family.GetState() == STATE_GS_APPEARANCE_FACE_BONE_WAIT:
            mark = "TestCase_Appearance_FaceBone"
            self.family.SetState(STATE_GS_APPEARANCE_FACE_LOOK)
        elif self.family.GetState() == STATE_GS_APPEARANCE_FACE_LOOK_WAIT:
            mark = "TestCase_Appearance_FaceLook"
            self.family.SetState(STATE_GS_APPEARANCE_FACE_SAVE)
        else:
            return
        if respond.result == True:
            self.MarkTestCase(mark)
        else:
            self.MarkTestCase(mark, isSuccess=False, exception="result=%s" % respond.result)
    
    def On_SyncCustomFaceStandAlone(self, respond):
        logging.debug("On_SyncCustomFaceStandAlone respond=%s" % respond)
        character = self.family.GetCharacterByPlayerId(respond.charId)
        if character and str(respond).find("customFace") != -1:
            character.faceData = respond.customFace
    
    def FaceDataElementAdd(self, request, faceDataType, opId, opValue):
        data = request.data.add()
        data.type = faceDataType
        data.opId = opId
        data.opValue = opValue
    
    #保存方案
    def ApplySaveFacePlan(self, faceData, member=FAMILY_MEMBER_TYPE_NULL, plan_index=0, appearType=emPlayer_Appearance_Male, hairId=None):
        if not member:
            member = self.memberType
        request = ApplySaveFacePlan()
        request.member = member
        request.plan_index = plan_index
        request.plan_data.appearType = appearType
        for data in faceData.data:
            self.FaceDataElementAdd(request.plan_data.faceData, data.type, data.opId, data.opValue)
        request.plan_data.faceData.face_id = faceData.face_id
        if hairId:
            request.plan_data.hairId = hairId
        self.SendProtocol(CLI_TO_GS_SAVE_FACE_PLAN, request)
        
    
    # -- 孔明灯 --
    # 领取孔明灯
    def GetLantern(self):
        self.CallScript('PlayerCmd', 'LanternGet')

    def UseLantern(self):
        index = 0
        for item in self.bagList:
            if not item.itemData.itemIndex.g == 5:
                index += 1
                continue
            if item.itemData.itemIndex.p == 30:
                self.PutOn_BagEuqipment(index, item.itemData.itemId)
                break
            index += 1

    def LanternReply(self):
        self.CallScript('PlayerCmd', 'LanternReply', 2)

    # --- 双人动作 ---
    def GesturePlay(self, id, ext):
        request = GesturePlay()
        request.familyId = self.family.familyId
        request.id = id
        request.ext = ext
        self.SendProtocol(CLI_TO_GS_GESTURE_PLAY, request)

    # 开始双人动作响应
    def On_StartDoubleAction(self, respond):
        #         print 'On_StartDoubleAction : %s' % respond
        if self.family.caseId == CaseManager.DOUBLEACTION:
            self.MarkTestCase("TestCase_DoubleAction_StartDoubleAction")
        if self.family.GetState() == STATE_GS_DOUBLEACTION_WAIT:
            self.family.SetState(STATE_GS_DOUBLEACTION_HUGGED)

    # 结束双人动作响应
    def On_StopDoubleAction(self, respond):
        #         print 'On_StopDoubleAction : %s' % respond
        if self.family.caseId == CaseManager.DOUBLEACTION:
            self.MarkTestCase("TestCase_DoubleAction_StopDoubleAction")
        if self.family.GetState() in [STATE_GS_DOUBLEACTION_STOPHUG_WAIT, STATE_GS_DOUBLEACTION_HUG_WAIT,
                                      STATE_GS_DOUBLEACTION_WAIT]:
            self.family.SetState(STATE_GS_END)
    
    
    # 发起切磋挑战
    def Ask_PK(self):
        self.CallScript("PlayerCmd", "AskFamilyPK", self.family.playerFight.GetMatchPlayid())
    
    # 接受切磋挑战
    def Accept_PK(self):
        self.CallScript("PlayerCmd", "AnswerFamilyPK", 1)
        
    # 拒绝切磋挑战，-1为假想参数，实际不传该参数
    def Reject_PK(self):
        self.CallScript("PlayerCmd", "AnswerFamilyPK", -1)
    
    # --- 衡道书 ---
    #邀请队友参加衡道书
#    def ApplyOpenDungeonGame(self, pageId, allotType=1.0):
##        self.CallScript("PlayerCmd", "GetRecommendDungeon")
##        gevent.sleep(2)
#        self.CallScript("PlayerCmd", "ApplyOpenDungeonGame", pageId)
    
    #队友应答
    def AnswerOpenDungeonGame(self):
        self.CallScript("PlayerCmd", "AnswerOpenDungeonGame", 1.0)
    
    #参加随机分配奖励
    def AnswerRollAward(self, id, index):
        self.CallScript("PlayerCmd", "AnswerRollAward", id, index)
    
    #领取通关奖励
    def GetRecommendAward(self):
        self.CallScript("PlayerCmd", "GetRecommendAward")
    
    
    # 幸运星活动
    def _GetItem(self, g, d, p, l):
        index = 0
        found = False
        
        num = (g << 36) + (d << 24) + (p << 12) + l
        for item in self.bagList:
            item_n = (item.itemData.itemIndex.g << 36) + \
            (item.itemData.itemIndex.d << 24) + \
            (item.itemData.itemIndex.p << 12) + \
            item.itemData.itemIndex.l
            if item_n < num:
                index += 1
            elif item_n == num:
                found = True
        if found:
            return (index, item)
        return None
            
                
    def UseItem(self, g, d, p, l):
        item = self._GetItem(g, d, p, l)
        if item:
            self.PutOn_BagEuqipment(item[0], item[1].itemData.itemId)
            return True
        return False
    
    def UseLuckStar(self):
        index = 0
        for item in self.bagList:
            if item.itemData.itemIndex.g == 5 and item.itemData.itemIndex.d == 4 and item.itemData.itemIndex.p == 206:
                continue
            elif not item.itemData.itemIndex.g == 5:
                index += 1
                continue
            
            if item.itemData.itemIndex.p == 211:
                self.PutOn_BagEuqipment(index, item.itemData.itemId)
                break
            index += 1
        
    # --- 聊天室 ---
    #设置说话开关(上麦/下麦)
    def ChatRoomChangeSpeakOpen(self, roomId, familyList, speakSwitch): 
        request = ChatRoomOperation()
        request.roomId = roomId
        request.speakSwitch = speakSwitch
        request.familyList._values.extend([familyList]) 
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_CHANGE_SPEAK_OPEN, request)
    
    #设置进入开关
    def ChatRoomChangeEnterOpen(self, roomId, enterSwitch):
        request = ChatRoomOperation()
        request.roomId = roomId
        request.enterSwitch = enterSwitch
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_CHANGE_ENTER_OPEN, request)
        
    #踢出成员
    def ChatRoomKickMember(self, familyId):
        request = KickChatRoomMember()
        request.familyId = familyId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_KICK_MEMBER, request)
        
    #查询聊天室
    def ChatRoomFindReq(self, roomId):
        request = ChatRoomOperation()
        request.roomId = roomId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_FIND_REQ, request)
    
    def On_FindChatRoomResult(self, respond):
        logging.debug("On_FindChatRoomResult respond = %s" % respond)
    
    #邀请成员
    def ChatRoomInviteMember(self, roomId, familyList):
        request = ChatRoomOperation()
        request.roomId = roomId
        request.familyList.extend(familyList)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_INVITE_MEMBER, request)
    
    def On_InviteEnterRoomRsp(self, respond):
        logging.debug("On_InviteEnterRoomRsp respond = %s" % respond)
        self.ChatRoomEnterRoom(respond.roomId, respond.roomType)
    
    #进入聊天室
    def ChatRoomEnterRoom(self, roomId, roomType):
        '''
            ChatRoom_None      = 0;
            ChatRoom_Kin       = 1;
            ChatRoom_Team      = 2;
            ChatRoom_SceneTeam = 3;
            ChatRoom_Custom    = 4;
            ChatRoom_Count     = 4;
        '''
        request = ChatRoomOperation()
        request.roomId = roomId
        request.roomType = roomType
        logging.debug("ChatRoomEnterRoom request = %s" % request)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_ENTER_ROOM, request)
    
    #离开聊天室
    def ChatRoomLeaveRoom(self, roomId):
        request = ChatRoomOperation()
        request.roomId = roomId
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATROOM_LEAVE_ROOM, request)
    
    #客户端进入聊天室结果
    def ChatRoomEnterRoomRes(self, familyId, isCanSpeak, name, type, memberId):
        request = ChatRoomMemberInfo()
        request.familyId = familyId
        request.isCanSpeak = isCanSpeak
        request.name = name
        request.type = type
        request.memberId = memberId
        logging.debug("ChatRoomEnterRoomRes request = %s" % request)
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CHATRROM_ENTER_ROOM_RES, request)
        
    def On_ChatRoomInfo(self, respond):
        logging.debug("On_ChatRoomInfo respond = %s" % respond)
        self.family.chatroom.SetInfo(respond)
        member = self.family.chatroom.memberDict[self.family.familyId]
        self.ChatRoomEnterRoomRes(member.familyId, member.isCanSpeak, member.name, member.type, member.familyId)
        if respond.roomType == 1:
            if respond.roomId == self.family.kinMan.id and self.family.kinMan.isLeader:
                if respond.enterSwitch == False: 
                    self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_OPEN_ENTER)
                else:
                    self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_LEADER)
            else:
                self.family.SetState(STATE_GS_REALTEAMVOICE_KIN_MEMBER)
        elif respond.roomType == 2:
            pass    


    def On_MemberChangeInfo(self, respond):
        logging.debug("On_MemberChangeInfo respond = %s" % respond)
#        if self.family.kinMan.GetLeader() and self.family.caseId == CaseManager.REALTIMEVOICE and respond.changeList: 
#            for member_info in respond.changeList:
#                if member_info.familyId not in self.family.chatroom.memberDict.keys():
#                    self.MarkTestCase("TestCase_RealTimeVoice_Room_AddOthenMember")
        self.family.chatroom.Update(respond)
        
    def On_ChatRoomOperateInfo(self, respond):
        logging.debug("On_ChatRoomOperateInfo respond = %s" % respond)
    
    def On_SyncRoomChatAppID(self, respond):
        logging.debug("On_SyncRoomChatAppID respond = %s" % respond)
    
    # ---情人节---
    #获取情人节烟花
    def GetValentineFireworks(self, count=1):
        self.CallScriptAddStackItem(5, 4, 209, 4, count, False, 0)
    
    
    
    #使用物品
    def Do_UseItem(self, itemId, member=1, useCount=1):
        request = UseItem()
        request.itemId = itemId
        request.member = member
        request.useCount = useCount
        self.SendProtocol(CLI_TO_GS_USE_ITEM, request)
    
    #根据位置使用物品
    def Do_UseItemBySlot(self, itemId, member=1, useCount=1, memberType=0, roomType=0, slotPosition=0):
        request = UseItem()
        request.itemId = itemId
        request.member = member
        request.useCount = useCount
        request.slotPos.memberType = memberType
        request.slotPos.roomType = roomType
        request.slotPos.slotPosition = slotPosition
        self.SendProtocol(CLI_TO_GS_USE_ITEM, request)
    
    def SelectAvartarBoxType(self, itemId):
        self.CallScript("ItemCmd", "SelectAvartarBoxType", {"type" : "NUMBER", "value" : None}, itemId, {"type" : "NUMBER", "value" : None}, {"type" : "NUMBER", "value" : None}, self.memberType)
    
    #---女神节---
    #获取女神节莺华玉
    def GetGoddessYingHuaYu(self, count=1):
        self.CallScriptAddStackItem(5, 4, 301, 3, count, False, 0)
    
    #是否优先使用绑定元宝
    def AvatarChangeUseBindGoldFirst(self, cost=0):
        '''
        0非绑定，1绑定
        '''
        if cost == 0:
            cost = {"type" : "NUMBER", "value" : None}
        self.CallScript("PlayerCmd", "AvatarChangeUseBindGoldFirst", cost)
    
    # ---技能---
    def EquipCharacterSkill(self, designatedSkillList=[], isReleaseByList=False):
        state = self.family.GetState()
        characterId = self.family.GetCurCharacter().GetCharacterId()
        if characterId not in self.family.skill.hasEquipedSkillCharacters:
            self.family.skill.hasEquipedSkillCharacters.append(characterId)
            self.LevelUp_Character(MaxLevel)
            gevent.sleep(2)
            self.ActiveCharacterAllSkill(self.family.GetCurCharacter().faction)
            gevent.sleep(3)
        if state != STATE_GS_SKILL_EQUIP_WAIT:
            self.family.skill.originalState = self.family.GetState()
            self.family.SetState(STATE_GS_SKILL_EQUIP_WAIT)
            if designatedSkillList:#使用指定的技能
                if isReleaseByList:
                    self.family.skill.skillReleaseList = designatedSkillList
                self.family.skill.designatedSkillList = designatedSkillList
                for pos, dSkillId in enumerate(designatedSkillList):
                    for (tSkillId, tSkillList) in SKILL_TALENT.items():
                        if dSkillId == tSkillId or dSkillId in tSkillList:
                            self.family.skill.skillDict[pos] = tSkillId
                            break
                skillList = FACTION_SKILL[self.family.GetCurCharacter().faction][1]
                while len(self.family.skill.skillDict) != 4:#没指定的位置随机选择其他技能
                    choose_id = random.choice(skillList)
                    logging.debug(self.family.skill.skillDict.values())
                    if choose_id not in self.family.skill.skillDict.values():
                        self.family.skill.skillDict[len(self.family.skill.skillDict)] = choose_id
                logging.debug(self.family.skill.skillDict)
            else:#随机选择技能
                self.family.skill.skillDict = {}
                skillList = random.sample(FACTION_SKILL[self.family.GetCurCharacter().faction][1], 4)
                for pos, skillId in enumerate(skillList):
                    self.family.skill.skillDict[pos] = skillId
        if self.family.skill.skillDict:
            for (pos, skillId) in self.family.skill.skillDict.items():
                if len(self.family.skill.designatedSkillList) > pos:#使用指定的技能天赋
                    self.family.skill.skillDict[pos] = self.family.skill.designatedSkillList[pos]
                else:#随机选择技能天赋
                    talentList = SKILL_TALENT[skillId] + [skillId]
                    self.family.skill.skillDict[pos] = random.choice(talentList)
            self.EquipSkill(*self.family.skill.skillDict.values())
        else:
            #设置技能列表
            self.family.GetCurCharacter().attackList = self.attackList = FACTION_SKILL[self.family.GetCurCharacter().faction][0]  # 普攻
            self.family.GetCurCharacter().skillList = self.skillList = self.family.skill.finalSkillList  # 技能
            logging.debug("完成技能列表设置 list = %s" % self.skillList)
            self.family.SetState(self.family.skill.originalState)
    
    #激活角色所有技能
    def ActiveCharacterAllSkill(self, faction):
        for originSkill in FACTION_SKILL[faction][1]:
            skillList = [originSkill] + SKILL_TALENT[originSkill]
            for skill_id in skillList:
                self.ActiveSkill(skill_id)
        gevent.sleep(3)
        
    #装备技能
    def EquipSkill(self, pos1SkillId, pos2SkillId, pos3SkillId, pos4SkillId):
        logging.debug("EquipSkill pos1SkillId=%s, pos2SkillId=%s, pos3SkillId=%s, pos4SkillId=%s" % (pos1SkillId, pos2SkillId, pos3SkillId, pos4SkillId))
        self.CallScript("PlayerCmd", "EquipAllSkill", self.memberType, pos1SkillId, pos2SkillId, pos3SkillId, pos4SkillId)
    
    #激活技能
    def ActiveSkill(self, skillId):
#         logging.debug("ActiveSkill skillId=%s" % skillId)
        self.CallScript("PlayerCmd", "ActiveSkill", self.memberType, skillId)
        
    
    #设置默认技能
    def SetOriginSkill(self):
        self.family.GetCurCharacter().attackList = self.attackList = FACTION_SKILL[self.family.GetCurCharacter().faction][0]  # 普攻
        self.family.GetCurCharacter().skillList = self.skillList = self.family.skill.originSkillDict[self.family.GetCurCharacter().faction]# 技能
    
    #增加峨眉技能莲花资源点
    def AddEmeiSkillPointLianhua(self, point):
        logging.debug("AddEmeiSkillPointLianhua point=%d" % point)
        self.CallScriptGmDoCommand("me:GetActivePlayer():CallAttributeFunction(200, true, 14, %d) " % point)
    
    #增加峨眉技能琴意资源点
    def AddEmeiSkillPointQinyi(self, point):
        logging.debug("AddEmeiSkillPointQinyi point=%d" % point)
        self.CallScriptGmDoCommand("me:GetActivePlayer():CallAttributeFunction(200, true, 8, %d) " % point)
    
    #增加天忍技能日资源点
    def AddTianrenSunSkillPoint(self, point):
        logging.debug("AddTianrenSunSkillPoint point=%d" % point)
        self.CallScriptGmDoCommand("me:GetActivePlayer():CallAttributeFunction(200, true, 6, %d) " % point)
        
    #增加天忍技能月资源点
    def AddTianrenMoonSkillPoint(self, point):
        logging.debug("AddTianrenMoonSkillPoint point=%d" % point)
        self.CallScriptGmDoCommand("me:GetActivePlayer():CallAttributeFunction(200, true, 4, %d) " % point)
        
    # 大秘境
    def DaMiJingEnterMission(self):
        self.CallScript("PlayerCmd", "DaMiJingEnterMission")
        
    def DaMiJingApplyFight(self, scene, level):
        self.CallScript("PlayerCmd", "DaMiJingApplyFight", scene, level)
        
    def DaMiJingApplyFinish(self, scene, level):
        self.CallScript("PlayerCmd", "DaMiJingApplyFinish", scene, level)
        
    def DaMiJingApplyMissionList(self):
        self.CallScript("PlayerCmd", "DaMiJingApplyMissionList")
        
    def DaMiJingExitMission(self):
        self.CallScript("PlayerCmd", "DaMiJingExitMission")
        
    def On_DaMiJingRobListRsp(self, respond):
        self.family.damijing.UpdateRobList(respond.robList)
        self.family.SetState(STATE_GS_DAMIJING_ROB_LIST_RSP)
        
    def ClientApplyRobMission(self):
        missionId = self.family.damijing.GetRobMIddsionId()
        if missionId is None:
            return False
        else:
            self.CallScript("PlayerCmd", "ClientApplyRobMission", missionId)
            return True
        
    def On_DaMiJingApplyRobResult(self, respond):
        if respond.result is not 0: # 入侵失败
            self.family.SetState(STATE_GS_DAMIJING_ROB_LIST_RSP)

    #喊话通知队友传送
    def CallTeamMember(self):
        self.ChatRequestByMsg(u"本队长已到达目标位置", emChatChannelTeam)
    
    #---江湖风云录---
    #增加打塔挑战次数
    def AddBossChallengeTime(self, times=10):
        self.CallScriptGmDoCommand("me:SetDataInt(510, 1, %d);" % times)
        
    #开始挑战
    def StartBossChallenge(self):
        self.CallScript("BossChallengeCmd", "ApplyStartGame")
    
    #案例标记
    def MarkTestCase(self, name, isSuccess=True, exception=""):
        if isSuccess:
            request_success.fire(request_type='get', name=name, response_time=0, response_length=0)
        else:
            request_failure.fire(request_type='get', name=name, response_time=0, exception=exception)
        
    # --- 连接相关 ---
    def ConnectGameServer(self):
        self.gsConnect = NetConnecter(self.OnGsConnect, self.OnGsDisConnect, self.OnGsProtocol, self.DoGsProtocol, is_encrypt=True, encrypt_key=(36, 45))
        self.gsConnect.connect(self.gsAddress)
        asyncresult_manager.await(self, "ConnectGameServer", TIMEOUT)

    def OnGsConnect(self):
        if self.gsChanged:
            gevent.sleep(0.5)
        self.isReady = False
        self.isLoginGame = False
        asyncresult_manager.fire(self, "ConnectGameServer", True)
        self.LoginGameHandShake()

    def OnGsDisConnect(self):
        self.isReady = False
        self.isLoginGame = False
        logging.error("game server disconnect, username id = %s, familyId = %s" % (self.family.userName, self.family.familyId))
        self.family.behavior = Behavior.END

    def GetConnect(self):
        return self.gsConnect

    def GSUninit(self):
        self.isReady = False
        if self.gsConnect:
            self.gsConnect.close()
        self.gsConnect = None
        
    def SendProtocol(self, *args, **kwds):
#         self.gsConnect.send_protocol(*args, **kwds)
        cmdId = args[0]
        if self.isReady \
        or cmdId in [CLI_TO_GS_HAND_SHAKE, CLI_TO_GS_LOGIN_GAME]:
            if cmdId == CLI_TO_GS_REDIRECT_GC:
                if self.family.KuaFuGroupId == self.family.serverGroupId:
                    args = args + (self.family.serverGroupId, )
                else:
                    args = args + (self.family.KuaFuGroupId, )
            self.gsConnect.send_protocol(*args, **kwds)
            return True
        elif self.isLoginGame:
            logging.error("LeagalNetPack : isReady=%s, last state=%d, state=%d, args=%s" 
                          % (self.isReady,
                             self.family.lastState,
                             self.family.state,
                             str(args)))
            self.MarkTestCase("LeagalNetPack", isSuccess=False, exception="caseId=%d" % self.family.caseId)
            return False
        return False
                
    
    def LoginGameHandShake(self):
        if self.family.encryptKey:
            request = LoginGameHandShake()
            request.key = self.family.encryptKey
            self.SendProtocol(CLI_TO_GS_HAND_SHAKE, request)
            asyncresult_manager.await(self, "LoginGameHandShake", TIMEOUT)
        else:
            self.MarkTestCase("LoginGameHandShake", isSuccess=False, exception="Can not find EncryptKey")
            self.family.behavior = Behavior.END
    
    def On_LoginGameHandShakeResponse(self, respond):
        HAND_SHAKE_SUCCESS = 0
        HAND_SHAKE_FAILED  = 1
        if respond.result == HAND_SHAKE_SUCCESS:
            asyncresult_manager.fire(self, "LoginGameHandShake", True)
            
            self.gsConnect.set_encrypt_key(*(self.gsConnect.get_encrypt_key(self.family.encryptKey)))
            self.ClientLoginGameRequest()
            self.isReady = True
            gevent.spawn(self.PingServer)
        else:
            asyncresult_manager.fire(self, "LoginGameHandShake", False)
            self.family.behavior = Behavior.END
            
    def Transfer(self, scene_id, x=0, y=0):
        self.CallScriptTransfer(scene_id, x, y)
    
    def CallScriptAddStackItem(self, g, d, p, l, count, is_forcbind, time_type=0, timeout=0):
        if Config.is_illegaltest():
            g = Rand.bound_uint32()
            d = Rand.bound_uint32()
            p = Rand.bound_uint32()
            l = Rand.bound_uint32()
        command = "KItem.AddStackItem(%d,%d,%d,%d,%d,%d,%s,%d);" \
                  % (self.familyId, g, d, p, l, count, str(is_forcbind).lower(), time_type)
        self.CallScriptGmDoCommand(command)

    def CallScriptTransfer(self, scene_id, x=0, y=0):
        if x and y:
            self.CallScript("PlayerCmd", "Transfer", scene_id, x, y)
        else:
            self.CallScript("PlayerCmd", "Transfer", scene_id)

    def CallScriptGmDoCommand(self, command):
        self.CallScript("GMCmd", "DoCommand", command)
        
    def CallScriptGcGmDoCommand(self, command, family_id):
        self.CallScript("GMCmd",
                         "DoCommand",
                         "GCExcute(me:GetGroupID(), {\"GM:DoCommand\", [[%s]], \"familyid:%d\"})"
                         % (command, family_id))

    def CallScript(self, fun_name, *args):
        request = C2SCallScript()
        request.funName = fun_name
        for arg in args:
            param = C2SCallScript.Param()
            if isinstance(arg, str) or isinstance(arg, unicode):
                param.type = C2SCallScript.STRING
                param.str = arg
            elif isinstance(arg, dict):
                if arg["type"] == "NUMBER" and arg["value"] == None:
                    param.type = C2SCallScript.NUMBER
                else:
                    return
            else:
                param.type = C2SCallScript.NUMBER
                param.number = arg
            request.paramList.extend([param])
        self.SendProtocol(CLI_TO_GS_CALL_SCRIPT, request)
        
    def CallGcScript(self, fun_name, *args):
        request = C2SCallScript()
        request.funName = fun_name
        for arg in args:
            param = C2SCallScript.Param()
            if isinstance(arg, str) or isinstance(arg, unicode):
                param.type = C2SCallScript.STRING
                param.str = arg
            elif isinstance(arg, dict):
                if arg["type"] == "NUMBER" and arg["value"] == None:
                    param.type = C2SCallScript.NUMBER
                else:
                    return
            else:
                param.type = C2SCallScript.NUMBER
                param.number = arg
            request.paramList.extend([param])
        self.SendProtocol(CLI_TO_GS_REDIRECT_GC, CLI_TO_GC_CALL_SCRIPT, request)

    def CallScriptGetRequest(self, fun_name, *args):
        request = C2SCallScript()
        request.funName = fun_name
        for arg in args:
            param = C2SCallScript.Param()
            if isinstance(arg, str) or isinstance(arg, unicode):
                param.type = C2SCallScript.STRING
                param.str = arg
            else:
                param.type = C2SCallScript.NUMBER
                if arg != 0:
                    param.number = arg
            request.paramList.extend([param])
        return request
    
    def SetFamilyLocationReq(self):
        request = CliSetFamilyLocationReq()
        request.info.familyId = self.family.familyId
        request.info.longitude = random.randint(-180, 180)
        request.info.latitude = random.randint(-90, 90)
        request.info.online = 1
        self.SendProtocol(CLI_TO_GS_SET_FAMILY_LOCATION_REQ, request)
        
    def On_SvrSetFamilyLocationRsp(self, respond):
        asyncresult_manager.fire(self.family, "SvrSetFamilyLocationRsp", True if respond.retCode==0 else False)
        
    def On_SyncTimeFrame(self, respond):
        self.family.openDay = datetime.date.fromtimestamp(respond.openTime)