# coding:utf8
'''
Created on 2015-5-9

@author: Administrator
'''
import io
import sys
import platform
import struct
from NetDefine import *

if sys.version_info.major == 2 and sys.version_info.minor == 7:
    platform_arch = platform.architecture()
    if "Windows" in 'Windows' in platform.system():
        if "64bit" in platform_arch:
            import _compress27_x64  as _compress
        else:
            import _compress27 as _compress
    else:
        if "64bit" in platform_arch:
            import _compress27 as _compress
        else:
            raise RuntimeError('load compress module error, current python verson "%s"' % sys.version)
else:
    raise RuntimeError('load compress module error, current python verson "%s"' % sys.version)

class NetProtocol(object):

    @staticmethod
    def unpack_head(data):
        if (len(data) < PACK_HEAD_LEN):
            raise "Nepack packdata len < PACK_HEAD_LEN"

        buffer_io = io.BytesIO(data)
        header_data = buffer_io.read(PACK_HEAD_LEN)
        header = NetPack()
        header.unserialize(header_data)
        return header

    @staticmethod
    def unpack_head_arp(data):
        if (len(data) < PACK_HEAD_ARQ_LEN):
            raise "Nepack packdata len < PACK_HEAD_ARQ_LEN_LEN"

        buffer_io = io.BytesIO(data)
        header_data = buffer_io.read(PACK_HEAD_ARQ_LEN)
        header = ARQNetPack()
        header.unserialize(header_data)
        return header

    @staticmethod
    def unpack_data(header, data):
        assert header.cmd > 0
        assert header.len > 0

        buffer_io = io.BytesIO(data)
        buffer = buffer_io.read(header.len - PACK_HEAD_LEN)
        if header.is_compressed():
            (uncompress_len, uncompress_buf) = _compress.Decompress(
                buffer,
                header.len - PACK_HEAD_LEN,
                MAX_COMPRESS_BUF_LENGTH
            )
            if uncompress_len < 0:
                raise "Nepack DeCompress failed!"
            return uncompress_buf[0:uncompress_len]
        return buffer

    @staticmethod
    def unpack(packdata):
        header_len = PACK_HEAD_LEN
        if (len(packdata) < header_len):
            raise "Nepack packdata len < PACK_HEAD_LEN"

        buffer_io = io.BytesIO(packdata)
        header_data = buffer_io.read(PACK_HEAD_LEN)
        header = NetPack()
        header.unserialize(header_data)
        assert header.cmd > 0
        assert header.len > 0

        buffer = buffer_io.read(header.len - header_len)
        if header.is_compressed():
            (uncompress_len, uncompress_buf) = _compress.Decompress(
                buffer,
                header.len - PACK_HEAD_LEN,
                MAX_COMPRESS_BUF_LENGTH
            )
            if uncompress_len < 0:
                raise "Nepack DeCompress failed!"
            return uncompress_buf[0:uncompress_len]
        return (header, buffer)

    @staticmethod
    def pack_data(cmd, data=None):

        header = NetPack()
        header.cmd = cmd

        if data is None:
            header.len = PACK_HEAD_LEN
            return header.serialize()

        length = len(data)
        header.len = PACK_HEAD_LEN + length
        
        if length >= COMPRESS_THRESHOLD:
            (compress_len, compress_buf) = _compress.Compress(data, length, MAX_COMPRESS_BUF_LENGTH)
            if (compress_len > 0 and compress_len < length):
                header.set_compress(True)
                header.len = PACK_HEAD_LEN + compress_len
                data = compress_buf[0:compress_len]
                
        return header.serialize() + data

    @staticmethod
    def pack(cmd, gc_cmd=0, server_group_id=0, protobuf=None):
        if protobuf:
            data = protobuf.SerializeToString()
        else:
            data = None
        if gc_cmd:
            if data is None:
                length = PACK_HEAD_LEN 
                header = NetPack(length, gc_cmd)
                buffer = struct.pack("H", server_group_id)+ GC_COMMAND_OFFSET_FILL + header.serialize() 
                return NetProtocol.pack_data(cmd, buffer)
            else:
                length = PACK_HEAD_LEN + len(data)
                header = NetPack(length, gc_cmd)
                buffer = struct.pack("H", server_group_id)+ GC_COMMAND_OFFSET_FILL + header.serialize() + data
                return NetProtocol.pack_data(cmd, buffer)
        else:
            return NetProtocol.pack_data(cmd, data)
