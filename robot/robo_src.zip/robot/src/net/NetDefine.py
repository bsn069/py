# -*- coding:utf-8 -*-
'''
Created on 2015-5-8

@author: Administrator
'''
import struct
from ctypes import *

#读取基础数据流状态
READ_HEAD = r"readHead"
READ_BODY = r"readBody"
READ_FINISH = r"readFinish"



#读取网络包数据固定长度
READ_PACK_LEN = 1024 * 60
COMPRESS_BIT_POS = 15
COMPRESS_THRESHOLD = 256
MAX_NET_PACK_LENGTH = 49152
MAX_COMPRESS_BUF_LENGTH = 98304


class EncrypFlag:
    NOT_ENCRYPT = 0
    XOR_ENCRYPT = 1
    TABLE_REPLACE = 2

class NetPackFlag:
    NPF_COMPRESS = 0x1 << 0  # 是否压缩
    NPF_MAX = 0x1 << 8

class EncryptKey(Union):
    class INT8VAL(Structure):
        _pack_ = 1
        _fields_ = [("subKeyA", c_uint8),
                    ("subKeyB", c_uint8),
                    ("subKeyC", c_uint8),
                    ("subKeyD", c_uint8)]
        
    class INT32VAL(Structure):
        _pack_ = 1
        _fields_ = [("subKeyX", c_uint32),
                    ("subKeyY", c_uint32)] 
           
    _fields_ = [("int8Val", INT8VAL),
                ("int32Val", INT32VAL),
                ("int64Val", c_uint64)]

class NetPack(Structure):
    _pack_ = 1
    _fields_ = [("len", c_uint32),
                ("cmd", c_uint16),
                ("flag", c_byte)]

    def reset(self):
        self.cmd = 0
        self.len = 0
        self.flag = 0

    def serialize(self):
        return buffer(self)[:]

    def unserialize(self, bytes):
        fit = min(len(bytes), sizeof(self))
        memmove(addressof(self), bytes, fit)

    def set_compress(self, compress):
        if compress:
            self.flag = self.flag | NetPackFlag.NPF_COMPRESS
        else:
            self.flag = self.flag & ~NetPackFlag.NPF_COMPRESS

    def is_compressed(self):
        return self.flag & NetPackFlag.NPF_COMPRESS

class ARQNetPack(NetPack):
    _fields_ = [("realCmd", c_uint32),
                ("seq", c_uint32)]

class HttpProxyPack(NetPack):
    _fields_ = [("seq", c_uint32),
                ("magic", c_uint32)]

#服务器网络数据包头大小
PACK_HEAD_LEN = sizeof(NetPack)
PACK_HEAD_ARQ_LEN = sizeof(ARQNetPack)
PACK_HEAD_HTTPPROXY_LEN = sizeof(HttpProxyPack)
PACK_HEAD_ARQ_EX_LEN = PACK_HEAD_ARQ_LEN - PACK_HEAD_LEN
GC_COMMAND_OFFSET_FILL = " " * (PACK_HEAD_LEN + sizeof(c_uint32))
