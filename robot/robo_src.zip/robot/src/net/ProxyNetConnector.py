# coding:utf-8
import traceback
import asyncore
import socket
import time
import gevent
import logging
import sys
from NetDefine import *
from ProxyNetProtocol import NetProtocol
from ProtoBuffer.GSToClientCmd_pb2 import GS_TO_CLI_ARQ_PACK

if sys.version_info[0] == 2:
    if sys.version_info[1] == 6:
        import _encrypt26 as _encrypt
    elif sys.version_info[1] == 7:
        import _encrypt27 as _encrypt
    else:
        raise RuntimeError('load encrypt module error, current python verson "%s"' % sys.version)
else:
    raise RuntimeError('load encrypt module error, current python verson "%s"' % sys.version)


class NetConnecter(asyncore.dispatcher):
    
    RUN = True
    LOOP = None

    @staticmethod
    def Loop():
        def Warpp():
            while NetConnecter.RUN:
                asyncore.loop(0)
                gevent.sleep(0)

        if not NetConnecter.LOOP:
            NetConnecter.LOOP = gevent.spawn(Warpp)
            
    '''
    classdocs
    on_protocol_handle格式:on_protocol_handle(NetPack)
    '''
    def __init__(self, connect_handle, close_handle, on_protocol_handle, do_protocol_handle, is_encrypt=False):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        NetConnecter.Loop()
        self.set_reuse_addr()
        # self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        self.on_connect_handle = connect_handle
        self.on_close_handle = close_handle
        self.on_protocol_handle = on_protocol_handle
        self.do_protocol_handle = do_protocol_handle
        self.is_encrypt = is_encrypt

        # self.send_cache_buf = bytearray(NetPack.MAX_NET_PACK_LENGTH)
        # self.send_cache_len = 0
        self._read_cache_buf = bytearray()
        self._read_cache_index = 0
        self._read_header = None
        self._header_data = None
        self._header_continue_arq = False
        self._header_size = PACK_HEAD_HTTPPROXY_LEN

    # recv函数有BUG，重载之
    # Issue16133
    # Error 11 is EAGAIN or EWOULDBLOCK, so asyncore/asynchat tries to read from a nonblocking socket which has no data
    # available. Since this is a temporary error the socket shouldn't be closed.
    # Issue15982
    # There are some differences between win32 and other os socket implementations. One specific I found is that in
    # windows, non-blocking socket apis will return WSAEWOULDBLOCK or 10035 instead of EWOULDBLOCK.
    def recv(self, buffer_size):
        try:
            data = self.socket.recv(buffer_size)
            if not data:
                # a closed connection is indicated by signaling
                # a read condition, and having recv() return 0.
                self.handle_close()
                return ''
            else:
                return data
        except socket.error, why:
            # winsock sometimes throws ENOTCONN
            if why.args[0] in asyncore._DISCONNECTED:
                self.handle_close()
                return ''
            elif why.args[0] in (asyncore.EAGAIN, asyncore.EWOULDBLOCK, 10035):
                return ''
            else:
                raise
        
    def handle_read(self):
        if self.closing:
            return
        # 收包
        if self._header_data:
            data = self.recv(self._read_header.len - self._header_size)
        else:
            try:
                data = self.recv(PACK_HEAD_HTTPPROXY_LEN)
            except Exception:
                print traceback.format_exc()
                return

        if data == '':
            return
        self._read_cache_buf.extend(data)
        read_cache_len = len(self._read_cache_buf)

        while True:
                if self._read_header is None:   # 读包头
                    if read_cache_len - self._read_cache_index < PACK_HEAD_HTTPPROXY_LEN:
                        break
                    data = str(buffer(self._read_cache_buf, self._read_cache_index, PACK_HEAD_HTTPPROXY_LEN))
                    self._read_cache_index += PACK_HEAD_HTTPPROXY_LEN
                    self._header_size = PACK_HEAD_HTTPPROXY_LEN
                    if self.is_encrypt:
                        _encrypt.TableDecrypt(data, len(data))
                    self._read_header = NetProtocol.unpack_head(data)
                    if(self._read_header.len == 0):  #垃圾包，丢弃
                        self._read_header = None
                        break
                    elif self._read_header.cmd == GS_TO_CLI_ARQ_PACK:
                        self._header_data = data
                        self._header_continue_arq = True
                elif self._header_continue_arq:  # 读取ARQ的扩展字段
                    if read_cache_len - self._read_cache_index < PACK_HEAD_ARQ_EX_LEN:
                        break
                    data = str(buffer(self._read_cache_buf, self._read_cache_index, PACK_HEAD_ARQ_EX_LEN))
                    self._read_cache_index += PACK_HEAD_ARQ_EX_LEN
                    self._header_size = PACK_HEAD_ARQ_LEN
                    if self.is_encrypt:
                        _encrypt.TableDecrypt(data, len(data))
                    self._read_header = NetProtocol.unpack_head_arp(self._header_data + data)
                    self._header_data = None
                    self._header_continue_arq = False
                    
                    self._read_cache_buf[:self._read_cache_index] = ''
                    self._read_cache_index = 0
                else:  # 读数据
                    body_length = self._read_header.len - self._header_size
                    if read_cache_len - self._read_cache_index < body_length:
                        break
                    data = str(buffer(self._read_cache_buf, self._read_cache_index, body_length))
                    self._read_cache_index += body_length
                    if self.is_encrypt:
                        _encrypt.TableDecrypt(data, body_length)
                    body = NetProtocol.unpack_data(self._read_header, data)
                    self.on_protocol_handle(self._read_header, body)  # 处理一个完整包
                    self._read_header = None
                    self._header_size = PACK_HEAD_HTTPPROXY_LEN

        self._read_cache_buf[:self._read_cache_index] = ''
        self._read_cache_index = 0

    def handle_connect(self):
        if self.on_connect_handle:
            self.on_connect_handle()

    def send_protocol(self, *args, **kwds):
        if self.closing:
            return

        argc = len(args)
        if argc == 1:
            buff = NetProtocol.pack(cmd=args[0])
        elif argc == 2:
            buff = NetProtocol.pack(cmd=args[0], protobuf=args[1])
        elif argc == 3:
            buff = NetProtocol.pack(cmd=args[0], gc_cmd=args[1], protobuf=args[2])
            
        # 加密
#         if 0 < buff and self.is_encrypt:
#             _encrypt.TableEncrypt(buff, len(buff))
        self.send(buff)

    def send_protocol_direct(self,  buff):
        if self.closing:
            return
        # 加密
        if 0 < buff and self.is_encrypt:
            _encrypt.TableEncrypt(buff, len(buff))
        self.send(buff)

    def handle_close(self):
        if self.connected:
            self.close()
            self.on_close_handle()

    def connect(self, address):
        asyncore.dispatcher.connect(self, address)

    def handle_error(self):
        self.handle_close()

