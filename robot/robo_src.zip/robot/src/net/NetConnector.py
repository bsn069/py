# -*- coding:utf-8 -*-
import traceback
import geventasyncore
from gevent import socket
import asyncore
import errno
import time
import gevent
import logging
import sys
import platform
import errno
from NetDefine import *
from NetProtocol import NetProtocol

if sys.version_info.major == 2 and sys.version_info.minor == 7:
    platform_arch = platform.architecture()
    if "Windows" in 'Windows' in platform.system():
        if "64bit" in platform_arch:
            from encrypt27_x64 import  TableReplace
        else:
            from encrypt27 import TableReplace
    else:
        if "64bit" in platform_arch:
            from encrypt27 import TableReplace
        else:
            raise RuntimeError('load encrypt module error, current python verson "%s"' % sys.version)
else:
    raise RuntimeError('load encrypt module error, current python verson "%s"' % sys.version)


class NetConnecter(geventasyncore.dispatcher):
    """
    classdocs
    on_protocol_handle格式:on_protocol_handle(NetPack)
    """

    RUN = True
    LOOP = None

    @staticmethod
    def Loop():
        def Warpp():
            try:
                now = time.time()
                while NetConnecter.RUN:
                    t = time.time()
                    geventasyncore.loop(0, count=1)
                    if time.time() - t>1:
                        print "lag loop more than 1s"
                    gevent.sleep(0)

            except Exception as e:
                print str(e)

        if not NetConnecter.LOOP:
            NetConnecter.LOOP = True
            NetConnecter.LOOP = gevent.spawn(Warpp)
            gevent.sleep(0)

    def __init__(self, connect_handle, close_handle, on_protocol_handle, do_protocol_handle, is_encrypt=True, encrypt_key=(49, 62)):
        geventasyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        NetConnecter.Loop()
        self.set_reuse_addr()
        # self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))#Protal压测负载机端口不够时启用
        self.on_connect_handle = connect_handle
        self.on_close_handle = close_handle
        self.on_protocol_handle = on_protocol_handle
        self.do_protocol_handle = do_protocol_handle

        self._read_cache_buf = bytearray()
        self._read_cache_index = 0
        self._read_header = None
        self._header_data = None
        self._header_continue_arq = False
        self._header_size = PACK_HEAD_LEN
        self.send_buffer = ""

        self.is_encrypt = is_encrypt
        if self.is_encrypt:
            self.encrypt = TableReplace()
            self.set_encrypt_key(*encrypt_key)
            self.encrypt_key = encrypt_key

    # recv函数有BUG，重载之
    # Issue16133
    # Error 11 is EAGAIN or EWOULDBLOCK, so asyncore/asynchat tries to read from a nonblocking socket which has no data
    # available. Since this is a temporary error the socket shouldn't be closed.
    # Issue15982
    # There are some differences between win32 and other os socket implementations. One specific I found is that in
    # windows, non-blocking socket apis will return WSAEWOULDBLOCK or 10035 instead of EWOULDBLOCK.
    def recv(self, buffer_size):
        try:
            data = self.socket.recv(buffer_size)
            if not data:
                # a closed connection is indicated by signaling
                # a read condition, and having recv() return 0.
                self.handle_close()
                return ''
            else:
                return data
        except socket.error, why:
            # winsock sometimes throws ENOTCONN
            if sys.platform == 'win32' and why.args[0] in asyncore._DISCONNECTED:
                self.handle_close()
                return ''
            elif why.args[0] in (errno.EAGAIN, errno.EWOULDBLOCK, 10035):
                return ''
            else:
                raise
            
    def handle_read(self):
        if self.closing:
            return
        # 收包
        try:
            data = self.recv(16384)
        except Exception:
            logging.error(traceback.format_exc())
            return

        if data == '':
            return
        self._read_cache_buf.extend(data)
        read_cache_len = len(self._read_cache_buf)

        while True:

            if self._read_header is None:   # 读包头
                if read_cache_len - self._read_cache_index < PACK_HEAD_LEN:

                    break
                data = str(buffer(self._read_cache_buf,
                                  self._read_cache_index, PACK_HEAD_LEN))
                self._read_cache_index += PACK_HEAD_LEN
                self._header_size = PACK_HEAD_LEN
                if self.is_encrypt:
                    self.encrypt.Decrypt(data, len(data), None, 0)
                self._read_header = NetProtocol.unpack_head(data)
                if(self._read_header.len == 0):  # 垃圾包，丢弃
                    self._read_header = None

                    break
            else:  # 读数据
                body_length = self._read_header.len - self._header_size
                if read_cache_len - self._read_cache_index < body_length:

                    break
                data = str(buffer(self._read_cache_buf,
                                  self._read_cache_index, body_length))
                self._read_cache_index += body_length
                if self.is_encrypt:
                    self.encrypt.Decrypt(data, body_length, None, 0)
                body = NetProtocol.unpack_data(self._read_header, data)
                self.on_protocol_handle(self._read_header, body)  # 处理一个完整包
                self._read_header = None
                self._header_size = PACK_HEAD_LEN

        self._read_cache_buf[:self._read_cache_index] = ''
        self._read_cache_index = 0

    def handle_connect(self):
        if self.on_connect_handle:
            self.on_connect_handle()
        
    def handle_write(self):
        sent = self.send(self.send_buffer)
        self.send_buffer = self.send_buffer[sent:]
        
    def send_protocol(self, *args, **kwds):
        if self.closing:
            return

        argc = len(args)
        if argc == 1:
            buff = NetProtocol.pack(cmd=args[0])
        elif argc == 2:
            buff = NetProtocol.pack(cmd=args[0], protobuf=args[1])
        elif argc == 4:
            buff = NetProtocol.pack(
                cmd=args[0], gc_cmd=args[1], protobuf=args[2], server_group_id=args[3])

        # 加密
        if 0 < buff and self.is_encrypt:
            #             _encrypt.TableEncrypt(buff, len(buff))
            self.encrypt.Encrypt(buff, len(buff), None, 0)
        self.send_buffer += buff


    def send_protocol_direct(self,  buff):
        if self.closing:
            return
        # 加密
        if 0 < buff and self.is_encrypt:
            #             _encrypt.TableEncrypt(buff, len(buff))
            self.encrypt.Encrypt(buff, len(buff), None, 0)
        self.send(buff)

    def handle_close(self):
        self.close()
        self.on_close_handle()

    # def handle_error(self):
    #     if self.connected:
    #         self.handle_error()
    #     self.handle_close()

    def get_encrypt_key(self, int64Val):
        e = EncryptKey()
        e.int64Val = int64Val
        return (e.int8Val.subKeyA, e.int8Val.subKeyB)
            
    def set_encrypt_key(self, subKeyA, subKeyB):
        self.encrypt.SetKey(subKeyA, subKeyB)