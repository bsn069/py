# coding:utf8
'''
Created on 2015-5-9

@author: Administrator
'''
import io
import logging
import ctypes
from NetDefine import*
import sys
if sys.version_info[0] == 2:
    if sys.version_info[1] == 6:
        import _compress26 as _compress
    elif sys.version_info[1] == 7:
        import _compress27 as _compress
    else:
        raise RuntimeError('load compress module error, current python verson "%s"' % sys.version)
else:
    raise RuntimeError('load compress module error, current python verson "%s"' % sys.version)

class NetPack(object):
    '''
    classdocs
    '''
    COMPRESS_BIT_POS = 15
    COMPRESS_THRESHOLD = 256
    MAX_NET_PACK_LENGTH = 49152
    MAX_COMPRESS_BUF_LENGTH = 98304
    GC_COMMAND_OFFSET_FILL = " " * (PACK_HEAD_FORMAT.size + ctypes.sizeof(ctypes.c_uint32))

    def PackData(self, cmd, protobuf):
        length = len(protobuf)

        if length >= NetPack.COMPRESS_THRESHOLD:
            (compress_len, compress_buf) = _compress.Compress(protobuf, length, NetPack.MAX_COMPRESS_BUF_LENGTH)
            if (compress_len > 0 and compress_len < length):
                self.SetCMD(cmd)
                self.SetCompress()
                self.total_len = PACK_HEAD_FORMAT.size + compress_len
                headbuf = PACK_HEAD_FORMAT.pack(self.cmd_and_flag, self.total_len)
                self.m_protobuffer = compress_buf[0:compress_len]
                self.m_buffer = headbuf + self.m_protobuffer
                return

        self.SetCMD(cmd)
        self.total_len = PACK_HEAD_FORMAT.size + length
        headbuf = PACK_HEAD_FORMAT.pack(self.cmd_and_flag, self.total_len)
        self.m_protobuffer = protobuf
        self.m_buffer = headbuf + self.m_protobuffer

    def UnPackData(self, packdata):
        if (len(packdata) < PACK_HEAD_LEN):
            raise "Nepack packdata len < PACK_HEAD_LEN"

        buffer_io = io.BytesIO(packdata)
        header = buffer_io.read(PACK_HEAD_FORMAT.size)
        self.cmd_and_flag, pack_length = PACK_HEAD_FORMAT.unpack(header)
        buffer = buffer_io.read(pack_length - PACK_HEAD_FORMAT.size)

        if(self.cmd_and_flag < 0):
            raise "Nepack m_cmd < 0"

        if(pack_length < 0):
            raise "Nepack packlength < 0"

        if self.IsCompressed():
            (uncompress_len, uncompress_buf) = _compress.Decompress(buffer,
                                                                    pack_length - PACK_HEAD_FORMAT.size,
                                                                    NetPack.MAX_COMPRESS_BUF_LENGTH)
            if uncompress_len < 0:
                raise "Nepack DeCompress failed!"
            self.m_protobuffer = uncompress_buf[0:uncompress_len]
            self.m_buffer = header + self.m_protobuffer
            self.total_len = PACK_HEAD_FORMAT.size + uncompress_len
            return

        self.m_protobuffer = buffer
        self.m_buffer = header + self.m_protobuffer
        self.total_len = pack_length

    def __init__(self, *T):

        def NetPack_Constructor(packdata):
            '''
            Constructor
            '''          
            self.UnPackData(packdata)
        
        def NetPack_CMDData(CMD, pdData):
            protobuf = pdData.SerializeToString()
            self.PackData(CMD, protobuf)

        def NetPack_GcCMDData(CMD, GcCMD, pdData):
            protobuf = pdData.SerializeToString()
            length = PACK_HEAD_FORMAT.size + len(protobuf)
            headbuf = PACK_HEAD_FORMAT.pack(GcCMD, length)
            buffer = NetPack.GC_COMMAND_OFFSET_FILL + headbuf + protobuf
            self.PackData(CMD, buffer)

        def NetPack_OnlyCMD(CMD):
            self.total_len = PACK_HEAD_FORMAT.size
            self.SetCMD(CMD)
            headbuf = PACK_HEAD_FORMAT.pack(self.cmd_and_flag, self.total_len)
            self.m_buffer = headbuf

        self.cmd_and_flag = 0
        self.length = 0
        self.m_protobuffer = ""
        self.m_buffer = ""

        DataLen = len(T)
        if DataLen == 2:
            if T[1] == 'OnlyCMD':
                NetPack_OnlyCMD(T[0])
            else:
                NetPack_CMDData(*T)

                
        elif DataLen == 1:
            NetPack_Constructor(*T)

        elif DataLen == 3:
            NetPack_GcCMDData(*T)
            
        
    def __del__(self):
        '''
        Destructor
        '''
    
    def Length(self):
        return self.total_len
    
    def GetProtoBuff(self):
        return self.m_protobuffer
    
    def GetProtoBuffLen(self):
        return len(self.m_protobuffer)
    
    def GetBuff(self):
        return self.m_buffer

    def SetCompress(self):
        self.cmd_and_flag |= (1 << NetPack.COMPRESS_BIT_POS)

    def ClearCompress(self):
        self.cmd_and_flag &= ~(1 << NetPack.COMPRESS_BIT_POS)

    def IsCompressed(self):
        return 0 != (self.cmd_and_flag & (1 << NetPack.COMPRESS_BIT_POS))

    def SetCMD(self, cmd):
        self.cmd_and_flag = cmd | (self.cmd_and_flag & (1 << NetPack.COMPRESS_BIT_POS))

    def GetCMD(self):
        return self.cmd_and_flag & (~(1 << NetPack.COMPRESS_BIT_POS))