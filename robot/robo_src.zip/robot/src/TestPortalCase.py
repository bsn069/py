# -*- coding:utf8 -*-
import gevent
import time
from locust import Locust, TaskSet, task
from locust.core import remotecall
from Family import Family
from TestCase.Files.Portal import Portal
from locust.events import request_failure
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese

index = 0
max_count = 1
start_time = 0
TIMEOUT =  60 * 60 * 12

@remotecall
def get_protal_account():
    global index, start_time
    if index > max_count:
        return index
    elif index == 0:
        start_time = time.time()
        print "begin time: %f" % start_time
    elif index == max_count:
        print "finished time: %f" % (time.time() - start_time)
    index += 1
    return index
    
class PortalTasks(TaskSet):
    TIMEOUT = 60
    PROTAL_SERVER = ('10.20.69.70', 9262)
    LOGIN_SERVER = ("10.20.69.70", 9252, 7)  # 7服
    
#     PROTAL_SERVER = ('192.168.32.17', 9262) # 金山云17
    # PROTAL_SERVER = ('10.20.77.53 ', 9262) #可改二 

    
    def on_start(self):
#        self.PROTAL_SERVER = ('10.20.69.70', 9262)
        gevent.sleep(1)

            
    @task(1)
    def test_portal(self):            
        result = get_protal_account()
        if result > max_count:
            request_failure.fire(request_type='get', name="[AccountEmpty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
            
#         portal = Portal(self.PROTAL_SERVER)
#         portal.Run()
            
        family = Family(ip=self.LOGIN_SERVER[0],
                port=self.LOGIN_SERVER[1],
                userName=generate_chinese(5),
                account=None,
                serverGroupId=self.LOGIN_SERVER[2],
                caseId=None)    
        

        portal = Portal(self.PROTAL_SERVER, family)
        if not portal.Run():
            return
        
        family.Init()      
        if not asyncresult_manager.wait(family, "All_LoginServer", TIMEOUT):
            family.UnLogin()
            return
        
        family.ConnectGameServer()
        if not asyncresult_manager.wait(family, "All_GameServer", TIMEOUT):
            family.UnLogin()
            return
        
        gevent.sleep(60)
        family.gameServerNetPackHandle.LeaveGame()
        asyncresult_manager.wait(family, "LeaveGame", 60)
        family.UnLogin()
            
        
class WebsiteUser(Locust):
    task_set = PortalTasks
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0
    

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
  
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)

    sys.argv.extend(["-f", "TestPortalCase.py", "--no-web",   "-H", "dddss", "-r", "1", "-c", "1"])
    locust.main.main()
