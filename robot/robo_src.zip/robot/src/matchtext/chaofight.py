# -*- coding:utf-8 -*-
import os
import time
import re
import glob  
        
class Text(object):
    def  __init__(self):
        self.total = {}                 #全部人员
        self.matchfinish = {}           #匹配对手完成
        self.lines = None
        self.txt_filenames = glob.glob('E:\\workspace\\JXSJTrunk\\src\\league\\*.log') 
        self.txt_filenames.sort()
        
    def run(self):
        for filename in self.txt_filenames:       
            f = open(filename, "r")  
            self.lines = f.readlines() #读取全部文件
            self.DealWithFile()        #正则捕捉有用信息
        self.DealWithInfor()       #处理抓取的信息
        print "剩余未匹配人数：%d" % len(self.total)
        print "完成匹配对手人数:%d" %len(self.matchfinish)
#        keys = self.total.keys()
#        for line in self.lines:
#            for i in range(len(keys)):
#                if str(keys[i]) in line:
#                    print line 
        print self.total.keys()
        
    def DealWithInfor(self):
        keys = self.matchfinish.keys()
        print "匹配总人数：%d" % len(self.total)
        for i in range(len(keys)):
            if self.total.has_key(keys[i]):
                self.total.pop(keys[i])



    def GetTimeStamp(self, year, hour):
        total = str(year)[0:4]+'-'+str(year)[4:6]+'-'+str(year)[6:8]+' '+str(hour)[0:2]+':'+str(hour)[2:4]+':'+str(hour)[4:6]
        timeArray = time.strptime(total, "%Y-%m-%d %H:%M:%S")
        timestamp = time.mktime(timeArray)
        return timestamp
         
    def DataValidation(self, line):
        if int(line.split('needRobotCount:')[1]) == 0:
            match2 = re.search('DEBUG\](\d+)\-(\d+)\:.*matchUserList:\[(\d+):.*:(\d+):.*].*matchedUserList:\[(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*,(\d+):.*:(\d+):.*]', line)
            if match2:
                time_end = self.GetTimeStamp(match2.group(1), match2.group(2))
                a = []           #当场匹配的战力列表
                b = []           #当前的ID列表
                timelist = []    #当前的时间表 
                x = 4
                y = 3
                while y <= 17:
                    timelist.append(self.total[int(match2.group(y))])
                    b.append(int(match2.group(y)))
                    self.matchfinish.setdefault(int(match2.group(y)),time_end - self.total[int(match2.group(y))])
                    y += 2
                while x <= 18:
                    a.append(int(match2.group(x)))
                    x += 2
                Poor_match = max(a)/(min(a)*1.0)
                time_start = time_end - min(timelist)
                if time_start < 60 and Poor_match >1.2:
                    print "*********************************************************************************"
                    print "error匹配时间=%f, 匹配值 = %f, 最大战力 = %d ,最小战力 = %d "%(time_start, Poor_match, max(a), min(a))
                    print "error匹配角色列表:", b
                    print "error匹配战力列表:", a
                    
        elif int(line.split('needRobotCount:')[1])>0:
                #时间戳
                a = line.split('[DEBUG]')[1].split(':')[0].split('-')
                time_end = self.GetTimeStamp(a[0], a[1])

                c = line.replace('] matchedUserList:[', ':').split('matchUserList:')[1].split(' ')[0].replace(':', ',')
                b = eval(c)
                i = 0
                minRobotValue = []
                maxFight = []
                player = []
                while i<len(b):
                    maxFight.append(b[i+2])
                    player.append(b[i])
                    minRobotValue.append(b[i+3])
                    self.matchfinish.setdefault(b[i], time_end - self.total[b[i]])
                    i += 4
                self.DealRobotRule(minRobotValue, maxFight, player, line)
                
        else:
            print line 
            
    def DealRobotRule(self, robot_value, maxFight, player, line):
        if (min(robot_value) >= 10 and max(maxFight)<=200000)\
        or (min(robot_value) >= 20 and max(maxFight)<=300000)\
        or (min(robot_value) >= 30 and max(maxFight)<=400000):
            pass
        else:
            print "error :", player
            print "power :", maxFight, max(maxFight)
            print "robot_value :", robot_value, min(robot_value)
                
    def DealWithFile(self): 
        for line in self.lines:
            match1 = re.search('DEBUG\](\d+)\-(\d+)\:.*MatchRequest.*matchUserList:\[(\d+):(\d+):(\d+):(\d+)\]', line)
            if match1:
                time = self.GetTimeStamp(match1.group(1), match1.group(2))
                self.total.setdefault(int(match1.group(3)), time)
                continue
            match2 = re.search('.*MatchResponse.*type:(\d+).*result:(\d+)', line)
            if match2:
                if int(match2.group(1)) == 2 and int(match2.group(2)) == 0:
                    self.DataValidation(line)

          
if __name__ == "__main__":  
        a = Text()
        a.run()
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
