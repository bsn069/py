# -*- coding:utf-8 -*-

import os
import time
import re
import glob  

class Player(object):
    def __init__(self):
        self.score = None
        self.playCount = None
        self.streakLoseCount = None
class Text(object):
    def  __init__(self):
        self.total = {}
        self.signup = {}                #单人
        self.double = {}                #双人
        self.third = {}                 #三人
        self.friend = {}                #匹配队友完成
        self.matchfinish = {}           #匹配对手完成
        self.lines = None
        self.txt_filenames = glob.glob('E:\\workspace\\JXSJTrunk\\src\\leage\\*.log') 
        self.txt_filenames.sort()
        self.robotnumber = 0

    def run(self):
        for filename in self.txt_filenames:       
            f = open(filename, "r")  
            self.lines = f.readlines() #读取全部文件
            self.DealWithFile()        #正则捕捉有用信息
        self.DealWithInfor()       #处理抓取的信息
        print "匹配队友完成中剩余未匹配对手人数：%d" % len(self.friend)
        print "完成匹配对手人数:%d" %len(self.matchfinish)
        print "剩余未匹配队友总人数：%d" % (len(self.total)-len(self.friend))
#        keys = self.total.keys()
#        for line in self.lines:
#            for i in range(len(keys)):
#                if str(keys[i]) in line:
#                    print line 
        print "单人池剩余：%d" % len(self.signup)
        print "双人池剩余：%d" % len(self.double)
        print "匹配到机器人数量：%d" % self.robotnumber
        
    def DealWithInfor(self):
        keys = self.matchfinish.keys()
        print "单人池：%d" % len(self.signup)
        print "双人池：%d" % len(self.double)
        print "三人人池：%d" % len(self.third)
        print "匹配总人数：%d" % len(self.total)
        print "匹配到队友人数：%d" % len(self.friend)
        for i in range(len(keys)):
            self.total.pop(int(keys[i]))
            if self.signup.has_key(int(keys[i])):
                self.signup.pop(int(keys[i]))
            elif self.double.has_key(int(keys[i])):
                self.double.pop(int(keys[i]))
            elif self.third.has_key(int(keys[i])):
                self.third.pop(int(keys[i]))  
            if self.friend.has_key(int(keys[i])):
                self.friend.pop(int(keys[i]))  
        key = self.friend.keys()
        for i in range(len(key)):
            if self.signup.has_key(int(key[i])):
                self.signup.pop(int(key[i]))
            elif self.double.has_key(int(key[i])):
                self.double.pop(int(key[i]))


    def GetTimeStamp(self, year, hour):
        total = str(year)[0:4]+'-'+str(year)[4:6]+'-'+str(year)[6:8]+' '+str(hour)[0:2]+':'+str(hour)[2:4]+':'+str(hour)[4:6]
        timeArray = time.strptime(total, "%Y-%m-%d %H:%M:%S")
        timestamp = time.mktime(timeArray)
        return timestamp
    
    def alone(self, line, dict):
        alone_match = re.search('DEBUG\](\d+)\-(\d+)\:', line)
        if alone_match:
            timestamp = self.GetTimeStamp(alone_match.group(1), alone_match.group(2))
            a = eval(line.split('matchUserList:')[1].replace(':',','))
            dict.setdefault(a[0], [a[1], timestamp])
            
    def doublesign(self, line, dict):
        double_match = re.search('DEBUG\](\d+)\-(\d+)\:', line)
        if double_match:
            timestamp = self.GetTimeStamp(double_match.group(1), double_match.group(2))
            a = eval(line.split('matchUserList:')[1].replace(':',','))
            dict.setdefault(a[0], [a[1], timestamp])
            dict.setdefault(a[4], [a[5], timestamp])
             
    def triple(self, line, dict, isfired=False):
        if isfired: 
            a = re.search('DEBUG\](\d+)\-(\d+)\:', line)
            if a:
                timestamp = self.GetTimeStamp(a.group(1), a.group(2))
                b = eval(line.split('matchUserList:')[1].replace(':',','))
                dict.setdefault(b[0], [b[1], timestamp])
                dict.setdefault(b[2], [b[3], timestamp])
                dict.setdefault(b[4], [b[5], timestamp])
        else:
            finish_match = re.search('DEBUG\](\d+)\-(\d+)\:', line)
            if finish_match:
                timestamp = self.GetTimeStamp(finish_match.group(1), finish_match.group(2))
                a = eval(line.split('matchUserList:')[1].replace(':',','))
                dict.setdefault(a[0], [a[1], timestamp])
                dict.setdefault(a[4], [a[5], timestamp])
                dict.setdefault(a[8], [a[9], timestamp])
                
    def RespondTeam(self, line, dict):
        finish_match = re.search('DEBUG\](\d+)\-(\d+)\:.*matchUserList:\[\d+\:(\d+):(\d+)\,\d+\:(\d+):(\d+)\,\d+\:(\d+):(\d+)\\].*matchedUserList:\[\d+\:(\d+):(\d+)\,\d+\:(\d+):(\d+)\,\d+\:(\d+):(\d+)\]', line)
        if finish_match:
            timestamp = self.GetTimeStamp(finish_match.group(1), finish_match.group(2)) 
            dict.setdefault(int(finish_match.group(3)), [int(finish_match.group(4)), timestamp])
            dict.setdefault(int(finish_match.group(5)), [int(finish_match.group(6)), timestamp])
            dict.setdefault(int(finish_match.group(7)), [int(finish_match.group(8)), timestamp])
            dict.setdefault(int(finish_match.group(9)), [int(finish_match.group(10)), timestamp])
            dict.setdefault(int(finish_match.group(11)), [int(finish_match.group(12)), timestamp])
            dict.setdefault(int(finish_match.group(13)), [int(finish_match.group(14)), timestamp])
            timestamp1 = timestamp - self.friend[int(finish_match.group(3))][1]
            timestamp2 = timestamp - self.friend[int(finish_match.group(9))][1]
            self.Timetojudge(timestamp1, 700)
            self.Timetojudge(timestamp2, 700)
            a = self.verification(timestamp1, int(finish_match.group(4)), timestamp2, int(finish_match.group(10)), int(finish_match.group(3)))
            if a == 0:
                print "error "+line          
            
    def RespondIntegral(self, line):
        match = re.search('DEBUG\](\d+)\-(\d+)\:.*matchUserList:\[\d+\:(\d+):(\d+)\:.*\:.*\].*matchedUserList:\[\d+\:(\d+):(\d+)\:.*\:.*,\d+\:(\d+):(\d+)\:.*\:.*\]', line)
        if match:
            timestamp = self.GetTimeStamp(match.group(1), match.group(2)) - self.total[int(match.group(3))][1] #花费的时间
            self.Timetojudge(timestamp, 149)
            if self.signup.has_key(int(match.group(5))):
                timealone1 = self.GetTimeStamp(match.group(1),match.group(2)) - self.total[int(match.group(5))][1] 
                timealone2 = self.GetTimeStamp(match.group(1),match.group(2)) - self.total[int(match.group(7))][1] 
                self.Timetojudge(timealone1, 149)
                self.Timetojudge(timealone2, 149)
                result1 = self.verification(timealone1, int(match.group(6)), timealone2, int(match.group(8)), int(match.group(5)))
                result2 = self.verification(timestamp, int(match.group(4)), timealone2, int(match.group(8)), int(match.group(3)))                
                result3 = self.verification(timestamp, int(match.group(4)), timealone1, int(match.group(6)), int(match.group(3)))                
                if (result1+result2+result3)<=1:
                    print "error 队友 " + line    

            else:
                timestamp1 = self.GetTimeStamp(int(match.group(1)),int(match.group(2))) - self.double[int(match.group(5))][1]
                self.Timetojudge(timestamp1, 149)
                result = self.verification(timestamp1, (int(match.group(6))+int(match.group(8)))/2, timestamp, int(match.group(4)), int(match.group(3)))
                if result == 0:
                    print "error 队友 " + line    
            return
        match1 = re.search('DEBUG\](\d+)\-(\d+)\:.*matchUserList:\[\d+\:(\d+):(\d+)\:.*\:.*,\d+\:(\d+):(\d+)\:.*\:.*\].*matchedUserList:\[\d+\:(\d+):(\d+)\:.*\:.*\]', line)
        if match1:
            timestamp = self.GetTimeStamp(match1.group(1),match1.group(2)) - self.total[int(match1.group(3))][1] #花费的时间
            timestamp2 = self.GetTimeStamp(match1.group(1), match1.group(2)) - self.total[int(match1.group(7))][1]
            self.Timetojudge(timestamp, 149)
            self.Timetojudge(timestamp2, 149)
            index = (int(match1.group(4))+int(match1.group(6)))/2
            result = self.verification(timestamp, index, timestamp2, int(match1.group(8)), int(match1.group(3)))
            if result == 0:
                print "error 队友 " + line    
            return
        
#        a = line.split('[DEBUG]')[1].split(':')[0].split('-')
#        timestamp = self.GetTimeStamp(a[0], a[1])
#        b = eval(line.split('matchUserList:')[1].split(' matchedUserList')[0].replace(':', ','))
#        self.DealWithList(b, self.matchfinish, timestamp)
        
    def Timetojudge(self, time, time1):
        if time >= time1:
            time = time1
            
    def DealWithFile(self): 
        for line in self.lines:
            match1 = re.match(r'.*MatchRequest.*type:(\d+).*needCount:(\d+)', line)
            if match1:
                if int(match1.group(1)) == 0:
                    needCount = int(match1.group(2))                    
                    if needCount == 1:
                        self.doublesign(line, self.total)   
                        self.doublesign(line, self.double)   #匹配阶段差一人
                    elif needCount == 2:
                        self.alone(line, self.total)    #匹配阶段差两人
                        self.alone(line, self.signup)  
                    elif needCount == 0:
                        self.triple(line, self.total)  
                        self.triple(line, self.third)   #匹配阶段不差人
                elif int(match1.group(1)) == 1:
                        self.triple(line, self.friend, isfired = True)
                continue
            match2 = re.match(r'.*MatchResponse.*type:(\d+).*result:(\d+)', line)
            if match2:
                #没有匹配到机器人
                if int(line.split('needRobotCount:')[1]) == 0:
                    if int(match2.group(1)) == 1 and int(match2.group(2)) == 0:
                        self.RespondTeam(line, self.matchfinish) #匹配敌方完成阶段 
                        
                    elif int(match2.group(1)) == 0 and int(match2.group(2)) == 0:
                        self.RespondIntegral(line)               #队友时间校验
                #匹配到机器人
                else:
                    if int(match2.group(1)) == 0 and int(match2.group(2)) == 0:
                        self.DealWithRobot(line, self.matchfinish)
                    
    def DealWithRobot(self, line, dict):
        #时间撮
        a = line.split('[DEBUG]')[1].split(':')[0].split('-')
        timestamp = self.GetTimeStamp(a[0], a[1])
        b = eval(line.split('matchUserList:')[1].split(' matchedUserList')[0].replace(':', ','))
        c = eval(line.split(' needRobotCount')[0].split('matchedUserList:')[1].replace(':', ','))

        self.DealWithList(b, dict, timestamp)
        self.DealWithList(c, dict, timestamp)
        dict = {}
        self.xxx(b, dict)
        self.xxx(c, dict)
        family_list = dict.keys()
        for i in range(len(family_list)):
            if dict[family_list[i]].score <= 1300 and dict[family_list[i]].streakLoseCount >= 2\
            or dict[family_list[i]].score <= 1600 and dict[family_list[i]].streakLoseCount >= 3\
            or dict[family_list[i]].score <= 1800 and dict[family_list[i]].streakLoseCount >= 4\
            or dict[family_list[i]].playCount <= 15:
                pass
            else:
#                print "error", family_list
                pass
        self.robotnumber += 3   
        
    def xxx(self, list, dict):
        i = 0
        while i <len(list):
            player = Player()
            player.family_id = list[i+1]
            player.score = list[i+3]
            player.playCount = list[i+4]
            player.streakLoseCount = list[i+5]
            dict [list[i]] = player
            i += 6


    #从列表取出玩家的familyid和 时间撮，联赛积分
    def DealWithList(self, list, dict, timestamp):
        i = 0
        while i <len(list):
            dict.setdefault(list[i+1], [list[i+3], timestamp])
            i += 6 
            
    def verification(self, timestamp, integral, timestamp1, fraction, familyid): 
        index = 50+(timestamp -1)*2
        index1 = 50+(timestamp1 -1)*2
        s1 = integral - index
        e1 = integral + index
        s2 = fraction - index1
        e2 = fraction + index1
        if (s2 <= e1) and (s1 <= e2):
            return 1
        else:
            return 0
          
if __name__ == "__main__":  
        a = Text()
        a.run()
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
