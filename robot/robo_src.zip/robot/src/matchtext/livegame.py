# -*- coding:utf-8 -*-
import os
import time
import re
import glob  

class Player(object):
    def __init__(self):
        self.time = None
        self.playcount = None

class Text(object):
    def  __init__(self):
        self.total = {}                 #全部人员
        self.matchfinish = {}           #匹配对手完成
        self.lines = None
        self.txt_filenames = glob.glob('E:\\workspace\\JXSJTrunk\\src\\league\\*.log') 
        self.txt_filenames.sort()
        self.single_pool = {}           #单人池
        self.double_pool = {}           #双人池
        self.triplr_pool = {}           #三人池
        self.quad_pool = {}             #四人池
        self.fire_pool = {}             #五人池
        
    def run(self):
        for filename in self.txt_filenames:       
            f = open(filename, "r")  
            self.lines = f.readlines() #读取全部文件
            self.DealWithFile()        #正则捕捉有用信息
        self.PrintInfor()
        
    def PrintInfor(self):
        print "matchfinish: ", len(self.matchfinish)
        print "total: " , len(self.total)  
        print "匹配一人池:" , len(self.single_pool.keys())
        print "匹配二人池:" , len(self.double_pool.keys())
        print "匹配三人池:" , len(self.triplr_pool.keys())
        print "匹配四人池:" , len(self.quad_pool.keys())
        print "匹配五人池:" , len(self.fire_pool.keys())
        keys = self.matchfinish.keys()
        for i in range(len(keys)):
            if self.single_pool.has_key(int(keys[i])):
                del self.single_pool[int(keys[i])]
            elif self.double_pool.has_key(int(keys[i])):
                del self.double_pool[int(keys[i])]
            elif self.triplr_pool.has_key(int(keys[i])):
                del self.triplr_pool[int(keys[i])]
            elif self.quad_pool.has_key(int(keys[i])):
                del self.quad_pool[int(keys[i])]
            elif self.fire_pool.has_key(int(keys[i])):
                del self.fire_pool[int(keys[i])]
        print "成功率： ", len(self.matchfinish)/(len(self.total) * 1.00000)*100 ,"%"
        print "一人池:" , len(self.single_pool.keys())
        print "二人池:" , len(self.double_pool.keys())
        print "三人池:" , len(self.triplr_pool.keys())
        print "四人池:" , len(self.quad_pool.keys())
        print "五人池:" , len(self.fire_pool.keys())
        
    def DealWithFile(self):
        for line in self.lines:
            if "[MatchMgr::MatchResponse]" in line:
                self.GetFinishPlayer(line)
            elif "LiveGameMatchSignUp::JoinMatch" in line:
                self.JoinFinishPlayer(line)
            elif "MatchMgr::MatchRequest" in line:
                self.DealWithTeam(line)
                
    def DealWithTeam(self, line):
        team_list = eval(line.split('matchUserList:')[1].replace(':', ","))
        if len(team_list)/2 == 1:
            self.PoolAddPeople(team_list, self.single_pool)
        elif len(team_list)/2 ==2:
            self.PoolAddPeople(team_list, self.double_pool)
        elif len(team_list)/2 ==3:
            self.PoolAddPeople(team_list, self.triplr_pool)
        elif len(team_list)/2 ==4:
            self.PoolAddPeople(team_list, self.quad_pool)
        elif len(team_list)/2 ==5:
            self.PoolAddPeople(team_list, self.fire_pool)
            
    def PoolAddPeople(self, teamlist, dict):
        i = 0
        while i< len(teamlist):
            dict.setdefault(teamlist[i], teamlist[i+1])
            i+=2
    #获取匹配完成人数          
    def GetFinishPlayer(self, line):  
        #时间撮
        time = line.split('[DEBUG]')[1].split(': [')[0].split('-')
        timestamp = self.GetTimeStamp(time[0], time[1]) 
        timelist = []
        playcount = []
        b = eval((line.split('matchedUserList:')[1].split(']')[0]+'}').replace('[', '{'))
        for i in range(len(b.keys())):
            self.AddPalyer(b.keys()[i], timestamp, b[b.keys()[1]], self.matchfinish)
            timelist.append(timestamp - self.matchfinish[b.keys()[i]].time)
            playcount.append(self.matchfinish[b.keys()[i]].playcount)
        d = eval(line.split('matchUserList:')[1].split(' matchedUserList:')[0].replace('[','{').replace(']', '}'))
        for i in range(len(d.keys())):
            self.AddPalyer(d.keys()[i], timestamp, d[d.keys()[i]], self.matchfinish)
            timelist.append(timestamp - self.matchfinish[d.keys()[i]].time)
        #匹配到机器人
        if line.split('needRobotCount:')[1]>0:
            #合并池
            if max(playcount)>10 and  min(playcount)<10:
                pass
            #单人池
            else:
                pass
        #没有匹配到机器人
        else:
            #合并池
            if max(playcount)>10 and  min(playcount)<10:
                pass
            #单人池
            else:
                pass
            
    def JoinFinishPlayer(self, line):
        #获取时间撮 
        time = line.split('[INFO ]')[1].split(': [')[0].split('-') 
        timestamp = self.GetTimeStamp(time[0], time[1]) 
        
        b = eval(line.split('matchUserList:')[1].replace('[','{').replace(']', '}'))
        for i in range(len(b.keys())):
            self.AddPalyer(b.keys()[i], timestamp, b[b.keys()[i]], self.total)
    
    def GetTimeStamp(self, year, hour):
        total = str(year)[0:4]+'-'+str(year)[4:6]+'-'+str(year)[6:8]+' '+str(hour)[0:2]+':'+str(hour)[2:4]+':'+str(hour)[4:6]
        timeArray = time.strptime(total, "%Y-%m-%d %H:%M:%S")
        timestamp = time.mktime(timeArray)
        return timestamp
         
    def AddPalyer(self, familyid, timestamp, playcount, dict):
        player = Player()
        player.time = timestamp
        player.playcount = playcount
        dict[familyid] = player
        
          
if __name__ == "__main__":  
        a = Text()
        a.run()
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
