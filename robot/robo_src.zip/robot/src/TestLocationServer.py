# -*- coding:utf8 -*-
import gevent
import time
import traceback
from locust import Locust, TaskSet, task
from locust.core import remotecall
from Family import Family
from TestCase.Files.LBSLocation import Loction
from locust.events import request_failure
from locust.asyncevent import asyncresult_manager
from Tools.GenerateChinese import generate_chinese
from ModuleState.StateDefine import *

index = 100000
max_count = 1000000
start_time = 0
TIMEOUT =  60 * 60 * 12
@remotecall
def get_familyid():
    global index
    if index < max_count:
        index += 1
        return index
    else:
        return -1
        
class LocationTest(TaskSet):
    TIMEOUT = 60
    PROTAL_SERVER = ('120.92.16.110', 9600)
#    PROTAL_SERVER = ('10.20.69.70', 9600)#7服
#    PROTAL_SERVER = ('192.168.32.2', 9275)
    
    def on_start(self):
        gevent.sleep(1)

            
    @task(1)
    def test_lbs(self):            
        familyid = get_familyid()
        if familyid == -1:
            request_failure.fire(request_type='get', name="[AccountEmpty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
        loction = Loction(self.PROTAL_SERVER, familyid)
        loction.ConnectLocationServer()
        if not loction.family.locationServerNetPackHandle.lsConnect:
            loction.Uninit()
            return
        gevent.sleep(3)
        loction.family.SetState(STATE_PS_ONE)
        loction.family.locationServerNetPackHandle.isDiffCheck = False
        try:
            while loction.family.GetState() == STATE_PS_ONE: 
                start_time = time.time()
                for i in range(500):#模仿gs每秒发500个
                    loction.LocationServerStart() #容错检测
                end_time = time.time() - start_time
                if end_time<1:
                    gevent.sleep(1-end_time)
        except Exception:
                print traceback.format_exc()
        finally:
                loction.Uninit()
        
    @task(0)
    def test_ill_lbs(self):            
        familyid = get_familyid()
        if familyid == -1:
            request_failure.fire(request_type='get', name="[AccountEmpty]", response_time=0, exception="Account Empty")
            asyncresult_manager.wait(self, "AccountEmpty", 99999999999)
        loction = Loction(self.PROTAL_SERVER, familyid)
        loction.ConnectLocationServer()
        if not loction.family.locationServerNetPackHandle.lsConnect:
            loction.Uninit()
            return
        gevent.sleep(3)
        loction.family.SetState(STATE_PS_ONE)
        loction.family.locationServerNetPackHandle.isDiffCheck = True
        try:
            while loction.family.GetState() == STATE_PS_ONE: 
                start_time = time.time()
                for i in range(500):#模仿gs每秒发500个
                    loction.ILL_SetKinLocationGeography() #容错检测
                end_time = time.time() - start_time
                if end_time<1:
                    gevent.sleep(1-end_time)
        except Exception:
                print traceback.format_exc()
        finally:
                loction.Uninit()
class WebsiteUser(Locust):
    task_set = LocationTest
    stop_timeout = 60 * 60 * 24
    min_wait = 0
    max_wait = 0
    

if __name__ == "__main__":
    import locust.main
    import sys
    import logging
  
    logging.basicConfig(level=logging.DEBUG)
#     logging.basicConfig(level=logging.ERROR)

    sys.argv.extend(["-f", "TestLocationServer.py", "--no-web",   "-H", "dddss", "-r", "2", "-c", "1"])
    locust.main.main()
