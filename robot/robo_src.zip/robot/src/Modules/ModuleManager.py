# -*- coding:utf-8 -*-
'''
Created on 2015-5-27

@author: Administrator
'''
from Cmd2protocol_Modules import *
from Item.Item import *
from Shop.Shop import *
from Skill.Skill import *
from net.NetProtocol import NetProtocol

class ModuleManager(object):
    def __init__(self):
        
        self.REGEDIT_MODULE ={
                                    "Item":True,
                                    "Shop":True,
                                    "Skill":True,
                                }
        
        self.OpenModules = []
        self.RegeditHandle() 
        self.RegeditModule()
        
        
    def RegeditModule(self):
        i = 1
        for (moduleName, isOpen) in self.REGEDIT_MODULE.items():
            i+=1
            if((moduleName == "Item") and isOpen == True):
                func = getattr(item, "OnProtocol")
                self.OpenModules.append(func)
            if((moduleName == "Shop") and isOpen == True):
                func = getattr(shop, "OnProtocol")
                self.OpenModules.append(func)
            if((moduleName == "Skill") and isOpen == True):
                func = getattr(skill, "OnProtocol")
                self.OpenModules.append(func)
                
    def RegeditHandle(self):
        for (protocolId, name) in S2CProtocolModules.items():
            try:
                func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
                self.respondS2CHandler[protocolId] = func
            except AttributeError, e:
                print str("ModuleManager has no attribute %s%s" % ("On_", str(name).split(".")[-1][:-2]))
    
    def OnProtocol(self, cmd, body):
        if cmd in S2CProtocolModules:
            protobuf = S2CProtocolModules[cmd]()
            protobuf.ParseFromString(body)
        
            if cmd in self.respondS2CHandler:
                self.respondS2CHandler[cmd](protobuf)   
        else:
            self.BroadcastProtocal(cmd, body)
    
    def BroadcastProtocal(self, cmd, netpack):
        for func in self.OpenModules:
            ret = func(cmd, netpack)
            if(ret):
                return
            
moduleManager = ModuleManager()