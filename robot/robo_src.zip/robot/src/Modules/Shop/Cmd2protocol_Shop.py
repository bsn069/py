# -*- coding:utf-8 -*-
from net.ProtoBuffer.LoginAndClient_pb2 import *
from net.ProtoBuffer.GSToClient_pb2 import *
from net.ProtoBuffer.ClientToGS_pb2 import *

from net.ProtoBuffer.LoginAndClientCmd_pb2 import*
from net.ProtoBuffer.ClientToGSCmd_pb2 import *
from net.ProtoBuffer.GSToClientCmd_pb2 import *


#客户端到游戏服务GS
C2SProtocolShop = {
#    CLI_TO_GS_ENTER_GAME:EnterGame,
#    CLI_TO_GS_LEAVE_GAME:LeaveGame,
#    CLI_TO_GS_LOGIN_GAME:ClientLoginGameRequest,
#    CLI_TO_GS_FAMILIY_LIST:ClientFamilyListRequest,
#    CLI_TO_GS_CREATE_FAMILY:ClientCreateFamilyRequest,
#    CLI_TO_GS_ASK_ROLE_NAME:ClientAskRoleNameRequest,
#    CLI_TO_GS_PING:PingReply,
}

#游戏服务器GS到客户端
S2CProtocolShop = {
#    GS_TO_CLI_LOGIN_GAME:ClientLoginGameResponse,
#    GS_TO_CLI_NOTIFY_CLIENT_STATE:NotifyClientState,
#    GS_TO_CLI_FAMILIY_LIST:ClientFamilyListResponse,
#    GS_TO_CLI_CREATE_FAMILIY:ClientCreateFamilyResponse,
#    GS_TO_CLI_ASK_ROLE_NAME:ClientAskRoleNameResponse,
#    GS_TO_CLI_PING:PingClient,
#     GS_TO_CLI_SYNC_CURRENT_FAMILY:CurrentFamily,
#     GS_TO_CLI_SYNC_CURRENT_PLAYER:CurrentPlayer,
#     GS_TO_CLI_PLAYER_ENTER_SCENE:PlayerEnterScene,
}
