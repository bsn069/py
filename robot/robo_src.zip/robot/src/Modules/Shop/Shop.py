# -*- coding:utf-8 -*-
'''
Created on 2015-5-28

@author: Administrator
'''
from Cmd2protocol_Shop import *
class Shop(object):
    def __init__(self):
        
        self.respondS2CHandler = []
        self.RegeditHandle()
        
    def RegeditHandle(self):
        for (protocolId, name) in S2CProtocolShop.items():
            func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
            self.respondS2CHandler[protocolId] = func
    
    def OnProtocol(self, cmd, body):
        if cmd in S2CProtocolShop:
            protobuf = S2CProtocolShop[cmd]()
            protobuf.ParseFromString(body)

            if cmd in self.respondS2CHandler:
                self.respondS2CHandler[cmd](protobuf)   
                return True
        else:
            return False
    

shop = Shop()