# -*- coding:utf-8 -*-
'''
Created on 2015-5-28

@author: Administrator
'''
from Cmd2protocol_Skill import *
import gevent
import random
class Skill(object):
    def __init__(self):
        
        self.respondS2CHandler = {}
        self.RegeditHandle()
        self.gs_connect = None
        self.sum = 0
        self.me = None
        
    def RegeditHandle(self):
        for (protocolId, name) in S2CProtocolSkill.items():
            try:
                func = getattr(self, "On_" + str(name).split(".")[-1][:-2])
                self.respondS2CHandler[protocolId] = func
            except AttributeError, e:
                print str("Skill has no attribute %s%s" % ("On_", str(name).split(".")[-1][:-2]))
    
    def OnProtocol(self, cmd, body):
        if cmd in S2CProtocolSkill:
            protobuf = S2CProtocolSkill[cmd]()
            protobuf.ParseFromString(body)

            if cmd in self.respondS2CHandler:
                self.respondS2CHandler[cmd](protobuf)   
                return True
        else:
            return False
        
    def Skill_Start(self, skillId, gs_connect, me, target):
        self.gs_connect = gs_connect
        self.me = me
#         self.Skill_Knife(me, target)

        if skillId == -1:
            random_skill = random.randint(0, 5)
            random_skill = 0#
            
            if random_skill == 0:
                print "%s release Skill_Knife" % self.me.name   
                self.Skill_Knife(me, target)
             
            if random_skill == 1:
                print "%s release Skill_A" % self.me.name   
                self.Skill_A()
             
            if random_skill == 2:
                print "%s release Skill_B" % self.me.name  
                self.Skill_B()
             
            if random_skill == 3:
                print "%s release Skill_C" % self.me.name   
                self.Skill_C()
             
            if random_skill == 4:
                print "%s release Skill_D" % self.me.name   
                self.Skill_D()
                
            if random_skill == 5:
                print "%s release Skill_Shoe" % self.me.name  
                self.Skill_Shoe()
                
        else:
            self.Skill_ExcuteById(skillId)
    
#    def Skill_Knife(self, me, target):
#        print "Skill_Knife"
#        request = CastSkill()
#        request.tick = 0
#        request.skill_id = 1
#        request.skill_level = 1
#        request.dir = me.GetCharacterDir()
#        request.posX = me.GetCharacterposX()
#        request.posY = me.GetCharacterposY()
#        #request.target_id = 268435518
#        #request.target_id = 268435490 268435496
#        request.target_id = me.GetCharacterId()
#        request.target_posX = me.GetCharacterposX()
#        request.target_posY = me.GetCharacterposY()
#        self.gsConnect.send_protocol(29, request)
    def Skill_random(self):
        random_skill = random.randint(0, 5)
            
        if random_skill == 0:
            self.Skill_Knife(self.me, None)
         
        if random_skill == 1:
            self.Skill_A()
         
        if random_skill == 2:
            self.Skill_B()
         
        if random_skill == 3:
            self.Skill_C()
         
        if random_skill == 4:
            self.Skill_D()
            
        if random_skill == 5:
            self.Skill_Shoe()


    def Skill_ExcuteById(self, skillId):
        request = CastSkill()
        request.tick = 0
        request.skill_id = skillId
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)





    def Skill_Knife(self, me, target):
        #print "Skill_Knife"
        if(me == None):
            return 
        
        request = CastSkill()
        request.tick = 0
        request.skill_id = random.randint(1, 5)
        request.skill_level = 1
        request.dir = me.GetCharacterDir()
        request.posX = me.GetCharacterposX()
        request.posY = me.GetCharacterposY()
        #request.target_id = 268435518
        #request.target_id = 268435490 268435496
        if(target == None):
            request.target_id = me.GetCharacterId()
            request.target_posX = me.GetCharacterposX()
            request.target_posY = me.GetCharacterposY()
        else:
            request.target_id = target.id
            request.target_posX = target.stateParam.posX
            request.target_posY = target.stateParam.posY

        print "Skill_Knife111111111111111"
        self.gs_connect.send_protocol(29, request)

        
    def Skill_Shoe(self):
#         print "Skill_Shoe"
        request = CastSkill()
        request.tick = 0
        request.skill_id = 5
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)
        
    def Skill_A(self):
#         print "Skill_A"
        request = CastSkill()
        request.tick = 0
        request.skill_id = 11
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)
        
    def Skill_B(self):
#         print "Skill_B"
        request = CastSkill()
        request.tick = 0
        request.skill_id = 10
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)
        
    def Skill_C(self):
#         print "Skill_C"
        request = CastSkill()
        request.tick = 0
        request.skill_id = 8
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)
        
    def Skill_D(self):
#         print "Skill_D"
        request = CastSkill()
        request.tick = 0
        request.skill_id = 7
        request.skill_level = 1
        request.dir = 0.0
        request.posX = 14.0
        request.posY = 14.0000038147
        request.target_id = 268435518
        request.target_posX = 14.0
        request.target_posY = 14.0000038147
        self.gs_connect.send_protocol(29, request)
        
    def On_SyncCastSkill(self, respond):
        #print u"释放技能"
#         print respond
        pass
        
    def On_SyncSkillState(self, respond):
        #print u"同步技能状态"
#         print respond
        pass
        
    def On_SyncBuffRepresent(self, respond):
#         print "On_SyncBuffRepresent"
#         print respond
        pass
    

skill = Skill()