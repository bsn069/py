# -*- coding:utf-8 -*-
from net.ProtoBuffer.LoginAndClient_pb2 import *
from net.ProtoBuffer.GSToClient_pb2 import *
from net.ProtoBuffer.ClientToGS_pb2 import *

from net.ProtoBuffer.LoginAndClientCmd_pb2 import*
from net.ProtoBuffer.ClientToGSCmd_pb2 import *
from net.ProtoBuffer.GSToClientCmd_pb2 import *


#客户端到游戏服务GS
C2SProtocolSkill = {
    CLI_TO_GS_CAST_SKILL:CastSkill,
}

#游戏服务器GS到客户端
S2CProtocolSkill = {
    GS_TO_CLI_SYNC_CAST_SKILL:SyncCastSkill,
    GS_TO_CLI_SYNC_SKILL_STATE:SyncSkillState,
}
