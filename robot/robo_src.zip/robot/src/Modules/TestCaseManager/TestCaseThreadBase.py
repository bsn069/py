#!/usr/bin/env python2.7
# coding=gb18030
import random
import asyncore
import gevent
from gevent import Greenlet

"""
    ���Ǳ�QH_Main���õ��߳���
    ����action�����ᱻTestcase_Move��example���е�action������д
"""

class TestCaseThreadBase(Greenlet):
    def __init__(self, ip, port, username, sleepTime): 
        Greenlet.__init__(self) 
        self._thread_flag = False
        self._sleep_time  = 2
        self._username = username
        self._ip = ip
        self._port = int(port)
        self._sleepTime = int(sleepTime)
        
    def run(self):
        while(self._thread_flag == False):
            gevent.sleep(0)
    
    def action(self):
        """    this action method will be override by TestCase_xx.py in _action method """ 
        pass
        
    def stop(self):
        self._thread_flag = True
    

if __name__ == "__main__":
    pass
    