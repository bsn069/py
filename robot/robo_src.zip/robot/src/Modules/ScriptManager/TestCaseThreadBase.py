#!/usr/bin/env python2.7
# coding=gb18030

import random
import asyncore
import gevent
from gevent import Greenlet
from Tools.JxLog import *
import socket
from Family import *
# from LocustPlugin.ModuleAsyncResultManager import *
from locust.asyncevent import asyncresult_manager
"""

"""

class TestCaseThreadBase(Greenlet):
    def __init__(self, host, port, username, sleepTime): 
        Greenlet.__init__(self) 
        self._thread_flag = False
        self._sleep_time  = 2
        self._sleepTime = int(sleepTime)
        self.family = Family(host, port, username)
        
    def setplayerinfo(self, ip, port, username):
        self._username = username
        self._ip = ip
        self._port = port
    
    def settime(self, time):
        if(time <= 0):
            return
        self._sleep_time = time
        
    def run(self):
        InitLog()
        
        while(True):
            try:
                logging.debug("running:" + self.family.userName)
                ###main logic####
                if(self.family.GetState() == STATE_INVALID):
                    self._enterWorld()

                else:
                    # self.action()
                    pass
                    
                ###main logic####
                gevent.sleep(0.01)
                
            except socket.error:
                gevent.sleep(0)
                

    def _enterWorld(self):
        self.family.Login()
        asyncresult_manager.wait(self.family, "All_LoginServer", 30)
        self.family.ConnectGameServer()


    def action(self):
        """    this action method will be override by TestCase_xx.py in _action method """
        pass
        
    def stop(self):
        self._thread_flag = True
    

if __name__ == "__main__":
    pass
