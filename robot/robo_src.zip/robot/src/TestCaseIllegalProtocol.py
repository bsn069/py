# coding:utf-8
'''
Created on 2015年12月3日

@author: zhangpengfei
'''

import asyncore
import socket

from locust import Locust, TaskSet, task

from Family import *
from GenerateChinese import generate_chinese
from Tools.Rand import *
from src.Tools.IncludeDir import InsertIncludeDir

InsertIncludeDir("./net")
from net.ProtoBuffer.ClientToGS_pb2 import *
from net.ProtoBuffer.ClientToGSCmd_pb2 import *
from net.Common.ComDefine_pb2 import *
from net.NetDefine import *
from net.NetProtocol import NetPack
import _encrypt

PROTOCAL_DATA_MAXLEN = 1024

class Connector(asyncore.dispatcher):
    # 服务端设置的网络超时时间是35s
    timeout = 5
    
    def __init__(self, host, port, case_name, protocal_id, buf):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect( (host, port) )
        self.case_name = case_name
        self.protocal_id = protocal_id
        self.buf = buf
        
    def handle_connect(self):
        self.send(self.buf)
    
    def handle_close(self):
        self.close()
        
    def handle_read(self):
        buf = self.recv(PROTOCAL_DATA_MAXLEN)
        if  buf == '': # 连接被关闭了
            asyncresult_manager.fire(self, self.case_name, True)
        else:   # 出错了，服务器有回包了
            asyncresult_manager.fire(self, self.case_name, False, error="protocal = %d" % self.protocal_id)
            self.close()
            
    def writable(self):
        gevent.sleep(0.1)
        return (len(self.buf) > 0)
    
    def handle_write(self):
        if 0 < self.buf:
            _encrypt.TableEncrypt(self.buf, len(self.buf))
        sent = self.send(self.buf)

  
class ProtocolFormat(TaskSet):

    def on_start(self):
        self.host = "10.20.110.39"
        # self.host = "172.18.99.42"
        self.loginPort = 9252
        self.gsPort = 9208
        self.isLogin = random.choice([True, False])

    def rand_cmd(self):
        return random.choice(CLIToGSProtocol.items())

    def run_task(self, case_name, protocal_id, buf):
        if self.isLogin:
            family = Family(self.host, self.loginPort, generate_chinese(4))
            family.RunType = 0#功能测试流程
            family.Init()
            if not asyncresult_manager.wait(family, "All_LoginServer", 30):
                family.loginServerNetPackHandle.LSUninit()
                return
            family.ConnectGameServer()
            asyncresult_manager.wait(family, "All_GameServer", 60)
            if family.gameServerNetPackHandle.gsConnect:
                family.gameServerNetPackHandle.gsConnect.send_protocol_direct(buf)
                gevent.sleep(5)
            if family.loginServerNetPackHandle:
                family.loginServerNetPackHandle.LSUninit()
            if family.gameServerNetPackHandle:
                family.gameServerNetPackHandle.GSUninit()
        else:
            conn = Connector(self.host, self.gsPort, case_name, protocal_id, buf)
            gevent.sleep(5)
            if conn and conn.connected:
                asyncresult_manager.wait(conn, case_name, Connector.timeout)
                if conn.connected:
                    conn.close()

    @task
    def head_id_bound(self):
        cmd_ids = { -1 : "hH",
                   0 : "HH",
                   65535 : "HH",
                   65536 : "LH"
                   }
        cmd_id = random.choice(cmd_ids.keys())
        head_format = struct.Struct(cmd_ids[cmd_id])
        headbuf = head_format.pack(cmd_id, head_format.size)       
        self.run_task(sys._getframe().f_code.co_name + str(cmd_id), cmd_id, headbuf)
    
    @task
    def head_len_bound(self):
        cmd_name, cmd_id = self.rand_cmd()
        cmd_lens = {-1 : "Hh",
                   0 : "HH",
                   1 : "HH",
                   PACK_HEAD_FORMAT.size - 1 : "HH",
                   PACK_HEAD_FORMAT.size : "HH",
                   PACK_HEAD_FORMAT.size + 1 : "HH",
                   65535 : "HH",
                   65536 : "HL"
                    }
        cmd_len = random.choice(cmd_lens.keys())
        headbuf = struct.Struct(cmd_lens[cmd_len]).pack(cmd_id, cmd_len)
        self.run_task(sys._getframe().f_code.co_name + str(cmd_len), cmd_id, headbuf)

    @task
    def head_only(self):
        cmd_name, cmd_id = self.rand_cmd()
        headbuf = PACK_HEAD_FORMAT.pack(cmd_id, PACK_HEAD_FORMAT.size)
        self.run_task(sys._getframe().f_code.co_name, cmd_id, headbuf)

    @task
    def illegal_data(self):
        cmd_name, cmd_id = self.rand_cmd()
        protobuf = rand.randstring(random.randint(0, PROTOCAL_DATA_MAXLEN))
        headbuf = PACK_HEAD_FORMAT.pack(cmd_id, PACK_HEAD_FORMAT.size + len(protobuf))
        self.run_task(sys._getframe().f_code.co_name, cmd_id, headbuf + protobuf)

    @task
    def illegal_gc_data(self):
        protobuf = rand.randstring(random.randint(1, PROTOCAL_DATA_MAXLEN))
        headbuf = PACK_HEAD_FORMAT.pack(random.randint(1, 4), PACK_HEAD_FORMAT.size + len(protobuf))
        databuffer = '        ' + headbuf + protobuf
        request = PACK_HEAD_FORMAT.pack(CLI_TO_GS_REDIRECT_GC, PACK_HEAD_FORMAT.size + len(databuffer)) + databuffer
        self.run_task(sys._getframe().f_code.co_name, CLI_TO_GS_REDIRECT_GC, request)

    @task
    def random_id_and_data(self):
        cmd_id = random.randint(0, 65535)
        protobuf = rand.randstring(random.randint(0, PROTOCAL_DATA_MAXLEN))
        headbuf = PACK_HEAD_FORMAT.pack(cmd_id, PACK_HEAD_FORMAT.size + len(protobuf))
        self.run_task(sys._getframe().f_code.co_name, cmd_id, headbuf + protobuf)

    @task
    def illegal_ping(self):
        request = PingServer()
        request.clientTick = int(time.time())
        self.run_task(sys._getframe().f_code.co_name, CLI_TO_GS_PING, NetPack(CLI_TO_GS_PING, request).GetBuff())

    @task
    def illegal_format(self):
        protobuf = rand.randstring(random.randint(1, PROTOCAL_DATA_MAXLEN))
        self.run_task(sys._getframe().f_code.co_name, 0, protobuf)
        
class WebsiteUser(Locust):
    task_set = ProtocolFormat
    stop_timeout = 200
    min_wait = 0
    max_wait = 0

if __name__ == "__main__":
    import locust.main
 
    sys.argv.extend(["-f", "TestCaseIllegalProtocol.py", "--no-web", "--run-asyncore", "-H", "dddss", "-r", "1", "-c", "1"])
    locust.main.main()