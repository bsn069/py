# coding:utf-8
from Tools.IncludeDir import InsertIncludeDir
InsertIncludeDir("./net")
InsertIncludeDir("./net/ProtoBuffer")
from net.ProtoBuffer.ComProtocol_pb2 import *

class Behavior:
    END = 0
    BEGIN = 1
    RUNNING = 2

#角色门派
TIANWANG = 1
TANGMEN = 2
EMEI = 3
TIANREN = 4
WUDANG = 5
FactionList = [TIANWANG, TANGMEN, EMEI, TIANREN, WUDANG]

#角色性别
MALE = 0
FEMALE = 1

# 任务
Task_ChuZhiLinAn = 10101  # 初至临安
Task_Jiusifengbo = 10117  # 酒肆风波
Task_Tantingfengsheng = 10136  # 探听风声
Task_Yizuifangxiu = 10183  # 一醉方休
Task_Tongmenqingshen = 10137  # 同门情深
Task_Yanzhixiang = 10001  # 胭脂巷
Task_Youxi = 10102  # 游戏
Task_Chunfenglou = 10004  # 春风楼
Task_Chalouyiju = 10103  # 茶楼一聚
Task_Yanzifengbo = 10112  # 燕子风波
Task_TianShengHaoCha = 10006 #天生好茶
Task_MiMiJuDian = 10109     #秘密据点
Task_LvZaoChaJin = 10010   #屡遭查禁
Task_LinAnFengMao = 10115   #临安风貌
Task_GuRenXiangFeng = 10149 #故人相逢
Tesk_DaDiaoZhengShi = 10045 #大雕争食
# 技能
# 技能列表在 server\data\setting\faction\faction_setting.lua
# 18 26 34 42是控制技能要有人才能放，目前机器人还没有这个功能先屏蔽掉
# 门派 : [[普攻],[技能]]
FACTION_SKILL = {
    TIANWANG: [[1],
               [11021, 11031, 11041, 11051, 11061, 11071, 11081]],
    TANGMEN: [[13],
              [12011, 12021, 12031, 12041, 12061, 12071, 12081]],
    EMEI: [[13001],
           [13015, 13025, 13031, 13041, 13051, 13061, 13071]],
    TIANREN: [[14001],
              [14011, 14021, 14031, 14041, 14051, 14061, 14081]],
    WUDANG: [[37],
            [15011, 15021, 15051, 15061, 15071, 15081, 15101]]
}
SKILL_TIANREN = 14001
SKILL_TALENT = {
                    #天王
                    11021 : [11022, 11023, 11024],
                    11031 : [11032, 11033, 11034],
                    11041 : [11042, 11043, 11044],
                    11051 : [11052, 11053, 11054],
                    11061 : [11062, 11063, 11064],
                    11071 : [11072, 11073, 11074],
                    11081 : [11082, 11083, 11084],
                    #唐门
                    12011 : [12012, 12013, 12014],
                    12021 : [12022, 12023, 12024],
                    12031 : [12032, 12033, 12034],
                    12041 : [12042, 12043, 12044],
                    12061 : [12062, 12063, 12064],
                    12071 : [12072, 12073, 12074],
                    12081 : [12082, 12083, 12084],
                    #峨眉
                    13015 : [13017, 13019, 13102],
                    13025 : [13027, 13029, 13202],
                    13031 : [13032, 13033, 13034],
                    13041 : [13042, 13043, 13044],
                    13051 : [13052, 13053, 13054],
                    13061 : [13062, 13063, 13064],
                    13071 : [13072, 13073, 13074],
                    #天忍
                    14011 : [14012, 14013, 14014],
                    14021 : [14022, 14023, 14024],
                    14031 : [14034, 14033, 14032],
                    14041 : [14042, 14043, 14044],
                    14051 : [14052, 14053, 14054],
                    14061 : [14062, 14063, 14064],
                    14081 : [14082, 14083, 14084],
                    #武当
                    15011 : [15012, 15013, 15014],
                    15021 : [15022, 15023, 15024],
                    15051 : [15052, 15053, 15054],
                    15061 : [15062, 15063, 15064],
                    15071 : [15072, 15073, 15074],
                    15081 : [15082, 15083, 15084],
                    15101 : [15102, 15103, 15104],
                }

COMBO_MOVE = 0 #技能中移动
COMBO_DOUBLE = 1 #二段技能
COMBO_CHARGE = 2 #蓄力技能
COMBO_TURN = 3 #技能中转向
COMBO_REPEAT = 4 #技能重复释放
COMBO_KID = 5
SKILL_COMBO = {
                    11022 : COMBO_DOUBLE,#此二段技能是打断原技能的释放
                    11032 : COMBO_MOVE,
                    11033 : COMBO_CHARGE,
                    11062 : COMBO_DOUBLE,
                    11083 : COMBO_DOUBLE,
                    12022 : COMBO_CHARGE,
                    12043 : COMBO_DOUBLE,
                    12044 : COMBO_DOUBLE,
                    12045 : COMBO_TURN,
                    12063 : COMBO_DOUBLE,
                    12067 : COMBO_DOUBLE,
                    12073 : COMBO_DOUBLE,#此二段技能是打断原技能的释放
                    12083 : COMBO_DOUBLE,#此二段技能是打断原技能的释放
                    12084 : COMBO_MOVE,
                    13015 : COMBO_DOUBLE,
                    13017 : COMBO_DOUBLE,
                    13019 : COMBO_DOUBLE,
                    13102 : COMBO_DOUBLE,
                    13034 : COMBO_DOUBLE,
                    13133 : COMBO_REPEAT,
                    13072 : COMBO_DOUBLE,#此二段技能是打断原技能的释放
                    14024 : COMBO_CHARGE,
                    14041 : COMBO_KID,
                    14042 : COMBO_KID,
                    14802 : COMBO_KID,
                    14803 : COMBO_KID,
                    14089 : COMBO_KID,
                    14087 : COMBO_KID,
#                    14001 : COMBO_KID,
#                    14002 : COMBO_KID,
#                    14003 : COMBO_KID,
                    14081 : COMBO_DOUBLE,
                    14082 : COMBO_DOUBLE,
                    14083 : COMBO_DOUBLE,
                    14084 : COMBO_DOUBLE,
#                     15013 : COMBO_DOUBLE,#TODO:校验bug
                    15064 : COMBO_DOUBLE,
                    15074 : COMBO_DOUBLE,
                    15078 : COMBO_DOUBLE,
               }

SKILL_POINT_QINYI = 1
SKILL_POINT_LIANHUA = 2

#技能消耗资源点数
SKILL_COST = {
                    #峨眉
                    13033 : { 13033 : [SKILL_POINT_QINYI, 3] },
                    13042 : { 13042 : [SKILL_POINT_QINYI, 3] },
                    13044 : { 13044 : [SKILL_POINT_LIANHUA, 5],
                                    13406 : [SKILL_POINT_LIANHUA, 10],
                                    13407 : [SKILL_POINT_LIANHUA, 15], },
                    13053 : { 13053 : [SKILL_POINT_QINYI, 3] },
                    13054 : { 13054 : [SKILL_POINT_LIANHUA, 5]},
#                    13054 : { 13057 : [SKILL_POINT_LIANHUA, 5],
#                                    13058 : [SKILL_POINT_LIANHUA, 10],
#                                    13059 : [SKILL_POINT_LIANHUA, 15], },
                    13062 : { 13062 : [SKILL_POINT_QINYI, 3] },
                    13063 : { 13063 : [SKILL_POINT_LIANHUA, 5], },
#                    13064 : { 13604 : [SKILL_POINT_LIANHUA, 5],
#                                    13067 : [SKILL_POINT_LIANHUA, 10],
#                                    13068 : [SKILL_POINT_LIANHUA, 15], },
                    13064 : { 13068 : [SKILL_POINT_LIANHUA, 15] },
                    13072 : { 13072 : [SKILL_POINT_QINYI, 5] },
                    13074 : { 13074 : [SKILL_POINT_LIANHUA, 5] },
                    #天忍 (TODO : 这里因为天忍的技能消耗有两种，但没有峨眉那种不同消耗值效果不同的，暂且让每次放技能都填充满资源)
                    14011 : { 14011 : 100 },
                    14012 : { 14012 : 100 },
                    14013 : { 14013 : 100 },
                    14014 : { 14014 : 100 },
                    14021 : { 14021 : 100 },
                    14022 : { 14022 : 100 },
                    14023 : { 14023 : 100 },
                    14024 : { 14024 : 100 },
                    14031 : { 14031 : 100 },
                    14032 : { 14032 : 100 },
                    14033 : { 14033 : 100 },
                    14034 : { 14034 : 100 },
                    14041 : { 14041 : 100 },
                    14042 : { 14042 : 100 },
                    14043 : { 14043 : 100 },
                    14044 : { 14044 : 100 },
                    14045 : { 14045 : 100 },
                    14046 : { 14046 : 100 },
                    14051 : { 14051 : 100 },
                    14052 : { 14052 : 100 },
                    14053 : { 14053 : 100 },
                    14054 : { 14054 : 100 },
                    14061 : { 14061 : 100 },
                    14062 : { 14062 : 100 },
                    14063 : { 14063 : 100 },
                    14064 : { 14064 : 100 },
                    14081 : { 14081 : 100 },
                    14082 : { 14082 : 100 },
                    14083 : { 14083 : 100 },
                    14084 : { 14084 : 100 },
              }

#技能最大蓄力时间
SKILL_CHARGE_SEC = {
                        11033 : 1.5,
                        12022 : 1.5,
                        12073 : 2.5,
                        14024 : 4.5,#由日月值决定，满值时大概是4.5s
                    }
#天忍含有子技能
SKILL_KID = {
                14041 : 14045,
                14042 : 14046,
                14802 : 14801,
                14803 : 14088,
                14089 : 14801,
                14087 : 14088,
#                14001 : 14002,
#                14002 : 14003,
#                14003 : 14004,
             }
#充能技能可释放次数
SKILL_STORAGE = {
                    12042 : {
                                "origin" : 2, 
                                "now" : 2,
                             },
                 }

#需要指定非己目标的技能
SKILL_NEED_TARGET = [
                        12013,
                        12021,
                        14041,
                        14042,
                        14043,
                        14044,
                        14024,
                        14801,
                        14802,
                        14803,
                        14089,
                        14088,
                        14087,
                        14081,
                        14082,
                        14083,
                        14084
                     ]

#会更改实际技能cd的技能(单位ms)
SKILL_CHANGE_CD = {
                        15074 : 24000
                   }

#观晴滩Boss点
BeachBossPoint1 = 1
BeachBossPoint2 = 2
BeachBossPoint3 = 3
BeachBossPoint4 = 4
BeachBossPoint5 = 5
BeachBossPoint6 = 6



#宋金战场
PartySong_RoadTop = 1
PartySong_RoadMid = 2
PartySong_RoadBottom = 3
PartyJin_RoadTop = 4
PartyJin_RoadMid = 5
PartyJin_RoadBottom = 6

#副本
Chapter1Level1 = 1011
Chapter1Level2 = 1012
Chapter1Level3 = 1013
Chapter1Level4 = 1014
Chapter1Level5 = 1015
Chapter1Level6 = 1016
Chapter1Level7 = 1017
Chapter1Level8 = 1018
Chapter1Level9 = 1019
Chapter1Level10 = 1010
Chapter1Elite = 1211

#场景
SceneTreasureMap = 1501
SceneXoyo = 1600
SceneXoyo1 = 1601
SceneXoyo2 = 1602
SceneXoyo3 = 1603
SceneXoyo4 = 1604
SceneXoyo5 = 1605
SceneXiaoMiJing1 = 1651 #天罗地网
SceneXiaoMiJing2 = 1652 #占山为王
SceneXiaoMiJing3 = 1653 #毒仙聚
SceneXiaoMiJing4 = 1654 #解救义军
SceneXiaoMiJing5 = 1655 #金军杀器
SceneXiaoMiJing6 = 1661 
SceneXiaoMiJing7 = 1671
SceneKinDaily = 1801
SceneKinWeek = 1810
SceneKinLand = 1820
SceneDungeon1 = 1851
SceneDungeon2 = 1852
SceneZhuluJinTan = 1901
SceneLinan = 2001
SceneTianWang = 2004
SceneTangMen = 2005
SceneEMei = 2006
SceneTianRen = 2007
SceneWuDang = 2008
SceneLongmen = 2014
SceneFenghua = 2015
# SceneArena1 = 2019#被废弃
#SceneArena2 = 2069
SceneArena3 = 2029
SceneArena4 = 2035
SceneArena5 = 2026
SceneArena6 = 2024
SceneMoBeiCaoYuan = 2033
SceneBossChallenge = 2034
SceneBattle = 2050
SceneBeach = 2028
SceneYaoWangGu = 2043
SceneLiShanYiJi = 2027
SceneShuiYunJing = 2032
SceneTaoLiYuan = 2040
ScencHeiShuiCaoYuan = 2045
SceneDiGong = 2201
SceneHuangLingWaiGong = 2301
SceneHuangLingNeiDian = 2302
ScenekKunLun = 2018
SceneLuWeiDang = 2017
SceneLuWeiHeBian = 2036
SceneFeiShaGuan = 2037
SenceFengQiaoWu = 2038
SenceKunLunShanDian = 2039
SenceQiMuHePan = 2041
SenceHuangQuanJian = 2060
SenceKuaFuBattle = 2047
SenceYouBiShenLin = 2062
SenceHenXuJingShenMu = 2063
SenceJianGeZhiShang1 = 2064
SenceHenXuJingXuanBin = 2065
SenceHenXuJingJiaoZhuo = 2066
SenceCuiYan = 2067
SenceJianGeZhiShang2 = 2068
SenceHanWuYiJi = 2069
SenceMoXiangJu = 1850
SenceEngChouHuanJing = 2100
SenceShiJianTai = 2046
SenceXueYuSha = 2303
#坐标
PosDiGongSecondFloorCenter = (78.96, 48.23)

#护法
JiBanShuLevel = 1401
YangTieXinLevel = 1402
TangRuLevel = 1421
TangYunLevel = 1422
ChouXueLevel = 1441
LiuMoYanLevel = 1442
RongTuLevel = 1461
WuSaLevel = 1462
KeXinLevel = 1481
YiYeZhenRenLevel = 1482

JiBanShuID = 1
YangTieXinID = 2
TangRuID = 5
TangYunID = 6
ChouXueID = 9
LiuMoYanID = 10
RongTuID = 13
WuSaID = 14
KeXinID = 17
YiYeZhenRenID = 18

#战场信息通知
BattleInfo_Start = 0
BattleInfo_Over = 1
BattleInfo_Leave = 2
BattleInfo_Error = 3

#NPC
LongWuGongZi = 5
DuGuJian = 7
BaiQiuLing = 6



# 组队
# net.ProtoBuffer.ComProtocol_pb2里面已经定义了大部分TEAM TYPE，这里只需补充其中么有定义的
TEAM_TYPE_KINWEEK = TEAM_TYPE_COUNT + 1
TEAM_TYPE_MAPLE = TEAM_TYPE_COUNT + 2
TEAM_TYPE_LONGMEN = TEAM_TYPE_COUNT + 3
TEAM_TYPE_MAINTASK = TEAM_TYPE_COUNT + 4
TEAM_TYPE_SKYLANTERN = TEAM_TYPE_COUNT + 5
TEAM_TYPE_JIE_BIAO = TEAM_TYPE_COUNT + 6
TEAM_TYPE_HENG_DAO_SHU = TEAM_TYPE_COUNT + 7
TEAM_TYPE_ACTIVITY_LUCKSTAR = TEAM_TYPE_COUNT + 8
TEAM_TYPE_BEACH = TEAM_TYPE_COUNT + 9
TEAM_TYPE_SKILLTEST = TEAM_TYPE_COUNT + 10
TEAM_TYPE_XIAOMIJING = TEAM_TYPE_COUNT + 11#小秘境暂时还没相应队伍类型，先用自定义的
TEAM_TYPE_Lishan= TEAM_TYPE_COUNT + 12
TEAM_TYPE_PUHISHEVIL= TEAM_TYPE_COUNT + 13
TEAM_TYPE_GUARDIAN = TEAM_TYPE_COUNT+ 14
TEAM_TYPE_VALENTINE = TEAM_TYPE_COUNT+ 15
#商店
CommonShop = 1
ArenaShop = 3
BattleShop = 7
XiaYiShop = 8
LiuLiShop = 34
FriendShop = 10
TreasureShop = 22
MasterShop = 26
GoldShop = 29
SilverShop = 30
KinShop = 33
'''
    data\sheet\shop
'''

SHOP_GOODS = {
    # SHOP_ID: [GOOD_INDEX1, GOOD_INDEX2]
    # 注意是GOOD_INDEX，不是ID
    CommonShop: [0, 1, 2, 3],
    ArenaShop: [0, 1, 2],
    BattleShop: [0, 1, 2],
    XiaYiShop: [0, 1, 2],
    LiuLiShop: [i for i in range(6)],
    MasterShop: [0, 1],
    GoldShop: [i for i in range(4)],
    SilverShop: [i for i in range(48)],
    KinShop :[0,1,2,3],
}

#家族职位
KinLeader = 1
KinDeputyLeader = 2
KinCommon = 3

#家族游戏类型
KinWeekGame = 1
KinFeastGame = 2
KinDefendGame = 3
KinWarGame = 4
KinWarRank = 5#添加周榜数据

#家族周末关卡目标
KinTargetWait = "在此烤火等待开始"
KinTargetStart = "前进！前进！"
KinTargetOne = "采集解毒之草"
KinTargetTwo = "击败所有敌人"
KinTargetThree = "【天】、【地】、【人】三路配合，按1-9的顺序开启机关"
KinTargetEnd = "同时击败3条路线的制尸者"

#家族争夺人员类型
KinWarCheerer = 0
KinWarAssaulter = 1

#家族争夺目标
KinWarWait = "报名结束后活动将开始"
KinWarPveFight = "深入皇陵，找到内殿入口"
KinWarLamp = "分别放入长明灯中"
KinWarEnterNeiDian = "内殿入口已出现，请立即前往！"
KinWarKillGenerals = "击杀始皇及其四员大将"
KinWarKillQinShiHuang = "击杀秦始皇"
KinWarCheer = "消灭敌人，收集战鼓，为冲锋的伙伴们呐喊助威！"
KinWarCheerEnd = "助威结束，请稍作等待"
KinWarEnd = "活动已结束"

#家族争夺-机器人任务
KinWarStartWait = 0 
KinWarSignUpCloseWait = 1 
KinWarPVPEndWait = 2
KinWarCloseWait = 3

#跨服约战
CROSS_Gong = 0
CROSS_Shou = 1

#师徒类型
MSTR_Master = 1
MSTR_Apprentice = 2

#徒弟离开类型
MSTR_Quit = 1
MSTR_Graduation = 2

#押镖类型
Escort_Food = 0
Escort_Treasure = 1

#押镖角色类型
Escort_Yabiao = 0
Escort_Jiebiao = 1

#劫镖组队类型
Escort_JiebiaoSingle = 0
Escort_JiebiaoTeam = 1

#离线聊天人物类型
OfflineChat_Relogin = 0
OfflineChat_Reply = 1

#武器1；上衣2；腰饰3；帽子4；护符5；戒指6；鞋子7；项链8；下装9
WEAPON = 1
CLOTH = 2
BELT = 3
HAT = 4
AMULET = 5
RING = 6
SHOE = 7
CUFF = 8
TROUSERS = 9
SIGNET = 10

#装备部位
EquipmentsPart = [WEAPON, CLOTH, BELT, HAT, AMULET, RING, SHOE, CUFF, TROUSERS]

SIGNET_YUNMENGBIAN = 201
SIGNET_JING_YUNMENGBIAN = 301
SIGNETLIST = [SIGNET_YUNMENGBIAN, SIGNET_JING_YUNMENGBIAN]
IMPROVEDSTONE = 1
GEMSTONE = 16
ALCHEM_CFG = {
              GEMSTONE : {
                                1: (2, 1, 1, 1, 3),    # 1级长生石合成2级长生石
                                2: (2, 2, 1, 1, 3),    # 1级气海石合成2级气海石
                                3: (2, 3, 1, 1, 3),    # 1级奔狼石合成2级奔狼石
                                4: (2, 4, 1, 1, 3),    # 1级金刚石合成2级金刚石
                                5: (2, 5, 1, 1, 3),    # 1级凌波石合成2级凌波石
                                6: (2, 6, 1, 1, 3),    # 1级锥心石合成2级锥心石
                                7: (2, 1, 1, 2, 3),    # 2级长生石合成3级长生石
                                8: (2, 2, 1, 2, 3),    # 2级气海石合成3级气海石
                                9: (2, 3, 1, 2, 3),    # 2级奔狼石合成3级奔狼石
                                10: (2, 4, 1, 2, 3),    # 2级金刚石合成3级金刚石
                                11: (2, 5, 1, 2, 3),    # 2级凌波石合成3级凌波石
                                12: (2, 6, 1, 2, 3),    # 2级锥心石合成3级锥心石
                                13: (2, 1, 1, 3, 3),    # 3级长生石合成4级长生石
                                14: (2, 2, 1, 3, 3),    # 3级气海石合成4级气海石
                                15: (2, 3, 1, 3, 3),    # 3级奔狼石合成4级奔狼石
                                16: (2, 4, 1, 3, 3),    # 3级金刚石合成4级金刚石
                                17: (2, 5, 1, 3, 3),    # 3级凌波石合成4级凌波石
                                18: (2, 6, 1, 3, 3),    # 3级锥心石合成4级锥心石
                                19: (2, 1, 1, 4, 3),    # 4级长生石合成5级长生石
                                20: (2, 2, 1, 4, 3),    # 4级气海石合成5级气海石
                                21: (2, 3, 1, 4, 3),    # 4级奔狼石合成5级奔狼石
                                22: (2, 4, 1, 4, 3),    # 4级金刚石合成5级金刚石
                                23: (2, 5, 1, 4, 3),    # 4级凌波石合成5级凌波石
                                24: (2, 6, 1, 4, 3),    # 4级锥心石合成5级锥心石
                                25: (2, 1, 1, 5, 3),    # 5级长生石合成6级长生石
                                26: (2, 2, 1, 5, 3),    # 5级气海石合成6级气海石
                                27: (2, 3, 1, 5, 3),    # 5级奔狼石合成6级奔狼石
                                28: (2, 4, 1, 5, 3),    # 5级金刚石合成6级金刚石
                                29: (2, 5, 1, 5, 3),    # 5级凌波石合成6级凌波石
                                30: (2, 6, 1, 5, 3),    # 5级锥心石合成6级锥心石
                         },
          IMPROVEDSTONE : {
                            101: (5, 1, 101, 1, 3),    # 1级强化石合成2级强化石
                            102: (5, 1, 101, 2, 3),    # 2级强化石合成3级强化石
                            103: (5, 1, 101, 3, 3),    # 3级强化石合成4级强化石
                            104: (5, 1, 101, 4, 3),    # 4级强化石合成5级强化石
                            105: (5, 1, 101, 5, 3),    # 5级强化石合成6级强化石
                            106: (5, 1, 101, 6, 3),    # 6级强化石合成7级强化石
                            107: (5, 1, 101, 7, 3),    # 7级强化石合成8级强化石
                },
}

MIJI = [(3, 1, p, 1) for p in range(1, 19)]
# 秘籍的话 本次只开放13-18ID的秘籍 - 拍卖行
# 13,14,15,16,17,18
CANYE = [(3, 2, p, l) for p in range(13, 19) for l in range(1, 10)]
# 目前只有六种宝石才能上架出售,并且每种宝石只有前5级才能卖 第六级是合成的 合成后就绑定了 - 拍卖行
# 1,2,3,4,5,6
# BAOSHILIST = [(2, d, 1, l) for l in range(1, 9) for d in range(1, 7)]#宝石-拍卖行 
BAOSHILIST = [(2, d, 1, 1) for d in range(1, 7)]#宝石-拍卖行(现在拍卖行只能拍卖1级的宝石) 

#挂件碎片 - 拍卖行
'''
5,3,28,1 夜未央碎片
5,3,44,1 吉运绵长碎片
5,3,44,3 锋利的菜刀碎片
5,3,44,4 锋芒傲骨碎片
5,3,44,5 满盘星碎片
5,3,44,6 阎罗天子碎片
5,3,301,1 墨狮碎片
5,3,302,1 天下第一镖碎片
5,3,303,1 招财喵碎片
'''
PENDANT = [(5, 3, 28, 1)] + [(5, 3, 44, l) for l in range(1, 7) if l != 2] + [(5, 3, p, 1) for p in range(301, 304)]
'''
5,4,7,1 神秘的线索
5,4,19,1 普通调色料
5,1,26,1 保险券
5,3,2,1 初级修炼丹
5,3,5,1 中级修炼丹
5,3,6,1 高级修炼丹
'''
#奇珍异宝 - 拍卖行
TREASURES = [(5, 4, 7, 1), (5, 4, 19, 1), (5, 1, 26, 1)] + [(5, 3, p, 1) for p in [2, 5, 6]] + PENDANT

#拍卖行角色
Trade_Trader = 0
Trade_Customer = 1

#挂件碎片 - 所有
'''
包括拍卖行挂件碎片和：
5,3,44,7 师恩重碎片
5,3,44,8 ,文心雕龙碎片
'''
AllPendantPieces = [(5, 3, 28, 1)] + [(5, 3, 44, l) for l in range(1, 9) if l != 2] + [(5, 3, p, 1) for p in range(301, 304)]

#时装
Fashion_SuYiJinXin = 1001
Fashion_LangRanQianKun = 1002
Fashion_MoYeXiGuang = 1003
Fashion_FengHuangYuFei = 1004#好像下架了
Fashion_TaLuoGe = 1005
Fashion_TaLuoGe_QingLan = 1006
Fashion_TianShengBuFan = 1007
Fashion_XuanYinLuoXue = 1010
Fashion_BingJiYuGu = 1011
Fashion_BingJiYuGu_ZiXiao = 1012
Fashion_MoLiChao_XingYue = 1013
Fashion_JinYiHuQiu_NianChen = 1015
Fashion_FeiYunZhui = 1016
Fashion_QiXingHuaYing = 1017
Fashion_MuYun = 1018
Fashion_JinYuLiangYuan = 1019
Fashion_ChaoTianQue_MiaoWu = 1020
Fashion_LingYuCui = 1021
Fashion_HuoZhiHeYun = 1022
#FashionList = [Fashion_SuYiJinXin, Fashion_LangRanQianKun, Fashion_MoYeXiGuang, Fashion_TaLuoGe, Fashion_TaLuoGe_QingLan, Fashion_TianShengBuFan, Fashion_XuanYinLuoXue, Fashion_BingJiYuGu, Fashion_BingJiYuGu_ZiXiao, Fashion_MoLiChao_XingYue, Fashion_JinYiHuQiu_NianChen, Fashion_FeiYunZhui, Fashion_QiXingHuaYing, Fashion_MuYun, Fashion_JinYuLiangYuan, Fashion_ChaoTianQue_MiaoWu, Fashion_LingYuCui, Fashion_HuoZhiHeYun]
FashionList = [Fashion_LingYuCui,Fashion_QiXingHuaYing,Fashion_TianShengBuFan,Fashion_JinYiHuQiu_NianChen,Fashion_XuanYinLuoXue,Fashion_MoYeXiGuang,Fashion_FengHuangYuFei,Fashion_SuYiJinXin, Fashion_TaLuoGe, Fashion_LangRanQianKun,Fashion_BingJiYuGu]

#发型
Hair_SuYiJinXin = 8001
Hair_LangRanQianKun = 8002
Hair_MoYeXiGuang = 8003
Hair_FengHuangYuFei = 8004#好像下架了
Hair_TaLuoGe = 8005
Hair_TianShengBuFan = 8007
Hair_XuanYinLuoXue = 8010
Hair_BingJiYuGu = 8011
Hair_MoLiChao = 8013
Hair_JinYiHuQiu = 8015
Hair_FeiYunZhui = 8016
Hair_QiXingHuaYing = 8017
Hair_MuYun = 8018
Hair_XianYunNongQiao = 8019
Hair_ChaoTianQue_QinYan = 8020
Hair_LingYu = 8021
Hair_JiTianNv = 8022
Hair_JingMeng = 8099
HairList = [Hair_XuanYinLuoXue,Hair_SuYiJinXin,Hair_MoYeXiGuang,Hair_LangRanQianKun,Hair_FeiYunZhui,Hair_JingMeng,Hair_SuYiJinXin,Hair_TaLuoGe, Hair_JinYiHuQiu, Hair_BingJiYuGu, Hair_LingYu,Hair_ChaoTianQue_QinYan]

#背饰
Pendant_XueHaiWuYa = 102
Pendant_TianXiaDiYiBiao = 109
Pendant_YueXiaDeAi = 122
Pendant_ShiEnZhong = 123
Pendant_ZhaoCaiMiao = 125
Pendant_QiongQiongBaiTu = 126
Pendant_LongZhongXian = 131
Pendant_YeHuoLunHui = 139
Pendant_WenQing = 142
Pendant_ManMan = 143
Pendant_YanGui = 147
Pendant_MiJuGuaiGuai = 155
#PendantList = [Pendant_MiJuGuaiGuai,Pendant_YanGui,Pendant_ManMan,Pendant_WenQing,Pendant_YeHuoLunHui,Pendant_LongZhongXian,Pendant_QiongQiongBaiTu,Pendant_ZhaoCaiMiao,Pendant_XueHaiWuYa,Pendant_TianXiaDiYiBiao,Pendant_YueXiaDeAi,Pendant_ShiEnZhong]
PendantList = [Pendant_YanGui,Pendant_WenQing]

#绚武
XuanWu1 = 5001
#奇兵
QiBing1 = 6001
QiBing2 = 6002
QiBing3 = 6003
QiBing_WuMuLiuJin = 6005
QiBing_YiHeTingXiang = 6006
QiBing_NuanYuDuanChou = 6007
QiBingList = [QiBing1, QiBing2, QiBing3, QiBing_WuMuLiuJin, QiBing_YiHeTingXiang, QiBing_NuanYuDuanChou]
#腰饰
Belt_ZhanShaChang_GouChen = 1
Belt_ZhanShaChang_XuanWu = 2
Belt_JiYunMianChang = 103
Belt_XiaoTuJiuJiu = 104
Belt_FengLiDeCaiDao = 106
Belt_QiongYaoYuPei = 115
Belt_ZuiDongFeng = 116
Belt_ManPanXing = 117
Belt_ZheHeYouZeng = 118
Belt_YanLuoTianZiLing = 119
Belt_WenXinDiaoLong = 124
Belt_XiangSi = 127
Belt_JinYiHuQiu_SiGu = 128
Belt_ManRouTuJi = 129
Belt_ZhuMeng = 130
BeltList = [Belt_ZhanShaChang_GouChen, Belt_ZhanShaChang_XuanWu, Belt_JiYunMianChang, Belt_XiaoTuJiuJiu, Belt_FengLiDeCaiDao, Belt_QiongYaoYuPei, Belt_ZuiDongFeng, Belt_ManPanXing, Belt_ZheHeYouZeng, Belt_YanLuoTianZiLing, Belt_WenXinDiaoLong, Belt_XiangSi, Belt_JinYiHuQiu_SiGu, Belt_ManRouTuJi, Belt_ZhuMeng]
#会根据门派变化的腰饰
SpecialBeltList = [Belt_ZhanShaChang_GouChen, Belt_ZhanShaChang_XuanWu]

#脸饰
Headdress_XiaoMianBanRuo = 603
Headdress_NanTingJie = 605
Headdress_XuanQingHuEr = 606
Headdress_YueBaiHuEr = 607
Headdress_XiYangMianJu = 608
Headdress_YueTuEr = 609
Headdress_ZhuYinMianJu = 610
Headdress_BuBuShengLian = 611
Headdress_QianYing = 613
HeaddressList = [Headdress_XiaoMianBanRuo, Headdress_NanTingJie, Headdress_XuanQingHuEr, Headdress_YueBaiHuEr, Headdress_XiYangMianJu, Headdress_YueTuEr, Headdress_BuBuShengLian, Headdress_QianYing]

#贴花 
FaceApplique_FeiYing = 7101
FaceApplique_XinXing = 7102
FaceApplique_CuiDian = 7103
FaceApplique_HongDie = 7105
FaceApplique_Er = 7106
FaceApplique_JinBo = 7107
FaceApplique_KeAi = 7108
FaceApplique_JinDian = 7109
FaceApplique_HuaYan = 7110
FaceApplique_ShouYing = 7111
FaceApplique_KuLou = 7112
FaceApplique_ZheZhiHuaZhi = 7113
FaceAppliqueList = [FaceApplique_ZheZhiHuaZhi, FaceApplique_KuLou, FaceApplique_ShouYing, FaceApplique_HuaYan, FaceApplique_JinDian, FaceApplique_KeAi, FaceApplique_JinBo, FaceApplique_FeiYing, FaceApplique_XinXing, FaceApplique_CuiDian, FaceApplique_HongDie, FaceApplique_Er]

#时装部位
Appearance_Fashion = 1
Appearance_Hair = 2
Appearance_Mounts = 3
Appearance_Pendant = 4
Appearance_Belt = 5
Appearance_Headdress = 6
Appearance_QiBing = 7

#好友送礼
Friend_MeiGuiHua = 303
Friend_YiWangQingShen = 305
Friend_XinXinXiangYin = 306
Friend_TianChangDiJiu = 307
Friend_XiangSiCao = 471
Friend_TaoHuaBaoXia = 11008

#组队状态
TEAM_STATE_IDEL = 0
TEAM_STATE_MATCH = 1
TEAM_STATE_GAME = 2

#茶馆
ChaGuanXiaoEr_id = 16777301

#附魔消耗类型
Enchant_Cost_Silver = 1
Enchant_Cost_Gold = 2

#挖宝
WeiChangFeng_id = 16777269
WaDaoXiangZi = 1
WaDaoDiGong = 2

WaBaoMove_Common = 1
WaBaoMove_ToNpc = 2
WaBaoMove_ToSecondFloor = 3
WaBaoMove_ToBonfire = 4

#身份
ShaShou = 4
BiaoShi = 1
DiaoKe = 2
MoJin = 3

#染色
ColoringHair = 1
ColoringHairBand = 2
ColoringCoat = 1
ColoringPants = 2

#随机移动案例任务类型
Move_LinanMove = 0
Move_LinanEquip = 1
Move_MapleSkill = 2
Move_LongmenSkill = 3
Move_TianWang = 4
Move_TangMen = 5
Move_EMei = 6
Move_WuDang = 7 
Move_TianRen = 8

#PK模式
PKMode_Peace = 0
PKMode_Kin = 1
PKMode_Kill = 2

#动作卷轴
ActionScroll = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,30,31,32,33,34,35]

#最高等级
MaxLevel = 70

#最大GM添加货币值
MaxGMAddCoinValue = 100000000.0