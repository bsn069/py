# coding:utf-8
from Tools.Rand import Rand

# 总账号池大小，每个案例的账号池大小按照用例的权重分配
TOTAL_ACCOUNT_POOL_SIZE = 8000 * 10

class Case(object):
    def __init__(self, name, weight, accountNum=0):
        self.name = name
        self.weight = weight
        self.accountNum = accountNum
        
class CaseManager(object):
    PVP = 0         #联赛
    JIAZU = 1       #家族
    FRIEND = 2      #好友
    MOVE = 3        #主城随机移动
    EQUIP= 4        #装备
    RANKING= 5      #排行帮
    MAINTASK = 6    #主线任务
    CHAT = 7        #消息
    LISHAN = 8      #骊山
    BOSS = 9        #龙门
    WELFARE = 10    #福利
    CHANGELINE = 11     #换线
    SHOP = 13           #商店
    GUARDIAN = 14       #护法
    INSTANCE = 15       #逐鹿金滩
    BATTLE = 16         #襄北演武
    XOYO = 17           #废弃
    XIAOMIJING = 18     #九州行
    MAPLE = 19          #废弃
    LUNJIAN = 20        #废弃
    TRADEHOUSE = 21     #拍卖行
    GRAVEDIGGER = 22    #废弃
    FISHING = 23        #钓鱼
    ESCORT = 24         #押镖
    KILLER = 25         #杀手
    SHOPONLINE = 26     #在线商城
    ASSIST = 27         #助战（废弃）
    APPEARANCE = 28     #捏脸
    HOMELAND = 29       #家园
    SKYLANTERN = 30     #废弃
    DOUBLEACTION = 31   #双人动作
    PLAYERFIGHT = 32    #野外PK 
    DESIGNATION = 33    #称号
    MASTER = 34         #拜师
    FESTIVALACTIVITY = 36   #国庆日活动（废弃）
    DUNGEON = 37        #衡道书
    DATACHECKER = 38    #数据校验
    ACTIVITY_NEWYEAR = 39   #新年活动
    TRADEHOUSE_DATA = 40    #拍卖行校验
    OFFLINECHAT = 41    #离线消息
    BEACH = 42          #观晴滩
    SQUAREDANCE = 43    #广场舞
    VALENTINE = 44      #情人节
    GODDESS = 45        #废弃
    SKILLTEST = 46      #技能测试
    DAMIJING = 47       #衡虚境
    BOSSCHALLENGE = 48  #废弃
    ROBOT = 49          #废弃
    AUTOPATH = 50       #废弃
    PERFORMANCE = 51    #换线放技能
    TEA = 52            #喝茶
    LIMITEDAUCTION = 53     #限时竞拍
    CRUSADEAGINST = 54      #流寇
    Acution_Data = 55       #限时竞拍数据校验
    BIGFIGHT = 56       #浴火争锋
    CROSSBATTLE = 57    #跨服约战
    CROSSFRIEND = 58    #跨服交友
    REALTIMEVOICE = 59  #实时语音
    REDPACKET = 60      #红包
    KINWAR = 61         #
    GRAVE = 62          #埋骨之窟
    TRAVELTASK = 63     #游历任务
    EATCHICKEN = 64     #血与沙
    WUYI = 65           #五一活动
    """
            权重为0表示改用例不会被选到，需要添加到非重复登录账号的Case中执行
    """
    CASES = {
            PVP:Case("TestCase.Script.TestCase_LeagueMatch.TestCase", 10),
            JIAZU:Case("TestCase.Script.TestCase_Kin.TestCase", 20),
            FRIEND:Case("TestCase.Script.TestCase_Friend.TestCase", 1),
            MOVE:Case("TestCase.Script.TestCase_RandomMove.TestCase", 1),
            RANKING:Case("TestCase.Script.TestCase_Rank.TestCase", 1),
            CHAT:Case("TestCase.Script.TestCase_Chat.TestCase", 1),
            LISHAN:Case("TestCase.Script.TestCase_Lishan.TestCase", 1),
            BOSS:Case("TestCase.Script.TestCase_RandomBoss.TestCase", 1),
            WELFARE:Case("TestCase.Script.TestCase_Welfare.TestCase", 1),
            CHANGELINE:Case("TestCase.Script.TestCase_ChangeLine.TestCase", 1),
            SHOP:Case("TestCase.Script.TestCase_Shop.TestCase", 1),
            INSTANCE:Case("TestCase.Script.TestCase_Instance.TestCase", 1),
            BATTLE:Case("TestCase.Script.TestCase_Battle.TestCase", 10),
            XOYO:Case("TestCase.Script.TestCase_Xoyo.TestCase", 0),
            XIAOMIJING:Case("TestCase.Script.TestCase_XiaoMiJing.TestCase", 10),
            MAPLE:Case("TestCase.Script.TestCase_RandomBoss_Maple.TestCase", 0),
            LUNJIAN:Case("TestCase.Script.TestCase_LunJian.TestCase", 0),
            TRADEHOUSE:Case("TestCase.Script.TestCase_TradeHouse.TestCase", 1),
            GRAVEDIGGER:Case("TestCase.Script.TestCase_GraveDigger.TestCase", 0),
            FISHING:Case("TestCase.Script.TestCase_Fishing.TestCase", 10),
            ESCORT:Case("TestCase.Script.TestCase_Escort.TestCase", 10),
            KILLER:Case("TestCase.Script.TestCase_Killer.TestCase", 10),
            SHOPONLINE:Case("TestCase.Script.TestCase_ShopOnline.TestCase", 1),
            APPEARANCE:Case("TestCase.Script.TestCase_Appearance.TestCase", 1),
            HOMELAND:Case("TestCase.Script.TestCase_HomeLand.TestCase", 1),
            SKYLANTERN:Case("TestCase.Script.TestCase_SkyLantern.TestCase", 0),
            DOUBLEACTION:Case("TestCase.Script.TestCase_DoubleAction.TestCase", 1),
            PLAYERFIGHT:Case("TestCase.Script.TestCase_PlayerFight.TestCase", 1),
            DESIGNATION:Case("TestCase.Script.TestCase_Designation.TestCase", 1),
            MASTER:Case("TestCase.Script.TestCase_Master.TestCase", 10),
            FESTIVALACTIVITY:Case("TestCase.Script.TestCase_FestivalActivity.TestCase", 0),
            DUNGEON:Case("TestCase.Script.TestCase_Dungeon.TestCase", 10),
            DATACHECKER:Case("TestCase.Script.TestCase_DataChecker.TestCase", 0),
            ACTIVITY_NEWYEAR:Case("TestCase.Script.TestCase_NewYear.TestCase", 0),
            TRADEHOUSE_DATA:Case("TestCase.Script.TestCase_TradeHouse_Data.TestCase", 0),
            OFFLINECHAT:Case("TestCase.Script.TestCase_OfflineChat.TestCase", 1),
            BEACH:Case("TestCase.Script.TestCase_Beach.TestCase", 1),
            SQUAREDANCE:Case("TestCase.Script.TestCase_SquareDance.TestCase", 1),
            VALENTINE:Case("TestCase.Script.TestCase_ValentinesDay.TestCase", 0),
            GODDESS:Case("TestCase.Script.TestCase_Goddess.TestCase", 0),
            SKILLTEST:Case("TestCase.Script.TestCase_SkillTest.TestCase", 0),
            DAMIJING:Case("TestCase.Script.TestCase_DaMiJing.TestCase", 10),
            BOSSCHALLENGE:Case("TestCase.Script.TestCase_BossChallenge.TestCase", 0),
            AUTOPATH:Case("TestCase.Script.TestCase_AutoPath.TestCase", 1),
            PERFORMANCE:Case("TestCase.Script.TestCase_Performance.TestCase", 0),
            TEA:Case("TestCase.Script.TestCase_DrinkTea.TestCase", 1),
            LIMITEDAUCTION:Case("TestCase.Script.TestCase_LimitedAuction.LimitedAuction", 0),         
            CRUSADEAGINST:Case("TestCase.Script.TestCase_CrusAgainst.TestCase", 1),   
            Acution_Data:Case("TestCase.Script.TestCase_Acution_Data.TestCase", 0),
            BIGFIGHT:Case("TestCase.Script.TestCase_BigFight.TestCase", 10),   
            CROSSBATTLE:Case("TestCase.Script.TestCase_CrossBattle.TestCase", 10), 
            CROSSFRIEND:Case("TestCase.Script.TestCase_CrossFriend.TestCase", 0),    
            REALTIMEVOICE:Case("TestCase.Script.TestCase_RealTimeVoice.TestCase", 1),
            REDPACKET:Case("TestCase.Script.TestCase_RedPacket.TestCase", 0),
            KINWAR:Case("TestCase.Script.TestCase_KinWar.TestCase", 0),
            GRAVE:Case("TestCase.Script.TestCase_Grave.TestCase", 1),
            EATCHICKEN:Case("TestCase.Script.TestCase_EatChicken.TestCase", 1),
            WUYI:Case("TestCase.Script.TestCase_WuYi.TestCase", 0),
            
            # 以下模块不能重复登录，已放到非循环账号的案例中
            TRAVELTASK:Case("TestCase.Script.TestCase_TravelTask.TestCase", 0),
            EQUIP:Case("TestCase.Script.TestCase_Equip.TestCase", 0),
            MAINTASK:Case("TestCase.Script.TestCase_MainTask.TestCase", 0),
            GUARDIAN:Case("TestCase.Script.TestCase_Guardian.TestCase", 1),
            ASSIST:Case("TestCase.Script.TestCase_Assist.TestCase", 0),
            ROBOT:Case("TestCase.Script.TestCase_Robot.TestCase", 0),
            }
    
    CASE_WEIGHT_TOTAL = sum([value.weight for value in CASES.values()])
    for key, value in CASES.items():
        if value.accountNum == 0:
            value.accountNum = TOTAL_ACCOUNT_POOL_SIZE * value.weight / CASE_WEIGHT_TOTAL
    CASE_ACCOUNTNUM = dict((key, value.accountNum) for key, value in CASES.items())
    
    @staticmethod
    def GetRandCaseId(case_dict):
        return Rand.weighted_choice(case_dict)
    
    @classmethod
    def GetCase(cls, caseId):
        if caseId in cls.CASES.keys():
            return cls.CASES[caseId].name
        else:
            return None
    
    
if __name__=="__main__":
    pass
