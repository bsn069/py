# coding:utf-8
__author__ = 'Administrator'

import random
from Tools.Rand import Rand
from Tools.Enum import enum


# 用例执行类型

# 配置信息
# 用例执行类型
CASE_TYPE = enum(PREPARE_ROLE=0,
                 LOGIN_ONLY=1,
                 PLAY_WITH_LOOP_ROLE=2,
                 PLAY_WITH_CREATE_ROLE=3,
                 PLAY_WITH_CREATE_MULTI_ROLE=4,
                 PLAY_WITH_CREATE_CUSTOM_ROLE=5
                 )

RUN_TYPE = CASE_TYPE.PLAY_WITH_CREATE_ROLE
# RUN_TYPE = CASE_TYPE.PLAY_WITH_CREATE_CUSTOM_ROLE
# RUN_TYPE = CASE_TYPE.PLAY_WITH_LOOP_ROLE

# 非法协议占用的比例，取值为0-100之间
# 0 表示不开启非法协议测试
# 1-100 表示非法协议的比例
ILLEGAL_TEST_PERCENT = 0



class Config:
    def __init__(self):
        pass

    @staticmethod
    def is_illegaltest(percent = ILLEGAL_TEST_PERCENT):
        return Rand.rand_percent(percent)