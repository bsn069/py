# coding:utf-8


'''
    皇陵冲锋，助威的怪物ID来源于\data\sheet\npc.scv 这个里面是中文名称以及所对应的ID
    \data\script\kin\kinwar\pvemission\action.lua 里面是皇陵外宫中冲锋以及助威的采用的小怪信息
'''
MOJINGXIAOWEI = 19001                   #摸金校尉
DAOMUZHEI = 19002                       #盗墓贼
SHOULINJISHI = 19004                    #守陵祭祀
SHOULINNVGUAN = 19005                   #守陵女官
JINGYIN_DUANGONGBINGYONG = 19006        #<精英>短弓兵俑
JINGYIN_CHANGJIBINGYONG = 19007         #<精英>长戟兵俑
ZHIJIANBINGYONG = 19008                 #直剑兵俑
ZHANGU = 19009                          #战鼓
YANG_SHOULINJIGUANREN = 19011           #守陵机关人——阳
YANG_SHOULINTIEWEI = 19012              #守陵铁卫——阳
YANG_SHAOMUPOPO = 19013                 #扫墓婆婆·阳
HUANGLINJIGUANREN = 19014               #皇陵机关人
HUANGLINTIEWEI = 19015                  #皇陵铁卫
SHAOMUPOPO = 19016                      #扫墓婆婆
JINGYIN_BANSHANDAOREN = 19029           #<精英>搬山道人
JINGYIN_SHOULINSHENREN = 19030          #<精英>守陵僧人
JINHYIN_SHOULINJINRUISHESHOU = 19031    #<精英>守陵精锐射手
HUANGLINBINGYONG = 19036                #皇陵兵俑
JINGYIN_HUANGLINBINGYONGDUTONG = 19035  #<精英>皇陵兵俑都统
HUANGLINDAOBING = 19037                 #皇陵刀兵
CHANGMINGDENG = 19038                   #长明灯

KIN_WAR_NPC = [HUANGLINDAOBING,JINGYIN_HUANGLINBINGYONGDUTONG,HUANGLINBINGYONG,JINHYIN_SHOULINJINRUISHESHOU,JINGYIN_SHOULINSHENREN,JINGYIN_BANSHANDAOREN,
               YANG_SHAOMUPOPO,YANG_SHOULINTIEWEI,MOJINGXIAOWEI,DAOMUZHEI,SHOULINJISHI,SHOULINNVGUAN,JINGYIN_CHANGJIBINGYONG,JINGYIN_DUANGONGBINGYONG,
               SHAOMUPOPO,HUANGLINTIEWEI,HUANGLINJIGUANREN,ZHIJIANBINGYONG,YANG_SHOULINJIGUANREN]