#encoding=utf-8

__author__ = 'Administrator'
import os
import csv

def singleton(cls, *args, **kw):
    instances = {}

    def _singleton():
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return _singleton

@singleton
class GameConfig(object):
    BOOK = 'data/sheet/item/book/book_list.csv'
    STONE = 'data/sheet/item/stone/stone_list.csv'
    CONSUME = 'data/sheet/item/consume/consume_list.csv'
    RANDSTONE = 'data/sheet/item/randstone/rand_stone_list.csv'
    '''
        client\swordm3d\Assets\_Game\Resources\Packages\Settings\FaceEdit
    '''
    FACEBONE = 'data/item/FaceEditBoneOpDef.txt'
    FACELOOK = 'data/item/FaceEditLookOpDef.txt'
    FACELOOK_OPTION = 'data/item/FaceEditLookOption.txt'

    def __init__(self):
        self.book = {}
        self.stone = {}
        self.consume = {}
        self.facebone = {}
        self.facelook = {}
        self.namewhitelist = []
        self.randstone = {}
    def _get_filelist(self, list_file):
        file_list = []
        read_head = False
        root_path = os.path.dirname(os.path.dirname(os.path.abspath(list_file)))
        with open(list_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                if not read_head:
                    assert line[0] == 'FileList'
                    read_head = True
                else:
                    file_list.append(os.path.join(root_path, line[0]))
        return file_list

    def _str2int(self, buff):
        if isinstance(buff, basestring):
            try:
                return int(buff)
            except ValueError:
                pass
        return 0
    
    def _str2float(self, buff):
        if isinstance(buff, basestring):
            try:
                return float(buff)
            except ValueError:
                pass
        return 0
    
    def _get_item_config(self, item_files):
        item_cfg = {}
        for item_file in item_files:
            line_index = 0
            with open(item_file, 'r') as csvfile:
                reader = csv.reader(csvfile)
                for line in reader:
                    line_index += 1
                    if line_index == 1:
                        if 'MinTradePrice' not in line:
#                             print "MinTradePrice no find in item_file(%s)" % item_file
                            continue
                        index_g = line.index('G')
                        index_d = line.index('D')
                        index_p = line.index('P')
                        index_l = line.index('L')
                        index_min_price = line.index('MinTradePrice')
                        index_max_price = line.index('MaxTradePrice')
                        index_score = line.index("Score") if "Score" in line else -1  # 只有装备才有Score字段
                    elif line_index == 2:
                        continue
                    else:
                        item_cfg[(
                            self._str2int(line[index_g]),
                            self._str2int(line[index_d]),
                            self._str2int(line[index_p]),
                            self._str2int(line[index_l]))
                        ] = (
                            self._str2int(line[index_min_price]),
                            self._str2int(line[index_max_price]),
                            None if index_score == -1 else self._str2int(line[index_score]),)
        return item_cfg
    
    def _get_face_bone_opdef(self, item_file):
        item_cfg = {}
        header_count = 2
        line_index = 0
        with open(item_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                line_index += 1
                if line_index == 1:
                    index_opid = line.index('OpId')
                    index_minvalue1 = line.index('MinValue1')
                    index_maxvalue1 = line.index('MaxValue1')
                elif line_index == header_count:
                    continue
                else:
                    item_cfg[
                        self._str2int(line[index_opid])
                    ] = (
                        self._str2float(line[index_minvalue1]),
                        self._str2float(line[index_maxvalue1]))
        return item_cfg
    
    def _get_face_look_opdef(self, def_file, option_file):
        item_cfg = {}
        header_count = 2
        line_index = 0
        with open(def_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                line_index += 1
                if line_index == 1:
                    index_opid = line.index('OpId')
                elif line_index == header_count:
                    continue
                else:
                    item_cfg[
                        self._str2int(line[index_opid])
                    ] = []
        line_index = 0
        with open(option_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                line_index += 1
                if line_index == 1:
                    index_opid = line.index('OpId')
                    index_id = line.index('ID')
                elif line_index == header_count:
                    continue
                else:
                    opid = self._str2int(line[index_opid])
                    if opid in item_cfg:
                        item_cfg[opid].append(self._str2int(line[index_id]))
        return item_cfg
    
    def get_stone_config(self):
        if not self.stone:
            file_list = self._get_filelist(self.STONE)
            self.stone = self._get_item_config(file_list)
        return self.stone

    def get_book_config(self):
        if not self.book:
            file_list = self._get_filelist(self.BOOK)
            self.book = self._get_item_config(file_list)
        return self.book
    
    def get_consume_config(self):
        if not self.consume:
            file_list = self._get_filelist(self.CONSUME)
            self.consume = self._get_item_config(file_list)
        return self.consume

    def get_face_bone_config(self):
        if not self.facebone:
            self.facebone = self._get_face_bone_opdef(self.FACEBONE)
        return self.facebone

    def get_face_look_config(self):
        if not self.facelook:
            self.facelook = self._get_face_look_opdef(self.FACELOOK, self.FACELOOK_OPTION)
        return self.facelook

    def get_xuan_jade_config(self):
        if not self.randstone:
            file_list = self._get_filelist(self.RANDSTONE)
            self.randstone = self._get_item_config(file_list)
        return self.randstone

