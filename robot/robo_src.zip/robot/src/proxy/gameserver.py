#coding:utf8
import hashlib
import hmac
import json
import random
import struct
import uuid

import gevent
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure

from net.ProxyNetConnector import *
from net.ProxyNetProtocol import *
from net.ProtoBuffer.HttpProxyProtocol_pb2 import *
from net.ProtoBuffer.LoginAndClient_pb2 import AccountLoginRsp

from account import accountDict, accountList


class GameServer(object):
    
    def __init__(self, server_cfg):
        self.S2CProtocol = {
                            CMD_VERIFYSESSION_RSP : [JxProxyRspBody, getattr(self, "On_RerifySession")],
                            CMD_REGISTER_RSP : [RegisterRsp, getattr(self, "On_RegisterRsp")],
                            CMD_MSGPUSH_RSP : [JxProxyRspBody, getattr(self, "On_MsgPushRsp")],
                            CMD_REALTIME_REPORT_ONLINENUM_RSP : [JxProxyRspBody, getattr(self, "On_ReportOnlineNumRsp")],
                            CMD_REALTIME_REPORT_LOGIN_RSP : [JxProxyRspBody, getattr(self, "On_ReportLoginRsp")],
                            }
        self.__server_cfg = server_cfg
    
    def Connect(self):
        self.connecter = NetConnecter(self.Connect_handle, self.Close_handle, self.On_protocol_handle, self.Do_protocol_handle)
        self.connecter.connect(self.__server_cfg)
        
    def Connect_handle(self):
        asyncresult_manager.fire(self, "connected", True)
    
    def Close_handle(self):
        print 'Close_handle'
        import traceback
        traceback.print_stack()
    
    def On_protocol_handle(self, header, buffer):
        cmd_id = header.realCmd if hasattr(header, "realCmd") else header.cmd
        
        if cmd_id in self.S2CProtocol:
            protobuf = self.S2CProtocol[cmd_id][0]()
            try:
                if buffer:
                    protobuf.ParseFromString(buffer)
            except Exception, e:
                print e
                print traceback.format_exc()
                return
            if cmd_id in self.S2CProtocol:
                self.S2CProtocol[cmd_id][1](protobuf)
        else:
            logging.debug('cmd_id not in self.S2CProtocol error : %s' % cmd_id)
    
    def Do_protocol_handle(self, nCmdId, protobufReq):
        return NetPack(nCmdId, protobufReq).GetBuff()
################################################################################
    def Send_RerifySession(self, paramType, token=None, uid=None, name=None, deviceId=None):
        request = JxProxyReqBody()
        request.needResponse = 1
        request.data = ''
        request.currTm = int(time.strftime('%Y%m%d%H%M%S',time.localtime(time.time())))
        
        if paramType == "jinshan":
            xg_AppKey = 'f50936b32731485c922c5fba78122296'
            dataDict = {
                        "uid": uid,
                        "extData": "{\"version\":\"4.0.4\"}",
                        "ts": request.currTm,
                        "channelId": "jinshan",
                        "name": name,
                        "xgAppId": "111111534",
#                         "xgAppId": "1024appid",
                        "authToken": token,
                        "planId": "7802",
                        "deviceId": deviceId
                        }
            dataList = []
            for key in  sorted(dataDict.keys()):
                dataList.append("%s=%s" % (key, dataDict[key]))
            data = "&".join(dataList)
            sign = hmac.new(xg_AppKey, data, hashlib.sha1).digest().encode('hex')
            dataDict["sign"] = sign
            data_json = json.dumps(dataDict)
            authInfo_data = data_json.encode('base64').replace("\n", "")
            authDataDict = {
                        'authInfo': authInfo_data,
                         'sign': sign,
                         'ts': request.currTm,
                         'type': 'verify-session',
                         }
            request.data = json.dumps(authDataDict, sort_keys=True).replace("\\", "").replace('"{', "{").replace('}"', "}")
        logging.debug("request.data = %s" % request.data)
        self.connecter.send_protocol(CMD_VERIFYSESSION_REQ, request)
    
    def On_RerifySession(self, respond):
        logging.debug("On_RerifySession respond.data = %s" % respond.data)
        try:
            resDict = json.loads(respond.data)
            if resDict["code"] == "0":
                asyncresult_manager.fire(self, 'RerifySession', True)
            else:
                request_failure.fire(request_type='get', name="RerifySession_err", response_time=0, exception="code = %s" % resDict["code"])
                asyncresult_manager.fire(self, 'RerifySession', False)
        except Exception, e:
            logging.debug(e)
            request_failure.fire(request_type='get', name="RerifySession_err", response_time=0, exception="data = %s" % respond.data)
            asyncresult_manager.fire(self, 'RerifySession', False)
    
    #注册
    def RegisterReq(self):
        request = RegisterReq()
        request.id = random.randint(1, 4294967295)
        request.serviceType = 3
        request.groupId = 3
        logging.debug("RegisterReq id = %s" % request.id)
        self.connecter.send_protocol(CMD_REGISTER_REQ, request)
    
    def On_RegisterRsp(self, respond):
#         logging.debug("On_RegisterRsp respond = %s" % respond)
        if respond.retCode == 0:
            asyncresult_manager.fire(self, 'RegisterReq', True)
        else:
            request_failure.fire(request_type='get', name="RegisterReq_err", response_time=0, exception="retCode = %s; desc = %s" % (respond.retCode, respond.desc))
            asyncresult_manager.fire(self, 'RegisterReq', False)
        
    #Push功能
    def MsgPushReq(self):
        request = JxProxyReqBody()
        request.needResponse = 1
        dataDict = {
                    "msgName" : uuid.uuid4().hex, 
                    "msgType" : "notification",
                    "msgTitle" : "title:%s" % uuid.uuid4().hex[:30],
                    "msgContent": "msg:%s" % uuid.uuid4().hex,
                    "appId": "2092",
                    "afterAction": "app",
                    "uids": "jxsj_ylcs_%s" % uuid.uuid4().hex[:22],#用户uid
                    "sendType": "immediate",
                    "expireTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()+60*35)),#必须晚于当前时间30分钟以上
                    "isTest": "true",
                    "platform": "android",
                    "commitTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())),
                    }
        XgServerKey = "675fdd36ea2c48feb7b3dfae241a251b"
        dataList = []
        for key in  sorted(dataDict.keys()):
            dataList.append("%s=%s" % (key, dataDict[key]))
        base_string = "&".join(dataList)+XgServerKey
        dataSHA1 = hmac.new(XgServerKey, base_string, hashlib.sha1).digest().encode('hex')
        dataDict["sign"] = dataSHA1.encode('base64').replace("\n", "")
        request.data = json.dumps(dataDict)
        self.connecter.send_protocol(CMD_MSGPUSH_REQ, request)
    
    def On_MsgPushRsp(self, respond):
        logging.debug("On_MsgPushRsp respond = %s" % respond)
        if respond.retCode == 0:
            try:
                ret = json.loads(respond.data)["ret"]
                if ret == "success":
                    asyncresult_manager.fire(self, 'MsgPushReq', True)
                    return
                else:
                    request_failure.fire(request_type='get', name="MsgPushReq_err", response_time=0, exception="ret = %s" % ret)
            except Exception, e:
                request_failure.fire(request_type='get', name="MsgPushReq_err", response_time=0, exception="err = %s; respond = %s" % (e, respond))
        else:
            request_failure.fire(request_type='get', name="MsgPushReq_err", response_time=0, exception="retCode = %s; desc = %s" % (respond.retCode, respond.desc))
        asyncresult_manager.fire(self, 'MsgPushReq', False)
        
    
    #在线人数上报
    def ReportOnlineNumReq(self):
        request = JxProxyReqBody()
        request.needResponse = 1
        dataDict = {
                        "gamename" : uuid.uuid4().hex[:15],
                        "os" : "android",
                        "dbname" : 1,
                        "online_num" : random.randint(1, 50000),
                        "online_time" : time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())),
                    }
        request.data = json.dumps(dataDict)
        request.currTm = int(time.strftime('%Y%m%d%H%M%S',time.localtime(time.time())))
        self.connecter.send_protocol(CMD_REALTIME_REPORT_ONLINENUM_REQ, request)
        
    def On_ReportOnlineNumRsp(self, respond):
        logging.debug("On_ReportOnlineNumRsp respond = %s" % respond)
        if respond.retCode == 0:
            try:
                result = json.loads(respond.data)["result"]
                if result == 1:
                    asyncresult_manager.fire(self, 'ReportOnlineNumReq', True)
                    return
                else:
                    request_failure.fire(request_type='get', name="ReportOnlineNumReq_err", response_time=0, exception="result = %s" % result)
            except Exception, e:
                request_failure.fire(request_type='get', name="ReportOnlineNumReq_err", response_time=0, exception="err = %s; respond = %s" % (e, respond))
        else:
            request_failure.fire(request_type='get', name="ReportOnlineNumReq_err", response_time=0, exception="retCode = %s; desc = %s" % (respond.retCode, respond.desc))
        asyncresult_manager.fire(self, 'ReportOnlineNumReq', False)

    #登陆上报
    def ReportLoginReq(self):
        request = JxProxyReqBody()
        request.needResponse = 1
        dataDict = {
                        "gamename" : uuid.uuid4().hex[:15],
                        "os" : "android",
                        "dbname" : 1,
                        "channelcode" : "1",
                        "accountid" : "1",
                        "equdid" : "1",
                        "stat_time" : time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())),
                        "roleid" : 0,
                        "rolename" : u"压力测试",
                        "mobilemodel" : "1",
                        "idfa" : "idfa"
                    }
        request.data = json.dumps(dataDict)
        request.currTm = int(time.strftime('%Y%m%d%H%M%S',time.localtime(time.time())))
        self.connecter.send_protocol(CMD_REALTIME_REPORT_LOGIN_REQ, request)
    
    def On_ReportLoginRsp(self, respond):
        logging.debug("On_ReportLoginRsp respond = %s" % respond)
        if respond.retCode == 0:
            try:
                result = json.loads(respond.data)["result"]
                if result == 1:
                    asyncresult_manager.fire(self, 'ReportLoginReq', True)
                    return
                else:
                    request_failure.fire(request_type='get', name="ReportLoginReq_err", response_time=0, exception="result = %s" % result)
            except Exception, e:
                request_failure.fire(request_type='get', name="ReportLoginReq_err", response_time=0, exception="err = %s; respond = %s" % (e, respond))
        else:
            request_failure.fire(request_type='get', name="ReportLoginReq_err", response_time=0, exception="retCode = %s; desc = %s" % (respond.retCode, respond.desc))
        asyncresult_manager.fire(self, 'ReportLoginReq', False)
