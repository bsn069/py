# coding:utf-8
import json
import logging
import gevent
import request
from locust.asyncevent import asyncresult_manager
from locust.events import request_success, request_failure

TIMEOUT = 30

class XGServer(object):
    def __init__(self, url):
        self.__url = url
    
    def paynotify(self):
        url = "{url}/paynotify?serverid=100101".format(url=self.__url)
        params = {
                "name" : "test"
                  }
        asyncresult_manager.await(self, "paynotify", TIMEOUT)
        request.post(self.On_paynotify, url, params=params, timeout=TIMEOUT)

    
    def On_paynotify(self, respond):
        httpStatus = str(respond.status_code)
        if httpStatus == "200":
            try:
                resData = json.loads(respond.text)
                logging.debug("resData = %s" % resData)
                if resData["code"] == "1":
                    asyncresult_manager.fire(self, 'paynotify', True)
                    asyncresult_manager.fire(self, 'All', True)
                else:
                    logging.debug("code = %s" % resData["code"])
                    request_failure.fire(request_type='get', name="paynotify_err", response_time=0, exception='code = %s; msg = %s' % (resData["code"], resData["msg"]))
                    asyncresult_manager.fire(self, 'paynotify', False)
                    asyncresult_manager.fire(self, 'All', False)
            except Exception, e:
#                 print "On_paynotify  error  = %s" % e
                request_failure.fire(request_type='get', name="paynotify_err", response_time=0, exception='err = %s; respond = %s;' % (e, respond.text))
                asyncresult_manager.fire(self, 'paynotify', False)
                asyncresult_manager.fire(self, 'All', False)
        else:
            logging.debug("httpStatus = %s" % httpStatus)
            asyncresult_manager.fire(self, 'paynotify', False, error='httpStatus = %s' % httpStatus)
            asyncresult_manager.fire(self, 'All', False)
            