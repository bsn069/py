# coding:utf8
import asyncore
import socket
import urlparse
from httplib import HTTPResponse, HTTPConnection
from StringIO import StringIO
import gevent
import time
import Cookie
from BaseHTTPServer import BaseHTTPRequestHandler
import json as JSON
import urllib

HEADERS = {
    'Accept-Encoding': 'identity',
    'Connection': 'close',
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': 'Mozilla/5.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

def get(callback, url, headers={}, params={}, cookies={}, timeout=30):
    http = Http()
    headers = dict(HEADERS, **headers)
    http.request(callback, "GET", url, headers=headers, params=params, cookies=cookies, timeout=timeout)
    gevent.sleep(0.01)

def post(callback, url, headers={}, params={}, cookies={}, json={}, timeout=30):
    http = Http()
    headers = dict(HEADERS, **headers)
    http.request(callback, "POST", url, headers=headers, params=params, cookies=cookies, json=json, timeout=timeout)
    gevent.sleep(0.01)

class FakeSocket:
    def __init__(self, response_str):
        self._file = StringIO(response_str)
    def makefile(self, *args, **kwargs):
        return self._file

class Http(asyncore.dispatcher):
    def __init__(self):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.callback = None
        self.timeout = 30
        self.is_connect = False
        self.is_callback= False
        self.netloc = ""
        self.scheme = None
        self.hostname = None
        self.port = None
        self.path = None
        self.query = ""
        self.params = ""
        self.post_data = ""
        self.send_data = ""
        self.return_data = ""
        self.headers = ""
        self.cookies = ""
        self.start_time = 0
        self.res = None

    def set_header(self, head):
        self.head.update(head)

    def request(self, callback, method, url, headers={}, params={}, cookies={}, json={}, timeout=30):
        self.callback = callback
        self.timeout = timeout
        u = urlparse.urlparse(url)
        headers['Host'] = u.netloc
        self.netloc = u.netloc
        self.scheme = str(u.scheme)
        self.hostname = u.hostname
        self.port = u.port if u.port else 443 if self.scheme == 'https' else 80
        self.path = u.path if u.path else '/'
        self.query = u.query
        urllib.url2pathname(self.query)

        if cookies:
            headers['Cookie'] = '; '.join(['%s=%s' % (key, val) for (key, val) in cookies.items()])
        if method == "GET":
            if params:
                self.query = urllib.urlencode(dict(urlparse.parse_qsl(self.query), **params))
        elif method == "POST":
            if params:
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
                self.post_data = urllib.urlencode(params)
            if json:
                headers['Content-Type'] = 'application/json'
                self.post_data = JSON.dumps(json)
            if self.post_data:
                headers['Content-Length'] = len(self.post_data)

        self.headers = ''.join(['%s: %s\r\n' % (key, val) for (key, val) in headers.items()])
        self.send_data = '%s %s?%s HTTP/1.1\r\n%s\r\n' % (method, self.path, self.query, self.headers)
        if method == 'POST':
            self.send_data += '%s' % self.post_data
        self.connect((self.hostname, self.port))

    def handle_connect(self):
        self.is_connect = True

    def handle_close(self):
        self.close()
        if not self.is_connect:
            return self.callback(ReponseError(0, "Connection aborted."))
        if self.callback and not self.is_callback:
            self.is_callback = True
            self.res = Reponse(self.return_data)
            if self.res.status_code == 302:
                get(self.callback, "%s://%s%s" % (self.scheme, self.netloc, self.res.headers["location"]), cookies=self.res.cookies)
            else:
                self.callback(self.res)

    def handle_read(self):
        data = self.recv(9999)
        self.return_data += data
    
    def handle_write(self):
        if len(self.send_data) > 0:
            # self.initialization()
            send_len = self.send(self.send_data)
            self.start_time = time.time()
            if send_len < len(self.send_data):
                self.send_data = self.send_data[:send_len]
            else:
                self.send_data = ""
        else:
            if time.time() - self.start_time > self.timeout:
                self.close()
                self.callback(ReponseError(0, "Read timed out"))
                
    def handle_error(self):
        self.close()

    def initialization(self):
        self.return_data = ""

class Reponse:
    def __init__(self, data):
        self.status_code = 0
        self.reason = ""
        self.headers = ""
        self.cookies = {}
        self.text = ""

        if len(data):
            source = FakeSocket(data)
            res = HTTPResponse(source)
            res.begin()
            self.text = res.read()
            self.status_code = res.status
            self.reason = res.reason
            self.headers = res.msg.dict
            if "set-cookie" in self.headers.keys():
                list = Cookie.SimpleCookie(self.headers["set-cookie"]).items()
                for val in list:
                    self.cookies[val[0]] = val[1].value
#                 self.cookies = {val[0]: val[1].value for val in Cookie.SimpleCookie(self.headers["set-cookie"]).items()}
                

class ReponseError:
    def __init__(self, status_code=0, reason=""):
        self.status_code = status_code
        self.reason = reason
        self.headers = ""
        self.cookies = {}
        self.text = ""

if __name__ == '__main__':
    def b(res):
        print res
    def a(res):
        print res
        get(b, u"http://localhost:2800/api/notes/1?e=fg", cookies={'a': 'b'})
    post(a, u"http://10.20.78.238:8002/login", params={"username": "test1", "password": "TiIeRcF4"}, timeout=30)
    asyncore.loop()
